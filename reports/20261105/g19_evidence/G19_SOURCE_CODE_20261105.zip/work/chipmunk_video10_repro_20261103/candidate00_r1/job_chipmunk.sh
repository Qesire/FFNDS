#!/bin/bash
set -euo pipefail
export OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4
exec /public/home/scc/pb23061276/miniconda3/envs/hif4/bin/python3.11 runner_chipmunk.py --scope "$1" --scope-sha "$2" --run-id "$3" --output "$4"
