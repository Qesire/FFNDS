"""Candidate pre-load source/model contract, based on independently reviewed native runner."""
import re
from pathlib import Path

BASE_ASSETS={'Wan2.1_VAE.pth','models_t5_umt5-xxl-enc-bf16.pth','configuration.json','high_noise_model/config.json','low_noise_model/config.json','google/umt5-xxl/tokenizer.json','google/umt5-xxl/tokenizer_config.json','google/umt5-xxl/special_tokens_map.json','google/umt5-xxl/spiece.model'}


def validate_pair_scopes(dense_scope,candidate_scope):
    keys=('base_model_dir','checkpoints','required_runtime_config','runtime_versions','python_executable','python_import_paths','python_source_roots','external_sources_sha256')
    for key in keys:
        if key not in dense_scope or key not in candidate_scope or dense_scope[key]!=candidate_scope[key]:raise RuntimeError('paired generation scope mismatch: '+key)


def validate_assets(scope,sha):
    base=Path(scope['base_model_dir']).resolve();assets=scope.get('base_assets_sha256',{})
    if set(assets)!=BASE_ASSETS:raise RuntimeError('base asset inventory incomplete or unexpected')
    identities={}
    for relative,spec in assets.items():
        path=(base/relative).resolve()
        if not path.is_relative_to(base) or not path.is_file() or path.stat().st_size!=spec['size']:raise RuntimeError('base asset path/size mismatch '+relative)
        expected=spec.get('sha256')
        if not isinstance(expected,str) or not re.fullmatch('[0-9a-f]{64}',expected):raise RuntimeError('base asset needs frozen SHA')
        digest=sha(path)
        if digest!=expected:raise RuntimeError('base asset SHA mismatch '+relative)
        identities[relative]={'size':spec['size'],'sha256':digest}
    return identities


def validate_effective_config(config,scope,find_model_path):
    base=Path(scope['base_model_dir']).resolve()
    for name in ('config.json','vae/config.json'):
        if (base/name).exists():raise RuntimeError('undeclared priority configuration exists: '+name)
    for key,expected in scope['required_runtime_config'].items():
        if config.get(key)!=expected:raise RuntimeError('preload config mismatch: '+key)
    if Path(config.get('model_path','')).resolve()!=base:raise RuntimeError('model path differs')
    for model in ('high','low'):
        val=config.get(model+'_noise_original_ckpt')
        if not val or Path(val).resolve()!=Path(scope['checkpoints'][model]['path']).resolve():raise RuntimeError('checkpoint path mismatch '+model)
    for key in ('dit_original_ckpt','adapter_model_path','dit_quantized_ckpt','high_noise_quantized_ckpt','low_noise_quantized_ckpt','t5_quantized_ckpt','clip_quantized_ckpt','lora_configs','lora_path','config_json'):
        if config.get(key) not in (None,False,'',[]):raise RuntimeError('forbidden alternate model path: '+key)
    for key in ('dit_quantized','t5_quantized','clip_quantized','use_lightvae','dummy_model','lazy_load','unload_modules','compile','use_compile','seq_parallel','parallel','mxfp8_fuse_enable','video_frame_interpolation','video_super_resolution','use_image_encoder'):
        if config.get(key) not in (None,False,''):raise RuntimeError('forbidden model mode: '+key)
    if config.get('quant_method') not in (None,''):raise RuntimeError('quant_method forbidden')
    if config.get('feature_caching') not in (None,'NoCaching'):raise RuntimeError('feature cache forbidden')
    for key,filename in (('t5_original_ckpt','models_t5_umt5-xxl-enc-bf16.pth'),('vae_path','Wan2.1_VAE.pth')):
        if Path(find_model_path(config,key,filename)).resolve()!=(base/filename).resolve():raise RuntimeError('actual asset selection mismatch: '+key)
    if config.get('vae_name') not in (None,'Wan2.1_VAE.pth'):raise RuntimeError('alternate VAE name forbidden')
    return config


def validate_allocation(scope,alloc):
    record=dict(re.findall(r'(\w+)=([^\s]+)',alloc['scheduler_job_record']))
    if alloc['memory_mib']>scope['budget']['host_memory_gib']*1024 or int(record['NumCPUs'])>scope['budget']['cpus']:raise RuntimeError('allocation exceeds reviewed budget')
    lim=re.fullmatch(r'(?:(\d+)-)?(\d+):(\d+):(\d+)',record.get('TimeLimit',''))
    if not lim:raise RuntimeError('unparseable Slurm wall limit')
    days,hours,minutes,seconds=(int(x or 0) for x in lim.groups())
    if days*86400+hours*3600+minutes*60+seconds>scope['budget']['wall_seconds']:raise RuntimeError('wall limit exceeds scope')
