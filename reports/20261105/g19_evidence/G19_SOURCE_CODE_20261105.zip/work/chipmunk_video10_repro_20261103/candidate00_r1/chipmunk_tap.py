"""Draft BF16 P64 old-H/old-Y selected-delta transplant for Wan2.2.
Imports no model code; caller must first verify Slurm scope and runtime identity.
This is packed dense GEMM on selected columns, not the author's CUDA sparse kernel.
"""
import hashlib,math,struct,threading,time

_LOCK=threading.Lock()


def ensure_finite(torch,value,label):
    if not torch.isfinite(value).all().item():raise RuntimeError('nonfinite '+label)


def require_transition(seen,cache,expert,step,layer):
    if step not in range(4) or layer not in range(40) or expert!=(0 if step<2 else 1) or (step,layer) in seen or (step,layer)!=(len(seen)//40,len(seen)%40):raise RuntimeError('expert/step/layer invalid')
    key=(expert,layer)
    if step%2 and key not in cache:raise RuntimeError('missing same-expert previous cache')
    if not step%2 and key in cache:raise RuntimeError('duplicate cache')
    return key


def validate_mask(indices,hidden=13824,selected=5120):
    if len(indices)!=selected or any(type(i)!=int or i<0 or i>=hidden for i in indices) or any(a>=b for a,b in zip(indices,indices[1:])):raise RuntimeError('invalid selected channel mask')


def validate_events(events,full_select_rtol):
    if len(events)!=160:raise RuntimeError('missing FFN events')
    per_layer=31668*(13824+5120)*2
    for index,e in enumerate(events):
        step,layer=divmod(index,40);expert=0 if step<2 else 1;odd=step%2
        if (e['step'],e['layer'],e['expert'])!=(step,layer,expert) or e['mode']!=('selected_delta' if odd else 'dense_cache'):raise RuntimeError('event identity/order mismatch')
        if e['full_W1_calls']!=(0 if odd else 1) or e['full_W2_calls']!=(0 if odd else 1) or e['proxy_W1_calls']!=(1 if odd else 0) or e['selected_W1_calls']!=(1 if odd else 0) or e['selected_W2_calls']!=(1 if odd else 0):raise RuntimeError('physical call counts mismatch')
        if not math.isfinite(e['synchronized_instrumented_wall_seconds']) or e['synchronized_instrumented_wall_seconds']<0 or any(not math.isfinite(s['cuda_ms']) or s['cuda_ms']<0 or not math.isfinite(s['synchronized_wall_seconds']) or s['synchronized_wall_seconds']<0 for s in e['stages']):raise RuntimeError('invalid stage timings')
        expected_cache=(39-layer if odd else layer+1)*per_layer
        if e['cache_live_bytes']!=expected_cache:raise RuntimeError('same-expert cache accounting mismatch')
        if odd:
            ids=e['mask_indices'];validate_mask(ids)
            if e['proxy_rows']!=64 or e['selected_neurons']!=5120 or hashlib.sha256(struct.pack('<5120q',*ids)).hexdigest()!=e['mask_sha256']:raise RuntimeError('mask identity mismatch')
        elif e['mask_indices'] is not None or e['mask_sha256'] is not None:raise RuntimeError('unexpected dense mask')
        check=e['full_select_check']
        if odd and layer==0:
            if not isinstance(check,dict) or not check['zero_delta_byte_equal'] or not math.isfinite(check['relative_l2']) or check['relative_l2']>full_select_rtol or check['rows']!=64 or check['full_hidden']!=13824:raise RuntimeError('full selection audit failed')
        elif check is not None:raise RuntimeError('unexpected full selection audit')
    return True


class ChipmunkTap:
    def __init__(self,torch,emit,full_select_rtol,seed=42,rows=64,selected=5120):
        self.torch=torch;self.emit=emit;self.seed=seed;self.nrows=rows;self.selected=selected
        self.cache={};self.seen=set();self.expert=None;self.owner=None;self.grid=None;self.mask_rows=None
        if rows!=64 or selected!=5120 or seed!=42 or not 0<full_select_rtol<1:raise ValueError('scope demands P64/K5120 and frozen full-select tolerance')
        self.full_select_rtol=full_select_rtol
    def dispatch(self,index):
        if index not in (0,1):raise ValueError('unknown expert')
        self.expert=index
    def install(self,owner):
        if self.owner is not None:raise RuntimeError('duplicate installation')
        tap=self;oldblock=owner.infer_block;oldffn=owner.infer_ffn
        def block(self,block,x,pre):
            if tap.grid is not None:raise RuntimeError('nested block')
            grid=getattr(getattr(pre,'grid_sizes',None),'tuple',None)
            if grid is None:raise RuntimeError('grid absent')
            tap.grid=tuple(int(v) for v in grid)
            try:return oldblock(self,block,x,pre)
            finally:tap.grid=None
        def ffn(self,phase,x,attn_out,c_shift_msa,c_scale_msa,c_gate_msa=None):
            t=tap.torch;import torch.nn.functional as F
            step=int(self.scheduler.step_index);layer=int(self.block_idx);expert=tap.expert
            key=require_transition(tap.seen,tap.cache,expert,step,layer)
            if tap.grid!=(21,29,52) or c_gate_msa is None or self._use_mxfp8_quant_fuse() or hasattr(phase,'smooth_norm2_weight'):raise RuntimeError('grid/gate/FFN numeric path mismatch')
            ensure_finite(t,c_gate_msa,'gate')
            manager=getattr(self,'offload_manager',None)
            if manager is None or getattr(self,'lazy_load',True) or getattr(manager,'lazy_load',True) or len(manager.cuda_buffers)!=2 or phase is not manager.cuda_buffers[0].compute_phases[2] or t.cuda.current_stream()!=manager.compute_stream:raise RuntimeError('active FFN offload phase/stream mismatch')
            mm1,mm2=phase.ffn_0,phase.ffn_2
            for mm in (mm1,mm2):
                if type(mm).__name__!='MMWeight' or type(mm).__module__!='lightx2v.common.ops.mm.mm_weight' or getattr(mm,'has_lora_branch',False) or getattr(mm,'has_diff',False):raise RuntimeError('unsupported W1/W2 backend')
            w1,w2=mm1.weight,mm2.weight;b1,b2=mm1.bias,mm2.bias
            if tuple(w1.shape)!=(5120,13824) or tuple(w2.shape)!=(13824,5120) or tuple(b1.shape)!=(13824,) or tuple(b2.shape)!=(5120,) or any(v.dtype!=t.bfloat16 or v.device.type!='cuda' for v in (w1,w2,b1,b2)):raise RuntimeError('weight geometry/precision mismatch')
            for mm in (mm1,mm2):
                if not hasattr(mm,'weight_cuda_buffer') or mm.weight_cuda_buffer is None or mm.weight.data_ptr()!=mm.weight_cuda_buffer.data_ptr():raise RuntimeError('weight is not active owned prefetch buffer')
            old1=mm1.apply;old2=mm2.apply;oldgelu=F.gelu;pending={};counts={'W1':0,'W2':0}
            def timed(label,fn):
                t.cuda.synchronize();begin=t.cuda.Event(enable_timing=True);end=t.cuda.Event(enable_timing=True)
                wall=time.monotonic();begin.record();value=fn();end.record();t.cuda.synchronize()
                pending.setdefault('stages',[]).append({'stage':label,'cuda_ms':begin.elapsed_time(end),'synchronized_wall_seconds':time.monotonic()-wall})
                return value
            def app1(z):
                counts['W1']+=1
                if counts['W1']!=1 or z.ndim!=2 or tuple(z.shape)!=(31668,5120) or z.dtype!=t.bfloat16:raise RuntimeError('unexpected W1 input')
                ensure_finite(t,z,'W1 input')
                if not step%2:return old1(z)
                oldh,oldy=tap.cache[key]
                ensure_finite(t,oldh,'cached H');ensure_finite(t,oldy,'cached Y')
                if tap.mask_rows is None:
                    tap.mask_rows=t.randperm(z.shape[0],generator=t.Generator(device='cpu').manual_seed(tap.seed))[:tap.nrows].to(z.device)
                x64=z.index_select(0,tap.mask_rows)
                densew1,densew2=timed('materialize_weights',lambda:(w1.T.contiguous(),w2.T.contiguous()))
                if step in (1,3) and layer==0:
                    def full_select_check():
                        current=oldgelu(old1(x64),approximate='tanh');h0=oldh.index_select(0,tap.mask_rows);y0=oldy.index_select(0,tap.mask_rows)
                        delta=(current.float()-h0.float()).to(t.bfloat16);yfull=(y0.float()+t.mm(delta,densew2.T,out_dtype=t.float32)).to(t.bfloat16)
                        direct=old2(current);difference=yfull.float()-direct.float();den=direct.float().square().sum();num=difference.square().sum()
                        rel=float((num/den).sqrt()) if float(den)>0 else (0. if float(num)==0 else float('inf'))
                        zero_delta=t.zeros_like(delta);zero_result=(y0.float()+t.mm(zero_delta,densew2.T,out_dtype=t.float32)).to(t.bfloat16)
                        return {'relative_l2':rel,'max_abs':float(difference.abs().max()),'zero_delta_byte_equal':bool(t.equal(y0.contiguous().view(t.uint8),zero_result.contiguous().view(t.uint8))),'rows':tap.nrows,'full_hidden':13824,'observer_native_W1_calls':1,'observer_native_W2_calls':1,'observer_full_delta_W2_calls':2}
                    check=timed('observer_full_selection_check',full_select_check);pending['full_select_check']=check
                    if not check['zero_delta_byte_equal'] or not check['relative_l2']<=tap.full_select_rtol:raise RuntimeError('full-select or zero-delta numerical check failed')
                score=timed('proxy_w1_gelu_rms',lambda:(oldgelu(t.nn.functional.linear(x64,densew1,b1),approximate='tanh').float()-oldh.index_select(0,tap.mask_rows).float()).square().mean(0).sqrt())
                ensure_finite(t,score,'proxy score')
                idx=timed('stable_topk',lambda:t.sort(t.argsort(score,descending=True,stable=True)[:tap.selected]).values)
                import hashlib
                index_cpu=idx.cpu().numpy();indices=index_cpu.tolist();validate_mask(indices);index_digest=hashlib.sha256(index_cpu.tobytes()).hexdigest()
                pw1,pb,pw2=timed('gather_pack',lambda:(densew1.index_select(0,idx),b1.index_select(0,idx),densew2.index_select(1,idx).contiguous()))
                hc,yc=timed('clone_caches',lambda:(oldh.clone(),oldy.clone()));old_selected=hc.index_select(1,idx)
                new=timed('selected_w1_gelu',lambda:oldgelu(t.nn.functional.linear(z,pw1,pb),approximate='tanh'))
                ensure_finite(t,new,'selected H')
                def delta_stage():
                    delta=(new.float()-old_selected.float()).to(t.bfloat16);hc.index_copy_(1,idx,new);return delta
                delta=timed('delta_and_h_update',delta_stage)
                ensure_finite(t,delta,'selected delta')
                correction=timed('selected_w2_fp32',lambda:t.mm(delta,pw2.T,out_dtype=t.float32))
                ensure_finite(t,correction,'W2 correction')
                pending['y']=timed('accumulate_y',lambda:(yc.float()+correction).to(t.bfloat16))
                ensure_finite(t,pending['y'],'candidate pre-gate Y')
                pending['sentinel']=t.empty((1,1),device=z.device,dtype=z.dtype).expand(z.shape[0],13824)
                pending['mask_sha256']=index_digest
                pending['mask_indices']=indices
                return pending['sentinel']
            def gelu(v,*args,**kwargs):
                if v is pending.get('sentinel'):
                    if kwargs.get('approximate')!='tanh':raise RuntimeError('unexpected activation')
                    return v
                return oldgelu(v,*args,**kwargs)
            def app2(h):
                counts['W2']+=1
                if counts['W2']!=1:raise RuntimeError('multiple W2')
                if step%2:
                    if h is not pending.get('sentinel') or 'y' not in pending:raise RuntimeError('candidate transaction failed')
                    y=pending['y'];del tap.cache[key];return y
                if h.shape!=(31668,13824) or h.dtype!=t.bfloat16:raise RuntimeError('cache H mismatch')
                ensure_finite(t,h,'dense H')
                y=old2(h)
                if y.shape!=(31668,5120) or y.dtype!=t.bfloat16:raise RuntimeError('cache Y mismatch')
                ensure_finite(t,y,'dense pre-gate Y')
                tap.cache[key]=timed('build_h_y_cache',lambda:(h.detach().clone(),y.detach().clone()));return y
            if not _LOCK.acquire(blocking=False):raise RuntimeError('concurrent FFN transaction')
            start=time.monotonic();mm1.apply=app1;mm2.apply=app2
            if step%2:F.gelu=gelu
            try:out=oldffn(self,phase,x,attn_out,c_shift_msa,c_scale_msa,c_gate_msa)
            finally:mm1.apply=old1;mm2.apply=old2;F.gelu=oldgelu;_LOCK.release()
            if counts!={'W1':1,'W2':1}:raise RuntimeError('FFN dispatch count mismatch')
            ensure_finite(t,out,'FFN output')
            t.cuda.synchronize()
            if step%2 and layer==39:
                if tap.cache:raise RuntimeError('cache not fully released at expert boundary')
                timed('expert_boundary_empty_cache',lambda:t.cuda.empty_cache())
            cache_bytes=sum(h.numel()*h.element_size()+y.numel()*y.element_size() for h,y in tap.cache.values())
            tap.seen.add((step,layer));tap.emit({'expert':expert,'step':step,'layer':layer,'mode':'selected_delta' if step%2 else 'dense_cache','synchronized_instrumented_wall_seconds':time.monotonic()-start,'stages':pending.get('stages',[]),'cache_live_bytes':cache_bytes,'cached_neurons':13824,'selected_neurons':5120 if step%2 else None,'proxy_rows':64 if step%2 else None,'mask_sha256':pending.get('mask_sha256'),'mask_indices':pending.get('mask_indices'),'full_select_check':pending.get('full_select_check'),'full_W1_calls':0 if step%2 else 1,'full_W2_calls':0 if step%2 else 1,'proxy_W1_calls':1 if step%2 else 0,'selected_W1_calls':1 if step%2 else 0,'selected_W2_calls':1 if step%2 else 0})
            return out
        owner.infer_block=block;owner.infer_ffn=ffn;self.owner=owner;self.original=(oldblock,oldffn)
    def finish(self):
        if self.cache or self.seen!={(s,i) for s in range(4) for i in range(40)}:raise RuntimeError('incomplete 160-site state or cache leak')
    def uninstall(self):
        if self.owner is not None:self.owner.infer_block,self.owner.infer_ffn=self.original;self.owner=None
