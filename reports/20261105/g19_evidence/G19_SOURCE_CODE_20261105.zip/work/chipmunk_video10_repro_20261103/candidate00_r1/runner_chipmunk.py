"""Per-source candidate video draft; no launch authority.
Requires an exact reviewed Slurm scope and registered matched Dense receipt.
"""
import argparse,hashlib,importlib,json,os,re,subprocess,sys,time
from pathlib import Path


def file_sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for data in iter(lambda:f.read(1024*1024),b''):h.update(data)
    return h.hexdigest()


def load_bound(root,scope,name):
    if name not in scope.get('frozen_inputs_sha256',{}):raise RuntimeError('unbound input')
    path=(root/name).resolve()
    if not path.is_relative_to(root) or file_sha(path)!=scope['frozen_inputs_sha256'][name]:raise RuntimeError('input identity mismatch')
    return json.loads(path.read_text(encoding='utf8'))


def validate_cohort(rows):
    if not isinstance(rows,list) or len(rows)!=10 or len({r['run_id'] for r in rows})!=10 or len({r['image_cluster'] for r in rows})!=10 or len({r['image_sha256'] for r in rows})!=10:raise ValueError('exact 10 genuinely distinct sources required')
    if {k:sum(r['planned_role']==k for r in rows) for k in ('DEVELOPMENT','CALIBRATION','HELDOUT')}!={'DEVELOPMENT':2,'CALIBRATION':4,'HELDOUT':4}:raise ValueError('cohort roles differ')
    for row in rows:
        if not re.fullmatch('[a-zA-Z0-9_-]{1,96}',row['run_id']) or row.get('exposure_status')!='UNVERIFIED' or row['seed']!=42 or hashlib.sha256(row['prompt'].encode()).hexdigest()!=row['prompt_sha256']:raise ValueError('bad source identity')


def video_digest(path):
    import imageio_ffmpeg
    reader=imageio_ffmpeg.read_frames(str(path),pix_fmt='rgb24');meta=next(reader);w,h=meta['size'];fps=meta.get('fps');digest=hashlib.sha256();count=0
    try:
        if (w,h)!=(832,464) or fps is None or abs(float(fps)-16.)>.01:raise RuntimeError('video geometry/fps mismatch')
        for frame in reader:
            if len(frame)!=w*h*3:raise RuntimeError('decoded frame geometry mismatch')
            digest.update(frame);count+=1
    finally:reader.close()
    if count!=81:raise RuntimeError('video does not contain exactly 81 decoded frames')
    return {'frames':81,'width':w,'height':h,'fps':float(fps),'decoded_rgb24_sha256':digest.hexdigest(),'mp4_sha256':file_sha(path)}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--scope',required=True);ap.add_argument('--scope-sha',required=True);ap.add_argument('--run-id',required=True);ap.add_argument('--output',required=True);args=ap.parse_args()
    from runtime_guard import require_compute_allocation,verify_frozen_scope,RunReceipt
    allocation=require_compute_allocation();root=Path(__file__).resolve().parent;scope=verify_frozen_scope(root,args.scope,args.scope_sha)
    if scope['phase']!='CHIPMUNK_VIDEO10_CANDIDATE':raise RuntimeError('wrong phase')
    if not Path(args.output).is_absolute() or Path(args.output).resolve()!=Path(scope['output_dir']).resolve():raise RuntimeError('output scope mismatch')
    if Path(sys.executable).resolve()!=Path(scope['python_executable']).resolve():raise RuntimeError('Python executable mismatch')
    from runtime_contract import validate_assets,validate_effective_config,validate_allocation,validate_pair_scopes
    validate_allocation(scope,allocation)
    with RunReceipt(args.output,scope,allocation) as receipt:
        receipt.result={'status':'PARTIAL','source_id':args.run_id}
        rows=load_bound(root,scope,scope['cohort_file']);dense=load_bound(root,scope,scope['dense_reference_file']);validate_cohort(rows)
        if args.run_id not in scope['run_ids'] or len(scope['run_ids'])!=1:raise RuntimeError('source not authorized')
        row=next(x for x in rows if x['run_id']==args.run_id);baseline=dense[args.run_id]
        if any(baseline[k]!=row[k] for k in ('image_sha256','prompt_sha256','seed')) or not re.fullmatch('[0-9a-f]{64}',baseline['initial_latent_sha256']):raise RuntimeError('paired Dense identity mismatch')
        if baseline['recipe_sha256']!=scope['recipe_sha256'] or baseline['checkpoint_sha256']!={k:scope['checkpoints'][k]['sha256'] for k in ('high','low')}:raise RuntimeError('paired Dense recipe or checkpoint mismatch')
        if baseline['base_assets_sha256']!={k:v['sha256'] for k,v in scope['base_assets_sha256'].items()}:raise RuntimeError('paired Dense base asset mismatch')
        if file_sha(baseline['start_receipt_path'])!=baseline['start_receipt_sha256'] or file_sha(baseline['asset_identities_path'])!=baseline['asset_identities_sha256'] or file_sha(baseline['environment_path'])!=baseline['environment_sha256']:raise RuntimeError('Dense start/assets/environment receipt mismatch')
        dense_start=json.loads(Path(baseline['start_receipt_path']).read_text(encoding='utf8'))
        if dense_start.get('scope',{}).get('_verified_scope_sha256')!=baseline['scope_sha256']:raise RuntimeError('Dense scope identity mismatch')
        validate_pair_scopes(dense_start['scope'],scope)
        dense_assets=json.loads(Path(baseline['asset_identities_path']).read_text(encoding='utf8'))
        if {k:v['sha256'] for k,v in dense_assets.items()}!=baseline['base_assets_sha256']:raise RuntimeError('Dense actual base assets mismatch')
        dense_env=json.loads(Path(baseline['environment_path']).read_text(encoding='utf8'))
        if dense_env['ffmpeg_sha256']!=scope['ffmpeg_sha256'] or dense_env['tf32_matmul'] is not False or dense_env['tf32_cudnn'] is not False or dense_env['bf16_reduced_precision_reduction'] is not True:raise RuntimeError('Dense runtime precision mismatch')
        if file_sha(baseline['video_path'])!=baseline['video_sha256'] or file_sha(baseline['exit_receipt_path'])!=baseline['exit_receipt_sha256']:raise RuntimeError('paired Dense artifact identity mismatch')
        dense_exit=json.loads(Path(baseline['exit_receipt_path']).read_text(encoding='utf8'))
        if dense_exit.get('status')!='SUCCESS' or dense_exit.get('result',{}).get('source_id')!=args.run_id or dense_exit.get('result',{}).get('status')!='CAPTURE_COMPLETE_NEEDS_INDEPENDENT_ASSET_REVIEW' or dense_exit['result'].get('capture_sites')!=160:raise RuntimeError('Dense capture is incomplete')
        prior=[v for v in dense_exit['result'].get('videos',[]) if v.get('arm')=='tap']
        if len(prior)!=1 or prior[0]['mp4_sha256']!=baseline['video_sha256'] or prior[0]['initial_noise']!={'sha256':baseline['initial_latent_sha256'],'shape':baseline['initial_latent_shape'],'dtype':baseline['initial_latent_dtype']}:raise RuntimeError('Dense receipt/video/noise mismatch')
        if file_sha(row['image_path'])!=row['image_sha256']:raise RuntimeError('source image changed')
        asset_identities=validate_assets(scope,file_sha)
        (receipt.path/'ASSET_IDENTITIES.json').write_text(json.dumps(asset_identities,indent=2,sort_keys=True),encoding='utf8')
        for name in ('high','low'):
            if file_sha(scope['checkpoints'][name]['path'])!=scope['checkpoints'][name]['sha256']:raise RuntimeError('checkpoint mismatch '+name)
        expected=scope['external_sources_sha256'];normalized={str(Path(p).resolve()):v for p,v in expected.items()}
        if len(normalized)!=len(expected):raise RuntimeError('duplicate resolved source paths')
        for tree in scope['python_source_roots']:
            actual={str(p.resolve()) for p in Path(tree).rglob('*.py') if p.is_file()}
            want={p for p in normalized if Path(p).is_relative_to(Path(tree).resolve()) and p.endswith('.py')}
            if not actual or actual!=want:raise RuntimeError('source inventory mismatch')
        for path,digest in normalized.items():
            if file_sha(path)!=digest:raise RuntimeError('source hash mismatch')
        receipt.check_deadline()
        if any(name in sys.modules for name in ('lightx2v','HiFloat4','prox_capture_runtime')) or os.environ.get('PROX_PATCH_ENABLE')=='1':raise RuntimeError('unexpected prior model patch')
        for path in reversed(scope['python_import_paths']):sys.path.insert(0,path)
        import torch
        if not torch.cuda.is_available() or torch.cuda.device_count()!=1 or torch.cuda.get_device_name(0)!='NVIDIA A100-SXM4-80GB' or torch.cuda.get_device_capability(0)!=(8,0) or torch.cuda.get_device_properties(0).total_memory<80_000_000_000:raise RuntimeError('single A100 80GB required')
        import imageio_ffmpeg,numpy as np
        if torch.__version__!=scope['runtime_versions']['torch'] or np.__version__!=scope['runtime_versions']['numpy'] or imageio_ffmpeg.__version__!=scope['runtime_versions']['imageio_ffmpeg']:raise RuntimeError('runtime version mismatch')
        ffmpeg_path=imageio_ffmpeg.get_ffmpeg_exe()
        if file_sha(ffmpeg_path)!=scope['ffmpeg_sha256']:raise RuntimeError('ffmpeg binary mismatch')
        gpu_limit=scope['budget']['gpu_memory_gib']*1024**3;total_gpu=torch.cuda.get_device_properties(0).total_memory
        if not 0<gpu_limit<total_gpu:raise RuntimeError('invalid frozen GPU limit')
        torch.cuda.set_per_process_memory_fraction(gpu_limit/total_gpu,0)
        torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False;torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction=True;torch.set_num_threads(scope['budget']['cpus'])
        adapter=importlib.import_module('HiFloat4.ptq.adapters.lightx2v_wan_distill')
        if str(Path(adapter.__file__).resolve()) not in normalized or getattr(adapter,'_PATCHED',False):raise RuntimeError('adapter identity mismatch')
        from lightx2v.utils.utils import find_torch_model_path
        original_builder=adapter.build_effective_lightx2v_pipeline_config
        def checked_builder(pipeline):
            cfg=original_builder(pipeline);validate_effective_config(cfg,scope,find_torch_model_path)
            with (receipt.path/'EFFECTIVE_CONFIG.json').open('x',encoding='utf8') as f:json.dump(dict(cfg),f,indent=2,default=str,ensure_ascii=False)
            return cfg
        adapter.build_effective_lightx2v_pipeline_config=checked_builder
        setup_start=time.monotonic()
        try:pipe=adapter.build_lightx2v_distill_pipeline(base_model_dir=scope['base_model_dir'],high_noise_ckpt=scope['checkpoints']['high']['path'],low_noise_ckpt=scope['checkpoints']['low']['path'])
        finally:adapter.build_effective_lightx2v_pipeline_config=original_builder
        torch.cuda.synchronize();setup_seconds=time.monotonic()-setup_start
        config=pipe.runner.config
        for k,v in scope['required_runtime_config'].items():
            if config.get(k)!=v:raise RuntimeError('runtime config mismatch '+k)
        if config.get('quant_method') not in (None,'') or config.get('seq_parallel') or config.get('parallel') or config.get('mxfp8_fuse_enable',False):raise RuntimeError('dense unfused baseline required')
        (receipt.path/'ENVIRONMENT.json').write_text(json.dumps({'torch':torch.__version__,'numpy':np.__version__,'cuda':torch.version.cuda,'imageio_ffmpeg':imageio_ffmpeg.__version__,'ffmpeg_sha256':scope['ffmpeg_sha256'],'gpu':torch.cuda.get_device_name(0),'tf32_matmul':torch.backends.cuda.matmul.allow_tf32,'tf32_cudnn':torch.backends.cudnn.allow_tf32,'bf16_reduced_precision_reduction':torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction,'runtime_config':{k:config.get(k) for k in scope['required_runtime_config']}},indent=2,default=str),encoding='utf8')
        from chipmunk_tap import ChipmunkTap,validate_events
        from lightx2v.models.networks.wan.infer.transformer_infer import WanTransformerInfer
        from lightx2v.models.runners.wan.wan_distill_runner import MultiDistillModelStruct
        event_file=receipt.path/'ffn_events.jsonl';event_file.touch(exist_ok=False)
        def emit(event):
            receipt.check_deadline()
            if torch.cuda.max_memory_reserved()>gpu_limit:raise MemoryError('GPU memory budget exceeded')
            with event_file.open('a',encoding='utf8') as f:f.write(json.dumps(event,allow_nan=False)+'\n')
        tap=ChipmunkTap(torch,emit,full_select_rtol=scope['full_select_rtol']);tap.install(WanTransformerInfer);old_dispatch=MultiDistillModelStruct.get_current_model_index;initial=[]
        def dispatched(model):
            result=old_dispatch(model);tap.dispatch(int(model.cur_model_index))
            if not initial:
                z=model.scheduler.latents.detach().contiguous()
                if not torch.isfinite(z).all().item():raise RuntimeError('nonfinite initial latent')
                raw=z.view(torch.uint8).cpu().numpy().tobytes()
                info={'sha256':hashlib.sha256(raw).hexdigest(),'shape':list(z.shape),'dtype':str(z.dtype)};initial.append(info)
                if info!={'sha256':baseline['initial_latent_sha256'],'shape':baseline['initial_latent_shape'],'dtype':baseline['initial_latent_dtype']}:raise RuntimeError('paired Dense initial latent mismatch')
            return result
        MultiDistillModelStruct.get_current_model_index=dispatched
        from safetensors.torch import save_file
        scheduler=pipe.runner.scheduler;old_step_post=scheduler.step_post;latent_digests=[];latent_bytes=[0]
        def observed_step_post():
            value=old_step_post();z=scheduler.latents.detach().contiguous()
            if not torch.isfinite(z).all().item():raise RuntimeError('nonfinite scheduler latent')
            if z.dtype not in (torch.float32,torch.bfloat16):raise RuntimeError('unexpected native latent dtype')
            native=z.cpu().contiguous();native_hash=hashlib.sha256(native.view(torch.uint8).numpy().tobytes()).hexdigest();step=int(scheduler.step_index)
            tensors={'native':native}
            if native.dtype!=torch.float32:tensors['fp32_exact_lift']=native.float()
            intended=sum(v.numel()*v.element_size() for v in tensors.values())
            if latent_bytes[0]+intended>scope['latent_capture_budget_bytes']:raise RuntimeError('latent capture byte budget exceeded')
            path=receipt.path/f'latent_step{step}.safetensors'
            if path.exists():raise RuntimeError('duplicate latent step')
            save_file(tensors,str(path));latent_bytes[0]+=path.stat().st_size
            if latent_bytes[0]>scope['latent_capture_budget_bytes']:raise RuntimeError('latent artifact byte budget exceeded')
            latent_digests.append({'step':step,'sha256':native_hash,'shape':list(z.shape),'dtype':str(z.dtype),'artifact_path':str(path),'artifact_bytes':path.stat().st_size,'artifact_sha256':file_sha(path),'fp32_semantics':'native' if native.dtype==torch.float32 else 'exact_bf16_lift'})
            return value
        scheduler.step_post=observed_step_post
        # Match Dense R5: reset scheduler generator before this fresh pass so
        # native preparation constructs it from the frozen source seed.
        if not hasattr(scheduler,'generator'):raise RuntimeError('scheduler generator unavailable')
        scheduler.generator=None
        video=receipt.path/'candidate.mp4';begin=time.monotonic()
        try:
            with torch.inference_mode():pipe.generate(seed=row['seed'],image_path=row['image_path'],prompt=row['prompt'],negative_prompt=row.get('negative_prompt',''),save_result_path=str(video))
            torch.cuda.synchronize();tap.finish()
        finally:
            scheduler.step_post=old_step_post;tap.uninstall();MultiDistillModelStruct.get_current_model_index=old_dispatch
        elapsed=time.monotonic()-begin;receipt.check_deadline();events=[json.loads(x) for x in event_file.read_text(encoding='utf8').splitlines() if x];validate_events(events,scope['full_select_rtol']);decoded=video_digest(video)
        if [x['step'] for x in latent_digests]!=list(range(4)):raise RuntimeError('latent step coverage')
        receipt.result={'status':'CANDIDATE_VIDEO_COMPLETE_NOT_QUALITY_ACCEPTED','source_id':args.run_id,'image_sha256':row['image_sha256'],'prompt_sha256':row['prompt_sha256'],'seed':row['seed'],'initial_latent':initial[0],'latent_digests':latent_digests,'video':decoded,'full_ffn_sites':160,'dense_cache_sites':80,'selected_delta_sites':80,'ffn_event_sha256':file_sha(event_file),'full_select_rtol':scope['full_select_rtol'],'model_setup_wall_seconds':setup_seconds,'candidate_generation_wall_instrumented':elapsed,'gpu_peak_allocated':torch.cuda.max_memory_allocated(),'gpu_peak_reserved':torch.cuda.max_memory_reserved(),'native_cuda_sparse_kernel':'NOT_USED_PACKED_DENSE_GEMMS','quality_status':'NOT_MEASURED','generator_policy':'RESET_NONE_BEFORE_GENERATE_NATIVE_RESEEDS_FROM_SOURCE'}

if __name__=='__main__':main()
