"""One-dimension custom paired I2V evaluator. Requires reviewed Slurm scope.
No replicated sample filenames; -0 symlinks point one-to-one to fresh video files.
"""
import argparse,hashlib,json,os,re,subprocess,sys,time
from pathlib import Path

DIMS=('subject_consistency','background_consistency','motion_smoothness','dynamic_degree','aesthetic_quality','imaging_quality','i2v_subject','i2v_background','camera_motion','temporal_flickering')
CAMERAS=('camera pans left','camera pans right','camera tilts up','camera tilts down','camera zooms in','camera zooms out','camera static')


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()


def validate_dimension(rows,dim):
    if dim not in DIMS or len(rows)!=10 or len({r['run_id'] for r in rows})!=10 or len({r['image_sha256'] for r in rows})!=10:raise ValueError('bad dimension or cohort')
    chosen=[r for r in rows if dim!='camera_motion' or r.get('camera_instruction') in CAMERAS]
    if dim=='camera_motion' and (len(chosen)!=7 or {r['camera_instruction'] for r in chosen}!=set(CAMERAS)):raise ValueError('camera coverage must include seven unique conditions')
    if dim!='camera_motion' and len(chosen)!=10:raise ValueError('incomplete source coverage')
    if len({r['prompt'] for r in chosen})!=len(chosen) or any('/' in r['prompt'] or '\\' in r['prompt'] or len((r['prompt']+'-0.mp4').encode())>255 for r in chosen):raise ValueError('unsafe/colliding prompt filename')
    return chosen


def extract_video_records(obj):
    found=[]
    def visit(value):
        if isinstance(value,dict):
            if 'video_path' in value:found.append(value)
            else:
                for v in value.values():visit(v)
        elif isinstance(value,list):
            for v in value:visit(v)
    visit(obj);return found


def check_video(path,scope):
    # Decode all frames with the exact native bundled ffmpeg, avoiding PATH/ffprobe.
    import tempfile
    exe=Path(scope['ffmpeg_path'])
    if not exe.is_absolute() or sha(exe)!=scope['ffmpeg_sha256']:raise ValueError('ffmpeg binary identity mismatch')
    with tempfile.TemporaryFile() as errors:
        process=subprocess.Popen([str(exe),'-hide_banner','-i',str(path),'-f','rawvideo','-pix_fmt','rgb24','-vsync','0','pipe:1'],stdout=subprocess.PIPE,stderr=errors)
        size=832*464*3;count=0
        try:
            while True:
                chunks=[];remaining=size
                while remaining:
                    data=process.stdout.read(remaining)
                    if not data:break
                    chunks.append(data);remaining-=len(data)
                if remaining==size:break
                if remaining:raise ValueError('incomplete decoded frame')
                count+=1
                if count>81:raise ValueError('too many decoded frames')
            status=process.wait(timeout=60)
        finally:
            if process.poll() is None:process.kill();process.wait()
            process.stdout.close()
        errors.seek(0);metadata=errors.read().decode('utf8',errors='replace')
        streams=[line for line in metadata.splitlines() if 'Stream #' in line and 'Video:' in line and '->' not in line]
        if status or count!=81 or not streams or not any(re.search(r'\b832x464\b',line) and re.search(r'\b16(?:\.0+)? fps\b',line) for line in streams):raise ValueError('video decode, geometry, frame count or fps mismatch')


def bound_json(root,scope,name):
    if name not in scope.get('frozen_inputs_sha256',{}):raise ValueError('unbound manifest')
    p=(root/name).resolve()
    if not p.is_relative_to(root) or sha(p)!=scope['frozen_inputs_sha256'][name]:raise ValueError('manifest identity')
    return json.loads(p.read_text(encoding='utf8'))


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--scope',required=True);ap.add_argument('--scope-sha',required=True);ap.add_argument('--output',required=True);args=ap.parse_args()
    from runtime_guard import require_compute_allocation,verify_frozen_scope,RunReceipt
    allocation=require_compute_allocation();root=Path(__file__).resolve().parent;scope=verify_frozen_scope(root,args.scope,args.scope_sha)
    from runtime_contract import validate_allocation
    validate_allocation(scope,allocation)
    if Path(sys.executable).resolve()!=Path(scope['python_executable']).resolve():raise ValueError('metric Python identity mismatch')
    if scope.get('phase')!='CHIPMUNK_VIDEO10_METRIC':raise ValueError('wrong metric scope')
    if not Path(args.output).is_absolute() or Path(args.output).resolve()!=Path(scope['output_dir']).resolve():raise ValueError('output not bound')
    with RunReceipt(args.output,scope,allocation) as receipt:
      c=bound_json(root,scope,scope['cohort_file']); videos=bound_json(root,scope,scope['video_manifest_file']);dim=scope['dimension']
      eligible=validate_dimension(c,dim); requested=scope['source_ids']
      if not isinstance(requested,list) or not requested or len(set(requested))!=len(requested) or not set(requested).issubset({r['run_id'] for r in eligible}):raise ValueError('invalid or nonapplicable source selection')
      selected=[r for r in eligible if r['run_id'] in requested]
      if set(videos)!=set(requested):raise ValueError('video manifest must match exact reviewed source subset')
      identities=[]
      for row in selected:
       item=videos[row['run_id']]
       if any(item[k]!=row[k] for k in ('image_sha256','prompt_sha256','seed')) or item['dense']['initial_latent_sha256']!=item['candidate']['initial_latent_sha256']:raise ValueError('unpaired source/noise')
       expected_image=(Path(scope['vbench_working_directory'])/'vbench2_beta_i2v/data/crop/16-9'/Path(row['image_path']).name).resolve()
       if Path(row['image_path']).resolve()!=expected_image or sha(row['image_path'])!=row['image_sha256']:raise ValueError('image identity or evaluator-relative path mismatch')
       for key in ('dense','candidate'):
        p=Path(item[key]['path']);st=p.stat()
        if not p.is_absolute() or sha(p)!=item[key]['sha256']:raise ValueError('video SHA mismatch')
        check_video(p,scope)
        if sha(item[key]['exit_receipt_path'])!=item[key]['exit_receipt_sha256']:raise ValueError('generation receipt mismatch')
        proof=json.loads(Path(item[key]['exit_receipt_path']).read_text(encoding='utf8')); data=proof.get('result',{})
        if proof.get('status')!='SUCCESS' or data.get('source_id')!=row['run_id']:raise ValueError('generation receipt not complete')
        if key=='dense':
         matches=[v for v in data.get('videos',[]) if v.get('arm')=='tap']
         if data.get('status')!='CAPTURE_COMPLETE_NEEDS_INDEPENDENT_ASSET_REVIEW' or data.get('capture_sites')!=160 or len(matches)!=1 or matches[0]['mp4_sha256']!=item[key]['sha256'] or matches[0]['initial_noise']['sha256']!=item[key]['initial_latent_sha256']:raise ValueError('dense capture identity mismatch')
        else:
         if data.get('status')!='CANDIDATE_VIDEO_COMPLETE_NOT_QUALITY_ACCEPTED' or data.get('full_ffn_sites')!=160 or data.get('dense_cache_sites')!=80 or data.get('selected_delta_sites')!=80 or data['video']['mp4_sha256']!=item[key]['sha256'] or data['initial_latent']['sha256']!=item[key]['initial_latent_sha256']:raise ValueError('candidate generation identity mismatch')
         event_path=Path(item[key]['event_path'])
         if sha(event_path)!=item[key]['event_sha256'] or data['ffn_event_sha256']!=item[key]['event_sha256']:raise ValueError('candidate event ledger identity mismatch')
         from chipmunk_tap import validate_events
         event_rows=[json.loads(line) for line in event_path.read_text(encoding='utf8').splitlines() if line]
         validate_events(event_rows,data['full_select_rtol'])
        identities.append((st.st_dev,st.st_ino))
      if len(set(identities))!=2*len(selected):raise ValueError('videos must be independent outputs, not aliases')
      from metric_contract import verify_closure
      if Path(scope['vbench_working_directory'])!=Path(scope['metric_project_root']):raise ValueError('VBench working directory must bind model root')
      mapping=verify_closure(dim,scope,sha)
      (receipt.path/'effective_loader.json').write_text(json.dumps({dim:mapping},indent=2),encoding='utf8')
      receipt.check_deadline();stage=receipt.path/'videos';stage.mkdir(); info=[]; lookup={}
      for row in selected:
       for index,arm in enumerate(('dense','candidate')):
        actual=videos[row['run_id']][arm]['path'];name=row['prompt']+f'-{index}.mp4';(stage/name).symlink_to(actual);camera=row.get('camera_instruction');stratum='CAMERA_STATIC_EXPLICIT' if camera=='camera static' else 'CAMERA_DYNAMIC_INSTRUCTION' if camera else 'CAMERA_UNSPECIFIED';lookup[str((stage/name).resolve())]={'source_id':row['run_id'],'arm':arm,'camera_stratum':stratum}
       info.append({'prompt_en':row['prompt'],'image_name':Path(row['image_path']).name,'dimension':[dim]})
      metadata=receipt.path/'full_info.json';metadata.write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf8')
      os.chdir(scope['vbench_working_directory'])
      os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
      import random,numpy as np,torch
      if not torch.cuda.is_available() or torch.cuda.device_count()!=1 or 'A100' not in torch.cuda.get_device_name(0):raise RuntimeError('one A100 GPU required')
      gpu_limit=scope['budget']['gpu_memory_gib']
      gpu_total=torch.cuda.get_device_properties(0).total_memory
      if not 0<gpu_limit<=80 or gpu_limit*1024**3>gpu_total:raise RuntimeError('invalid GPU memory budget')
      torch.cuda.set_per_process_memory_fraction(min(0.95,gpu_limit*1024**3/gpu_total),0)
      torch.cuda.reset_peak_memory_stats()
      metric_seed=scope['metric_seed'];random.seed(metric_seed);np.random.seed(metric_seed);torch.manual_seed(metric_seed);torch.cuda.manual_seed_all(metric_seed)
      torch.set_num_threads(scope['budget']['cpus']);torch.backends.cuda.matmul.allow_tf32=False
      import importlib, importlib.metadata
      if torch.__version__!=scope['runtime_versions']['torch'] or np.__version__!=scope['runtime_versions']['numpy']:raise RuntimeError('metric torch/numpy version mismatch')
      for package,version in scope['metric_package_versions'].items():
       if importlib.metadata.version(package)!=version:raise RuntimeError('metric package version mismatch: '+package)
      package_by_dim={'i2v_background':['dreamsim','open_clip','clip','peft'],'background_consistency':['clip'],'aesthetic_quality':['clip'],'imaging_quality':['pyiqa']}
      for module_name in ['vbench','vbench2_beta_i2v']+package_by_dim.get(dim,[]):
       module=importlib.import_module(module_name);module_path=str(Path(module.__file__).resolve())
       if module_path not in scope['metric_code_sha256'] or sha(module_path)!=scope['metric_code_sha256'][module_path]:raise RuntimeError('imported metric package identity mismatch: '+module_name)
      import vbench2_beta_i2v as vbench_module
      from metric_loaders import safe_loaders
      VBenchI2V=vbench_module.VBenchI2V
      observations=[];restore=None
      if dim=='dynamic_degree':
       import vbench.dynamic_degree as dynamic
       score_old=dynamic.DynamicDegree.get_score;infer_old=dynamic.DynamicDegree.infer;forward_old=dynamic.RAFT.forward; current=[None]
       def score(self,*args,**kwargs):
        if current[0] is None:raise RuntimeError('RAFT score without active video')
        value=float(score_old(self,*args,**kwargs))
        if not __import__('math').isfinite(value) or value<0:raise RuntimeError('nonfinite or negative RAFT score')
        current[0]['scores'].append(value);return value
       def infer(self,path,*args,**kwargs):
        item={'video_path':path,'scores':[],'forward_count':0};observations.append(item);current[0]=item
        try:
         value=infer_old(self,path,*args,**kwargs);item['official_dynamic_degree']=bool(value)
         if len(item['scores'])!=40 or item['forward_count']!=40:raise RuntimeError('expected 40 RAFT pairs')
         item['mean_top5percent_flow_px_per_2frame_pair']=sum(item['scores'])/40
         item['windows']=[sum(item['scores'][i:i+8])/8 for i in range(0,40,8)]
         if len(item['windows'])!=5 or any(not __import__('math').isfinite(v) or v<0 for v in item['windows']):raise RuntimeError('invalid RAFT windows')
         return value
        finally:current[0]=None
       def forward(self,*args,**kwargs):
        if current[0] is None or kwargs.get('iters')!=20 or kwargs.get('test_mode') is not True:raise RuntimeError('RAFT protocol mismatch')
        current[0]['forward_count']+=1
        output=forward_old(self,*args,**kwargs)
        if not isinstance(output,(tuple,list)) or len(output)<2 or not torch.isfinite(output[1]).all().item():raise RuntimeError('nonfinite RAFT flow_up')
        return output
       dynamic.DynamicDegree.get_score=score;dynamic.DynamicDegree.infer=infer;dynamic.RAFT.forward=forward
       def restore():dynamic.DynamicDegree.get_score=score_old;dynamic.DynamicDegree.infer=infer_old;dynamic.RAFT.forward=forward_old
      started=time.monotonic()
      try:
       with safe_loaders(torch,vbench_module,dim,mapping,scope):
        bench=VBenchI2V('cuda',str(metadata),str(receipt.path));bench.evaluate(videos_path=str(stage),name='metric',dimension_list=[dim],local=True,resolution='16-9')
      finally:
       if restore:restore()
      receipt.check_deadline()
      if torch.cuda.max_memory_allocated()>gpu_limit*1024**3:raise RuntimeError('GPU memory budget exceeded')
      result=receipt.path/'metric_eval_results.json';raw=json.loads(result.read_text(encoding='utf8'));rec=extract_video_records(raw)
      paths=[str(Path(x['video_path']).resolve()) for x in rec]
      if len(paths)!=2*len(selected) or len(set(paths))!=len(paths) or set(paths)!=set(lookup):raise RuntimeError('metric omitted or duplicated video')
      for item,path in zip(rec,paths):
       if not isinstance(item.get('video_results'),(int,float,bool)) or not __import__('math').isfinite(float(item['video_results'])):raise ValueError('nonfinite per-video metric')
       item.update(lookup[path])
      (receipt.path/'per_video_scores.json').write_text(json.dumps(rec,indent=2,allow_nan=False),encoding='utf8')
      if dim=='dynamic_degree':
       if len(observations)!=2*len(selected):raise RuntimeError('missing RAFT observations')
       for item in observations:item.update(lookup[str(Path(item['video_path']).resolve())])
       (receipt.path/'continuous_raft.json').write_text(json.dumps(observations,indent=2,allow_nan=False),encoding='utf8')
      receipt.result={'status':'CUSTOM_I2V_DIMENSION_COMPLETE_NUMERICS_UNASSESSED','dimension':dim,'arms':['dense','candidate'],'source_count':len(selected),'video_count':2*len(selected),'source_ids':[r['run_id'] for r in selected],'fps':16,'metric_seed':metric_seed,'official_five_sample_leaderboard':False,'aggregate_warning':'raw VBench aggregate mixes methods; use paired per_video_scores only','temporal_flicker_warning':'camera and subject motion can confound this proxy; explicit camera-static, dynamic and unspecified strata remain separate' if dim=='temporal_flickering' else None,'gpu_peak_allocated_bytes':torch.cuda.max_memory_allocated(),'elapsed_seconds':time.monotonic()-started,'loader_mapping_sha256':sha(receipt.path/'effective_loader.json'),'metrics_file_sha256':sha(result),'per_video_scores_sha256':sha(receipt.path/'per_video_scores.json'),'other_dimensions':'NOT_EVALUATED_IN_THIS_SCOPE'}

      if dim=='dynamic_degree':receipt.result['continuous_raft_sha256']=sha(receipt.path/'continuous_raft.json')

if __name__=='__main__':main()
