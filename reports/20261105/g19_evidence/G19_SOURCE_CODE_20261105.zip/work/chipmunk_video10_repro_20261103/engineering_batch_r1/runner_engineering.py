"""All-frame paired engineering diagnostics on a reviewed compute allocation."""
import argparse,json,os,sys
from pathlib import Path
from runner_metrics import sha,bound_json


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--scope',required=True);ap.add_argument('--scope-sha',required=True);ap.add_argument('--output',required=True);args=ap.parse_args()
    from runtime_guard import require_cpu_compute_allocation,verify_frozen_scope,RunReceipt
    alloc=require_cpu_compute_allocation();root=Path(__file__).resolve().parent;scope=verify_frozen_scope(root,args.scope,args.scope_sha)
    from runtime_contract import validate_allocation
    validate_allocation(scope,alloc)
    if Path(sys.executable).resolve()!=Path(scope['python_executable']).resolve():raise ValueError('engineering Python identity mismatch')
    if scope['phase']!='CHIPMUNK_VIDEO10_ENGINEERING':raise ValueError('wrong phase')
    if not Path(args.output).is_absolute() or Path(args.output).resolve()!=Path(scope['output_dir']).resolve():raise ValueError('output identity')
    with RunReceipt(args.output,scope,alloc) as receipt:
        cohort=bound_json(root,scope,scope['cohort_file']);videos=bound_json(root,scope,scope['video_manifest_file'])
        sources=scope['source_ids']
        if not isinstance(sources,list) or not sources or len(set(sources))!=len(sources) or set(videos)!=set(sources):raise ValueError('batch source manifest mismatch')
        for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS'):
            os.environ[key]=str(scope['budget']['cpus'])
        import cv2,numpy
        if cv2.__version__!=scope['runtime_versions']['opencv'] or numpy.__version__!=scope['runtime_versions']['numpy']:raise ValueError('engineering package versions mismatch')
        cv2.setNumThreads(scope['budget']['cpus'])
        from ffnds_video_metrics import evaluate,validate
        reports={};receipt.result={'status':'PARTIAL','completed':reports}
        for source in sources:
            receipt.check_deadline()
            row=next(r for r in cohort if r['run_id']==source);item=videos[source]
            if any(item[k]!=row[k] for k in ('image_sha256','prompt_sha256','seed')) or item['dense']['initial_latent_sha256']!=item['candidate']['initial_latent_sha256']:raise ValueError('pair identity')
            proof={}
            for arm in ('dense','candidate'):
                a=item[arm]
                if sha(a['path'])!=a['sha256'] or sha(a['exit_receipt_path'])!=a['exit_receipt_sha256']:raise ValueError('video/receipt identity')
                p=json.loads(Path(a['exit_receipt_path']).read_text(encoding='utf8')); data=p.get('result',{})
                if p.get('status')!='SUCCESS' or data.get('source_id')!=source:raise ValueError('generation incomplete')
                proof[arm]=data
            if proof['candidate'].get('status')!='CANDIDATE_VIDEO_COMPLETE_NOT_QUALITY_ACCEPTED' or proof['candidate'].get('full_ffn_sites')!=160:raise ValueError('candidate action not evidenced')
            if proof['dense'].get('status')!='CAPTURE_COMPLETE_NEEDS_INDEPENDENT_ASSET_REVIEW' or proof['dense'].get('capture_sites')!=160:raise ValueError('dense capture not evidenced')
            if proof['candidate']['video']['mp4_sha256']!=item['candidate']['sha256'] or proof['candidate']['initial_latent']['sha256']!=item['candidate']['initial_latent_sha256']:raise ValueError('candidate receipt provenance mismatch')
            dense_tap=[x for x in proof['dense'].get('videos',[]) if x.get('arm')=='tap']
            if len(dense_tap)!=1 or dense_tap[0]['mp4_sha256']!=item['dense']['sha256'] or dense_tap[0]['initial_noise']['sha256']!=item['dense']['initial_latent_sha256']:raise ValueError('dense receipt provenance mismatch')
            events=Path(item['candidate']['event_path'])
            if sha(events)!=item['candidate']['event_sha256'] or proof['candidate']['ffn_event_sha256']!=item['candidate']['event_sha256']:raise ValueError('event ledger identity')
            ev=[json.loads(line) for line in events.read_text(encoding='utf8').splitlines() if line]
            from chipmunk_tap import validate_events
            validate_events(ev,proof['candidate']['full_select_rtol'])
            seconds=sum(x['synchronized_instrumented_wall_seconds'] for x in ev)
            identity={'identity':{'source_id':source,'seed':row['seed'],'expected_frames':81,'input_prompt_digest':row['prompt_sha256'],'model_digest':scope['recipe_sha256'],'protocol_sha256':args.scope_sha,'run_sha256':item['candidate']['exit_receipt_sha256']},'reference_identity':{'source_id':source,'seed':row['seed'],'input_prompt_digest':row['prompt_sha256'],'run_sha256':item['dense']['exit_receipt_sha256']},'cost':{'generation_wall_seconds':proof['candidate']['candidate_generation_wall_instrumented'],'ffn_boundary_seconds':seconds,'setup_seconds':proof['candidate']['model_setup_wall_seconds'],'peak_gpu_memory_mib':proof['candidate']['gpu_peak_allocated']/1024**2}}
            report=evaluate(Path(item['candidate']['path']),Path(item['dense']['path']),identity);errors=validate(report)
            receipt.check_deadline()
            if errors:raise ValueError('incomplete all-frame engineering metrics: '+str(errors))
            if report['metrics']['artifact']['decoded_frames']!=81:raise ValueError('incomplete frames')
            path=receipt.path/('engineering_'+source+'.json');path.write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf8')
            reports[source]={'path':str(path),'sha256':sha(path),'frames':81}
        receipt.result={'status':'ALL_81_FRAMES_ENGINEERING_BATCH_COMPLETE_QUALITY_NOT_ACCEPTED','sources':sources,'reports':reports,'FFN_cost_note':'synchronized instrumented candidate only; not a comparable clean Dense benchmark'}

if __name__=='__main__':main()
