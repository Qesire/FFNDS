"""Collect successful receipts and local video bytes; never submit or retry jobs."""
import argparse,hashlib,json,shutil,subprocess
from pathlib import Path
from build_scopes import scope_from_start
from chipmunk_tap import validate_events
HERE=Path(__file__).resolve().parent
REMOTE='/public/home/scc/pb23061276/projects/wan-quant/work/'
def fetch(out,remote,files,scope):
 out.mkdir(exist_ok=False)
 for name in files:
  cmd='cat '+remote+'/'+name
  data=subprocess.run(['plink','-batch','-load','107',cmd],stdout=subprocess.PIPE,check=True).stdout
  (out/name).write_bytes(data)
 for name in ('scope.json','INDEPENDENT_REVIEW.json'):shutil.copy2(scope/name,out/name)
 scope_from_start(out,remote)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('kind',choices=('native','candidate'));ap.add_argument('--index',type=int,required=True);args=ap.parse_args()
 n=args.index
 if not 1<=n<=9:raise ValueError('only subsequent sources 01-09')
 source=f'chip10_{n:02}'
 if args.kind=='native':
  scope=HERE.parent/'g19_native_capture10_20261103'/source;remote=REMOTE+'g19_native_capture10_20261103/'+source+'/output_'+source;out=HERE/f'native{n:02}_proof'
  fetch(out,remote,['START.json','EXIT.json','ASSET_IDENTITIES.json','ENVIRONMENT.json'],scope)
  result=json.loads((out/'EXIT.json').read_text())['result']
  if result.get('source_id')!=source or result.get('status')!='CAPTURE_COMPLETE_NEEDS_INDEPENDENT_ASSET_REVIEW' or result.get('capture_sites')!=160:raise ValueError('bad native result')
  name=f'candidate{n:02}_r1';subprocess.run([__import__('sys').executable,str(HERE/'build_scopes.py'),'candidate','--name',name,'--source',source,'--dense-local',str(out),'--dense-remote',remote,'--rtol','0.01'],check=True)
 else:
  name=f'candidate{n:02}_r1';scope=HERE/name;remote=REMOTE+'chipmunk_video10_repro_20261103/'+name+'/output';out=scope/'results'
  fetch(out,remote,['START.json','EXIT.json','ffn_events.jsonl','ENVIRONMENT.json','ASSET_IDENTITIES.json','EFFECTIVE_CONFIG.json','candidate.mp4'],scope)
  x=json.loads((out/'EXIT.json').read_text())['result'];events=[json.loads(x) for x in (out/'ffn_events.jsonl').read_text().splitlines()];validate_events(events,x['full_select_rtol'])
  if x.get('source_id')!=source or x.get('status')!='CANDIDATE_VIDEO_COMPLETE_NOT_QUALITY_ACCEPTED' or x['video']['mp4_sha256']!=sha(out/'candidate.mp4') or x['ffn_event_sha256']!=sha(out/'ffn_events.jsonl'):raise ValueError('candidate artifact mismatch')
  dense_local=HERE/f'native{n:02}_proof';dense_remote=REMOTE+f'g19_native_capture10_20261103/{source}/output_{source}'
  index={source:{'dense':{'local':str(dense_local),'remote':dense_remote},'candidate':{'local':str(out),'remote':remote}}}
  (HERE/f'pairs{n:02}_local.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf8')
  from build_scopes import pairs
  pairs(index);print('verified',source,sha(out/'candidate.mp4'))
if __name__=='__main__':main()
