"""Index all exact scope, review, receipt and artifact hashes without reinterpreting scores."""
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
dims=('camera_motion','dynamic_degree','subject_consistency','background_consistency','motion_smoothness','imaging_quality','aesthetic_quality','i2v_subject','i2v_background','temporal_flickering')
metrics={}
for d in dims:
 p=R/f'metric_{d}_batch_{"r2" if d=="motion_smoothness" else "r1"}';s=json.loads((p/'scope.json').read_text());ex=json.loads((p/'results/EXIT.json').read_text());assert ex['status']=='SUCCESS'
 metrics[d]={'scope_sha256':sha(p/'scope.json'),'independent_review_sha256':sha(p/'INDEPENDENT_REVIEW.json'),'exit_receipt_sha256':sha(p/'results/EXIT.json'),'score_sha256':sha(p/'results/per_video_scores.json'),'loader_mapping_sha256':sha(p/'results/effective_loader.json'),'source_ids':s['source_ids'],'asset_sha256':s['metric_asset_sha256'],'source_sha256':s['metric_code_sha256'],'runtime_versions':s['runtime_versions'],'metric_package_versions':s['metric_package_versions'],'ffmpeg_sha256':s['ffmpeg_sha256']}
 if d=='dynamic_degree':metrics[d]['continuous_raft_sha256']=sha(p/'results/continuous_raft.json')
inputs=[]
for n in range(10):
 p=R/(f'candidate{n:02}_r2/results' if n==0 else f'candidate{n:02}_r1/results');e=json.loads((p/'EXIT.json').read_text());dp=R/('native_r5_proof' if n==0 else f'native{n:02}_proof');de=json.loads((dp/'EXIT.json').read_text());dv=next(v for v in de['result']['videos'] if v['arm']=='tap')
 inputs.append({'source_id':f'chip10_{n:02}','candidate_scope_sha256':sha(p/'scope.json'),'candidate_exit_sha256':sha(p/'EXIT.json'),'candidate_video_sha256':sha(p/'candidate.mp4'),'candidate_events_sha256':sha(p/'ffn_events.jsonl'),'dense_scope_sha256':sha(dp/'scope.json'),'dense_exit_sha256':sha(dp/'EXIT.json'),'dense_video_sha256':dv['mp4_sha256']})
first=R/'metric00_i2v_background_r1';failure=R/'metric_motion_smoothness_batch_r1/results/EXIT.json'
out={'method':'CUSTOM_PAIRED','numerical_status':'UNASSESSED','source_count':10,'metric_axes':metrics,'input_pairs':inputs,'i2v_background_source00_reused':{'scope_sha256':sha(first/'scope.json'),'score_sha256':sha(first/'results/per_video_scores.json')},'motion_first_attempt_failure_retained':{'job':129081,'exit_sha256':sha(failure)},'first_read_identity_sha256':sha(R/'metric_identity_r1/results/identities.json')}
(R/'QUALITY_PROVENANCE.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8');print('wrote',sha(R/'QUALITY_PROVENANCE.json'))
if __name__=='__main__':pass
