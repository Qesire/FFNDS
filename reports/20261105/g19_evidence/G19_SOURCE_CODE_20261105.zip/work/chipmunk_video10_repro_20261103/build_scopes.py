"""Build exact review candidates from successful local receipt copies; never submit."""
import argparse,hashlib,json,re,shutil
from pathlib import Path
HERE=Path(__file__).resolve().parent
REMOTE='/public/home/scc/pb23061276/projects/wan-quant/work/chipmunk_video10_repro_20261103/'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf8'))
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def path_remote(s):
 if not isinstance(s,str) or not s.startswith('/public/home/scc/pb23061276/') or '..' in s.split('/') or '/public/public/' in s:raise ValueError('invalid remote path')
 return s.rstrip('/')
def scope_from_start(local,remote):
 local=Path(local);remote=path_remote(remote);start=read(local/'START.json');end=read(local/'EXIT.json');scope=start['scope'];digest=scope['_verified_scope_sha256']
 reviewed=read(local/'scope.json');review=read(local/'INDEPENDENT_REVIEW.json')
 if sha(local/'scope.json')!=digest or not review.get('reviewer') or review.get('status')!='ACCEPTED' or review.get('scope_sha256')!=digest or review.get('reviewer') in reviewed.get('authors',[]):raise ValueError('missing exact independent scope review')
 if {k:v for k,v in scope.items() if k!='_verified_scope_sha256'}!=reviewed:raise ValueError('START scope differs from reviewed scope')
 if end.get('status')!='SUCCESS' or scope['output_dir']!=remote or not re.fullmatch('[0-9a-f]{64}',digest):raise ValueError('run incomplete or remote output mismatch')
 return scope,end['result']
def make_dir(name,code):
 if not re.fullmatch('[a-zA-Z0-9_]+',name):raise ValueError('unsafe scope name')
 out=HERE/name;out.mkdir(exist_ok=False)
 for file in code:shutil.copy2(HERE/file,out/file)
 shutil.copy2(HERE/'cohort_draft.json',out/'cohort.json');shutil.copy2(HERE/'ROOT_SELF_AUDIT.md',out/'AUTHOR_SELF_AUDIT.md')
 return out
def finalize(out,scope,config):
 dump(out/'config.json',config);scope['config_file']='config.json';scope['config_sha256']=sha(out/'config.json');scope['required_runtime_config']=config
 scope['input_manifest_file']='cohort.json';scope['manifest_sha256']=sha(out/'cohort.json')
 scope['active_registry_file']='ACTIVE_RESEARCH.json';scope['status']='REVIEW_CANDIDATE';scope['authors']=['/root/terra_v7_runner'];scope['scheduler']={'partition':'P107-A100','account':'competition','qos':'qos_p107-a100'}
 scope['scope_id']=out.name;scope['output_dir']=REMOTE+out.name+'/output';scope['external_sources_sha256']=scope.get('external_sources_sha256',{})
 scope['code_sha256']={p.name:sha(p) for p in out.iterdir() if p.suffix in ('.py','.sh')};scope['frozen_inputs_sha256']={p.name:sha(p) for p in out.iterdir() if (p.suffix=='.json' and p.name not in ('scope.json','config.json')) or p.name=='AUTHOR_SELF_AUDIT.md'}
 dump(out/'scope.json',scope);print(out,sha(out/'scope.json'))
def rows():return {x['run_id']:x for x in read(HERE/'cohort_draft.json')}
def dense_proof(local,remote,source):
 scope,result=scope_from_start(local,remote);row=rows()[source]
 if scope.get('manifest_sha256')!=sha(HERE/'cohort_draft.json') or source not in scope.get('run_ids',[]):raise ValueError('Dense frozen cohort/source mismatch')
 if scope.get('phase')!='NATIVE_TRAJECTORY' or result.get('status')!='CAPTURE_COMPLETE_NEEDS_INDEPENDENT_ASSET_REVIEW' or result.get('source_id')!=source or result.get('capture_sites')!=160:raise ValueError('invalid Dense proof')
 tap=[v for v in result['videos'] if v['arm']=='tap']
 if len(tap)!=1 or (tap[0]['width'],tap[0]['height'],tap[0]['frames'])!=(832,464,81):raise ValueError('Dense geometry/tap mismatch')
 assets=read(Path(local)/'ASSET_IDENTITIES.json');env=read(Path(local)/'ENVIRONMENT.json');noise=tap[0]['initial_noise']
 if len(assets)!=9 or not re.fullmatch('[0-9a-f]{64}',noise['sha256']):raise ValueError('missing base asset/noise')
 if env.get('tf32_matmul') is not False or env.get('tf32_cudnn') is not False:raise ValueError('Dense numeric precision')
 for key in ('image_sha256','prompt_sha256','seed'):
  if not row.get(key):raise ValueError('source metadata missing')
 return scope,result,tap[0],assets,env

def candidate(args):
 if args.rtol!=0.01:raise ValueError('predeclared full-select diagnostic rtol is fixed at 0.01')
 source=args.source;dense,_,tap,assets,env=dense_proof(args.dense_local,args.dense_remote,source);row=rows()[source]
 common=('base_model_dir','checkpoints','required_runtime_config','runtime_versions','python_executable','python_import_paths','python_source_roots','external_sources_sha256')
 recipe=hashlib.sha256(json.dumps({k:dense[k] for k in common},sort_keys=True,separators=(',',':')).encode()).hexdigest()
 remote=path_remote(args.dense_remote);local=Path(args.dense_local);noise=tap['initial_noise']
 baseline={k:row[k] for k in ('image_sha256','prompt_sha256','seed')};baseline.update({'recipe_sha256':recipe,'checkpoint_sha256':{k:v['sha256'] for k,v in dense['checkpoints'].items()},'base_assets_sha256':{k:v['sha256'] for k,v in assets.items()},'initial_latent_sha256':noise['sha256'],'initial_latent_shape':noise['shape'],'initial_latent_dtype':noise['dtype'],'video_path':remote+'/tap.mp4','video_sha256':tap['mp4_sha256'],'scope_sha256':dense['_verified_scope_sha256']})
 for key,file in [('start_receipt','START.json'),('exit_receipt','EXIT.json'),('asset_identities','ASSET_IDENTITIES.json'),('environment','ENVIRONMENT.json')]:baseline[key+'_path']=remote+'/'+file;baseline[key+'_sha256']=sha(local/file)
 code=['runtime_guard.py','runtime_contract.py','runner_chipmunk.py','chipmunk_tap.py','job_chipmunk.sh'];out=make_dir(args.name,code);dump(out/'dense_reference.json',{source:baseline})
 scope={k:dense[k] for k in common};scope.update({'phase':'CHIPMUNK_VIDEO10_CANDIDATE','run_ids':[source],'cohort_file':'cohort.json','dense_reference_file':'dense_reference.json','recipe_sha256':recipe,'base_assets_sha256':{k:{'size':v['size'],'sha256':v['sha256']} for k,v in assets.items()},'ffmpeg_sha256':env['ffmpeg_sha256'],'full_select_rtol':args.rtol,'latent_capture_budget_bytes':256*1024**2,'budget':{'gpus_per_job':1,'max_jobs':1,'cpus':4,'host_memory_gib':192,'wall_seconds':3600,'soft_seconds':3480,'gpu_memory_gib':78,'min_free_disk_gib':30}})
 finalize(out,scope,dense['required_runtime_config'])

def pairs(index):
 result={}
 for source,item in index.items():
  dlocal=Path(item['dense']['local']);dr=path_remote(item['dense']['remote']);clocal=Path(item['candidate']['local']);cr=path_remote(item['candidate']['remote'])
  ds,_,tap,_,_=dense_proof(dlocal,dr,source);cs,ce=scope_from_start(clocal,cr);row=rows()[source]
  if cs.get('manifest_sha256')!=sha(HERE/'cohort_draft.json') or source not in cs.get('run_ids',[]):raise ValueError('candidate frozen cohort/source mismatch')
  if cs.get('phase')!='CHIPMUNK_VIDEO10_CANDIDATE' or ce.get('status')!='CANDIDATE_VIDEO_COMPLETE_NOT_QUALITY_ACCEPTED' or ce.get('source_id')!=source or ce.get('full_ffn_sites')!=160 or ce['initial_latent']!=tap['initial_noise']:raise ValueError('candidate identity mismatch')
  if (ce['video']['width'],ce['video']['height'],ce['video']['frames'])!=(832,464,81):raise ValueError('candidate geometry')
  entry={k:row[k] for k in ('image_sha256','prompt_sha256','seed')};entry['dense']={'path':dr+'/tap.mp4','sha256':tap['mp4_sha256'],'initial_latent_sha256':tap['initial_noise']['sha256'],'exit_receipt_path':dr+'/EXIT.json','exit_receipt_sha256':sha(dlocal/'EXIT.json')}
  entry['candidate']={'path':cr+'/candidate.mp4','sha256':ce['video']['mp4_sha256'],'initial_latent_sha256':ce['initial_latent']['sha256'],'exit_receipt_path':cr+'/EXIT.json','exit_receipt_sha256':sha(clocal/'EXIT.json'),'event_path':cr+'/ffn_events.jsonl','event_sha256':ce['ffn_event_sha256']};result[source]=entry
 return result

def evaluation(args):
 index=read(args.pairs);video=pairs(index);ids=list(index);ident=read(HERE/'metric_assets_firstread.json');py=ident['python_executable'];site='/public/home/scc/pb23061276/miniconda3/envs/vbench_i2v_official/lib/python3.10/site-packages';project='/public/home/scc/pb23061276/projects/wan-quant'
 if args.kind=='metric':
  from runner_metrics import validate_dimension
  if not set(ids).issubset({r['run_id'] for r in validate_dimension(list(rows().values()),args.dimension)}):raise ValueError('inapplicable source')
  code=['runtime_guard.py','runtime_contract.py','runner_metrics.py','metric_contract.py','metric_loaders.py','chipmunk_tap.py','job_metrics.sh'];out=make_dir(args.name,code)
  scope={'phase':'CHIPMUNK_VIDEO10_METRIC','dimension':args.dimension,'source_ids':ids,'metric_seed':20261103,'metric_project_root':project,'metric_cache_root':'/public/home/scc/pb23061276/.cache/vbench','metric_site_packages':site,'vbench_working_directory':project,'metric_asset_sha256':ident['metric_asset_sha256'],'metric_code_sha256':ident['metric_code_sha256'],'metric_package_versions':ident['metric_package_versions'],'ffmpeg_path':ident['ffmpeg_path'],'ffmpeg_sha256':ident['ffmpeg_sha256'],'runtime_versions':{'torch':ident['metric_package_versions']['torch'],'numpy':ident['metric_package_versions']['numpy']},'budget':{'gpus_per_job':1,'max_jobs':1,'cpus':4,'host_memory_gib':64,'wall_seconds':3600,'soft_seconds':3480,'gpu_memory_gib':60,'min_free_disk_gib':10}}
 else:
  code=['runtime_guard.py','runtime_contract.py','runner_engineering.py','runner_metrics.py','ffnds_video_metrics.py','chipmunk_tap.py','job_engineering.sh'];out=make_dir(args.name,code)
  candidate_scopes=[scope_from_start(index[i]['candidate']['local'],index[i]['candidate']['remote'])[0] for i in ids]
  recipes={s['recipe_sha256'] for s in candidate_scopes}
  if len(recipes)!=1:raise ValueError('engineering batch mixes recipes')
  if not args.opencv_version:raise ValueError('explicit actual opencv version required')
  scope={'phase':'CHIPMUNK_VIDEO10_ENGINEERING','source_ids':ids,'recipe_sha256':recipes.pop(),'runtime_versions':{'opencv':args.opencv_version,'numpy':ident['metric_package_versions']['numpy']},'budget':{'gpus_per_job':0,'max_jobs':1,'cpus':2,'host_memory_gib':16,'wall_seconds':1800,'soft_seconds':1680,'min_free_disk_gib':5}}
 shutil.copy2(HERE/'metric_assets_firstread.json',out/'metric_assets_firstread.json')
 dump(out/'video_manifest.json',video);scope.update({'python_executable':py,'cohort_file':'cohort.json','video_manifest_file':'video_manifest.json'});finalize(out,scope,{})

def main():
 p=argparse.ArgumentParser();sub=p.add_subparsers(dest='kind',required=True)
 c=sub.add_parser('candidate');c.add_argument('--name',required=True);c.add_argument('--source',required=True);c.add_argument('--dense-local',required=True);c.add_argument('--dense-remote',required=True);c.add_argument('--rtol',type=float,required=True)
 for name in ('metric','engineering'):
  q=sub.add_parser(name);q.add_argument('--name',required=True);q.add_argument('--pairs',required=True);q.add_argument('--dimension');q.add_argument('--opencv-version')
 args=p.parse_args();candidate(args) if args.kind=='candidate' else evaluation(args)
if __name__=='__main__':main()
