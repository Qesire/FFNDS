#!/bin/bash
set -euo pipefail
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
exec /public/home/scc/pb23061276/miniconda3/envs/vbench_i2v_official/bin/python runner_metric_identity.py --scope "$1" --scope-sha "$2" --output "$3"
