"""Independent receipt/record arithmetic review; no evaluation/model/video rerun."""
import collections,csv,hashlib,json,math,statistics
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parent
DIMS=('subject_consistency','background_consistency','motion_smoothness','dynamic_degree','aesthetic_quality','imaging_quality','i2v_subject','i2v_background','camera_motion','temporal_flickering')
read=lambda p:json.loads(p.read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
csvread=lambda p:list(csv.DictReader(p.open(encoding='utf8',newline='')))
def eq(a,b):assert math.isclose(float(a),float(b),rel_tol=2e-12,abs_tol=2e-13),(a,b)
def finite(x):
 if isinstance(x,float):assert math.isfinite(x)
 elif isinstance(x,dict):
  for v in x.values():finite(v)
 elif isinstance(x,list):
  for v in x:finite(v)
def video_records(x):
 if isinstance(x,dict):
  if 'video_path' in x:
   yield x
  else:
   for v in x.values():yield from video_records(v)
 elif isinstance(x,list):
  for v in x:yield from video_records(v)
cohort={r['run_id']:r for r in read(ROOT/'metric_motion_smoothness_batch_r2/cohort.json')}
assert len(cohort)==10
combined=read(ROOT/'METRIC_SCORES_COMBINED.json');prov=read(ROOT/'QUALITY_PROVENANCE.json')
assert combined['status']=='COMPLETE' and combined['unavailable']==[]
rows={};scope_receipts=[];dims={};raw_lookup={};metric_folders={}
def checked_scope(folder):
 s=read(folder/'scope.json');rev=read(folder/'INDEPENDENT_REVIEW.json');st=read(folder/'results/START.json');en=read(folder/'results/EXIT.json');h=sha(folder/'scope.json')
 assert rev['status']=='ACCEPTED' and rev['scope_sha256']==h and rev['reviewer']=='/root/independent_math_review'
 assert st['scope']['_verified_scope_sha256']==h and {k:v for k,v in st['scope'].items() if k!='_verified_scope_sha256'}==s
 assert en['status']=='SUCCESS' and en['exception'] is None
 assert en['elapsed_seconds']<s['budget']['soft_seconds'] and en['process_peak_rss_bytes']<s['budget']['host_memory_gib']*1024**3
 for n,d in {**s['code_sha256'],**s['frozen_inputs_sha256'],s['config_file']:s['config_sha256']}.items():assert sha(folder/n)==d
 job=st['allocation']['job_id'];schedule=folder/'results/SCONTROL_FINAL.txt'
 if schedule.exists():
  text=schedule.read_text()
  assert f'JobId={job}' in text and 'JobState=COMPLETED' in text and 'ExitCode=0:0' in text
 scope_receipts.append({'folder':folder.name,'scope_sha256':h,'job_id':job,'elapsed_seconds':en['elapsed_seconds'],'final_scheduler_available':schedule.exists()})
 return s,en,h
for dim in DIMS:
 folder=ROOT/f'metric_{dim}_batch_r1'
 if dim=='motion_smoothness':folder=ROOT/'metric_motion_smoothness_batch_r2'
 metric_folders[dim]=folder
 folders=([ROOT/'metric00_i2v_background_r1'] if dim=='i2v_background' else [])+[folder]
 for f in folders:
  s,en,h=checked_scope(f);assert s['dimension']==en['result']['dimension']==dim
  r=f/'results';score_file=r/'per_video_scores.json';scores=read(score_file)
  assert sha(score_file)==en['result']['per_video_scores_sha256']
  assert sha(r/'effective_loader.json')==en['result']['loader_mapping_sha256']
  assert sha(r/'metric_eval_results.json')==en['result']['metrics_file_sha256']
  raw=list(video_records(read(r/'metric_eval_results.json')[dim]))
  raw_by_path={x['video_path']:x['video_results'] for x in raw}
  assert len(raw)==len(raw_by_path)==len(scores)==2*len(s['source_ids'])
  assert en['result']['gpu_peak_allocated_bytes']<=s['budget']['gpu_memory_gib']*1024**3
  expected={(sid,arm) for sid in s['source_ids'] for arm in ('dense','candidate')}
  assert {(x['source_id'],x['arm']) for x in scores}==expected
  for x in scores:
   finite(x);sid=x['source_id'];arm=x['arm'];key=(dim,sid,arm)
   assert key not in rows and x['video_results']==raw_by_path[x['video_path']]
   assert x['video_path']==s['output_dir']+'/videos/'+cohort[sid]['prompt']+('-0.mp4' if arm=='dense' else '-1.mp4')
   camera=cohort[sid].get('camera_instruction')
   stratum='CAMERA_STATIC_EXPLICIT' if camera=='camera static' else 'CAMERA_DYNAMIC_INSTRUCTION' if camera else 'CAMERA_UNSPECIFIED'
   assert x['camera_stratum']==stratum
   rows[key]={'dimension':dim,'source_id':sid,'arm':arm,'score':float(x['video_results']),'camera_stratum':stratum,'scope_sha256':h,'score_file_sha256':sha(score_file)}
   raw_lookup[key]=x
  if f==folder:
   pv=prov['metric_axes'][dim]
   assert pv['scope_sha256']==h and pv['independent_review_sha256']==sha(f/'INDEPENDENT_REVIEW.json')
   assert pv['exit_receipt_sha256']==sha(r/'EXIT.json') and pv['score_sha256']==sha(score_file)
   assert pv['loader_mapping_sha256']==sha(r/'effective_loader.json') and pv['source_ids']==s['source_ids']
   assert pv['asset_sha256']==s['metric_asset_sha256'] and pv['source_sha256']==s['metric_code_sha256']
 assert {k[1:] for k in rows if k[0]==dim}=={(sid,arm) for sid in cohort if dim!='camera_motion' or cohort[sid].get('camera_instruction') for arm in ('dense','candidate')}
assert len(rows)==194 and len(combined['per_video'])==194
assert { (x['dimension'],x['source_id'],x['arm']):x for x in combined['per_video']}==rows
old_failure=ROOT/'metric_motion_smoothness_batch_r1/results/EXIT.json'
assert read(old_failure)['status']=='FAILED_OR_PARTIAL' and read(old_failure)['result']=={}
assert prov['motion_first_attempt_failure_retained']['exit_sha256']==sha(old_failure)
assert prov['i2v_background_source00_reused']['scope_sha256']==sha(ROOT/'metric00_i2v_background_r1/scope.json')
assert prov['i2v_background_source00_reused']['score_sha256']==sha(ROOT/'metric00_i2v_background_r1/results/per_video_scores.json')

paired=csvread(ROOT/'METRIC_PAIRED.csv');assert len(paired)==97
for p in paired:
 key=(p['dimension'],p['source_id']);a=rows[(*key,'dense')]['score'];b=rows[(*key,'candidate')]['score']
 eq(p['dense'],a);eq(p['candidate'],b);eq(p['candidate_minus_dense'],b-a)
 assert p['camera_stratum']==rows[(*key,'dense')]['camera_stratum']
for d in csvread(ROOT/'METRIC_DIMENSION_SUMMARY.csv'):
 name=d['dimension'];source_ids=sorted({k[1] for k in rows if k[0]==name});a=[rows[(name,s,'dense')]['score'] for s in source_ids];b=[rows[(name,s,'candidate')]['score'] for s in source_ids]
 assert int(d['source_count'])==len(source_ids)
 eq(d['dense_mean'],statistics.mean(a));eq(d['candidate_mean'],statistics.mean(b));eq(d['mean_candidate_minus_dense'],statistics.mean(y-x for x,y in zip(a,b)))
 diffs=[y-x for x,y in zip(a,b)]
 dims[name]={'source_count':len(source_ids),'dense_mean':statistics.mean(a),'candidate_mean':statistics.mean(b),'mean_candidate_minus_dense':statistics.mean(diffs),'negative_pairs':sum(x<0 for x in diffs),'positive_pairs':sum(x>0 for x in diffs),'equal_pairs':sum(x==0 for x in diffs)}

raft_file=metric_folders['dynamic_degree']/'results/continuous_raft.json';raft=read(raft_file)
assert sha(raft_file)==read(metric_folders['dynamic_degree']/'results/EXIT.json')['result']['continuous_raft_sha256']
assert raft==combined['continuous_raft_per_video'] and len(raft)==20
raft_map={}
for x in raft:
 key=x['source_id'],x['arm'];assert key not in raft_map;raft_map[key]=x
 assert x['forward_count']==len(x['scores'])==40 and len(x['windows'])==5
 assert all(math.isfinite(v) and v>=0 for v in x['scores']+x['windows'])
 assert x['official_dynamic_degree']==raw_lookup[('dynamic_degree',*key)]['video_results']
 eq(x['mean_top5percent_flow_px_per_2frame_pair'],statistics.mean(x['scores']))
 for j,w in enumerate(x['windows']):eq(w,statistics.mean(x['scores'][j*8:j*8+8]))
raft_ratios={}
for p in csvread(ROOT/'RAFT_PAIRED.csv'):
 sid=p['source_id'];a=raft_map[(sid,'dense')];b=raft_map[(sid,'candidate')]
 av=a['mean_top5percent_flow_px_per_2frame_pair'];bv=b['mean_top5percent_flow_px_per_2frame_pair']
 eq(p['dense_mean_px'],av);eq(p['candidate_mean_px'],bv);eq(p['candidate_minus_dense_px'],bv-av)
 assert json.loads(p['dense_windows'])==a['windows'] and json.loads(p['candidate_windows'])==b['windows']
 raft_ratios[sid]=bv/av

def distribution(v):
 v=sorted(v);n=len(v)
 def q(p):
  x=(n-1)*p;i=math.floor(x);j=math.ceil(x);return v[i]+(v[j]-v[i])*(x-i)
 return {'mean':statistics.mean(v),'p50':q(.5),'p95':q(.95),'max':max(v),'n':n}
def compare_stats(actual,expected):
 assert actual.keys()==expected.keys()
 for k,v in actual.items():eq(v,expected[k])
eng=read(ROOT/'ENGINEERING_SUMMARY.json');assert len(eng['sources'])==10
engineering=[]
for i,x in enumerate(eng['sources']):
 sid=x['source_id'];f=ROOT/('engineering00_r1' if sid=='chip10_00' else 'engineering_batch_r1')
 s,en,h=checked_scope(f);path=f/'results'/('engineering.json' if sid=='chip10_00' else f'engineering_{sid}.json')
 expected=en['result']['report_sha256'] if sid=='chip10_00' else en['result']['reports'][sid]['sha256']
 assert sha(path)==expected==x['report_sha256'];r=read(path);finite(r)
 assert r['identity']['source_id']==sid and r['identity']['input_prompt_digest']==cohort[sid]['prompt_sha256']
 assert r['identity']['protocol_sha256']==h and r['metrics']==x['metrics']
 assert r['metrics']['artifact']['decoded_frames']==r['metrics']['artifact']['verified_full_decode_frames']==81
 frames=r['per_frame'];assert [v['frame'] for v in frames]==list(range(81))
 for field,(family,name) in {'paired_RGB_RMSE_0to1':('paired_spatial','RGB_RMSE_0to1'),'paired_encoded_luma_RMSE_0to1':('paired_spatial','encoded_luma_RMSE_0to1'),'paired_signed_encoded_luma_drift_0to1':('paired_spatial','signed_encoded_luma_drift_0to1'),'candidate_to_reference_laplacian_energy_ratio':('paired_spatial','candidate_to_reference_laplacian_energy_ratio'),'paired_temporal_delta_RGB_RMSE_0to1':('paired_temporal','adjacent_delta_RGB_RMSE_0to1'),'paired_Farneback_flow_L2_px':('paired_motion','downsampled_Farneback_flow_L2_px')}.items():
  compare_stats(distribution([v[field] for v in frames if field in v]),r['metrics'][family][name])
 assert len(r['windows16'])==6
 for j,w in enumerate(r['windows16']):
  lo=j*16;hi=min(81,lo+16)
  assert (w['first_frame'],w['last_frame'],w['frames'])==(lo,hi-1,hi-lo)
  for field,stats in w.items():
   if isinstance(stats,dict):compare_stats(distribution([v[field] for v in frames[lo:hi] if field in v]),stats)
 engineering.append({'source_id':sid,'RGB_frame_RMSE_mean':r['metrics']['paired_spatial']['RGB_RMSE_0to1']['mean'],'temporal_delta_RMSE_mean':r['metrics']['paired_temporal']['adjacent_delta_RGB_RMSE_0to1']['mean'],'quality_accepted':r['quality_accepted']})

# Cost records are checked against actual producer receipts, without a speed ratio.
cost=read(ROOT/'CANDIDATE_COST_LEDGER.json')
assert cost['cache_bytes']==40*31668*(13824+5120)*2==47993487360
eq(cost['cache_gib'],cost['cache_bytes']/1024**3)
assert len(cost['sources'])==10
for x in cost['sources']:
 sid=x['source_id'];pair=read(ROOT/f'pairs{int(sid[-2:]):02d}_local.json')[sid]
 candidate=Path(pair['candidate']['local']);dense=Path(pair['dense']['local'])
 ce=read(candidate/'EXIT.json');de=read(dense/'EXIT.json');cr=ce['result'];dr=de['result']
 assert ce['status']==de['status']=='SUCCESS'
 assert x['event_count']==160 and x['dense_cache_sites']==x['selected_delta_sites']==80
 events=[json.loads(line) for line in (candidate/'ffn_events.jsonl').read_text().splitlines()]
 assert sha(candidate/'ffn_events.jsonl')==cr['ffn_event_sha256'] and len(events)==160
 eq(x['candidate_sync_ffn_wall_seconds'],math.fsum(e['synchronized_instrumented_wall_seconds'] for e in events))
 assert x['observed_peak_cache_live_bytes']==max(e['cache_live_bytes'] for e in events)
 assert x['full_select_compatibility_checks']==[e['full_select_check'] for e in events if e['full_select_check']]
 # Every displayed cost must occur in the corresponding original receipt tree.
 def contains_value(tree,value):
  if isinstance(tree,dict):return any(contains_value(v,value) for v in tree.values())
  if isinstance(tree,list):return any(contains_value(v,value) for v in tree)
  return tree==value
 for k,v in x.items():
  if k.startswith('candidate_') and k not in ('candidate_mp4_sha256','candidate_sync_ffn_wall_seconds'):assert contains_value(ce,v),(sid,k)
  if k.startswith('dense_') and k!='dense_cache_sites':assert contains_value(de,v),(sid,k)
 assert contains_value(ce,x['candidate_mp4_sha256'])
 for check in x['full_select_compatibility_checks']:assert check['relative_l2']<=.01 and check['zero_delta_byte_equal']
 p=next(v for v in prov['input_pairs'] if v['source_id']==sid)
 assert p['candidate_exit_sha256']==sha(candidate/'EXIT.json') and p['dense_exit_sha256']==sha(dense/'EXIT.json')
 assert p['candidate_video_sha256']==x['candidate_mp4_sha256']
 assert p['candidate_events_sha256']==sha(candidate/'ffn_events.jsonl')
 assert p['candidate_scope_sha256']==read(candidate/'START.json')['scope']['_verified_scope_sha256']
 assert p['dense_scope_sha256']==read(dense/'START.json')['scope']['_verified_scope_sha256']
 assert p['dense_video_sha256']==next(v['mp4_sha256'] for v in dr['videos'] if v['arm']=='tap')
result={'status':'PASS_RECORDED_QUALITY_PROVENANCE_AND_INDEPENDENT_AGGREGATION','reviewer':'/root/independent_math_review',
        'metric_observations':194,'paired_dimension_source_rows':97,'distinct_source_clusters':10,
        'continuous_RAFT_video_records':20,'continuous_RAFT_pair_scores':800,'continuous_RAFT_windows':100,
        'engineering_sources':10,'engineering_frame_rows':810,'dimension_summaries':dims,
        'raft_candidate_to_dense_flow_ratios':raft_ratios,'engineering':engineering,
        'scope_receipts':scope_receipts,'failed_AMT129081_retained':True,'actual_AMT_R2_job129106_success':True,
        'input_sha256':{n:sha(ROOT/n) for n in ('METRIC_SCORES_COMBINED.json','METRIC_PAIRED.csv','METRIC_DIMENSION_SUMMARY.csv','RAFT_PAIRED.csv','ENGINEERING_SUMMARY.json','CANDIDATE_COST_LEDGER.json','QUALITY_PROVENANCE.json')},
        'learned_metric_or_flow_or_video_recomputed':False,'remote_execution':False}
(ROOT/'INDEPENDENT_QUALITY_RESULT_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k not in ('scope_receipts','input_sha256')},indent=2))
