"""Review the exact AMT compatibility change using synthetic CPU data only."""
import hashlib,json,pathlib,sys,tempfile,zipfile
from collections import OrderedDict
from types import SimpleNamespace

ROOT=pathlib.Path(__file__).resolve().parent
OLD=ROOT/'metric_motion_smoothness_batch_r1'
NEW=ROOT/'metric_motion_smoothness_batch_r2'
EXPECTED='8941c555d4db3700dc757d61acaa9023141bf86a44490e6c414419fd89db602c'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf8'))
assert sha(NEW/'scope.json')==EXPECTED
a,b=read(OLD/'scope.json'),read(NEW/'scope.json')
assert {k for k in a.keys()|b.keys() if a.get(k)!=b.get(k)}=={'scope_id','output_dir','code_sha256','frozen_inputs_sha256'}
assert {k for k in a['code_sha256'] if a['code_sha256'][k]!=b['code_sha256'][k]}=={'metric_loaders.py'}
assert {k for k in a['frozen_inputs_sha256'] if a['frozen_inputs_sha256'][k]!=b['frozen_inputs_sha256'][k]}=={'AUTHOR_SELF_AUDIT.md'}
for n,h in {**b['code_sha256'],**b['frozen_inputs_sha256'],b['config_file']:b['config_sha256']}.items():assert sha(NEW/n)==h
assert sha(NEW/'video_manifest.json')==sha(OLD/'video_manifest.json')
assert sha(NEW/'cohort.json')==sha(OLD/'cohort.json')
failure=read(OLD/'results/EXIT.json')
assert failure['status']=='FAILED_OR_PARTIAL' and not failure['result']
assert 'GLOBAL typing.OrderedDict' in failure['exception']
sys.path.insert(0,str(NEW))
from metric_loaders import safe_loaders
import torch
old_load=torch.load
before_globals=set(torch.serialization.get_safe_globals())
cases=[]
with tempfile.TemporaryDirectory() as tmp:
 p=pathlib.Path(tmp);original=p/'original.pth';target=p/'typing_ordered_dict.pth';other=p/'other.pth'
 original_data=OrderedDict([('x',torch.tensor([1.,2.],dtype=torch.float32))])
 torch.save(original_data,original,pickle_protocol=2)
 with zipfile.ZipFile(original) as src,zipfile.ZipFile(target,'w') as dst:
  substitutions=0
  for info in src.infolist():
   data=src.read(info.filename)
   if info.filename.endswith('/data.pkl'):
    old=b'ccollections\nOrderedDict\n';new=b'ctyping\nOrderedDict\n'
    substitutions+=data.count(old);data=data.replace(old,new)
   dst.writestr(info,data)
 assert substitutions==1
 other.write_bytes(target.read_bytes())
 try:old_load(target,weights_only=True)
 except Exception as e:assert 'typing.OrderedDict' in str(e);cases.append('unmodified_weights_only_rejects_named_global')
 else:raise AssertionError('baseline unexpectedly accepted')
 module=SimpleNamespace(init_submodules=lambda *a,**k:None)
 old_init=module.init_submodules
 try:
  with safe_loaders(torch,module,'motion_smoothness',{'ckpt':str(target)},{}):
   result=torch.load(target,map_location='cpu')
   assert isinstance(result,OrderedDict) and torch.equal(result['x'],original_data['x'])
   cases.append('bound_target_real_safe_globals_loads_equal_synthetic_tensor')
   assert set(torch.serialization.get_safe_globals())==before_globals
   cases.append('per_load_allowlist_removed_before_return')
   try:torch.load(target,weights_only=False)
   except RuntimeError:cases.append('bound_target_rejects_explicit_unsafe_mode')
   else:raise AssertionError('unsafe mode allowed')
   try:torch.load(other,weights_only=True)
   except Exception as e:assert 'typing.OrderedDict' in str(e);cases.append('other_file_no_allowlist')
   else:raise AssertionError('other file unexpectedly accepted')
   raise ValueError('synthetic caller failure')
 except ValueError as e:assert str(e)=='synthetic caller failure'
 assert torch.load is old_load and module.init_submodules is old_init
 assert set(torch.serialization.get_safe_globals())==before_globals
 cases.append('torch_load_and_allowlist_restored_after_exception')
out={'status':'PASS_EXACT_DIFF_AND_SYNTHETIC_CPU_COMPATIBILITY',
     'scope_sha256':EXPECTED,'changed_code':['metric_loaders.py'],
     'same_inputs_assets_sources_videos_metric_definition_budget':True,
     'failed_prior_job':129081,'prior_failure_sha256':sha(OLD/'results/EXIT.json'),
     'local_python':sys.version,'local_torch':torch.__version__,'cases':cases,
     'actual_AMT_checkpoint_read':False,'server_or_GPU_execution':False,
     'limitation':'This local CPU Torch version is not the frozen server 2.7.1+cu118; no successful real metric load or score is asserted.'}
(NEW/'INDEPENDENT_COMPATIBILITY_CHECKS.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')
print(json.dumps(out,indent=2))
