"""Reviewer-owned tiny counterexamples; no real Torch/model/video/network IO."""
from types import SimpleNamespace
from unittest.mock import patch
from pathlib import Path
import hashlib
import json
import numpy as np
import metric_loaders
import runtime_guard as g
from runtime_contract import validate_allocation

checks = {}

# The installed metric's aggregation really can erase a NaN.
assert max(0., float('nan')) == 0.
flow_magnitudes = np.ones(100)
flow_magnitudes[-1] = np.nan
assert np.isfinite(np.mean(abs(np.sort(-flow_magnitudes))[:5]))
checks['nan_can_hide_behind_cosine_clamp_and_raft_top5percent'] = True

class Handle:
    def __init__(self, model, fn): self.model, self.fn = model, fn
    def remove(self): self.model.hooks.remove(self.fn)

class Model:
    def __init__(self): self.hooks = []
    def register_forward_hook(self, fn):
        self.hooks.append(fn)
        return Handle(self, fn)
    def __call__(self, value):
        result = (value, np.ones(3))
        for fn in self.hooks: fn(self, (), result)
        return result

model = Model()
old_cosine = lambda: np.array([np.nan])
hub = SimpleNamespace(load=lambda *a, **k:model,
                      load_state_dict_from_url=lambda *a, **k:None,
                      download_url_to_file=lambda *a, **k:None)
torch = SimpleNamespace(hub=hub, nn=SimpleNamespace(functional=SimpleNamespace(cosine_similarity=old_cosine)),
                        isfinite=np.isfinite, load=lambda *a, **k:{'loaded':True})
module = SimpleNamespace(init_submodules=lambda *a, **k:None)
project = '/public/home/scc/pb23061276/projects/wan-quant'
scope = {'metric_project_root':project, 'metric_cache_root':'/public/home/scc/pb23061276/.cache/vbench',
         'metric_asset_sha256':{}}
with metric_loaders.safe_loaders(torch, module, 'camera_motion', {}, scope):
    try: torch.nn.functional.cosine_similarity()
    except RuntimeError: pass
    else: raise AssertionError('NaN cosine accepted')
    tracker = torch.hub.load(str(Path(project)/'facebookresearch/co-tracker'), 'cotracker2', source='local')
    tracker(np.ones(3))
    try: tracker(np.array([1.,np.nan,2.]))
    except RuntimeError: pass
    else: raise AssertionError('NaN CoTracker tracks accepted')
    try: torch.hub.load(str(Path(project)/'unbound-repo'), 'cotracker2', source='local')
    except RuntimeError: pass
    else: raise AssertionError('Unbound local hub accepted')
assert torch.nn.functional.cosine_similarity is old_cosine and not model.hooks
checks['cosine_and_cotracker_nan_rejected_before_lossy_conversion'] = True
checks['unapproved_local_repo_rejected_and_observers_restored'] = True

record = 'JobId=123 JobState=RUNNING UserId=person(1000) NodeList=compute01 NumNodes=1 NumCPUs=4 TimeLimit=00:31:00 AllocTRES=cpu=4,mem=32G ReqTRES=mem=32G MinMemoryNode=32G'
def command(args): return record if args[2]=='job' else 'compute01'
with patch.object(g.socket,'gethostname',return_value='compute01'), patch.object(g.getpass,'getuser',return_value='person'), patch.dict(g.os.environ,{'SLURM_JOB_ID':'123','SLURM_JOB_NODELIST':''}), patch.object(g,'_command',side_effect=command), patch.object(g.os,'getuid',return_value=1000,create=True):
    allocation = g.require_cpu_compute_allocation()
try: validate_allocation({'budget':{'host_memory_gib':32,'cpus':4,'wall_seconds':1800}}, allocation)
except RuntimeError: pass
else: raise AssertionError('Actual wall time exceeds bound CPU scope')
checks['cpu_scope_30min_rejects_live_31min_allocation'] = True

files = ['metric_loaders.py','metric_contract.py','runtime_guard.py','runtime_contract.py',
         'runner_metrics.py','runner_engineering.py']
checks['code_sha256'] = {name:hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in files}
checks['status'] = 'PASS_SYNTHETIC_ONLY_NOT_EXECUTION_APPROVAL'
print(json.dumps(checks,indent=2))
