"""Collect and validate one completed reviewed metric batch; never submit/retry."""
import argparse,hashlib,json,subprocess,shutil
from pathlib import Path
from build_scopes import scope_from_start
from summarize_metrics import ingest
ROOT=Path(__file__).resolve().parent

def main():
 p=argparse.ArgumentParser();p.add_argument('dimension');p.add_argument('job',type=int);p.add_argument('--revision',default='r1',choices=('r1','r2'));a=p.parse_args()
 folder=ROOT/f'metric_{a.dimension}_batch_{a.revision}';scope=json.loads((folder/'scope.json').read_text());remote=scope['output_dir'];out=folder/'results';out.mkdir(exist_ok=False)
 files=['START.json','EXIT.json','metric_eval_results.json','per_video_scores.json','effective_loader.json']
 if a.dimension=='dynamic_degree':files.append('continuous_raft.json')
 for name in files:
  data=subprocess.run(['plink','-batch','-load','107','cat '+remote+'/'+name],check=True,stdout=subprocess.PIPE).stdout;(out/name).write_bytes(data)
 for name in ('scope.json','INDEPENDENT_REVIEW.json'):shutil.copy2(folder/name,out/name)
 start, result=scope_from_start(out,remote);rows=ingest(folder,a.dimension)
 exit=json.loads((out/'EXIT.json').read_text());sha=lambda n:hashlib.sha256((out/n).read_bytes()).hexdigest()
 if sha('metric_eval_results.json')!=exit['result']['metrics_file_sha256'] or sha('effective_loader.json')!=exit['result']['loader_mapping_sha256']:raise ValueError('raw/loader SHA mismatch')
 if a.dimension=='dynamic_degree':
  f='continuous_raft.json';raft=json.loads((out/f).read_text())
  if sha(f)!=exit['result']['continuous_raft_sha256'] or len(raft)!=len(rows) or any(len(x['scores'])!=40 or len(x['windows'])!=5 for x in raft):raise ValueError('RAFT identity or coverage')
 cmd=f'scontrol show job -o {a.job}'
 (out/'SCONTROL_FINAL.txt').write_bytes(subprocess.run(['plink','-batch','-load','107',cmd],check=True,stdout=subprocess.PIPE).stdout)
 print('verified',a.dimension,len(rows),'score sha',sha('per_video_scores.json'))
if __name__=='__main__':main()
