"""Write reviewer records after the separate, completed independent review.

This does not execute, submit, or change any experiment or implementation.
"""
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REVIEWER = '/root/independent_math_review'
EXPECTED = {
    'engineering_batch_r1': 'd97e5e7f2ffdd0f2af87ff6e70f1b3807a025bb0e47c64b125f817052a64eb03',
    'metric_aesthetic_quality_batch_r1': '415eb974881c734b8628d36e760d7e90377dd4474b5f2a63fa119984236f9bd5',
    'metric_background_consistency_batch_r1': 'ad9fdbae353a7eb4bd4782867bcee84577bf5ae165bb4d897d20695bf16319b0',
    'metric_camera_motion_batch_r1': '595b79b7bb5c26cdbc6282e969a9a944d97ca162a6275a8b1f301b061f4bd84c',
    'metric_dynamic_degree_batch_r1': 'de166a4417bac5167f01d85459116d526be947505ea6ea19364c01e02a3127b6',
    'metric_i2v_background_batch_r1': '64428a497412f30db1809ee3628216f92e3851858e8408e5a68bd77bda7b807f',
    'metric_i2v_subject_batch_r1': 'dbad27681937e256ffabda40cb2457eca3981d3300f0c5e298f3e1105577b5bf',
    'metric_imaging_quality_batch_r1': 'ab68c98f2d3c743b778a22661e0fba008128d58de02d06385dea543970c3c32d',
    'metric_motion_smoothness_batch_r1': '7eab5fff167c4f30ccaa5fa8abb57fb2201885dbd24b835ed13ebc1c584bf30b',
    'metric_subject_consistency_batch_r1': 'f67d13fe24d3bfea8b4af80cc93c96c1176c0b685c5ff9cb3456d2577a1ba794',
    'metric_temporal_flickering_batch_r1': '8091822b202f001a0578828dc8a265d9e90ae5f4c2c7e15ee2a54752935eeac4',
}

COMMON = '''Independent exact-scope review, 2026-11-03.
Reviewer: /root/independent_math_review.

ACCEPTED means one finite collection/evaluation job for each exact scope below,
after the existing fresh ACTIVE registration and actual allocation guards.
It is not evidence that a batch has run, numerical certification, a successful
quality result, or permission to retry a failed/partial job. The whole session
remains limited to two live jobs including pending and at most two GPUs.

Review performed:
Read the frozen scope/config/cohort/video manifests, author self-audit, the new
root integration audits, engineering loop, metric runner/loader changes and
the unchanged allocation/receipt contract. Independently reconstructed all ten
source-specific pairs from producer scope/review/START/SUCCESS EXIT records;
rehash-verified all 20 actual local MP4 files and all ten event ledgers. Checked
1,600 ordered candidate events, per-expert full-select/zero-delta records,
selected-index range/uniqueness/hash and actual source image/prompt/seed/noise
binding. The common initial noise is not used as a substitute for source identity.
The exact bound_json consumers accepted each frozen cohort/video manifest.
All local frozen code/config/input hashes and the first-read metric asset and
source-closure dictionaries were checked. Review arithmetic and provenance are
recorded in INDEPENDENT_BATCH_INPUT_CHECKS.json and per-scope checks files.

The independent local run of test_chipmunk, test_cpu_guard, test_metric_safety
and test_build_scopes passed all 14 tests in 1.122 seconds. The common frozen
metric batch directory preceded the author test directory in PYTHONPATH.
Environment: local Windows Python 3.12.14, CPU-only synthetic tests, no server
model work and no learned metric inference or fresh video evaluation. These
tests check interfaces and failure paths; they do not substitute for the
declared server Python/package/CUDA execution. Engineering batch loop was
reviewed statically; no local OpenCV evaluation of its nine pairs was run.

Code/meaning changes reviewed:
Engineering evaluates the nine specified pairs separately, preserves completed
reports and their hashes on a later failure, and reuses source00's already
completed separate job. Its metric definitions are unchanged. The metric
loader now also rejects urllib.urlopen/urlretrieve fallbacks and restores
patched functions in finally. Known local checkpoint URL remapping is not a
network download. This is a guard on the reviewed loader paths, not a universal
OS network sandbox. Dynamic-degree now binds continuous_raft.json by SHA in
EXIT. The reviewed hooks reject nonfinite original flow/track/visibility/cosine
values before downstream score clipping; RAFT requires 40 scores, 20 iterations
per pair, and five consecutive eight-pair windows. CoTracker and all assets
remain local and identity-bound. Runtime must fail on unsupported dependencies,
nonfinite output, wrong counts/identity or exhausted budgets; no silent fallback.

Coverage and interpretation:
Camera motion uses exactly sources00--06 (seven predeclared camera prompts).
I2V-background and engineering use01--09, reusing their successful source00
jobs outside these scopes. The other eight learned/official axes use00--09.
There are 192 new per-video metric observations, plus two already completed
source00 I2V-background observations: 194 applicable observations in total.
This is ten distinct source clusters and one frozen seed, not 81 independent
frames per source, not an official five-sample VBench benchmark. Exposure and
previous development roles remain declared. Use per-video paired arm results;
the raw VBench aggregate mixing Dense and Candidate is neither method's score.
Full 81-frame decode validation does not imply all learned metrics internally
use all 81 frames. Dynamic degree/flow is not universally higher-is-better.
Camera and subject motion can confound flicker. Unlabelled T2V semantic axes
are explicitly inapplicable/unmeasured, not zero or silently completed.
No numerical error envelope, statistical equivalence threshold, blinded human
acceptance, or fair uninstrumented speed comparison is supplied by this scope.
Any success/failure and later cross-source conclusions require result review.
'''

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def write_review(name):
    d = ROOT / name
    expected = EXPECTED[name]
    assert sha(d / 'scope.json') == expected
    s = json.loads((d / 'scope.json').read_text())
    checks = json.loads((d / 'INDEPENDENT_BATCH_CHECKS.json').read_text())
    assert checks['scope_sha256'] == expected
    assert checks['status'] == 'PASS_EXACT_SCOPE_AND_ACTUAL_PAIR_PROVENANCE'
    for filename, digest in s['code_sha256'].items():
        assert sha(d / filename) == digest, filename
    for filename, digest in s['frozen_inputs_sha256'].items():
        assert sha(d / filename) == digest, filename
    assert sha(d / s['config_file']) == s['config_sha256']
    root_audit = d / 'ROOT_INTEGRATION_SELF_AUDIT.txt'
    assert expected in root_audit.read_text()
    detail = ('\nExact scope: ' + name + '\nSHA256: ' + expected +
              '\nSources: ' + ', '.join(s['source_ids']) +
              '\nBudget: ' + json.dumps(s['budget'], sort_keys=True) +
              '\nCode identities: ' + json.dumps(s['code_sha256'], sort_keys=True) + '\n')
    record = {
        'status': 'ACCEPTED', 'scope_sha256': expected, 'reviewer': REVIEWER,
        'date': '2026-11-03', 'scope_id': s['scope_id'],
        'source_ids': s['source_ids'], 'budget': s['budget'],
        'comments': 'One finite exact-scope evaluation job only. No automatic retry; global maximum two live jobs/two GPUs. Quality, numerical certification and speed claims are not accepted by this execution review.',
        'report': 'INDEPENDENT_REVIEW.txt',
        'independent_checks_sha256': sha(d / 'INDEPENDENT_BATCH_CHECKS.json'),
        'root_integration_audit_sha256': sha(root_audit),
        'local_synthetic_tests': {'passed': 14, 'failed': 0, 'seconds': 1.122,
                                  'server_or_gpu_experiment': False},
    }
    for filename, contents in [
        ('INDEPENDENT_REVIEW.txt', COMMON + detail),
        ('INDEPENDENT_REVIEW.json', json.dumps(record, indent=2) + '\n')
    ]:
        with (d / filename).open('x', encoding='utf-8', newline='\n') as f:
            f.write(contents)
    print(name, expected, 'ACCEPTED')

if __name__ == '__main__':
    for name in sys.argv[1:]:
        write_review(name)
