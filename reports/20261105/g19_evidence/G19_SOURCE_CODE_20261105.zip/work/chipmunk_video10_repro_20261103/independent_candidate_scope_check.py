"""Reviewer-only exact continuation audit; writes checks, never authorization."""
import hashlib,json,sys
from pathlib import Path
root=Path(__file__).resolve().parent
number=int(sys.argv[1]);expected=sys.argv[2]
assert 1<=number<=9
source=f'chip10_{number:02}';p=root/f'candidate{number:02}_r1';proof=root/f'native{number:02}_proof'
read=lambda x:json.loads(x.read_text(encoding='utf8'))
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
s=read(p/'scope.json');o=read(root/'candidate00_r2'/'scope.json')
assert sha(p/'scope.json')==expected
changes={k for k in set(s)|set(o) if s.get(k)!=o.get(k)}
assert changes=={'run_ids','scope_id','output_dir','frozen_inputs_sha256'},changes
assert s['code_sha256']==o['code_sha256'] and s['run_ids']==[source]
files=dict(s['code_sha256']);files.update(s['frozen_inputs_sha256']);files[s['config_file']]=s['config_sha256'];files[s['input_manifest_file']]=s['manifest_sha256']
for n,h in files.items():assert sha(p/n)==h,n
sys.path.insert(0,str(p))
from runner_chipmunk import load_bound
from runtime_contract import validate_pair_scopes
cohort=load_bound(p,s,'cohort.json');ref=load_bound(p,s,'dense_reference.json')
assert list(ref)==[source];b=ref[source];row=next(r for r in cohort if r['run_id']==source)
for k in ('image_sha256','prompt_sha256','seed'):assert b[k]==row[k]
ns=read(proof/'scope.json');rv=read(proof/'INDEPENDENT_REVIEW.json');start=read(proof/'START.json');end=read(proof/'EXIT.json')
assert rv['status']=='ACCEPTED' and rv['reviewer']=='/root/independent_math_review'
assert rv['scope_sha256']==sha(proof/'scope.json')==b['scope_sha256']
assert {k:v for k,v in start['scope'].items() if k!='_verified_scope_sha256'}==ns
assert start['scope']['_verified_scope_sha256']==b['scope_sha256']
assert ns['run_ids']==[source] and ns['manifest_sha256']==s['manifest_sha256']
assert end['status']=='SUCCESS' and end['result']['source_id']==source and end['result']['capture_sites']==160
v=end['result']['videos'];assert len(v)==1 and v[0]['arm']=='tap';v=v[0]
assert (v['width'],v['height'],v['frames'],v['fps'])==(832,464,81,16.)
assert v['mp4_sha256']==b['video_sha256']
assert v['initial_noise']=={'sha256':b['initial_latent_sha256'],'shape':b['initial_latent_shape'],'dtype':b['initial_latent_dtype']}
assert [x['step'] for x in v['latent_digests']]==list(range(4))
assert v['expert_dispatch']==[{'step':i,'expert':i//2} for i in range(4)]
for key,name in [('start_receipt','START.json'),('exit_receipt','EXIT.json'),('asset_identities','ASSET_IDENTITIES.json'),('environment','ENVIRONMENT.json')]:
 assert b[key+'_sha256']==sha(proof/name) and b[key+'_path']==ns['output_dir']+'/'+name
assert {k:z['sha256'] for k,z in read(proof/'ASSET_IDENTITIES.json').items()}==b['base_assets_sha256']
assert read(proof/'ENVIRONMENT.json')['runtime_config']==s['required_runtime_config']
validate_pair_scopes(ns,s)
sys.path.insert(0,str(root.parent/'g19_native_trajectory_20261103'))
from independent_canonical_path_checks import check_scope,absolute_strings,canonical_error
paths=check_scope(p);assert paths['status']=='PASS'
for loc,path in absolute_strings(ref):assert canonical_error(path) is None,(loc,path)
result={'status':'PASS_EXACT_SCOPE_AND_SPECIFIC_DENSE_RECEIPTS','source':source,
        'scope_sha256':expected,'bound_unique_files':len(files),'canonical_scope_paths':paths['absolute_paths_checked'],
        'changed_fields':sorted(changes),'execution_code_unchanged':True,'actual_input_consumers_pass':True,
        'Dense_scope_sha256':b['scope_sha256'],'Dense_video_sha256':b['video_sha256'],
        'Dense_elapsed_seconds':end['elapsed_seconds'],'local_Dense_video_rehash':False,
        'runtime_Dense_video_SHA_gate_retained':True,'no_execution_approval_created_by_this_script':True}
(p/'INDEPENDENT_SCOPE_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,indent=2))
