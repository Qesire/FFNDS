"""Rebuild descriptive candidate cost ledger from completed, hash-checked local receipts."""
from pathlib import Path
import json,hashlib,os
os.chdir(Path(__file__).resolve().parent)
from chipmunk_tap import validate_events
rows=[]
for n in range(10):
 p=Path(f'candidate{n:02}_r2/results' if n==0 else f'candidate{n:02}_r1/results')
 if not (p/'EXIT.json').exists():continue
 e=json.loads((p/'EXIT.json').read_text());r=e['result'];events=[json.loads(s) for s in (p/'ffn_events.jsonl').read_text().splitlines()]
 sha=lambda q:hashlib.sha256((p/q).read_bytes()).hexdigest()
 if e['status']!='SUCCESS' or sha('ffn_events.jsonl')!=r['ffn_event_sha256'] or sha('candidate.mp4')!=r['video']['mp4_sha256']:raise ValueError('candidate identity')
 validate_events(events,r['full_select_rtol'])
 dp=Path('native_r5_proof' if n==0 else f'native{n:02}_proof')/'EXIT.json'
 scope=json.loads((p/'scope.json').read_text());ref=p.parent/'dense_reference.json'
 if hashlib.sha256(ref.read_bytes()).hexdigest()!=scope['frozen_inputs_sha256']['dense_reference.json']:raise ValueError('unbound Dense reference')
 baseline=json.loads(ref.read_text())[r['source_id']]
 if hashlib.sha256(dp.read_bytes()).hexdigest()!=baseline['exit_receipt_sha256']:raise ValueError('Dense receipt identity')
 d=json.loads(dp.read_text())['result']
 rows.append({'source_id':r['source_id'],'candidate_mp4_sha256':r['video']['mp4_sha256'],'event_count':len(events),'full_select_compatibility_checks':[z['full_select_check'] for z in events if z.get('full_select_check')],'observed_peak_cache_live_bytes':max(z['cache_live_bytes'] for z in events),'dense_cache_sites':r['dense_cache_sites'],'selected_delta_sites':r['selected_delta_sites'],'candidate_gpu_peak_allocated_bytes':r['gpu_peak_allocated'],'candidate_gpu_peak_reserved_bytes':r['gpu_peak_reserved'],'candidate_model_setup_wall_seconds':r['model_setup_wall_seconds'],'candidate_generation_wall_instrumented_seconds':r['candidate_generation_wall_instrumented'],'candidate_sync_ffn_wall_seconds':sum(z['synchronized_instrumented_wall_seconds'] for z in events),'dense_gpu_peak_allocated_bytes':d.get('gpu_peak_allocated_bytes'),'dense_gpu_peak_reserved_bytes':d.get('gpu_peak_reserved_bytes'),'dense_tap_wall_seconds':next(z['wall_seconds'] for z in d['videos'] if z['arm']=='tap'),'status':'MEASURED_INSTRUMENTED_NOT_FAIR_SPEED_COMPARISON'})
ledger={'status':'PARTIAL_NOT_ALL_TEN' if len(rows)<10 else 'ALL_TEN_LEDGER','method':'global P64 packed dense selected delta','cache_basis':'one expert, 40 layers, 31,668 tokens, H 13,824 + Y 5,120 BF16','cache_bytes':47993487360,'cache_gib':47993487360/1024**3,'note':'Candidate and Dense have different instrumentation. These timings and peaks do not prove a fair speed or memory comparison. Video quality remains under evaluation.','sources':rows}
Path('CANDIDATE_COST_LEDGER.json').write_text(json.dumps(ledger,indent=2)+'\n',encoding='utf8');print('sources',len(rows))
