"""Reviewer-only exact-scope fixtures. No server, model or asset-byte access."""
import hashlib, importlib.util, json, os
from pathlib import Path, PurePosixPath
import sys
from unittest.mock import patch

root=Path(sys.argv[1]).resolve()
read=lambda p:json.loads(p.read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
scope=read(root/'scope.json')
assert sha(root/'scope.json')=='2246d4cb78bed69dc280b1c971cce7413299745be26527ddec1f894ada062575'
identities={**scope['code_sha256'],**scope['frozen_inputs_sha256'],scope['config_file']:scope['config_sha256'],scope['input_manifest_file']:scope['manifest_sha256']}
for name,digest in identities.items():assert sha(root/name)==digest,name
manifest=read(root/scope['asset_manifest_file'])
assert len(manifest['assets'])==15 and len(manifest['source_roots'])==10
paths=[scope['python_executable'],scope['output_dir'],manifest['ffmpeg_path']]+manifest['source_roots']+[x['path'] for x in manifest['assets']]
assert len(paths)==len(set(paths))
for p in paths:
    assert p.startswith('/public/home/scc/pb23061276/') and '..' not in p.split('/') and str(PurePosixPath(p))==p,p
assert scope['phase']=='CHIPMUNK_VIDEO10_METRIC_IDENTITY'
assert scope['budget']['gpus_per_job']==0 and scope['budget']['max_jobs']==1
assert scope['budget']['cpus']==2 and scope['budget']['host_memory_gib']==16
assert scope['budget']['wall_seconds']==1800 and scope['budget']['soft_seconds']==1680

def load(name):
    spec=importlib.util.spec_from_file_location('review_'+name,root/(name+'.py'))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module
g=load('runtime_guard');contract=load('runtime_contract')
base=dict(JobId='123',JobState='RUNNING',UserId='person(1000)',NodeList='compute01',NumNodes='1',NumCPUs='2',TimeLimit='00:30:00',AllocTRES='cpu=2,node=1',ReqTRES='cpu=2,mem=16G,node=1',MinMemoryNode='16384M')
def invoke(changes,host='compute01'):
    record=' '.join(f'{k}={v}' for k,v in {**base,**changes}.items())
    def command(args):return record if args[2]=='job' else 'compute01'
    with patch.object(g.socket,'gethostname',return_value=host),patch.object(g.getpass,'getuser',return_value='person'),patch.dict(g.os.environ,{'SLURM_JOB_ID':'123','SLURM_JOB_NODELIST':''}),patch.object(g,'_command',side_effect=command),patch.object(g.os,'getuid',return_value=1000,create=True):
        alloc=g.require_cpu_compute_allocation()
        contract.validate_allocation(scope,alloc)
        return alloc
invoke({})
counterexamples={
 'GPU1':{'AllocTRES':'cpu=2,node=1,gres/gpu=1'},
 'CPU3':{'NumCPUs':'3'},
 'MEM17':{'ReqTRES':'cpu=2,mem=17G,node=1','MinMemoryNode':'17G'},
 'WALL1801':{'TimeLimit':'00:30:01'},
 'WRONGJOB':{'JobId':'124'},
 'NOTRUNNING':{'JobState':'PENDING'},
 'MEMMISMATCH':{'MinMemoryNode':'15G'},
 'MALFORMEDMEM':{'AllocTRES':'cpu=2,node=1,mem=BAD'},
}
for name,change in counterexamples.items():
    try:invoke(change)
    except RuntimeError:pass
    else:raise AssertionError(name)
try:invoke({},host='tradmin-02')
except RuntimeError:pass
else:raise AssertionError('login host accepted')
print(json.dumps({'status':'PASS_SYNTHETIC_ONLY','scope_sha256':sha(root/'scope.json'),'frozen_local_files':len(identities),'canonical_paths':len(paths),'asset_bytes':sum(x['size_bytes'] for x in manifest['assets']),'adverse_allocation_fixtures':len(counterexamples)+1},indent=2))
