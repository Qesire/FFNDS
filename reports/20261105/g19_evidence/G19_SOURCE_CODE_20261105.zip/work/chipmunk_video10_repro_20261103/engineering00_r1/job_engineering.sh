#!/bin/bash
set -euo pipefail
export OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4
exec /public/home/scc/pb23061276/miniconda3/envs/vbench_i2v_official/bin/python runner_engineering.py --scope "$1" --scope-sha "$2" --output "$3"
