from contextlib import contextmanager
import subprocess
from pathlib import Path

@contextmanager
def safe_loaders(torch, module, dim, mapping, scope):
 from metric_contract import DINO_URL,COTRACKER_URL
 old_init=module.init_submodules; old_hub=torch.hub.load; old_state=torch.hub.load_state_dict_from_url; old_download=torch.hub.download_url_to_file; old_run=subprocess.run
 old_cosine=torch.nn.functional.cosine_similarity
 handles=[]
 def init(dimension_list,local=False,read_frame=False,resolution='1-1'):
  if dimension_list!=[dim] or not local or read_frame or resolution!='16-9':raise RuntimeError('unexpected VBench initializer contract')
  return {dim:mapping}
 def state(url,*args,**kwargs):
  if url==COTRACKER_URL and dim=='camera_motion':path=Path(scope['metric_project_root'])/'code/VBench/models/checkpoints/cotracker2.pth'
  elif url==DINO_URL and dim in ('subject_consistency','i2v_subject','i2v_background'):
   path=(Path(scope['metric_project_root'])/'models/checkpoints/dino_vitbase16_pretrain.pth') if dim=='i2v_background' else (Path(scope['metric_cache_root'])/'dino_model/dino_vitbase16_pretrain.pth')
  else:raise RuntimeError('unapproved hub checkpoint URL: '+str(url))
  if str(path) not in scope['metric_asset_sha256']:raise RuntimeError('hub asset unbound')
  return torch.load(str(path),map_location=kwargs.get('map_location','cpu'),weights_only=True)
 def hub(repo_or_dir,model,*args,**kwargs):
  if repo_or_dir=='facebookresearch/dino:main' and dim=='i2v_background':
   repo_or_dir=str(Path(scope['metric_project_root'])/'models/facebookresearch_dino_main');kwargs['source']='local'
  if kwargs.get('source','github')!='local':raise RuntimeError('remote torch hub forbidden')
  project=Path(scope['metric_project_root']);cache=Path(scope['metric_cache_root'])
  allowed={
   'camera_motion':(project/'facebookresearch/co-tracker','cotracker2'),
   'subject_consistency':(cache/'dino_model/facebookresearch_dino_main','dino_vitb16'),
   'i2v_subject':(cache/'dino_model/facebookresearch_dino_main','dino_vitb16'),
   'i2v_background':(project/'models/facebookresearch_dino_main','dino_vitb16')}
  if dim not in allowed or (Path(repo_or_dir).resolve(),model)!=(allowed[dim][0].resolve(),allowed[dim][1]):raise RuntimeError('unapproved local hub repo/model')
  obj=old_hub(repo_or_dir,model,*args,**kwargs)
  if dim=='camera_motion' and model=='cotracker2':
   def finite_hook(_module,_inputs,output):
    if not isinstance(output,(tuple,list)) or len(output)<2 or not all(torch.isfinite(x).all().item() for x in output[:2]):raise RuntimeError('nonfinite CoTracker tracks/visibility')
   handles.append(obj.register_forward_hook(finite_hook))
  return obj
 def cosine(*args,**kwargs):
  result=old_cosine(*args,**kwargs)
  if not torch.isfinite(result).all().item():raise RuntimeError('nonfinite cosine similarity before aggregation')
  return result
 def no_download(*args,**kwargs):raise RuntimeError('metric download forbidden')
 def run(command,*args,**kwargs):
  executable=command[0] if isinstance(command,(list,tuple)) and command else command
  if not isinstance(executable,str) or Path(executable).name in ('git','wget','curl') or kwargs.get('shell'):raise RuntimeError('unexpected downloader/shell invocation')
  return old_run(command,*args,**kwargs)
 module.init_submodules=init;torch.nn.functional.cosine_similarity=cosine;torch.hub.load=hub;torch.hub.load_state_dict_from_url=state;torch.hub.download_url_to_file=no_download;subprocess.run=run
 try:yield
 finally:
  for handle in handles:handle.remove()
  module.init_submodules=old_init;torch.nn.functional.cosine_similarity=old_cosine;torch.hub.load=old_hub;torch.hub.load_state_dict_from_url=old_state;torch.hub.download_url_to_file=old_download;subprocess.run=old_run
