from pathlib import Path
DINO_URL='https://dl.fbaipublicfiles.com/dino/dino_vitbase16_pretrain/dino_vitbase16_pretrain.pth'
COTRACKER_URL='https://huggingface.co/facebook/cotracker/resolve/main/cotracker2.pth'

def loader_spec(dim, project, cache, site):
 p,c,s=map(Path,(project,cache,site)); d=c/'dino_model'; repo=d/'facebookresearch_dino_main'; w=d/'dino_vitbase16_pretrain.pth'
 specs={
 'subject_consistency':({'repo_or_dir':str(repo),'path':str(w),'model':'dino_vitb16','source':'local','read_frame':False},[w],[repo]),
 'i2v_subject':({'repo_or_dir':str(repo),'path':str(w),'model':'dino_vitb16','source':'local','resolution':'16-9'},[w],[repo]),
 'i2v_background':({'resolution':'16-9'},[p/'models/dino_vitb16_pretrain.pth',p/'models/open_clip_vitb16_pretrain.pth.tar',p/'models/clip_vitb16_pretrain.pth.tar',p/'models/ensemble_lora/adapter_config.json',p/'models/ensemble_lora/adapter_model.safetensors',p/'models/checkpoints/dino_vitbase16_pretrain.pth'],[p/'models/facebookresearch_dino_main']),
 'camera_motion':({'repo':str(p/'facebookresearch/co-tracker'),'model':'cotracker2'},[p/'code/VBench/models/checkpoints/cotracker2.pth'],[p/'facebookresearch/co-tracker']),
 'background_consistency':([str(c/'clip_model/ViT-B-32.pt'),False],[c/'clip_model/ViT-B-32.pt'],[]),
 'temporal_flickering':([],[],[]),
 'motion_smoothness':({'config':str(s/'vbench/third_party/amt/cfgs/AMT-S.yaml'),'ckpt':str(c/'amt_model/amt-s.pth')},[s/'vbench/third_party/amt/cfgs/AMT-S.yaml',c/'amt_model/amt-s.pth'],[]),
 'dynamic_degree':({'model':str(c/'raft_model/models/raft-things.pth')},[c/'raft_model/models/raft-things.pth'],[]),
 'aesthetic_quality':([str(c/'clip_model/ViT-L-14.pt'),str(c/'aesthetic_model/emb_reader')],[c/'clip_model/ViT-L-14.pt',c/'aesthetic_model/emb_reader/sa_0_4_vit_l_14_linear.pth'],[]),
 'imaging_quality':({'model_path':str(c/'pyiqa_model/musiq_spaq_ckpt-358bb6af.pth')},[c/'pyiqa_model/musiq_spaq_ckpt-358bb6af.pth'],[])}
 if dim not in specs:raise ValueError('unknown dimension')
 return specs[dim]

def verify_closure(dim,scope,sha):
 project=Path(scope['metric_project_root']);cache=Path(scope['metric_cache_root']);site=Path(scope['metric_site_packages'])
 for path in (project,cache,site):
  if not path.is_absolute() or not str(path).startswith('/public/home/scc/pb23061276/') or '..' in path.parts or path.resolve()!=path:raise ValueError('metric roots require exact canonical public home paths')
 mapping,weights,repos=loader_spec(dim,project,cache,site);assets=scope['metric_asset_sha256'];code=scope['metric_code_sha256']
 if not code:raise ValueError('empty metric code closure')
 for path in weights:
  if str(path) not in assets:raise ValueError('missing required bound asset '+str(path))
 roots=[site/'vbench',site/'vbench2_beta_i2v',*repos]
 if dim=='i2v_background':roots.extend(site/x for x in ('dreamsim','open_clip','clip','peft'))
 if dim in ('background_consistency','aesthetic_quality'):roots.append(site/'clip')
 if dim=='imaging_quality':roots.append(site/'pyiqa')
 roots.extend(Path(x) for x in scope.get('metric_additional_source_roots',[]))
 for root in roots:
  if not root.is_dir():raise ValueError('missing source root '+str(root))
  files=list(root.rglob('*.py'))
  if not files:raise ValueError('empty source root '+str(root))
  for file in files:
   if str(file) not in code:raise ValueError('unbound source '+str(file))
 for entries in (assets,code):
  for path,digest in entries.items():
   if not Path(path).is_absolute() or not path.startswith('/public/home/scc/pb23061276/') or '..' in Path(path).parts or Path(path).resolve()!=Path(path) or sha(path)!=digest:raise ValueError('asset/source identity mismatch '+path)
 return mapping
