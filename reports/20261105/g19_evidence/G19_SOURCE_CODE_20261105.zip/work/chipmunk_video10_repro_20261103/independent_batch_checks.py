"""Reviewer-only local exact scopes/producers/video/event audit; no evaluation."""
import hashlib,json,math,struct,sys
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parent
EXPECTED={
 'engineering_batch_r1':'d97e5e7f2ffdd0f2af87ff6e70f1b3807a025bb0e47c64b125f817052a64eb03',
 'metric_aesthetic_quality_batch_r1':'415eb974881c734b8628d36e760d7e90377dd4474b5f2a63fa119984236f9bd5',
 'metric_background_consistency_batch_r1':'ad9fdbae353a7eb4bd4782867bcee84577bf5ae165bb4d897d20695bf16319b0',
 'metric_camera_motion_batch_r1':'595b79b7bb5c26cdbc6282e969a9a944d97ca162a6275a8b1f301b061f4bd84c',
 'metric_dynamic_degree_batch_r1':'de166a4417bac5167f01d85459116d526be947505ea6ea19364c01e02a3127b6',
 'metric_i2v_background_batch_r1':'64428a497412f30db1809ee3628216f92e3851858e8408e5a68bd77bda7b807f',
 'metric_i2v_subject_batch_r1':'dbad27681937e256ffabda40cb2457eca3981d3300f0c5e298f3e1105577b5bf',
 'metric_imaging_quality_batch_r1':'ab68c98f2d3c743b778a22661e0fba008128d58de02d06385dea543970c3c32d',
 'metric_motion_smoothness_batch_r1':'7eab5fff167c4f30ccaa5fa8abb57fb2201885dbd24b835ed13ebc1c584bf30b',
 'metric_subject_consistency_batch_r1':'f67d13fe24d3bfea8b4af80cc93c96c1176c0b685c5ff9cb3456d2577a1ba794',
 'metric_temporal_flickering_batch_r1':'8091822b202f001a0578828dc8a265d9e90ae5f4c2c7e15ee2a54752935eeac4'}
def read(p):return json.loads(p.read_text(encoding='utf8'))
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4*1024**2),b''):h.update(b)
 return h.hexdigest()
def canonical(p):assert p.startswith('/public/home/scc/pb23061276/') and '/public/public/' not in p and '..' not in PurePosixPath(p).parts,p
cohort=read(ROOT/'cohort_draft.json');rowmap={r['run_id']:r for r in cohort}
ident=read(ROOT/'metric_assets_firstread.json')
sys.path.insert(0,str(ROOT/'engineering_batch_r1'))
from runner_metrics import bound_json,validate_dimension
from chipmunk_tap import validate_events
from runtime_contract import validate_pair_scopes
pairs={};pair_stats=[]
for i in range(10):
 sid=f'chip10_{i:02d}';row=rowmap[sid]
 idx=read(ROOT/f'pairs{i:02d}_local.json');assert set(idx)=={sid};idx=idx[sid]
 dp=Path(idx['dense']['local']);cp=Path(idx['candidate']['local'])
 results={};scopes={}
 for arm,folder in (('dense',dp),('candidate',cp)):
  s=read(folder/'scope.json');review=read(folder/'INDEPENDENT_REVIEW.json');st=read(folder/'START.json');en=read(folder/'EXIT.json')
  assert sha(folder/'scope.json')==review['scope_sha256']==st['scope']['_verified_scope_sha256']
  assert review['status']=='ACCEPTED' and review['reviewer']=='/root/independent_math_review'
  assert {k:v for k,v in st['scope'].items() if k!='_verified_scope_sha256'}==s
  assert s['run_ids']==[sid] and s['manifest_sha256']==sha(ROOT/'cohort_draft.json')
  assert en['status']=='SUCCESS' and en['exception'] is None and en['result']['source_id']==sid
  assert s['output_dir']==idx[arm]['remote'];canonical(s['output_dir'])
  results[arm]=en['result'];scopes[arm]=s
 d,c=results['dense'],results['candidate'];ds,cs=scopes['dense'],scopes['candidate']
 validate_pair_scopes(ds,cs)
 assert d['capture_sites']==160 and d['status']=='CAPTURE_COMPLETE_NEEDS_INDEPENDENT_ASSET_REVIEW'
 assert c['status']=='CANDIDATE_VIDEO_COMPLETE_NOT_QUALITY_ACCEPTED'
 assert (c['full_ffn_sites'],c['dense_cache_sites'],c['selected_delta_sites'])==(160,80,80)
 assert c['full_select_rtol']==cs['full_select_rtol']==.01
 dv=[v for v in d['videos'] if v['arm']=='tap'];assert len(dv)==1;dv=dv[0];cv=c['video']
 for v in (dv,cv):assert (v['width'],v['height'],v['frames'],v['fps'])==(832,464,81,16.)
 assert c['initial_latent']==dv['initial_noise']
 assert sha(cp/'candidate.mp4')==cv['mp4_sha256']
 event_sha=sha(cp/'ffn_events.jsonl');assert event_sha==c['ffn_event_sha256']
 ev=[json.loads(x) for x in (cp/'ffn_events.jsonl').read_text().splitlines()]
 # Independent mechanical ledger checks before also invoking the frozen validator.
 assert len(ev)==160
 for j,e in enumerate(ev):
  step,layer=divmod(j,40);assert (e['step'],e['layer'],e['expert'])==(step,layer,step//2)
  if step%2:
   ids=e['mask_indices'];assert len(ids)==len(set(ids))==5120 and sorted(ids)==ids and min(ids)>=0 and max(ids)<13824
   assert hashlib.sha256(struct.pack('<5120q',*ids)).hexdigest()==e['mask_sha256']
  if step%2 and layer==0:
   q=e['full_select_check'];assert q['zero_delta_byte_equal'] is True and math.isfinite(q['relative_l2']) and q['relative_l2']<=.01
 validate_events(ev,.01)
 item={k:row[k] for k in ('image_sha256','prompt_sha256','seed')}
 item['dense']={'path':idx['dense']['remote']+'/tap.mp4','sha256':dv['mp4_sha256'],
  'initial_latent_sha256':dv['initial_noise']['sha256'],'exit_receipt_path':idx['dense']['remote']+'/EXIT.json','exit_receipt_sha256':sha(dp/'EXIT.json')}
 item['candidate']={'path':idx['candidate']['remote']+'/candidate.mp4','sha256':cv['mp4_sha256'],
  'initial_latent_sha256':c['initial_latent']['sha256'],'exit_receipt_path':idx['candidate']['remote']+'/EXIT.json','exit_receipt_sha256':sha(cp/'EXIT.json'),
  'event_path':idx['candidate']['remote']+'/ffn_events.jsonl','event_sha256':event_sha}
 pairs[sid]=item
 dense_local=ROOT.parent/'g19_native_trajectory_20261103/pilot_128882_results/tap.mp4' if i==0 else ROOT.parent/'g19_native_capture10_results_20261103'/sid/'tap.mp4'
 dense_rehashed=dense_local.is_file()
 if dense_rehashed:assert sha(dense_local)==dv['mp4_sha256']
 pair_stats.append({'source':sid,'candidate_video_sha256':cv['mp4_sha256'],'dense_video_sha256':dv['mp4_sha256'],
   'candidate_video_independently_rehashed':True,'dense_video_independently_rehashed':dense_rehashed,'event_records':160,
   'full_select_relative_l2':[ev[j]['full_select_check']['relative_l2'] for j in (40,120)],'recipe_sha256':cs['recipe_sha256']})
assert len({v['recipe_sha256'] for v in pair_stats})==1
batch_results=[]
for name,digest in EXPECTED.items():
 p=ROOT/name;s=read(p/'scope.json');assert sha(p/'scope.json')==digest
 assert (p/'ROOT_INTEGRATION_SELF_AUDIT.txt').is_file()
 bind={**s['code_sha256'],**s['frozen_inputs_sha256'],s['config_file']:s['config_sha256'],s['input_manifest_file']:s['manifest_sha256']}
 for f,h in bind.items():assert sha(p/f)==h,(name,f)
 assert read(p/'config.json')==s['required_runtime_config']=={}
 assert bound_json(p.resolve(),s,s['cohort_file'])==cohort
 vm=bound_json(p.resolve(),s,s['video_manifest_file'])
 dim=s.get('dimension');engineering=s['phase']=='CHIPMUNK_VIDEO10_ENGINEERING'
 wanted=[f'chip10_{i:02d}' for i in (range(1,10) if engineering or dim=='i2v_background' else range(7) if dim=='camera_motion' else range(10))]
 assert s['source_ids']==wanted and vm=={k:pairs[k] for k in wanted}
 if engineering:
  assert s['budget']=={'gpus_per_job':0,'max_jobs':1,'cpus':2,'host_memory_gib':16,'wall_seconds':1800,'soft_seconds':1680,'min_free_disk_gib':5}
  assert s['recipe_sha256']==pair_stats[0]['recipe_sha256']
 else:
  assert set(wanted).issubset({r['run_id'] for r in validate_dimension(cohort,dim)})
  for k in ('metric_asset_sha256','metric_code_sha256','metric_package_versions','ffmpeg_path','ffmpeg_sha256','python_executable'):assert s[k]==ident[k],(name,k)
  assert s['budget']=={'gpus_per_job':1,'max_jobs':1,'cpus':4,'host_memory_gib':64,'wall_seconds':3600,'soft_seconds':3480,'gpu_memory_gib':60,'min_free_disk_gib':10}
 paths=[]
 def walk(o):
  if isinstance(o,dict):
   for k,v in o.items():
    if isinstance(k,str) and k.startswith('/public/'):paths.append(k)
    walk(v)
  elif isinstance(o,list):
   for v in o:walk(v)
  elif isinstance(o,str) and o.startswith('/public/'):paths.append(o)
 for o in (s,cohort,vm):walk(o)
 for path in paths:canonical(path)
 check={'status':'PASS_EXACT_SCOPE_AND_ACTUAL_PAIR_PROVENANCE','scope_sha256':digest,'source_ids':wanted,
        'bound_files':len(bind),'canonical_paths':len(paths),'distinct_video_pairs':len(wanted),
        'candidate_events_checked':160*len(wanted),'actual_bound_json_consumers':True,
        'code_review_separate_from_this_checker':True,'no_new_model_or_video_evaluation':True,
        'no_execution_approval_created_by_checker':True}
 (p/'INDEPENDENT_BATCH_CHECKS.json').write_text(json.dumps(check,indent=2)+'\n',encoding='utf8')
 batch_results.append({'folder':name,**check})
out={'pair_evidence':pair_stats,'batches':batch_results,'metric_video_evaluations_planned':sum(2*len(x['source_ids']) for x in batch_results if x['folder'].startswith('metric_')),
     'engineering_pairs_planned':9,'independently_rehashed_candidate_videos':10,
     'independently_rehashed_dense_videos':sum(x['dense_video_independently_rehashed'] for x in pair_stats),
     'new_metric_or_model_or_remote_computation':False}
(ROOT/'INDEPENDENT_BATCH_INPUT_CHECKS.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in out.items() if k not in ('pair_evidence','batches')},indent=2))
for b in batch_results:print(b['folder'],len(b['source_ids']),'pairs',b['bound_files'],'boundfiles',b['scope_sha256'])
