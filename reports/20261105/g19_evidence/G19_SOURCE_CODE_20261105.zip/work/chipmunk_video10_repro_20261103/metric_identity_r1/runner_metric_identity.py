"""Read-only finite metric identity collection; no model inference or GPU use."""
import argparse,hashlib,importlib.metadata,json,os,sys
from pathlib import Path

def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def public_path(raw):
 p=Path(raw)
 if not p.is_absolute() or not raw.startswith('/public/home/scc/pb23061276/') or '..' in p.parts or p.resolve()!=p:raise ValueError('noncanonical path')
 return p

def main():
 a=argparse.ArgumentParser();a.add_argument('--scope',required=True);a.add_argument('--scope-sha',required=True);a.add_argument('--output',required=True);args=a.parse_args()
 from runtime_guard import require_cpu_compute_allocation,verify_frozen_scope,RunReceipt
 from runtime_contract import validate_allocation
 alloc=require_cpu_compute_allocation();root=Path(__file__).resolve().parent;scope=verify_frozen_scope(root,args.scope,args.scope_sha);validate_allocation(scope,alloc)
 if scope.get('phase')!='CHIPMUNK_VIDEO10_METRIC_IDENTITY':raise ValueError('wrong phase')
 if Path(args.output).resolve()!=Path(scope['output_dir']).resolve() or Path(sys.executable).resolve()!=Path(scope['python_executable']).resolve():raise ValueError('output or interpreter mismatch')
 name=scope['asset_manifest_file'];p=(root/name).resolve()
 if not p.is_relative_to(root) or scope['frozen_inputs_sha256'].get(name)!=sha(p):raise ValueError('unbound manifest')
 manifest=json.loads(p.read_text(encoding='utf8'))
 with RunReceipt(args.output,scope,alloc) as receipt:
  assets={}
  for item in manifest['assets']:
   receipt.check_deadline();p=public_path(item['path']);size=p.stat().st_size
   if not p.is_file() or size!=item['size_bytes'] or str(p) in assets:raise ValueError('missing/duplicate/size mismatch asset')
   before=p.stat();digest=sha(p);after=p.stat()
   fields=('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns')
   if any(getattr(before,k)!=getattr(after,k) for k in fields):raise ValueError('asset changed while reading')
   assets[str(p)]={'size_bytes':size,'sha256':digest,'stat':{k:getattr(before,k) for k in fields}}
  source={}
  for name in manifest['source_roots']:
   rootpath=public_path(name)
   if not rootpath.is_dir():raise ValueError('missing source directory')
   files=sorted(rootpath.rglob('*.py'))
   if not files:raise ValueError('empty source tree')
   for path in files:
    receipt.check_deadline();path=public_path(str(path));source[str(path)]=sha(path)
  ffmpeg=public_path(manifest['ffmpeg_path'])
  if ffmpeg.stat().st_size!=manifest['ffmpeg_size_bytes']:raise ValueError('ffmpeg size mismatch')
  versions={x:importlib.metadata.version(x) for x in manifest['packages']}
  output={'status':'FIRST_READ_IDENTITIES_NOT_PRELOCKED','assets':assets,'metric_code_sha256':source,'python_executable':str(Path(sys.executable).resolve()),'package_versions':versions,'ffmpeg_path':str(ffmpeg),'ffmpeg_sha256':sha(ffmpeg)}
  out=receipt.path/'identities.json';out.write_text(json.dumps(output,indent=2),encoding='utf8');receipt.check_deadline()
  receipt.result={'status':output['status'],'asset_count':len(assets),'code_file_count':len(source),'identities_sha256':sha(out),'no_model_inference':True}
if __name__=='__main__':main()
