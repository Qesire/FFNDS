OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 /home/scc/pb23061276/miniconda3/envs/wan/bin/python -B - <<'PY'
import json,struct,pathlib,hashlib,datetime,numpy as np
root=pathlib.Path('/home/scc/pb23061276/projects/wan-quant/weights/Wan2.2-I2V-A14B-LightX2V-Distill-4step')
out={'scope':'read-only inventory: all FFN headers and biases, block20 full W1/W2 bytes; no forward, fitting, spectral estimation or GPU','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':[]}
for p in sorted(root.glob('*_noise_model/*.safetensors')):
 before=p.stat()
 with p.open('rb') as f:
  n=struct.unpack('<Q',f.read(8))[0]; raw_header=f.read(n); h=json.loads(raw_header)
  rec={'path':str(p),'file_size':before.st_size,'mtime_ns':before.st_mtime_ns,'header_sha256':hashlib.sha256(raw_header).hexdigest(),'ffn_headers':{},'tensors':[]}
  for k,v in h.items():
   if '.ffn.' in k: rec['ffn_headers'][k]=v
  keys=sorted(k for k in h if '.ffn.' in k and (k.endswith('.bias') or k.startswith('blocks.20.')))
  for k in keys:
   spec=h[k]; lo,hi=spec['data_offsets']; assert spec['dtype']=='BF16'
   f.seek(8+n+lo); raw=f.read(hi-lo); assert len(raw)==hi-lo
   bits=np.frombuffer(raw,dtype='<u2'); x=(bits.astype(np.uint32)<<16).view(np.float32).reshape(spec['shape'])
   v={'key':k,'shape':spec['shape'],'dtype':spec['dtype'],'bytes_read':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'finite':bool(np.isfinite(x).all()),'nonzero':int(np.count_nonzero(x)),'numel':int(x.size),'min':float(x.min()),'max':float(x.max()),'mean':float(x.mean(dtype=np.float64)),'squared_frobenius':float(np.einsum('i,i->',x.ravel(),x.ravel(),dtype=np.float64))}
   if k=='blocks.20.ffn.0.weight':
    rowsum=x.sum(axis=1,dtype=np.float64)
    v['all_ones_input_direction_energy_fraction']=float(np.dot(rowsum,rowsum)/x.shape[1]/v['squared_frobenius'])
   rec['tensors'].append(v)
   del x,bits,raw
 after=p.stat(); rec['file_stat_unchanged']=before.st_size==after.st_size and before.st_mtime_ns==after.st_mtime_ns
 out['files'].append(rec)
print(json.dumps(out,allow_nan=False))
PY
