import getpass
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import runtime_guard as g


class GuardTests(unittest.TestCase):
    def record(self, **kw):
        uid = os.getuid() if hasattr(os, 'getuid') else 123
        d = dict(JobId='123', JobState='RUNNING', UserId=f'{getpass.getuser()}({uid})',
                 NodeList='anode12', NumNodes='1', NumCPUs='4', TimeLimit='00:30:00',
                 AllocTRES='cpu=4,mem=64G,gres/gpu=1,gres/gpu:a100=1')
        d.update(kw)
        return ' '.join(k+'='+v for k,v in d.items())

    def test_login_rejected_before_scheduler_or_weight_access(self):
        with patch('socket.gethostname', return_value='tradmin-02'), patch.object(g,'_command') as c:
            with self.assertRaisesRegex(RuntimeError, 'LOGIN_NODE_FORBIDDEN'):
                g.require_compute_allocation()
            c.assert_not_called()

    def test_missing_job(self):
        with patch('socket.gethostname', return_value='anode12'), patch.dict(os.environ, {}, clear=True):
            with self.assertRaisesRegex(RuntimeError, 'SLURM_JOB_ID'):
                g.require_compute_allocation()

    def test_real_alloc_membership_required_even_with_env(self):
        with patch('socket.gethostname', return_value='anode99'), patch.dict(os.environ, {'SLURM_JOB_ID':'123'}, clear=False), patch.object(g,'_command',side_effect=[self.record(),'anode12']):
            with self.assertRaisesRegex(RuntimeError, 'outside'):
                g.require_compute_allocation()

    def test_matching_allocation(self):
        with patch('socket.gethostname', return_value='anode12.site'), patch.dict(os.environ, {'SLURM_JOB_ID':'123'}, clear=False), patch.object(g,'_command',side_effect=[self.record(),'anode12']):
            self.assertEqual(g.require_compute_allocation()['job_id'],'123')

    def test_finished_or_wrong_owner_or_gpu_count(self):
        for update in ({'JobState':'COMPLETED'}, {'UserId':'another(123)'}, {'AllocTRES':'cpu=4,gres/gpu=2'},
                       {'NumCPUs':'8'}, {'NumNodes':'2'}, {'TimeLimit':'01:00:00'},
                       {'AllocTRES':'cpu=4,mem=128G,gres/gpu=1'}):
            with patch('socket.gethostname',return_value='anode12'), patch.dict(os.environ,{'SLURM_JOB_ID':'123'},clear=False), patch.object(g,'_command',side_effect=[self.record(**update),'anode12']):
                with self.assertRaises(RuntimeError): g.require_compute_allocation()

    def test_cluster_without_memory_in_alloc_tres(self):
        record=self.record(AllocTRES='cpu=4,node=1,billing=4,gres/gpu=1',ReqTRES='cpu=4,mem=64G,node=1,gres/gpu=1',MinMemoryNode='64G')
        with patch('socket.gethostname',return_value='anode18'), patch.dict(os.environ,{'SLURM_JOB_ID':'123'}), patch.object(g,'_command',side_effect=[record,'anode18']):
            result=g.require_compute_allocation()
            self.assertIn('request_only',result['memory_evidence'])
            self.assertEqual(result['memory_mib'],65536)
        for minimum in ('128G','32G','0G',''):
            record=self.record(AllocTRES='cpu=4,gres/gpu=1',ReqTRES='cpu=4,mem=64G,gres/gpu=1',MinMemoryNode=minimum)
            with patch('socket.gethostname',return_value='anode18'), patch.dict(os.environ,{'SLURM_JOB_ID':'123'}), patch.object(g,'_command',side_effect=[record,'anode18']):
                with self.assertRaises(RuntimeError):g.require_compute_allocation()
        record=self.record(AllocTRES='cpu=4,gres/gpu=1',ReqTRES='cpu=4,mem=64G,gres/gpu=1',MinMemoryNode='65536M')
        with patch('socket.gethostname',return_value='anode18'), patch.dict(os.environ,{'SLURM_JOB_ID':'123'}), patch.object(g,'_command',side_effect=[record,'anode18']):
            self.assertEqual(g.require_compute_allocation()['memory_mib'],65536)
        for requested,minimum in (('','64G'),('cpu=4,mem=128G,gres/gpu=1','128G')):
            record=self.record(AllocTRES='cpu=4,gres/gpu=1',ReqTRES=requested,MinMemoryNode=minimum)
            with patch('socket.gethostname',return_value='anode18'), patch.dict(os.environ,{'SLURM_JOB_ID':'123'}), patch.object(g,'_command',side_effect=[record,'anode18']):
                with self.assertRaises(RuntimeError):g.require_compute_allocation()
        record=self.record(AllocTRES='cpu=4,mem=128,gres/gpu=1',ReqTRES='cpu=4,mem=64G,gres/gpu=1',MinMemoryNode='64G')
        with patch('socket.gethostname',return_value='anode18'), patch.dict(os.environ,{'SLURM_JOB_ID':'123'}), patch.object(g,'_command',side_effect=[record,'anode18']):
            with self.assertRaisesRegex(RuntimeError,'fallback forbidden'):g.require_compute_allocation()

    def test_host_rss_budget_writes_failure(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(g,'process_peak_rss_bytes',return_value=65*1024**3):
            p=Path(tmp)/'run'
            with self.assertRaises(MemoryError):
                with g.RunReceipt(p,{'budget':{'soft_seconds':10,'host_memory_gib':64}}, {}) as r:
                    r.check_deadline()
            self.assertEqual(json.loads((p/'EXIT.json').read_text())['status'],'FAILED_OR_PARTIAL')
            p=Path(tmp)/'terminal'
            with self.assertRaises(MemoryError):
                with g.RunReceipt(p,{'budget':{'soft_seconds':10,'host_memory_gib':64}}, {}): pass
            self.assertEqual(json.loads((p/'EXIT.json').read_text())['status'],'FAILED_OR_PARTIAL')

    def test_fail_receipt_and_exclusive_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'run'; scope={'budget':{'soft_seconds':10}}
            with self.assertRaisesRegex(ValueError,'fixture'):
                with g.RunReceipt(p,scope,{}): raise ValueError('fixture')
            self.assertEqual(json.loads((p/'EXIT.json').read_text())['status'],'FAILED_OR_PARTIAL')
            with self.assertRaises(FileExistsError):
                with g.RunReceipt(p,scope,{}): pass

    def test_review_and_scope_identity(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp); code={}
            for name in ('runner_v7.py','runtime_guard.py','weights_v7.py','core_math.py','statistics_v7.py','structure_v7.py','job_v7.sh','config.json','manifest.json'):
                (p/name).write_text('fixture'); code[name]=g.sha256_file(p/name)
            scope=dict(status='FROZEN_REVIEWED',authors=['author'],code_sha256=code,
                       config_file='config.json',config_sha256=code['config.json'],
                       input_manifest_file='manifest.json',manifest_sha256=code['manifest.json'],
                       budget=dict(gpus_per_job=1,max_jobs=1,wall_seconds=1800,soft_seconds=1650,cpus=4,host_memory_gib=64))
            s=p/'scope.json'; s.write_text(json.dumps(scope)); digest=g.sha256_file(s)
            r=p/'INDEPENDENT_REVIEW.json'; r.write_text(json.dumps(dict(status='REJECTED',reviewer='reviewer',scope_sha256=digest)))
            with self.assertRaisesRegex(RuntimeError,'ACCEPTED'): g.verify_frozen_scope(p,s,digest)
            r.write_text(json.dumps(dict(status='ACCEPTED',reviewer='reviewer',scope_sha256=digest)))
            self.assertEqual(g.verify_frozen_scope(p,s,digest)['_verified_scope_sha256'],digest)
            (p/'runner_v7.py').write_text('changed')
            with self.assertRaisesRegex(RuntimeError,'Identity mismatch'): g.verify_frozen_scope(p,s,digest)


if __name__ == '__main__': unittest.main()
