"""Compute-only finite v7 pilot. Diagnostic results are not confirmations."""
import argparse,json,math,time,hashlib
from pathlib import Path
import numpy as np
from runtime_guard import verify_frozen_scope,require_compute_allocation,RunReceipt
from weights_v7 import load_tensor,rne_lift
from statistics_v7 import rng_for
from core_math import coefficients


def emit(path,row):
    with path.open('a',encoding='utf8') as f: f.write(json.dumps(row,allow_nan=False)+'\n')


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--scope',type=Path,required=True); ap.add_argument('--scope-sha',required=True); args=ap.parse_args()
    allocation=require_compute_allocation()
    root=Path(__file__).resolve().parent; scope=verify_frozen_scope(root,args.scope,args.scope_sha)
    config=json.loads((root/scope['config_file']).read_text(encoding='utf-8-sig'))
    manifest=json.loads((root/scope['input_manifest_file']).read_text(encoding='utf-8-sig'))
    import torch
    import scipy
    import torch.nn.functional as TF
    if not torch.cuda.is_available() or torch.cuda.device_count()!=1: raise RuntimeError('exactly one visible GPU required')
    if torch.cuda.get_device_properties(0).total_memory < 32*1024**3: raise RuntimeError('pilot requires at least 32 GiB GPU memory')
    total_memory=torch.cuda.get_device_properties(0).total_memory
    torch.cuda.set_per_process_memory_fraction(min(.95,40*1024**3/total_memory),0)
    torch.backends.cuda.matmul.allow_tf32=False; torch.backends.cudnn.allow_tf32=False
    torch.set_num_threads(scope['budget']['cpus'])
    if config['layers']!=[0,12,23,37] or config['experts']!=['high','low'] or config['blocks']!=64 or config['development_samples']!=64 or config['candidate_rank']!=32 or config['probe_width']!=64: raise ValueError('only reviewed finite pilot supported')
    out=Path(config['output_dir']); hashes=config.get('tensor_sha256',{})
    with RunReceipt(out,scope,allocation) as receipt:
      receipt.result={'status':'PARTIAL','completed_units':[], 'limitations':['PH1mix/S2 not measured','S3/S4/S5 UNIMPLEMENTED','pilot diagnostics only, not confirmation']}
      emit(out/'metadata.jsonl',{'scope_sha':args.scope_sha,'torch':torch.__version__,'numpy':np.__version__,'scipy':scipy.__version__,'gpu':torch.cuda.get_device_name(),'gpu_memory_bytes':total_memory,'tf32':False,'identity_policy':'header_size_mtime_plus_tensor_sha_on_read','blocks':64,'development_samples':64,'scope_budget':scope['budget']})
      try:
       for expert in config['experts']:
        for layer in config['layers']:
         receipt.check_deadline(); models={}
         for model in ('original','distilled'):
          data={}
          for suffix in ('0.weight','0.bias','2.weight','2.bias'):
           receipt.check_deadline(); key=f'{expert}/{model}/blocks.{layer}.ffn.{suffix}'
           arr,rec=load_tensor(manifest,expert,model,layer,suffix,hashes.get(key)); emit(out/'weights.jsonl',{'expert':expert,'model':model,'layer':layer,**rec}); data[suffix]=arr
          models[model]=data
         oq={k:rne_lift(v) for k,v in models['original'].items()}
         raw=[models['original'],oq,models['distilled']]; labels=['O32','Oq','Dq']
         arms=[{k:torch.as_tensor(v,device='cuda',dtype=torch.float32) for k,v in model.items()} for model in raw]
         d=arms[0]['0.weight'].shape[1]; m=arms[0]['0.weight'].shape[0]; k=32
         def fw(z,w,dtype=torch.float32):
          z=z.to(dtype=dtype); u=(z-z.mean(-1,keepdim=True))*math.sqrt(d/(d-1))
          w1=w['0.weight'].to(dtype); w2=w['2.weight'].to(dtype); b1=w['0.bias'].to(dtype); b2=w['2.bias'].to(dtype)
          return TF.linear(TF.gelu(TF.linear(u,w1,b1),approximate='tanh'),w2,b2)
         dev=rng_for(config['seed'],'DEVELOPMENT',expert,layer,0); held=rng_for(config['seed'],'DEVELOPMENT',expert,layer,1)
         zd=torch.as_tensor(dev.standard_normal((64,d)),device='cuda',dtype=torch.float32)
         shared_tr=torch.as_tensor(dev.standard_normal((d,)),device='cuda',dtype=torch.float64)
         shared_omega=torch.as_tensor(dev.standard_normal((d,64)),device='cuda',dtype=torch.float64)
         shared_omega-=shared_omega.mean(0,keepdim=True)
         zw=held.standard_normal((64,2,d)).astype(np.float32)
         z=torch.as_tensor(np.stack([zw[:,0],-zw[:,0],zw[:,1],-zw[:,1]],axis=1).reshape(-1,d),device='cuda')
         with torch.no_grad():
          ys=[fw(z,w).double() for w in arms]
          o,q,dd=[y.reshape(64,4,-1) for y in ys]; delta=dd-q; rounding=q-o; total=dd-o
          diff_path=out/f'{expert}_{layer}_mean_differences.npz'; np.savez_compressed(diff_path,mean_difference=delta.mean(1).cpu().numpy())
          emit(out/'artifacts.jsonl',{'expert':expert,'layer':layer,'kind':'PAIRED_BLOCK_MEAN_DIFFERENCE','path':diff_path.name,'sha256':hashlib.sha256(diff_path.read_bytes()).hexdigest()})
          sq=lambda x: x.square().sum(-1)
          variance=lambda x: (sq(x[:,0]-x[:,2])+sq(x[:,1]-x[:,3]))/4
          for i in range(64):
           emit(out/'blocks.jsonl',{'expert':expert,'layer':layer,'block_id':i,'stream_id':'PILOT_HOLDOUT','D_O32':float(variance(o)[i]),'D_Oq':float(variance(q)[i]),'D_Dq':float(variance(dd)[i]),'U_checkpoint':float(sq(delta).mean(1)[i]),'U_round':float(sq(rounding).mean(1)[i]),'U_total':float(sq(total).mean(1)[i]),'cross':float((2*delta*rounding).sum(-1).mean(1)[i]),'mean_diff_norm_unbiased':float(((delta[i,0]+delta[i,1])*(delta[i,2]+delta[i,3])).sum()/4)})
          for label,w,y in zip(labels,arms,ys):
           receipt.check_deadline(); unit_start=time.monotonic()
           W=w['0.weight'].double(); W=(W-W.mean(1,keepdim=True))*math.sqrt(d/(d-1)); norms=W.norm(dim=1); p=W/norms.clamp_min(1e-300)[:,None]; V=w['2.weight'].double().T
           a=[]; a_half=[]
           for start in range(0,m,512):
            receipt.check_deadline(); end=min(m,start+512); ac,_=coefficients(norms[start:end].cpu().numpy(),w['0.bias'][start:end].double().cpu().numpy(),4,config['gh_nodes']); ah,_=coefficients(norms[start:end].cpu().numpy(),w['0.bias'][start:end].double().cpu().numpy(),4,max(2,config['gh_nodes']//2)); a.append(ac); a_half.append(ah)
           aa=np.concatenate(a); ah=np.concatenate(a_half); zero=norms.cpu().numpy()==0; aa[zero,1:]=0; ah[zero,1:]=0
           gh_relative_delta=float(np.linalg.norm(aa-ah)/max(np.linalg.norm(aa),1e-300))
           a=torch.as_tensor(aa,device='cuda',dtype=torch.float64)
           A=(p.T*a[:,1])@V; mu=a[:,0]@V+w['2.bias'].double()
           # Output basis is learned only on independent development responses.
           yd=fw(zd,w).double(); mean=yd.mean(0); _,s,vh=torch.linalg.svd(yd-mean,full_matrices=False)
           output_rank=int((s>s[0]*max(yd.shape)*torch.finfo(torch.float64).eps).sum())
           if output_rank<k: raise ValueError('rank deficient development outputs')
           B=vh[:k].T
           # Matrix-free M_t Omega with independent random output slice; all vectors in Pi.
           tr=shared_tr; omega=shared_omega
           weights=a[:,2]*(V@tr); probe=p.T@(weights[:,None]*(p@omega)); probe-=probe.mean(0,keepdim=True)
           U,sv,_=torch.linalg.svd(probe,full_matrices=False); nr=int((sv>sv[0]*max(probe.shape)*torch.finfo(torch.float64).eps).sum())
           if nr<k: raise ValueError('rank deficient random quadratic probe')
           U=U[:,:nr]; small=U.T@(p.T@(weights[:,None]*(p@U))); eig,rot=torch.linalg.eigh(small); Q=U@rot[:,torch.argsort(eig.abs())[-k:]]
           if float(Q.sum(0).abs().max())>1e-8: raise ValueError('quadratic basis outside Pi')
           C=V.T@(a[:,2,None]*(p@Q).square())
           candidate_path=out/f'{expert}_{layer}_{label}_candidate.npz'
           np.savez_compressed(candidate_path,mu=mu.cpu().numpy(),Q=Q.cpu().numpy(),C=C.cpu().numpy(),output_mean=mean.cpu().numpy(),B=B.cpu().numpy())
           emit(out/'artifacts.jsonl',{'expert':expert,'layer':layer,'arm':label,'kind':'CANDIDATE_PARAMETERS','path':candidate_path.name,'sha256':hashlib.sha256(candidate_path.read_bytes()).hexdigest(),'linear_A1':'NOT_SAVED'})
           # Held-out full-vector errors and polynomial residuals.
           zh=z.double(); h=zh@p.T
           H2=(h*h-1)/math.sqrt(2); H3=(h*h*h-3*h)/math.sqrt(6); H4=(h**4-6*h*h+3)/math.sqrt(24)
           pred2=mu+zh@A+(H2*a[:,2])@V
           pred4=pred2+(H3*a[:,3]+H4*a[:,4])@V
           output_pred=mean+(y-mean)@B@B.T
           quad_pred=mu+zh@A+(((zh@Q).square()-1)/math.sqrt(2))@C.T
           e2=sq(y-pred2).reshape(64,4).mean(1); e4=sq(y-pred4).reshape(64,4).mean(1); eo=sq(y-output_pred).reshape(64,4).mean(1); eq=sq(y-quad_pred).reshape(64,4).mean(1)
           spot=fw(z[:1],w,torch.float64); spot32=y[:1]; spot_err=float(sq(spot-spot32)[0]); spot_ref=float(sq(spot)[0])
           peak=torch.cuda.max_memory_allocated()
           if peak>40*1024**3: raise RuntimeError('GPU memory budget exceeded')
           emit(out/'unit_diagnostics.jsonl',{'expert':expert,'layer':layer,'arm':label,'a1_frobenius_sq':float(A.square().sum()),'mean_norm_sq':float(mu.square().sum()),'gh_nodes':config['gh_nodes'],'gh_coefficient_relative_delta_vs_half_nodes':gh_relative_delta,'gpu_peak_allocated_bytes':peak,'unit_seconds':time.monotonic()-unit_start,'ffn_rows':{'heldout_fp32':256,'development_fp32':64,'spot_fp64':1},'output_dev_singular_values':s.cpu().tolist(),'quadratic_probe_rank':nr,'quadratic_basis_sum_max_abs':float(Q.sum(0).abs().max()),'fp64_spot_squared_error':spot_err,'fp64_spot_reference_squared_norm':spot_ref,'numerical_status':'UNASSESSED_NO_PREREGISTERED_THRESHOLD','main_mac_ledger':{'original':2*d*m,'output_candidate':d*m+m*k+k*d,'quadratic_candidate':d*d+2*d*k,'excludes':'setup, activation, memory, biases'},'status':'PILOT_DEVELOPMENT_HOLDOUT_DIAGNOSTIC'})
           for i in range(64): emit(out/'candidate_blocks.jsonl',{'expert':expert,'layer':layer,'arm':label,'block_id':i,'stream_id':'PILOT_HOLDOUT','Q2_residual':float(e2[i]),'Q4_residual':float(e4[i]),'output_projection_error':float(eo[i]),'quadratic_candidate_error':float(eq[i])})
           receipt.result['completed_units'].append(f'{expert}/{layer}/{label}')
           del W,p,V,a,A,mu,yd,B,tr,omega,weights,probe,U,sv,small,eig,rot,Q,C,zh,h,H2,H3,H4,pred2,pred4,output_pred,quad_pred
         del arms,models,oq,raw,ys; torch.cuda.empty_cache()
       receipt.result['status']='PILOT_COMPLETE_WITH_DECLARED_LIMITATIONS'
      except TimeoutError:
       receipt.result['status']='PARTIAL_TIMELIMIT'
       raise

if __name__=='__main__': main()

