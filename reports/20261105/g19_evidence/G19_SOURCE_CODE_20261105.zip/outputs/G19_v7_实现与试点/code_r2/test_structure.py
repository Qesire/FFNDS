import unittest
import json,hashlib,struct,tempfile
from pathlib import Path
from unittest.mock import patch
import numpy as np
from structure_v7 import fit_output_basis, heldout_output_error, quadratic_candidate, quadratic_heldout, representation_cost
from weights_v7 import rne_lift,load_tensor
class StructureTests(unittest.TestCase):
    def test_output_heldout(self):
        x=np.array([[1.,0],[2,0],[-1,0]])
        f=fit_output_basis(x,1); y=heldout_output_error(np.array([[0.,3.]]),f)
        self.assertAlmostEqual(y['squared_error_per_sample'][0],9.)
    def test_separable_quadratic(self):
        p=np.linalg.qr(np.eye(4)[:,:3]-np.ones((4,3))/4)[0].T; v=np.eye(3); a=np.ones(3); t=np.array([[1.],[2.],[-3.]])
        fit=quadratic_candidate(p,v,a,t,p.T,3)
        z=np.array([[1.,2.,3.,4.],[0.,0.,0.,0.]])
        target=((z@p.T)**2-1)/np.sqrt(2)
        result=quadratic_heldout(z,target,np.zeros(3),np.zeros((4,3)),fit)
        np.testing.assert_allclose(result['squared_error_per_sample'],0,atol=1e-20)
    def test_holdout_may_reject_development_rank(self):
        fit=fit_output_basis(np.array([[-1.,0.],[1.,0.]]),1)
        result=heldout_output_error(np.array([[0.,4.]]),fit)
        self.assertAlmostEqual(result['squared_error_per_sample'][0],16.)
    def test_rank_deficient_probe_rejected(self):
        p=np.array([[1.,-1.,0.]])/np.sqrt(2)
        with self.assertRaises(ValueError): quadratic_candidate(p,np.ones((1,2)),np.ones(1),np.ones((2,1)),np.eye(3),2)
    def test_bf16_ties(self):
        bits=np.array([0x3f808000,0x3f818000],dtype=np.uint32)
        np.testing.assert_array_equal(rne_lift(bits.view(np.float32)).view(np.uint32),[0x3f800000,0x3f820000])
    def test_reader_checks_bytes_and_hash(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'tiny.safetensors'; key='blocks.0.ffn.0.bias'
            spec={'dtype':'F32','shape':[2],'data_offsets':[0,8]}; header=json.dumps({key:spec}).encode(); raw=np.array([1.,2.],dtype='<f4').tobytes()
            path.write_bytes(struct.pack('<Q',len(header))+header+raw); stat=path.stat()
            manifest={'files':{str(path):{'size':stat.st_size,'mtime_ns':stat.st_mtime_ns,'header_sha256':hashlib.sha256(header).hexdigest()}},'tensors':{'high/original/'+key:{'path':str(path),'spec':spec}}}
            with patch('runtime_guard.require_compute_allocation',return_value={}):
                x,receipt=load_tensor(manifest,'high','original',0,'0.bias',None)
                np.testing.assert_equal(x,[1.,2.]); self.assertEqual(receipt['identity_status'],'FIRST_READ_IDENTITY')
                with self.assertRaises(ValueError): load_tensor(manifest,'high','original',0,'0.bias','0'*64)
    def test_cost(self):
        self.assertEqual(representation_cost(4,8,2)['output_projected_macs'],56)
if __name__=='__main__': unittest.main()


