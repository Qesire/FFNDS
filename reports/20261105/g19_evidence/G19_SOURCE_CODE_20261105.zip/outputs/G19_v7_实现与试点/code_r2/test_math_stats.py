import unittest, numpy as np
import core_math as c
import statistics_v7 as s
class TestV7(unittest.TestCase):
 def test_precision(self):
  bits=np.array([0x3f808000,0x3f818000,0xbf808000],dtype=np.uint32)
  x=bits.view(np.float32); np.testing.assert_array_equal(c.bf16_round(x),[1,1.015625,-1]); np.testing.assert_array_equal(c.bf16_decode(np.array([0x3f80,0xbf80],dtype=np.uint16)),[1,-1])
  with self.assertRaises(ValueError): c.bf16_round(np.array([np.finfo(np.float32).max],dtype=np.float32))
 def test_projection_and_ffn(self):
  z=np.array([[1.,2.,3.]]); u=c.project_gaussian(z); self.assertAlmostEqual(float(u.sum()),0.)
  W=np.array([[1.,2.,-1.],[2.,0.,1.]]); V=np.array([[1.,-1.],[2.,3.],[0.,4.]]); b=np.array([.2,-.1]); b2=np.arange(3.)
  np.testing.assert_allclose(c.evaluate_ffn(z,W,V,b,b2),c.tanh_gelu(u@W.T+b)@V.T+b2)
 def test_coeffs_stein(self):
  beta=np.array([[1.,-1.,0.],[0.,0.,0.]]); V=np.array([[1.,2.],[3.,4.]]); norm=np.linalg.norm(beta,axis=1); a,g=c.coefficients(norm,np.array([.2,.1]),4,192)
  np.testing.assert_allclose(c.a1_matrix(beta,V,a),beta.T@(g[:,None]*V),atol=1e-12)
  self.assertAlmostEqual(c.hermite_approx(np.zeros((1,3)),beta,V,np.zeros(2),a).shape[1],2)
 def test_tail(self):
  self.assertEqual(c.sobolev_tail_bound(6,{2:0},2,2)['upper'],1); self.assertAlmostEqual(c.sobolev_tail_bound(2.6,{2:1},2,2)['upper'],.1)
  with self.assertRaises(ValueError): c.sobolev_tail_bound(1,{2:1},2,2)
 def test_linear_and_paired(self):
  rng=np.random.default_rng(4); z=rng.normal(size=(30,3)); w=rng.normal(size=(30,3)); A=np.array([[1.,2.],[3.,-1.],[.5,.25]]); F=lambda x:x@A; P=np.zeros((3,3))
  q=c.pick_freeze_block(F,z,w,P,A); o=c.paired_block(F,F,F,z,w,A)
  np.testing.assert_allclose(q['Y'],q['C']); np.testing.assert_allclose(q['Y'],o['D']); self.assertEqual(np.var(q['Y']/o['D']),0.)
  self.assertTrue(np.allclose(c.pick_freeze_block(F,z,w,np.eye(3)-np.ones((3,3))/3)['Y'],.5*np.sum(((z-w)@np.ones((3,3))/3@A)**2,axis=1)))
  with self.assertRaises(ValueError): c.pick_freeze_block(F,z,w,np.eye(3))
 def test_fieller_degenerate_sets(self):
  self.assertEqual(s.fieller_quadratic(0,0,1)[0],[])
  self.assertEqual(s.fieller_quadratic(0,2,-4)[0],[[None,2]])
  self.assertEqual(s.fieller_quadratic(0,-2,4)[0],[[2,None]])
  for d in ([0,0,0,0],[-1,-1,-1,-1],[-2,-1,1,2]):
   self.assertFalse(s.fieller_set([1,1,1,1],d)['decision_eligible'])
 def test_projection_full_support_zero_risk(self):
  rng=np.random.default_rng(2); z=rng.normal(size=(20,4)); w=rng.normal(size=(20,4)); P=np.eye(4)-np.ones((4,4))/4
  F=lambda x: c.tanh_gelu(x@P)@np.array([[1.,2.],[2.,1.],[.4,.2],[-1.,2.]])
  np.testing.assert_allclose(c.pick_freeze_block(F,z,w,P)['Y'],0,atol=1e-28)
 def test_fixed_basis_matches_dense(self):
  rng=np.random.default_rng(77); d=5; x=rng.normal(size=(d,3)); x-=x.mean(axis=0); B=np.linalg.qr(x)[0]; P=B@B.T
  z=rng.normal(size=(9,d)); w=rng.normal(size=(9,d)); A=rng.normal(size=(d,4)); F=lambda x:x@A
  fixed=c.FixedProjectionBasis(B); a=fixed.block(F,z,w,A); b=c.pick_freeze_block(F,z,w,P,A)
  np.testing.assert_allclose(a['Y'],b['Y'],atol=1e-12); np.testing.assert_allclose(a['C'],b['C'],atol=1e-12); self.assertAlmostEqual(a['c'],b['c'])
  with self.assertRaises(ValueError): c.FixedProjectionBasis(np.ones((d,1)))
  with self.assertRaises(ValueError): fixed.basis[0,0]=0
 def test_fieller_collinear_stability(self):
  d=np.linspace(10,20,200); u=1.23456789*d
  r=s.fieller_set(u,d); self.assertAlmostEqual(r['intervals'][0][0],1.23456789,places=7); self.assertAlmostEqual(r['intervals'][0][1],1.23456789,places=7)
 def test_cross_and_wrong_ahat(self):
  z=np.array([[1.,-1.,0.]]); w=np.array([[2.,-2.,0.]]); F0=lambda x:x; Fq=lambda x:2*x; Fd=lambda x:5*x
  o=c.paired_block(F0,Fq,Fd,z,w,np.eye(3)); np.testing.assert_allclose(o['U_total'],o['U_checkpoint']+o['U_round']+o['cross']); self.assertGreater(float(o['cross'][0]),0)
  # F=2z, Ahat=z, P=0: 4=1+1+2 per ||z||² in expectation.
  A=2*np.eye(3); Ahat=np.eye(3); self.assertAlmostEqual(np.linalg.norm(A)**2,np.linalg.norm(Ahat)**2+np.linalg.norm(A-Ahat)**2+2*np.sum(Ahat*(A-Ahat)))
 def test_wrong_ahat_cv_expectation(self):
  # P=0, true F=2z, Ahat=z: E[Y]=4, E[C]=1, CV retains E[Y].
  from numpy.polynomial.hermite import hermgauss
  x,w=hermgauss(8); x=x*np.sqrt(2); w=w/np.sqrt(np.pi)
  z=np.repeat(x,8); zz=np.tile(x,8); weights=np.repeat(w,8)*np.tile(w,8)
  Y=2*(z-zz)**2; C=.5*(z-zz)**2
  self.assertAlmostEqual(float(weights@Y),4); self.assertAlmostEqual(float(weights@C),1)
  self.assertAlmostEqual(float(weights@(Y-3.7*(C-1))),4)
 def test_cv_fixed_signed(self):
  x=s.apply_cv(np.array([0.,2.]),np.array([4.,1.]),2.,1.)
  np.testing.assert_array_equal(x,[-2.,3.])
 def test_separable_fullrank(self):
  # Product-normal Gauss-Hermite confirms H2=I, E||F||²=d, O(d) evaluation.
  from numpy.polynomial.hermite import hermgauss
  x,w=hermgauss(8); x=x*np.sqrt(2); w=w/np.sqrt(np.pi); h2=(x*x-1)/np.sqrt(2)
  self.assertAlmostEqual(float(w@h2),0); self.assertAlmostEqual(float(w@(h2*h2)),1)
  d=7; H2=np.eye(d); self.assertEqual(np.linalg.matrix_rank(H2),d)
  z=np.arange(d,dtype=float); F=(z*z-1)/np.sqrt(2); self.assertEqual(F.shape,(d,))
 def test_polynomial_residual_bound(self):
  from numpy.polynomial.hermite import hermgauss
  x,w=hermgauss(10); x=x*np.sqrt(2); w=w/np.sqrt(np.pi)
  h2=(x*x-1)/np.sqrt(2); h3=(x**3-3*x)/np.sqrt(6)
  F=2*h2+h3; G=1.4*h2
  self.assertAlmostEqual(float(w@((F-G)**2)),1+.6**2,places=12)
  self.assertGreater(float(w@((F-G)**2)),1.)
 def test_residual_and_estimands(self):
  z=np.array([[1.,-1.,0.]]);w=np.array([[.4,-.2,0.]]); F=lambda x:x*x; G=lambda x:np.zeros_like(x)
  self.assertEqual(c.polynomial_residual_block(F,G,z,w)['status'],'ALG_EXACT_EXPECTATION_RELATION_ONLY'); self.assertNotEqual(c.representation_error_block(F,G,z,w)['estimand'],c.pick_freeze_block(F,z,w,np.zeros((3,3)))['estimand'])
 def test_mean_shift_and_affine_control(self):
  z=np.array([[1.,-1.,0.]]); w=np.array([[2.,-2.,0.]])
  F=lambda x:x; G=lambda x:x+np.array([3.,-2.,1.])
  out=c.paired_block(F,F,G,z,w); self.assertAlmostEqual(float(out['U_checkpoint'][0]),14); self.assertAlmostEqual(float(out['mean_diff_norm_unbiased'][0]),14)
  ctrl=c.affine_error_control(z,w,np.array([3.,-2.,1.]),np.zeros((3,3))); self.assertAlmostEqual(ctrl['c'],14); self.assertAlmostEqual(float(ctrl['C'][0]),14)
 def test_sample_covariance_pseudorank(self):
  x=np.random.default_rng(123).normal(size=(3,8)); C=np.cov(x,rowvar=False)
  self.assertLessEqual(np.linalg.matrix_rank(C,tol=1e-10),2)
  self.assertEqual(np.linalg.matrix_rank(np.eye(8)),8)
 def test_cv_ratio_and_plan(self):
  rng=np.random.default_rng(8); X=rng.chisquare(3,512); p=s.cv_pilot(X,X,X,3.,cost_raw=1,cost_cv=1,delta=.01,alpha=.025,K=16)
  self.assertEqual(p['lambda'],0); self.assertFalse(p['cv_selected']); self.assertLess(p['s_psi'],1e-14)
  self.assertEqual(s.plan_n(100,.01,.025,16)['status'],'UNDERPOWERED')
 def test_fieller(self):
  U=np.array([1.,2.,3.,4.]); D=np.array([1.,2.,3.,4.]); r=s.fieller_set(U,D); self.assertAlmostEqual(r['intervals'][0][0],1); self.assertAlmostEqual(r['intervals'][0][1],1)
  r=s.fieller_set([1,1,1,1],[-2,-1,1,2]); self.assertFalse(r['decision_eligible']); self.assertEqual(len(r['intervals']),2)
  r=s.fieller_set([0,0,0,0],[-2,-1,1,2]); self.assertEqual(r['intervals'],[[None,None]])
 def test_strata_and_rng(self):
  v=s.stratified_mean_variance([[1,2,3],[4,5,6]],[[.1,.2,.3],[.2,.3,.4]],[10,10]); self.assertAlmostEqual(v['mean'],3.5); self.assertAlmostEqual(v['variance'],.25*(.7/3+.3*.2/3)+.25*(.7/3+.3*.3/3))
  a=s.rng_for(7,'DEVELOPMENT','high',0).normal(size=4); b=s.rng_for(7,'CONFIRMATION','high',0).normal(size=4); self.assertFalse(np.array_equal(a,b)); np.testing.assert_array_equal(a,s.rng_for(7,'DEVELOPMENT','high',0).normal(size=4))
if __name__=='__main__': unittest.main(verbosity=2)

