"""Static identity packaging only. Does not read weights or submit jobs."""
import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
code=['core_math.py','statistics_v7.py','structure_v7.py','weights_v7.py',
      'runtime_guard.py','runner_v7.py','job_v7.sh','test_math_stats.py',
      'test_structure.py','test_runtime_guard.py']
scope={
 'scope_id':'G19_V7_RESOURCE_PILOT_20261102_R2',
 'previous_scope':'R1 job 127851 failed on anode18 before torch/weights: AllocTRES omitted memory; R1 outputs and review retained unchanged. R2 adapts scheduler request parsing and observes process RSS; no automatic retry.',
 'status':'FROZEN_REVIEWED',
 'activation_requires':'INDEPENDENT_REVIEW.json ACCEPTED with this exact scope SHA; otherwise entrypoint refuses execution',
 'authors':['/root','/root/terra_p0_implementation','/root/terra_v7_runner'],
 'code_sha256':{f:sha(root/f) for f in code},
 'config_file':'pilot_config.json','config_sha256':sha(root/'pilot_config.json'),
 'input_manifest_file':'input_manifest.json','manifest_sha256':sha(root/'input_manifest.json'),
 'design_registry_sha256':'2ba95431248fa6a1fabec6cb2218d5671b34ab5f5ef5f4da5c6fed05c08c87e6',
 'budget':{'max_jobs':1,'gpus_per_job':1,'session_max_gpus':2,'cpus':4,
           'host_memory_gib':64,'gpu_allocation_peak_gib':40,'wall_seconds':1800,'soft_seconds':1650},
 'units':[{'expert':e,'layer':l,'arm':a} for e in ['high','low'] for l in [0,12,23,37] for a in ['O32','Oq','Dq']],
 'unit_count':24,
 'question':'Can the real lifted FFN probes execute within budget, and what competing input/output/quadratic structure diagnostics warrant the next all-layer or representative-depth experiment?',
 'competing_predictions':[
    'small first-chaos input rank does not imply small full nonlinear error',
    'poor low-rank output projection can coexist with a useful separable quadratic representation',
    'similar first-chaos energy can coexist with nonzero paired checkpoint function difference'],
 'claims_allowed':['FIRST_READ_PROVENANCE','PILOT_RESOURCE_MEASUREMENTS','EXPLORATORY_FUNCTION_DIAGNOSTICS'],
 'claims_forbidden':['numerical certificate','finite-sample confidence certificate','statistical confirmation','all-layer generalization','native BF16 accuracy','video quality','actual deployed speedup'],
 'identity_policy':'Frozen header SHA, file size and mtime, dtype/shape/offset; raw tensor SHA established and recorded during this first-read pilot. Confirmation must precommit those tensor hashes.',
 'memory_policy':'Use AllocTRES memory when present; otherwise require agreeing ReqTRES and MinMemoryNode <=64GiB. Fallback is requested memory, not proof of hard cgroup enforcement. Observe process peak RSS at checkpoints and EXIT; exceeding64GiB fails.',
 'sampling':'Preselected first draw in each of four strata, both experts and all arms; all arms share inputs. DEVELOPMENT streams 0 and 1 only; confirmation streams untouched.',
 'failure_policy':'No retry/redraw/extra job. Partial outputs and failed EXIT retained; new scope and exact review needed for any followup.',
 'known_limits':['Only S0 resource/numeric pilot, not S1 census or S2 confirmatory map',
                 'GH192/96 and FP64 one-row comparisons are indicators, not rigorous error bounds',
                 'Output rank32 and quadratic rank32 are initial probe candidates, not optimized architectures',
                 'A1 computed but not persisted; quadratic candidate reconstruction requires weights',
                 'Hard kill can leave START without EXIT; such run is incomplete']}
(root/'scope.json').write_text(json.dumps(scope,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('scope_sha256='+sha(root/'scope.json'))
