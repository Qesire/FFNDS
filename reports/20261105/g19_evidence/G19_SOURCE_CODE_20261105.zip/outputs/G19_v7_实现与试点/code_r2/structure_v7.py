"""Exploratory structure probes; fit and evaluation samples must be disjoint."""
import numpy as np


def fit_output_basis(development, rank):
    x=np.asarray(development,dtype=np.float64)
    if x.ndim!=2 or not 0<rank<=min(x.shape): raise ValueError('invalid development or rank')
    mean=x.mean(0); _,s,vt=np.linalg.svd(x-mean,full_matrices=False)
    return {'mean':mean,'basis':vt[:rank].T,'singular_values':s,'sample_count':len(x),'status':'DEVELOPMENT_ONLY'}


def heldout_output_error(heldout,fit):
    x=np.asarray(heldout,dtype=np.float64)-fit['mean']; b=fit['basis']; residual=x-(x@b)@b.T
    return {'squared_error_per_sample':np.sum(residual**2,axis=1),'energy_about_development_mean_per_sample':np.sum(x**2,axis=1),'status':'HELDOUT_DIRECT_FULL_VECTOR'}


def quadratic_candidate(p,v,a2,output_directions,probe,rank):
    """Random slice combination: matrix-free M_t X, probe subspace eigensystem.
    This is an exploratory shared-basis candidate, not proof of joint diagonalization.
    p=(m,d), v=(m,o), output_directions=(o,s), probe=(d,k).
    """
    p=np.asarray(p,dtype=float); v=np.asarray(v,dtype=float); a2=np.asarray(a2,dtype=float)
    t=np.asarray(output_directions,dtype=float); x=np.asarray(probe,dtype=float)
    if p.ndim!=2 or v.ndim!=2 or v.shape[0]!=len(p) or a2.shape!=(len(p),) or t.shape[0]!=v.shape[1] or x.shape[0]!=p.shape[1] or not 0<rank<=x.shape[1]: raise ValueError('invalid geometry')
    # A deterministic mixture of random slices; use independent directions for checks.
    weights=(v@t).sum(axis=1)*a2
    x=x-x.mean(axis=0,keepdims=True)
    y=p.T@(weights[:,None]*(p@x)); y=y-y.mean(axis=0,keepdims=True)
    q,s,_=np.linalg.svd(y,full_matrices=False)
    numerical_rank=int(np.sum(s > (s[0]*max(y.shape)*np.finfo(float).eps))) if len(s) and s[0]>0 else 0
    if numerical_rank<rank: raise ValueError('rank-deficient quadratic probe')
    q=q[:,:numerical_rank]
    small=q.T@(p.T@(weights[:,None]*(p@q))); eig,rot=np.linalg.eigh(small)
    basis=q@rot[:,np.argsort(np.abs(eig))[-rank:]]; coeff=v.T@(a2[:,None]*(p@basis)**2)
    return {'basis':basis,'coefficients':coeff,'status':'EXPLORATORY_RANDOM_SLICE_CANDIDATE'}


def quadratic_predict(z,mean,A,fit):
    z=np.asarray(z,dtype=float); q=fit['basis']; c=fit['coefficients']
    return mean+z@A+(((z@q)**2-1)/np.sqrt(2))@c.T


def quadratic_heldout(z,actual,mean,A,fit):
    err=np.asarray(actual)-quadratic_predict(z,mean,A,fit)
    return {'squared_error_per_sample':np.sum(err**2,axis=1),'status':'HELDOUT_DIRECT_FULL_VECTOR'}


def representation_cost(d,m,k):
    return {'original_ffn_macs':2*d*m,'output_projected_macs':d*m+m*k+k*d,'quadratic_candidate_macs':d*d+2*d*k,'scope':'MAIN_MAC_ONLY; storage, bias, activation, setup and memory traffic excluded'}


