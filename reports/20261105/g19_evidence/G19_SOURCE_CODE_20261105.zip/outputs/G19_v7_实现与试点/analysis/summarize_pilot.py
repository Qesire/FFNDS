"""Read-only local summary of existing S0 receipts; no weights/model execution."""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
from collections import defaultdict

base=Path(__file__).resolve().parents[2]
parser=argparse.ArgumentParser()
parser.add_argument('--evidence',type=Path,default=base/'work'/'g19_v7_pilot_results')
parser.add_argument('--out',type=Path,default=base/'outputs'/'G19_v7_实现与试点')
args=parser.parse_args()
root=args.evidence
out=args.out
out.mkdir(exist_ok=True)
def rows(name):
    p=root/name
    return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s.strip()] if p.exists() else []
def mean(values):
    v=list(values)
    return sum(v)/len(v)
def ratio(a,b): return a/b if b>0 else None
def rms(v): return math.sqrt(v) if v is not None and v>=0 else None
blocks=rows('blocks.jsonl'); candidates=rows('candidate_blocks.jsonl'); units=rows('unit_diagnostics.jsonl')
group=defaultdict(list); cg=defaultdict(list)
for b in blocks: group[b['expert'],b['layer']].append(b)
for b in candidates: cg[b['expert'],b['layer'],b['arm']].append(b)
assert all(len(v)==len({x['block_id'] for x in v}) for v in group.values())
assert all(len(v)==len({x['block_id'] for x in v}) for v in cg.values())
records=[]
for u in units:
    key=(u['expert'],u['layer']); bb=group[key]; cc=cg[key+(u['arm'],)]
    denom=mean(x['D_'+u['arm']] for x in bb); doq=mean(x['D_Oq'] for x in bb)
    rec={k:u[k] for k in ('expert','layer','arm')}
    rec.update(block_count=len(bb),candidate_block_count=len(cc),variance_point=denom,
               first_chaos_share_point=ratio(u['a1_frobenius_sq'],denom),
               checkpoint_relative_rms_point=rms(ratio(mean(x['U_checkpoint'] for x in bb),doq)),
               rounding_relative_rms_point=rms(ratio(mean(x['U_round'] for x in bb),doq)),
               fp32_fp64_spot_relative_rms=rms(ratio(u['fp64_spot_squared_error'],u['fp64_spot_reference_squared_norm'])),
               gh_coeff_relative_delta=u['gh_coefficient_relative_delta_vs_half_nodes'],
               peak_gpu_gib=u['gpu_peak_allocated_bytes']/1024**3)
    for metric in ('Q2_residual','Q4_residual','output_projection_error','quadratic_candidate_error'):
        rec[metric+'_relative_mse_point']=ratio(mean(x[metric] for x in cc),denom)
    records.append(rec)
cross=max((abs(x['U_total']-x['U_checkpoint']-x['U_round']-x['cross'])/max(x['U_total'],1e-300) for x in blocks),default=None)
receipt=json.loads((root/'EXIT.json').read_text(encoding='utf-8')) if (root/'EXIT.json').exists() else {'status':'MISSING_EXIT_INCOMPLETE'}
weights=rows('weights.jsonl')
tensor_hashes={f"{x['expert']}/{x['model']}/{x['key']}":x['sha256'] for x in weights}
summary={'status':'PILOT_DIAGNOSTICS_ONLY','exit':receipt,'observed_unit_count':len(units),
         'paired_block_count':len(blocks),'candidate_block_count':len(candidates),
         'raw_tensor_receipt_count':len(weights),'unique_tensor_identities':len(tensor_hashes),
         'cross_decomposition_max_relative_roundoff':cross,'records':records,
         'limits':['64-block pilot, no confidence/power assertion','No all-layer extrapolation',
                   'Numerical deltas unassessed indicators, not certificates',
                   'Q2/Q4 are direct fixed-polynomial residual points, not rigorous tail upper bounds',
                   'Rank32 and 64-development-sample candidate outcomes are not optimal representation errors',
                   'Point ratios may exceed natural exact ranges due sampling; no clipping'],
         'source_files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.glob('*.json*')}}
(out/'pilot_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(out/'first_read_tensor_hashes.json').write_text(json.dumps(tensor_hashes,indent=2)+'\n',encoding='utf-8')
if records:
    with (out/'pilot_units.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
print(json.dumps({'exit_status':receipt['status'],'unit_count':len(units),'blocks':len(blocks),'candidate_blocks':len(candidates),'tensor_count':len(weights),'cross_roundoff':cross,'records':records},ensure_ascii=False))
