import torch,unittest
from odd_math import evaluate_batch
from secant_math import gelu_tanh
class OddTest(unittest.TestCase):
 def setUp(self):torch.manual_seed(7);torch.set_default_dtype(torch.float64)
 def test_gelu_reflection(self):
  x=torch.linspace(-8,8,101);self.assertTrue(torch.allclose(gelu_tanh(x)-gelu_tanh(-x),x,rtol=1e-14,atol=1e-14))
 def test_opposite_endpoint_exact_and_bias_cancels(self):
  z=torch.randn(10,3);w1=torch.randn(4,3);w2=torch.randn(3,4);b=torch.zeros(4);b2=torch.randn(3);g=torch.ones(10,3);r=evaluate_batch(-z,z,w1,w2,b,b2,g,g)
  self.assertLess(float(r['output_even_error_sq'].max()),1e-25);self.assertLess(float(r['hidden_vector_closure_sq'].max()),1e-25)
  r2=evaluate_batch(-z,z,w1,w2,b,b2+300,g,g);self.assertTrue(torch.equal(r['output_target_sq'],r2['output_target_sq']))
 def test_general_closure_gate_and_signed_cross(self):
  z0=torch.randn(10,3);z1=torch.randn(10,3);w1=torch.randn(4,3);w2=torch.randn(3,4);b1=torch.randn(4);b2=torch.randn(3);g0=torch.randn(10,3);g1=torch.randn(10,3);r=evaluate_batch(z0,z1,w1,w2,b1,b2,g0,g1)
  for name in ('hidden','output','midgate','endpoint_gate'):
   self.assertLess(float(r[name+'_vector_closure_sq'].max()),1e-25);self.assertLess(float(r[name+'_closure_signed'].abs().max()),1e-12)
  self.assertGreater(float(r['output_even_error_sq'].max()),1e-8)
 def test_native_endpoint_increment_and_gate(self):
  z0=torch.zeros(2,2);z1=torch.ones(2,2);w=torch.eye(2);b=torch.zeros(2);g0=torch.ones(2,2);g1=torch.tensor([[2.,3.],[2.,3.]]);y0=torch.tensor([[1.,2.],[1.,2.]]);y1=y0+.5
  r=evaluate_batch(z0,z1,w,w,b,b,g0,g1,y0,y1);self.assertLess(float(r['native_endpoint1_error_sq'].max()),1e-25);self.assertAlmostEqual(float(r['native_endpoint1_gate_energy'][0]),65.25)
  with self.assertRaises(ValueError):evaluate_batch(z0,z1,w,w,b,b,g0,g1,y0,None)
 def test_zero_chord(self):
  z=torch.randn(4,3);r=evaluate_batch(z,z,torch.randn(5,3),torch.randn(3,5),torch.randn(5),torch.randn(3),torch.ones(4,3),torch.ones(4,3));self.assertEqual(float(r['output_target_sq'].max()),0)
if __name__=='__main__':unittest.main()
