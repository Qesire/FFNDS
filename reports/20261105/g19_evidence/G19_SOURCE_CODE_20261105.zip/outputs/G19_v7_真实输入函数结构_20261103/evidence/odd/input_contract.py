"""Small stdlib manifest-to-consumer contract, before tensor access."""
import re
from pathlib import PurePosixPath


def digest(value):
    return isinstance(value,str) and re.fullmatch('[0-9a-f]{64}',value) is not None


def validate_manifest(manifest):
    sources=manifest['sources']
    if not 1<=len(sources)<=10 or len({s['source_id'] for s in sources})!=len(sources):
        raise ValueError('invalid source set')
    for source in sources:
        if not re.fullmatch('chip10_0[0-9]',source['source_id']):raise ValueError('unknown source')
        if source['seed']!=42 or source['planned_role'] not in ('DEVELOPMENT','CALIBRATION','HELDOUT'):
            raise ValueError('source design changed')
        if any(not digest(source[k]) for k in ('exit_sha256','start_sha256','scope_sha256','image_sha256','prompt_sha256')):
            raise ValueError('missing source digest')
        if set(source['sites'])!={f'{step}/{layer}' for step in range(4) for layer in range(40)}:
            raise ValueError('incomplete capture site set')
        for path in (source['exit_path'],source['start_path'],*[e['path'] for e in source['sites'].values()]):
            p=PurePosixPath(path)
            if not path.startswith('/public/home/scc/pb23061276/') or '..' in p.parts or '/public/public/' in path:
                raise ValueError('noncanonical path')
        for (key,entry) in source['sites'].items():
            step,layer=map(int,key.split('/'))
            expected=f'{source["source_id"]}__seed42__s{step:02d}__b{layer:02d}.pt'
            if PurePosixPath(entry['path']).name!=expected or not digest(entry['sha256']) or not 0<entry['bytes']<128*1024**2:
                raise ValueError('site identity incomplete')
    return sources


def validate_capture_receipts(source,start,end):
    if end['status']!='SUCCESS' or end['result']['source_id']!=source['source_id'] or end['result']['capture_sites']!=160:
        raise ValueError('unsuccessful or wrong capture')
    scope=start['scope']
    if scope['_verified_scope_sha256']!=source['scope_sha256'] or scope['phase']!='NATIVE_TRAJECTORY' or scope['run_ids']!=[source['source_id']]:
        raise ValueError('producer scope mismatch')
    return scope
