"""Frozen secant token matching and tanh-GELU; no quadrature."""
import math
import numpy as np

def join_indices(ids0,ids1,*,require_equal=False,total=31668):
    a=np.asarray(ids0);b=np.asarray(ids1)
    for v in (a,b):
        if v.ndim!=1 or not np.issubdtype(v.dtype,np.integer) or len(v)==0 or len(np.unique(v))!=len(v) or np.any(v<0) or np.any(v>=total):raise ValueError('invalid token ids')
    if require_equal and (len(a)!=len(b) or not np.array_equal(a,b)):raise ValueError('tubelet identities differ')
    ids,ix0,ix1=np.intersect1d(a,b,assume_unique=True,return_indices=True)
    if not len(ids):raise ValueError('no matched tokens')
    return ids,ix0,ix1

def gelu_tanh(x):
    import torch
    c=math.sqrt(2/math.pi)
    return .5*x*(1+torch.tanh(c*(x+0.044715*x*x*x)))

def check_tubelet_ids(ids,times=21,height=29,width=52,spatial_count=16):
    ids=np.asarray(ids)
    if ids.shape!=(times*spatial_count,) or not np.issubdtype(ids.dtype,np.integer):raise ValueError('tubelet size')
    grid=ids.reshape(times,spatial_count);positions=grid%(height*width);t=grid//(height*width)
    if not np.array_equal(t,np.broadcast_to(np.arange(times)[:,None],t.shape)) or not np.all(positions==positions[0]) or len(np.unique(positions[0]))!=spatial_count or np.any(np.diff(positions[0])<=0):raise ValueError('tubelet grid structure')
    return positions[0]
