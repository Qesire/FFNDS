"""Finite paired native chord analysis. No launch without reviewed allocation/scope."""
import argparse,json,os,re,sys,time
from pathlib import Path

def emit(path,obj):
    with path.open('a',encoding='utf8') as f:
        f.write(json.dumps(obj,ensure_ascii=False,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())

def validate_allocation(scope,alloc):
    rec=dict(re.findall(r'(\w+)=([^\s]+)',alloc['scheduler_job_record']))
    if int(rec['NumCPUs'])>scope['budget']['cpus'] or alloc['memory_mib']>scope['budget']['host_memory_gib']*1024:raise ValueError('actual CPU/RAM exceeds scope')
    m=re.fullmatch(r'(?:(\d+)-)?(\d+):(\d+):(\d+)',rec.get('TimeLimit',''))
    if not m:raise ValueError('unknown scheduler walltime')
    days,hours,minutes,seconds=(int(x or 0) for x in m.groups())
    if days*86400+hours*3600+minutes*60+seconds>scope['budget']['wall_seconds']:raise ValueError('actual walltime exceeds scope')

def native_panels(d0,d1):
    """Verify identities; paired positions refer to each saved endpoint."""
    import numpy as np,torch
    from secant_math import join_indices,check_tubelet_ids
    out={}
    for panel,ids_key,zkey,ykey in (('tubelet','tubelet_indices','tubelet_z','tubelet_w2_output_before_gate'),('uniform','token_indices','z','w2_output_before_gate')):
        z0,z1,y0,y1=(d0[zkey],d1[zkey],d0[ykey],d1[ykey]);want=336 if panel=='tubelet' else 2048
        for tensor in (z0,z1,y0,y1):
            if tensor.shape!=(want,5120) or tensor.dtype!=torch.bfloat16 or not bool(torch.isfinite(tensor).all()):raise ValueError('bad native panel tensor')
        ids0=d0[ids_key];ids1=d1[ids_key]
        if ids0.dtype!=torch.int64 or ids1.dtype!=torch.int64 or ids0.shape!=(want,) or ids1.shape!=(want,):raise ValueError('bad native ids')
        ids,i0,i1=join_indices(ids0.numpy(),ids1.numpy(),require_equal=(panel=='tubelet'))
        if panel=='tubelet':
            spatial=check_tubelet_ids(ids)
            for data in (d0,d1):
                saved=data['tubelet_spatial_indices']
                if saved.dtype!=torch.int64 or saved.shape!=(16,) or not np.array_equal(saved.numpy(),spatial):raise ValueError('tubelet spatial identities differ')
        out[panel]=(ids,i0,i1,z0,z1,y0,y1)
    return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--scope',required=True);ap.add_argument('--scope-sha',required=True);a=ap.parse_args()
    from runtime_guard import require_compute_allocation,verify_frozen_scope,RunReceipt,sha256_file
    alloc=require_compute_allocation();root=Path(__file__).resolve().parent;scope=verify_frozen_scope(root,a.scope,a.scope_sha)
    if scope.get('phase')!='NATIVE_ODD_SECANT' or Path(sys.executable).resolve()!=Path(scope['python_executable']).resolve():raise ValueError('phase/interpreter mismatch')
    validate_allocation(scope,alloc);budget=scope['budget']
    if not 0<budget['gpu_memory_gib']<=24 or not 0<budget['output_bytes']<=256*1024**2:raise ValueError('GPU/output limit')
    def bound(name):
        if name not in scope['frozen_inputs_sha256'] or sha256_file(root/name)!=scope['frozen_inputs_sha256'][name]:raise ValueError('unbound input')
        return json.loads((root/name).read_text(encoding='utf8'))
    manifest=bound('capture_manifest.json');weights=bound('weight_manifest.json');hashes=bound('weight_hashes.json')
    cfg=scope['required_runtime_config'];expected={'layers':list(range(40)),'source_ids':[f'chip10_{i:02}' for i in range(10)],'pairs':[[0,1],[2,3]],'arms':['Oq','Dq'],'batch_rows':16,'panels':['tubelet','uniform_intersection'],'numeric':'BF16_WEIGHTS_LIFTED_F64','gate_weight':['ENDPOINT_MIDPOINT','ENDPOINT_G1'],'activation':'GELU_TANH','decomposition':'FIXED_GELU_ODD_PLUS_EVEN','native_endpoint_increment':'DQ_ONLY'}
    if cfg!=expected:raise ValueError('scope differs from finite protocol')
    from input_contract import validate_manifest,validate_capture_receipts,digest
    sources=validate_manifest(manifest)
    if {x['source_id'] for x in sources}!=set(expected['source_ids']):raise ValueError('exact 10 sources required')
    expected_keys={f'{e}/{m}/blocks.{l}.ffn.{suffix}' for e in ('high','low') for m in ('original','distilled') for l in range(40) for suffix in ('0.weight','2.weight','0.bias','2.bias')}
    if set(hashes)!=expected_keys or any(not digest(x) for x in hashes.values()):raise ValueError('all 640 frozen tensor hashes required')
    import numpy as np,torch
    from capture_inputs import read_capture,sampled_condition
    from odd_math import evaluate_batch
    from weights_v7 import load_tensor,rne_lift
    if np.__version__!=scope['runtime_versions']['numpy'] or torch.__version__!=scope['runtime_versions']['torch']:raise ValueError('runtime versions mismatch')
    if not torch.cuda.is_available() or torch.cuda.device_count()!=1 or torch.cuda.get_device_name(0)!='NVIDIA A100-SXM4-80GB':raise ValueError('one A100 GPU required')
    torch.set_num_threads(budget['cpus']);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    total=torch.cuda.get_device_properties(0).total_memory;limit=budget['gpu_memory_gib']*1024**3
    if limit>=total:raise ValueError('invalid GPU cap')
    torch.cuda.set_per_process_memory_fraction(limit/total,0);torch.cuda.reset_peak_memory_stats()
    out=Path(scope['output_dir']);started=time.monotonic()
    with RunReceipt(out,scope,alloc) as receipt:
        receipt.result={'status':'PARTIAL','pair_count':0,'arm_count':0,'artifact_bytes':0}
        emit(out/'environment.jsonl',{'python':sys.version,'torch':torch.__version__,'numpy':np.__version__,'cuda':torch.version.cuda,'gpu':torch.cuda.get_device_name(0),'tf32':False,'numeric_status':'UNASSESSED','panel_semantics':'tubelet and uniform intersection are distinct samples'})
        for source in sources:
            for kind in ('start','exit'):
                if sha256_file(source[kind+'_path'])!=source[kind+'_sha256']:raise ValueError('capture receipt changed')
            producer=validate_capture_receipts(source,json.loads(Path(source['start_path']).read_text(encoding='utf8')),json.loads(Path(source['exit_path']).read_text(encoding='utf8')))
            if {k:v['sha256'] for k,v in producer['checkpoints'].items()}!=scope['dense_checkpoint_sha256']:raise ValueError('producer checkpoint mismatch')
        used=0;count=0
        for expert,steps in (('high',(0,1)),('low',(2,3))):
            for layer in range(40):
                receipt.check_deadline();models={}
                for model,label in (('original','Oq'),('distilled','Dq')):
                    tensors=[]
                    for suffix in ('0.weight','2.weight','0.bias','2.bias'):
                        key=f'{expert}/{model}/blocks.{layer}.ffn.{suffix}';arr,identity=load_tensor(weights,expert,model,layer,suffix,hashes[key])
                        if model=='original':arr=rne_lift(arr)
                        tensors.append(torch.as_tensor(arr,dtype=torch.float64,device='cuda'));emit(out/'weight_reads.jsonl',{'expert':expert,'layer':layer,'arm':label,**identity})
                    if tuple(x.shape for x in tensors)!=((13824,5120),(5120,13824),(13824,),(5120,)):raise ValueError('weight shape')
                    models[label]=tensors
                for source in sources:
                    receipt.check_deadline();sid=source['source_id'];entries=[source['sites'][f'{step}/{layer}'] for step in steps]
                    captures=[read_capture(entry,sid,step,layer,expert) for entry,step in zip(entries,steps)]
                    for data,entry,step in zip(captures,entries,steps):
                        meta=data['metadata']
                        if meta['scope_sha256']!=source['scope_sha256'] or meta['image_sha256']!=source['image_sha256'] or meta['prompt_sha256']!=source['prompt_sha256'] or meta['seed']!=source['seed'] or meta['checkpoint_sha256']!=scope['dense_checkpoint_sha256'][expert]:raise ValueError('capture provenance mismatch')
                    panels=native_panels(*captures);archive={};descriptions={}
                    for panel,(ids,i0,i1,z0,z1,y0,y1) in panels.items():
                        ix0=torch.as_tensor(i0,dtype=torch.long);ix1=torch.as_tensor(i1,dtype=torch.long);token=torch.as_tensor(ids,dtype=torch.long)
                        z0=z0.index_select(0,ix0).double();z1=z1.index_select(0,ix1).double();y0=y0.index_select(0,ix0).double();y1=y1.index_select(0,ix1).double()
                        g0=sampled_condition(captures[0]['gate'],token,31668,5120).double();g1=sampled_condition(captures[1]['gate'],token,31668,5120).double()
                        arrays={'ids':ids.astype(np.int64),'time_index':(ids//(29*52)).astype(np.int16)}
                        for arm in ('Oq','Dq'):
                            chunks={}
                            for first in range(0,len(ids),cfg['batch_rows']):
                                receipt.check_deadline();last=min(first+cfg['batch_rows'],len(ids));bs=slice(first,last)
                                result=evaluate_batch(z0[bs].cuda(),z1[bs].cuda(),*models[arm],g0[bs].cuda(),g1[bs].cuda(),*((y0[bs].cuda(),y1[bs].cuda()) if arm=='Dq' else ()))
                                for k,v in result.items():chunks.setdefault(k,[]).append(v.cpu().numpy())
                            for k,v in chunks.items():arrays[arm+'__'+k]=np.concatenate(v)
                        for name,values in arrays.items():
                            if name not in ('ids','time_index'):
                                if not np.isfinite(values).all():raise FloatingPointError('nonfinite result')
                                archive[panel+'__time_sum__'+name]=np.bincount(arrays['time_index'],weights=values,minlength=21)
                            archive[panel+'__'+name]=values
                        descriptions[panel]={'matched_rows':len(ids),'latent_time_counts':np.bincount(arrays['time_index'],minlength=21).tolist(),'sums':{k:float(np.sum(v)) for k,v in arrays.items() if k not in ('ids','time_index')},'token_match':'FIXED_TUBELET_EXACT' if panel=='tubelet' else 'ID_INTERSECTION_NOT_POSITIONAL'}
                    artifact=out/f'{sid}__{expert}__layer{layer:02}.npz';reservation=sum(x.nbytes for x in archive.values())+1024**2
                    if artifact.exists() or used+reservation>budget['output_bytes']:raise RuntimeError('output artifact budget or overwrite')
                    with artifact.open('xb') as f:np.savez_compressed(f,**archive);f.flush();os.fsync(f.fileno())
                    used+=artifact.stat().st_size
                    record={'source_id':sid,'expert':expert,'steps':list(steps),'layer':layer,'capture_sha256':[x['sha256'] for x in entries],'artifact':artifact.name,'artifact_sha256':sha256_file(artifact),'panels':descriptions,'semantic':'fixed odd/even GELU decomposition on observed Dq-state chords; native endpoint incremental prediction Dq only; F64-lifted boundary, no BF16 deployment or general structural claim','numeric_status':'UNASSESSED'}
                    emit(out/'pairs.jsonl',record);count+=1
                    logbytes=sum((out/x).stat().st_size for x in ('pairs.jsonl','weight_reads.jsonl','environment.jsonl') if (out/x).exists())
                    if used+logbytes+(out/'START.json').stat().st_size+1024**2>budget['output_bytes']:raise RuntimeError('output budget including START/EXIT reserve exceeded')
                    if torch.cuda.max_memory_allocated()>limit:raise MemoryError('GPU budget exceeded')
                    receipt.result.update(pair_count=count,arm_count=2*count,artifact_bytes=used+logbytes,last_pair=f'{sid}/{expert}/{layer}')
                    print(sid,expert,layer,'COMPLETE',flush=True)
                    del captures,panels,archive
                del models;torch.cuda.empty_cache()
        receipt.check_deadline()
        if count!=800:raise ValueError('incomplete 800-pair coverage')
        if sum(1 for line in (out/'weight_reads.jsonl').open(encoding='utf8') if line.strip())!=640:raise ValueError('incomplete 640 weight read identities')
        if sum(1 for line in (out/'pairs.jsonl').open(encoding='utf8') if line.strip())!=800:raise ValueError('pair ledger count mismatch')
        final_bytes=sum(p.stat().st_size for p in out.iterdir() if p.is_file())
        if final_bytes+1024**2>budget['output_bytes']:raise RuntimeError('terminal output budget including EXIT reserve exceeded')
        receipt.result.update(actual_output_bytes_before_exit=final_bytes,exit_reserved_bytes=1024**2,status='NATIVE_ODD_SECANT_COMPLETE_DESCRIPTIVE_NUMERICS_UNASSESSED',pair_count=count,arm_count=2*count,weight_read_count=640,pairs_ledger_sha256=sha256_file(out/'pairs.jsonl'),weight_ledger_sha256=sha256_file(out/'weight_reads.jsonl'),environment_sha256=sha256_file(out/'environment.jsonl'),gpu_peak_allocated_bytes=torch.cuda.max_memory_allocated(),elapsed_seconds=time.monotonic()-started)
if __name__=='__main__':main()
