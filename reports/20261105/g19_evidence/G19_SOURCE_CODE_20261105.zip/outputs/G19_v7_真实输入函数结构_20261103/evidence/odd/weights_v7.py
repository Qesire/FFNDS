"""Strict safetensors byte reader. Call only after compute allocation guard."""
import hashlib,json,re,struct
from pathlib import Path
import numpy as np


def load_tensor(manifest, expert, model, layer, suffix, expected_sha256):
    from runtime_guard import require_compute_allocation
    require_compute_allocation()
    if not isinstance(expected_sha256,str) or not re.fullmatch('[0-9a-f]{64}',expected_sha256): raise ValueError('precommitted tensor hash required')
    key=f'blocks.{layer}.ffn.{suffix}'; entry=manifest['tensors'][f'{expert}/{model}/{key}']; path=Path(entry['path']); info=manifest['files'][str(path)]
    st=path.stat()
    if st.st_size!=info['size'] or st.st_mtime_ns!=info['mtime_ns']: raise ValueError('file identity mismatch')
    with path.open('rb') as f:
        b=f.read(8)
        if len(b)!=8: raise ValueError('truncated header')
        n=struct.unpack('<Q',b)[0]; header=f.read(n)
        if hashlib.sha256(header).hexdigest()!=info['header_sha256']: raise ValueError('header hash mismatch')
        spec=json.loads(header)[key]
        if spec!=entry['spec']: raise ValueError('tensor specification mismatch')
        lo,hi=spec['data_offsets']; dt=spec['dtype']; size={'F32':4,'BF16':2}.get(dt)
        shape=spec['shape']
        if size is None or not isinstance(shape,list) or any(type(x)!=int or x<0 for x in shape): raise ValueError('invalid tensor shape or dtype')
        if type(lo)!=int or type(hi)!=int or not 0<=lo<=hi or 8+n+hi>st.st_size or hi-lo!=int(np.prod(shape,dtype=object))*size: raise ValueError('invalid tensor bounds or byte count')
        f.seek(8+n+lo); raw=f.read(hi-lo)
    end=path.stat()
    if (end.st_size,end.st_mtime_ns)!=(st.st_size,st.st_mtime_ns): raise ValueError('file changed during tensor read')
    digest=hashlib.sha256(raw).hexdigest()
    if len(raw)!=hi-lo or (expected_sha256 is not None and digest!=expected_sha256): raise ValueError('raw tensor hash mismatch')
    dt=spec['dtype']; required='F32' if model=='original' else 'BF16' if model=='distilled' else None
    if dt!=required: raise ValueError('unexpected storage precision')
    if dt=='BF16': arr=(np.frombuffer(raw,dtype='<u2').astype(np.uint32)<<16).view(np.float32)
    else: arr=np.frombuffer(raw,dtype='<f4').copy()
    arr=arr.reshape(spec['shape'])
    if not np.isfinite(arr).all(): raise ValueError('nonfinite tensor')
    return arr, {'key':key,'sha256':digest,'dtype':dt,'bytes':len(raw),'path':str(path),'identity_status':'PRECOMMITTED_HASH_MATCH' if expected_sha256 else 'FIRST_READ_IDENTITY'}


def rne_lift(arr):
    arr=np.asarray(arr)
    if arr.dtype!=np.float32 or not np.isfinite(arr).all(): raise ValueError('finite F32 required')
    u=arr.view(np.uint32); out=((u+np.uint32(0x7fff)+((u>>16)&1))&np.uint32(0xffff0000)).view(np.float32)
    if not np.isfinite(out).all(): raise ValueError('BF16 overflow')
    return out

