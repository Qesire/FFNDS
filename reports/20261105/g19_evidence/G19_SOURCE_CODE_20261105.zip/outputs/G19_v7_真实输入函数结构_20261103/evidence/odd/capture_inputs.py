"""Strict capture reading helpers. Runner must establish compute scope first."""
import hashlib
from pathlib import Path
import torch


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(4*1024**2),b''):h.update(chunk)
    return h.hexdigest()


def sampled_condition(raw, indices, total, dimension):
    """Only the two broadcast forms actually accepted by the native operation.

    A latent-time-only T,D tensor is not silently broadcast over spatial tokens.
    """
    if not torch.isfinite(raw).all():raise ValueError('nonfinite conditioning')
    x=raw.squeeze()
    if x.shape==(dimension,):return x[None,:].expand(len(indices),-1)
    if x.shape==(total,dimension):return x.index_select(0,indices)
    raise ValueError('unrecognized native conditioning shape')


def read_capture(entry, expected_source, step, layer, expert):
    path=Path(entry['path']);before=path.stat()
    if not str(path).startswith('/public/home/scc/pb23061276/') or '..' in path.parts or before.st_size!=entry['bytes'] or sha(path)!=entry['sha256']:
        raise ValueError('capture path/byte identity mismatch')
    data=torch.load(path,map_location='cpu',weights_only=True)
    after=path.stat()
    if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):raise ValueError('capture changed')
    meta=data['metadata']
    if (meta['source'],meta['step'],meta['layer'],meta['expert'])!=(expected_source,step,layer,expert):raise ValueError('capture site mismatch')
    if tuple(meta['grid'])!=(21,29,52) or meta['flattened_tokens']!=31668:raise ValueError('capture geometry mismatch')
    for key in ('z','w2_output_before_gate'):
        if data[key].shape!=(2048,5120) or data[key].dtype!=torch.bfloat16 or not torch.isfinite(data[key]).all():raise ValueError('bad native tensor')
    ids=data['token_indices']
    if ids.shape!=(2048,) or ids.dtype!=torch.int64 or len(torch.unique(ids))!=2048 or ids.min()<0 or ids.max()>=31668:raise ValueError('bad token identities')
    for key in ('gate','shift','scale'):
        sampled_condition(data[key],ids,31668,5120)
    return data
