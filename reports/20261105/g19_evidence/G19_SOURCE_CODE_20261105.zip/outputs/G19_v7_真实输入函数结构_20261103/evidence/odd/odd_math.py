"""F64 odd/even GELU chord decomposition; no fitted parameters."""
import math,torch
from secant_math import gelu_tanh

def evaluate_batch(z0,z1,w1,w2,b1,b2,g0,g1,native0=None,native1=None):
 arrays=(z0,z1,w1,w2,b1,b2,g0,g1)
 if any(x.dtype!=torch.float64 or x.device!=z0.device or not bool(torch.isfinite(x).all()) for x in arrays):raise ValueError('finite same-device F64 required')
 n,d=z0.shape;m=w1.shape[0]
 if z1.shape!=(n,d) or w1.shape!=(m,d) or w2.shape!=(d,m) or b1.shape!=(m,) or b2.shape!=(d,) or g0.shape!=(n,d) or g1.shape!=(n,d):raise ValueError('bad geometry')
 a0=z0@w1.T+b1;a1=z1@w1.T+b1;da=a1-a0;linear=((z1-z0)@w1.T)*.5;direct_hidden=gelu_tanh(a1)-gelu_tanh(a0)
 c=math.sqrt(2/math.pi);psi=lambda a: .5*a*torch.tanh(c*(a+.044715*a*a*a));even=psi(a1)-psi(a0)
 target=direct_hidden@w2.T;odd=linear@w2.T;out_even=even@w2.T;gate=(g0+g1)*.5
 def norms(x,y,z,prefix):
  sq=lambda a:(a*a).sum(dim=1)
  target_sq=sq(x);odd_sq=sq(y);even_sq=sq(z);cross=2*(y*z).sum(dim=1)
  return {prefix+'target_sq':target_sq,prefix+'odd_sq':odd_sq,prefix+'even_error_sq':even_sq,prefix+'direct_odd_residual_sq':sq(x-y),prefix+'twice_cross':cross,prefix+'closure_signed':target_sq-odd_sq-even_sq-cross,prefix+'vector_closure_sq':sq(x-y-z)}
 result={**norms(direct_hidden,linear,even,'hidden_'),**norms(target,odd,out_even,'output_'),**norms(target*gate,odd*gate,out_even*gate,'midgate_'),**norms(target*g1,odd*g1,out_even*g1,'endpoint_gate_')}
 result.update(preactivation_sum_sq=((a0+a1)**2).sum(dim=1),preactivation_delta_sq=(da*da).sum(dim=1),odd_backbone_computation_discrepancy_sq=(da*.5-linear).square().sum(dim=1))
 if (native0 is None)!=(native1 is None):raise ValueError('both native endpoints required')
 if native0 is not None:
  if any(x.shape!=(n,d) or x.dtype!=torch.float64 or x.device!=z0.device or not bool(torch.isfinite(x).all()) for x in (native0,native1)):raise ValueError('invalid native endpoints')
  error=native0+odd-native1;result.update(native_endpoint1_energy=native1.square().sum(1),native_endpoint1_error_sq=error.square().sum(1),native_endpoint1_gate_energy=(native1*g1).square().sum(1),native_endpoint1_gate_error_sq=(error*g1).square().sum(1))
 if any(not bool(torch.isfinite(v).all()) for v in result.values()):raise FloatingPointError('nonfinite decomposition')
 return result
