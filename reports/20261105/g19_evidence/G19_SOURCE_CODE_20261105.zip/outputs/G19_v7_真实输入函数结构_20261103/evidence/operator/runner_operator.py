"""Draft compute-only operator transfer; requires separately frozen, reviewed scope."""
import argparse,json,os,re,sys,time
from pathlib import Path
from runtime_guard import require_compute_allocation,verify_frozen_scope,RunReceipt,sha256_file,process_peak_rss_bytes

def save(path,obj):
 with path.open('x',encoding='utf8') as f:json.dump(obj,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())

def main():
 p=argparse.ArgumentParser();p.add_argument('--scope',required=True);p.add_argument('--scope-sha',required=True);a=p.parse_args()
 allocation=require_compute_allocation();root=Path(__file__).resolve().parent;s=verify_frozen_scope(root,a.scope,a.scope_sha)
 if Path(sys.executable).resolve()!=Path(s['python_executable']).resolve():raise ValueError('python identity mismatch')
 if allocation['memory_mib']>s['budget']['host_memory_gib']*1024:raise ValueError('host allocation exceeds scope')
 expected_config={'steps':list(range(4)),'layers':list(range(40)),'rows_per_source':2048,'input_dimension':5120,'output_dimension':5120,'cal':['02','04','07','09'],'dev':['00','01'],'held':['03','05','06','08'],'projection_dimensions':[32,64],'ridge_multipliers':[1e-6,1e-4,1e-2,1.0],'target':'Dq_native_W2_BF16_before_gate','gate_arithmetic':'F64_LIFTED','dtype':'F64'}
 if s['required_runtime_config']!=expected_config:raise ValueError('unsupported exact analysis contract')
 b=s['budget'];v=dict(re.findall(r'(\w+)=([^\s]+)',allocation['scheduler_job_record']));t=re.fullmatch(r'(?:(\d+)-)?(\d+):(\d+):(\d+)',v.get('TimeLimit',''))
 if not t:raise ValueError('invalid wall')
 days,h,m,sec=(int(x or 0) for x in t.groups())
 if int(v['NumCPUs'])>b['cpus'] or days*86400+h*3600+m*60+sec>b['wall_seconds'] or b['gpu_memory_gib']!=24 or b['output_bytes']>2*1024**3:raise ValueError('resource mismatch')
 manifest=json.loads((root/s['input_manifest_file']).read_text(encoding='utf8'))
 from input_contract import validate_manifest,validate_capture_receipts
 sources=validate_manifest(manifest);sources={x['source_id'][-2:]:x for x in sources}
 from operator_core import CAL,DEV,HELD,run_site,decompose
 if set(sources)!=set(CAL+DEV+HELD):raise ValueError('wrong source set')
 roles={**{x:'CALIBRATION' for x in CAL},**{x:'DEVELOPMENT' for x in DEV},**{x:'HELDOUT' for x in HELD}}
 for sid,entry in sources.items():
  if entry['planned_role']!=roles[sid] or entry['exposure_status']!='UNVERIFIED':raise ValueError('source role mismatch')
  for kind in ('start','exit'):
   if sha256_file(entry[kind+'_path'])!=entry[kind+'_sha256']:raise ValueError('receipt SHA mismatch')
  producer=validate_capture_receipts(entry,json.loads(Path(entry['start_path']).read_text()),json.loads(Path(entry['exit_path']).read_text()))
  if {k:v['sha256'] for k,v in producer['checkpoints'].items()}!=s['dense_checkpoint_sha256']:raise ValueError('checkpoint mismatch')
 import torch,numpy as np
 from capture_inputs import read_capture
 from weights_v7 import load_tensor
 for filename in ('weight_manifest.json','weight_hashes.json'):
  if filename not in s['frozen_inputs_sha256']:raise ValueError('bias provenance not frozen')
 weight_manifest=json.loads((root/'weight_manifest.json').read_text(encoding='utf8'));weight_hashes=json.loads((root/'weight_hashes.json').read_text(encoding='utf8'));bias_cache={}
 if not torch.cuda.is_available() or torch.cuda.device_count()!=1:raise ValueError('exactly one CUDA device required')
 if torch.__version__!=s['runtime_versions']['torch'] or np.__version__!=s['runtime_versions']['numpy']:raise ValueError('runtime version mismatch')
 torch.set_num_threads(b['cpus']);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
 torch.cuda.set_per_process_memory_fraction(b['gpu_memory_gib']*1024**3/torch.cuda.get_device_properties(0).total_memory)
 out=Path(s['output_dir']);used=0
 with RunReceipt(out,s,allocation) as receipt,torch.no_grad():
  index=out/'sites.jsonl'
  save(out/'ENVIRONMENT.json',{'python':sys.version,'torch':torch.__version__,'numpy':np.__version__,'cuda':torch.version.cuda,'gpu':torch.cuda.get_device_name(0),'tf32':False,'target':'native BF16 W2+b2 before gate; gate multiplication F64 lifted','heldout_exposure':'UNVERIFIED'})
  for step in range(4):
   expert='high' if step<2 else 'low'
   for layer in range(40):
    receipt.check_deadline();start=time.monotonic();batch={};torch.cuda.reset_peak_memory_stats()
    for sid,source in sources.items():
     entry=source['sites'][f'{step}/{layer}']; side=Path(entry['sidecar_path'])
     if sha256_file(side)!=entry['sidecar_sha256']:raise ValueError('capture sidecar SHA mismatch')
     sidecar=json.loads(side.read_text(encoding='utf8'))
     if (sidecar['source'],sidecar['step'],sidecar['layer'],sidecar['file_sha256'])!=(source['source_id'],step,layer,entry['sha256']):raise ValueError('sidecar identity mismatch')
     data=read_capture(entry,source['source_id'],step,layer,expert);meta=data['metadata']
     if meta['scope_sha256']!=source['scope_sha256'] or meta['image_sha256']!=source['image_sha256'] or meta['prompt_sha256']!=source['prompt_sha256'] or meta['seed']!=42 or meta['checkpoint_sha256']!=s['dense_checkpoint_sha256'][expert]:raise ValueError('capture identity mismatch')
     gate=data['gate'].squeeze()
     if gate.shape!=(5120,):raise ValueError('nonbroadcast gate unsupported')
     batch[sid]={'z':data['z'].to(device='cuda',dtype=torch.float64),'y':data['w2_output_before_gate'].to(device='cuda',dtype=torch.float64),'gate':gate.to(device='cuda',dtype=torch.float64)}
    loading=time.monotonic()-start
    if (expert,layer) not in bias_cache:
     key=f'{expert}/distilled/blocks.{layer}.ffn.2.bias';arr,identity=load_tensor(weight_manifest,expert,'distilled',layer,'2.bias',weight_hashes[key]);
     if arr.shape!=(5120,):raise ValueError('bad b2 shape')
     bias_cache[expert,layer]=(torch.as_tensor(arr,device='cuda',dtype=torch.float64),identity)
    bias,identity=bias_cache[expert,layer];decomp,mean_order,means=decompose(batch,bias)
    mean_path=out/f's{step:02d}_b{layer:02d}_means.npz'
    with mean_path.open('xb') as file:np.savez(file,**means);file.flush();os.fsync(file.fileno())
    result=run_site(batch,check=receipt.check_deadline);result.update({'source_anova':decomp,'source_mean_order':mean_order,'source_means_file':mean_path.name,'source_means_sha256':sha256_file(mean_path),'bias_identity':identity});result.update({'step':step,'layer':layer,'expert':expert,'load_seconds':loading,'gpu_peak_allocated_bytes':torch.cuda.max_memory_allocated(),'process_peak_rss_bytes':process_peak_rss_bytes(),'process_source_ids':sorted(sources),'estimand':'Dq captured input and native pre-gate BF16 W2 response; F64 lifted gate'})
    if result['gpu_peak_allocated_bytes']>b['gpu_memory_gib']*1024**3:raise MemoryError('GPU allocation exceeded budget')
    path=out/f's{step:02d}_b{layer:02d}.json';save(path,result);used+=path.stat().st_size+mean_path.stat().st_size
    if used>b['output_bytes']:raise RuntimeError('output cap exceeded')
    with index.open('a',encoding='utf8') as f:
     f.write(json.dumps({'step':step,'layer':layer,'site_file':path.name,'site_sha256':sha256_file(path),'means_file':mean_path.name,'means_sha256':sha256_file(mean_path)},allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())
    receipt.result={'status':'IN_PROGRESS','sites':step*40+layer+1,'output_bytes':used,'site_index_sha256':sha256_file(index)};del batch,result;torch.cuda.empty_cache()
  receipt.result={'status':'NATIVE_OPERATOR_TRANSFER_COMPLETE_DESCRIPTIVE','sites':160,'output_bytes':used,'site_index_sha256':sha256_file(index),'interpretation':'restricted candidate transfer; no heldout-tuned hyperparameters and no global optimality claim'}
if __name__=='__main__':main()
