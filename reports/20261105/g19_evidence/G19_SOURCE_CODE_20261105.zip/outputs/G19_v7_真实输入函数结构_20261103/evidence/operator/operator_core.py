"""Torch F64 native-response ridge candidates. DRAFT, no execution authorization."""
import hashlib,math,time
import torch

CAL=('02','04','07','09');DEV=('00','01');HELD=('03','05','06','08')
RIDGE=(1e-6,1e-4,1e-2,1.)

def checked(x):
 if not torch.isfinite(x).all().item():raise ValueError('nonfinite tensor')
 return x.to(dtype=torch.float64)

def quadratic(q):
 n,k=q.shape;i,j=torch.triu_indices(k,k,offset=1,device=q.device)
 return torch.cat((q,q*q,math.sqrt(2.)*q[:,i]*q[:,j]),dim=1)

def metrics(y,p,g):
 y,p,g=checked(y),checked(p),checked(g);e=p-y
 def stat(a,b):
  diff=a-b;center=diff-diff.mean(dim=0,keepdim=True);bcenter=b-b.mean(dim=0,keepdim=True)
  total=float((diff*diff).sum(dim=1).mean());cent=float((center*center).sum(dim=1).mean());energy=float((b*b).sum(dim=1).mean());oracle=float((bcenter*bcenter).sum(dim=1).mean())
  return {'mse_total':total,'mse_centered':cent,'target_energy':energy,'oracle_mean_mse':oracle,'mse_over_target_energy':total/energy if energy>0 else None,'mse_over_oracle_mean_mse':total/oracle if oracle>0 else None}
 return {'pre_gate':stat(p,y),'post_gate':stat(p*g,y*g)}

def decompose(sources,bias):
 """Equal-source finite-panel ANOVA; return scalars and detached per-source means."""
 ids=tuple(sorted(sources));n=len(ids)
 if n<2:raise ValueError('AT_LEAST_TWO_SOURCES_REQUIRED')
 b=checked(bias);result={};saved={}
 for panel in ('pre_gate','post_gate'):
  ys=[checked(sources[s]['y'])*(checked(sources[s]['gate']) if panel=='post_gate' else 1.) for s in ids]
  means=torch.stack([y.mean(0) for y in ys]);mean=means.mean(0);variances=torch.stack([((y-m)**2).sum(1).mean() for y,m in zip(ys,means)])
  within=variances.mean();between=((means-mean)**2).sum(1).mean();mean_energy=(mean*mean).sum();total=torch.stack([(y*y).sum(1).mean() for y in ys]).mean()
  risks={};biasrisk={}
  for i,sid in enumerate(ids):
   excluded=(means.sum(0)-means[i])/(n-1);risks[sid]=float(((ys[i]-excluded)**2).sum(1).mean());prediction=b*(checked(sources[sid]['gate']) if panel=='post_gate' else 1.);biasrisk[sid]=float(((ys[i]-prediction)**2).sum(1).mean())
  loso=sum(risks.values())/n;identity=float(within+(n/(n-1))**2*between)
  result[panel]={'within':float(within),'between':float(between),'grand_mean_energy':float(mean_energy),'total_energy_direct':float(total),'total_decomposition_residual':float(total-(mean_energy+within+between)),'loso_risk_by_source':risks,'loso_mean':loso,'loso_identity':identity,'loso_identity_residual':loso-identity,'bias_constant_risk_by_source':biasrisk,'per_source_variance':{sid:float(variances[i]) for i,sid in enumerate(ids)}}
  saved[panel+'_source_means']=means.detach().cpu().numpy()
 return result,ids,saved

def pca(cal_x):
 x=checked(cal_x);mu=x.mean(0);xc=x-mu;c=xc.T@xc/x.shape[0];c=(c+c.T)*.5
 ev,U=torch.linalg.eigh(c);scale=ev.abs().max();mn=ev.min();
 if mn < -1e-10*scale:raise ValueError('CAL_INPUT_COVARIANCE_INDEFINITE')
 return {'mean':mu,'eigenvalues':ev,'basis':U,'min_eigenvalue':float(mn),'trace':float(torch.trace(c)),'covariance':c}

def make_features(x,kind,pca_obj):
 xc=checked(x)-pca_obj['mean']
 if kind=='affine':return xc
 mode,ks=kind.split('_');k=int(ks);ev=pca_obj['eigenvalues'][-k:];U=pca_obj['basis'][:,-k:]
 if len(ev)!=k or ev.min()<=0 or ev.min()<=1e-12*ev.max():raise ValueError('WHITENING_EIGENVALUE_UNAVAILABLE')
 q=(xc@U)/torch.sqrt(ev)
 return q if mode=='linear' else quadratic(q) if mode=='quadratic' else (_ for _ in ()).throw(ValueError('unknown model'))

def prepare(f,y):
 f,y=checked(f),checked(y);fm=f.mean(0);ym=y.mean(0);fc=f-fm;yc=y-ym;n=f.shape[0];G=fc.T@fc/n;G=(G+G.T)*.5;rhs=fc.T@yc/n
 ev,U=torch.linalg.eigh(G);scale=ev.abs().max()
 if ev.min() < -1e-10*scale:raise ValueError('FEATURE_COVARIANCE_INDEFINITE')
 trace=float(torch.trace(G));p=f.shape[1]
 if not trace>0:raise ValueError('ZERO_FEATURE_VARIANCE')
 return {'feature_mean':fm,'target_mean':ym,'G':G,'rhs':rhs,'eigenvalues':ev,'U':U,'base_lambda':trace/p,'trace':trace,'min_eigenvalue':float(ev.min())}

def solve(prepared,multiplier):
 ev,U=prepared['eigenvalues'],prepared['U'];lam=prepared['base_lambda']*multiplier;den=ev+lam
 if not torch.isfinite(den).all().item() or den.min()<=0:raise ValueError('RIDGE_SYSTEM_NOT_POSITIVE')
 B=U@((U.T@prepared['rhs'])/den[:,None]);res=prepared['G']@B+lam*B-prepared['rhs'];denom=torch.linalg.vector_norm(prepared['rhs']);error=float(torch.linalg.vector_norm(res)/(denom if denom>0 else 1.))
 if not math.isfinite(error) or error>1e-7:raise ValueError('RIDGE_RESIDUAL_EXCEEDS_TOLERANCE')
 condition=float(den.max()/den.min());coefnorm=float(torch.linalg.vector_norm(B))
 return B,{'lambda':lam,'multiplier':multiplier,'relative_system_residual':error,'regularized_condition_number':condition,'coefficient_frobenius_norm':coefnorm,'feature_min_eigenvalue':prepared['min_eigenvalue'],'feature_trace':prepared['trace']}

def predict(features,prepared,B):return (features-prepared['feature_mean'])@B+prepared['target_mean']

def tensor_sha(items):
 h=hashlib.sha256()
 for x in items:
  if x is None:continue
  t=x.detach().contiguous().cpu();h.update(str(tuple(t.shape)).encode());h.update(str(t.dtype).encode());h.update(t.numpy().tobytes())
 return h.hexdigest()

def run_site(sources,k_values=(32,64),check=lambda:None):
 """sources keyed 00..09 -> {'z','y','gate'}; held tensors never enter fit/choice."""
 if set(sources)!=set(CAL+DEV+HELD):raise ValueError('SOURCE_SPLIT_MISMATCH')
 t0=time.monotonic();x=torch.cat([checked(sources[s]['z']) for s in CAL]);y=torch.cat([checked(sources[s]['y']) for s in CAL]);po=pca(x);ym=y.mean(0)
 result={'cal_input_covariance_min_eigenvalue':po['min_eigenvalue'],'cal_input_trace':po['trace'],'models':{},'source_split':{'CAL':CAL,'DEV':DEV,'HELD':HELD}}
 # Constant is estimated only from CAL; has no ridge parameter.
 result['models']['constant']={'selected_multiplier':None,'feature_count':0,'coefficient_bytes_f64':ym.numel()*8,'prediction_macs_per_row':0,'model_sha256':tensor_sha([ym]),'source_metrics':{s:metrics(sources[s]['y'],ym.expand_as(sources[s]['y']),sources[s]['gate']) for s in CAL+DEV+HELD}}
 for kind in ['affine']+[f'{v}_{k}' for k in k_values for v in ('linear','quadratic')]:
  check();started=time.monotonic();f=make_features(x,kind,po);pr=prepare(f,y);prepare_seconds=time.monotonic()-started;diagnostics=[];best=None
  for mult in RIDGE:
   check();fit_start=time.monotonic();B,diag=solve(pr,mult);solve_seconds=time.monotonic()-fit_start;dev_start=time.monotonic();dev={s:metrics(sources[s]['y'],predict(make_features(sources[s]['z'],kind,po),pr,B),sources[s]['gate']) for s in DEV};score=sum(v['post_gate']['mse_total'] for v in dev.values())/len(DEV);diagnostics.append({'solve':diag,'solve_seconds':solve_seconds,'cal_training_residual':float(((predict(f,pr,B)-y)**2).sum(dim=1).mean()),'dev_seconds':time.monotonic()-dev_start,'dev':dev,'dev_equal_source_post_gate_mse':score})
   if best is None or score<best[0]:best=(score,mult,B.clone())
  score,mult,B=best
  # Only after DEV selection is fixed, report all held grid values, without using them for selection.
  held_grid=[]
  for candidate in RIDGE:
   check();candidate_B,_=solve(pr,candidate);held_start=time.monotonic();held_grid.append({'multiplier':candidate,'held':{s:metrics(sources[s]['y'],predict(make_features(sources[s]['z'],kind,po),pr,candidate_B),sources[s]['gate']) for s in HELD},'held_seconds':time.monotonic()-held_start})
  measured=next(z['held'] for z in held_grid if z['multiplier']==mult);p=f.shape[1];d=x.shape[1];o=y.shape[1];k=int(kind.split('_')[-1]) if kind!='affine' else None
  result['models'][kind]={'dev_grid':diagnostics,'selected_multiplier':mult,'held_grid_after_selection':held_grid,'held_metrics':measured,'selected_cal_training_residual':float(((predict(f,pr,B)-y)**2).sum(dim=1).mean()),'cal_metrics':{s:metrics(sources[s]['y'],predict(make_features(sources[s]['z'],kind,po),pr,B),sources[s]['gate']) for s in CAL},'feature_count':p,'coefficient_bytes_f64':int((B.numel()+pr['feature_mean'].numel()+pr['target_mean'].numel()+d+(d*k if k else 0)+(k if k else 0))*8),'prediction_macs_per_row':int(p*o+(d*k if k else 0)),'model_sha256':tensor_sha([po['mean'],po['basis'][:,-k:] if k else None,po['eigenvalues'][-k:] if k else None,pr['feature_mean'],pr['target_mean'],B]),'feature_covariance_prepare_seconds':prepare_seconds,'feature_construction_extra_multiplications':int((k*k+k if kind.startswith('quadratic') else k) if k else 0),'cal_projection_variance_fraction':float(po['eigenvalues'][-k:].sum()/po['eigenvalues'].sum()) if k else 1.,'fit_and_eval_seconds':time.monotonic()-started}
 result['elapsed_seconds']=time.monotonic()-t0;return result
