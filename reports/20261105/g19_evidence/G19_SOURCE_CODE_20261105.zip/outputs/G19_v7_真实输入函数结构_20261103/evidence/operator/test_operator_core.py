import unittest,torch
from operator_core import pca,make_features,prepare,solve,predict,quadratic,metrics,run_site,decompose,CAL,DEV,HELD
class Tiny(unittest.TestCase):
 def setUp(self):torch.manual_seed(42);torch.set_default_dtype(torch.float64)
 def test_q_feature_geometry(self):
  q=torch.tensor([[2.,3.]]);self.assertTrue(torch.allclose(quadratic(q),torch.tensor([[2.,3.,4.,9.,2**.5*6]])))
 def test_linear_truth(self):
  x=torch.randn(80,3);y=x@torch.tensor([[1.,2.],[3.,-1.],[.5,.7]])+4;po=pca(x);f=make_features(x,'affine',po);pr=prepare(f,y);B,di=solve(pr,1e-6);self.assertLess(float(((predict(f,pr,B)-y)**2).mean()),1e-9);self.assertLess(di['relative_system_residual'],1e-10)
 def test_quadratic_truth(self):
  x=torch.randn(120,2);y=(x[:,0]**2+3*x[:,0]*x[:,1]+x[:,1]).reshape(-1,1);po=pca(x);f=make_features(x,'quadratic_2',po);pr=prepare(f,y);B,_=solve(pr,1e-6);self.assertLess(float(((predict(f,pr,B)-y)**2).mean()),1e-8)
 def test_centering_and_gate_units(self):
  y=torch.tensor([[0.,1.],[2.,3.]]);p=y+torch.tensor([2.,-1.]);r=metrics(y,p,torch.tensor([2.,0.]));self.assertAlmostEqual(r['pre_gate']['mse_total'],5);self.assertAlmostEqual(r['post_gate']['mse_total'],16);self.assertAlmostEqual(r['pre_gate']['mse_centered'],0);self.assertAlmostEqual(r['pre_gate']['oracle_mean_mse'],2)
 def test_held_sentinel_cannot_change_fit_or_selection(self):
  x=torch.randn(20,2);weights=torch.tensor([[1.,2.],[-.5,1.]])
  data={s:{'z':x.clone(),'y':x@weights+0.2,'gate':torch.tensor([1.,2.])} for s in CAL+DEV+HELD};a=run_site(data,k_values=(2,));data['03']['y']=data['03']['y']+100;b=run_site(data,k_values=(2,))
  for k in a['models']:
   self.assertEqual(a['models'][k]['selected_multiplier'],b['models'][k]['selected_multiplier']);self.assertEqual(a['models'][k]['model_sha256'],b['models'][k]['model_sha256'])
  self.assertNotEqual(a['models']['affine']['held_metrics']['03']['post_gate']['mse_total'],b['models']['affine']['held_metrics']['03']['post_gate']['mse_total'])
 def test_ill_conditioned_ridge_matches_augmented_lstsq(self):
  x=torch.randn(120,3);x[:,2]=x[:,0]+1e-5*x[:,2];y=(2*x[:,0]-x[:,1]+.7*x[:,2]).reshape(-1,1)+.03*torch.randn(120,1);po=pca(x);f=make_features(x,'affine',po);pr=prepare(f,y);B,diag=solve(pr,1e-4);fc=f-pr['feature_mean'];yc=y-pr['target_mean'];lam=diag['lambda'];aug=torch.cat((fc/(len(f)**.5),lam**.5*torch.eye(3)),dim=0);ay=torch.cat((yc/(len(f)**.5),torch.zeros(3,1)),dim=0);qr=torch.linalg.lstsq(aug,ay).solution
  self.assertGreater(diag['regularized_condition_number'],1000);self.assertLess(diag['relative_system_residual'],1e-10);self.assertTrue(torch.allclose(fc@B,fc@qr,rtol=1e-8,atol=1e-8))
 def test_source_anova_loso_and_bias(self):
  data={'a':{'y':torch.tensor([[1.,2.],[3.,4.]]),'gate':torch.tensor([2.,0.5])},'b':{'y':torch.tensor([[3.,1.],[5.,3.]]),'gate':torch.tensor([2.,0.5])},'c':{'y':torch.tensor([[0.,2.],[2.,4.]]),'gate':torch.tensor([2.,0.5])}}
  result,ids,means=decompose(data,torch.tensor([1.,1.]));self.assertEqual(ids,('a','b','c'));self.assertEqual(means['pre_gate_source_means'].shape,(3,2))
  for panel in result.values():self.assertAlmostEqual(panel['total_decomposition_residual'],0,places=12);self.assertAlmostEqual(panel['loso_identity_residual'],0,places=12)
  self.assertAlmostEqual(result['post_gate']['bias_constant_risk_by_source']['a'],9.25)
 def test_zero_variance_rejected(self):
  with self.assertRaises(ValueError):prepare(torch.ones(5,2),torch.ones(5,1))
if __name__=='__main__':unittest.main()
