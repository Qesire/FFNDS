import json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from runtime_guard import RunReceipt
class GuardTest(unittest.TestCase):
 def test_terminal_soft_failure_writes_exit(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'run';scope={'_verified_scope_sha256':'a'*64,'budget':{'host_memory_gib':64,'soft_seconds':1}}
   with patch('runtime_guard.signal.signal'),patch('runtime_guard.time.monotonic',side_effect=[0,2,2]):
    with self.assertRaises(TimeoutError):
     with RunReceipt(p,scope,{}):pass
   x=json.loads((p/'EXIT.json').read_text());self.assertEqual(x['status'],'FAILED_OR_PARTIAL');self.assertEqual(x['scope_sha256'],'a'*64)
if __name__=='__main__':unittest.main()
