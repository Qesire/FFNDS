"""Finite paired secant metrics; no GPU experiment entry point here."""
import math
import numpy as np

def join_indices(ids0,ids1,*,require_equal=False,total=31668):
    a=np.asarray(ids0);b=np.asarray(ids1)
    for v in (a,b):
        if v.ndim!=1 or not np.issubdtype(v.dtype,np.integer) or len(v)==0 or len(np.unique(v))!=len(v) or np.any(v<0) or np.any(v>=total):raise ValueError('invalid token ids')
    if require_equal and (len(a)!=len(b) or not np.array_equal(a,b)):raise ValueError('tubelet identities differ')
    ids,ix0,ix1=np.intersect1d(a,b,assume_unique=True,return_indices=True)
    if not len(ids):raise ValueError('no matched tokens')
    return ids,ix0,ix1

def quadrature_hidden(phi,prime,a0,a1):
    """No divided difference: all derivative estimates multiply the full da."""
    da=a1-a0;mid=(a0+a1)*0.5;offset=da/(2*math.sqrt(3))
    return {'direct':phi(a1)-phi(a0),'left':prime(a0)*da,'mid':prime(mid)*da,
            'gl2':(prime(mid-offset)+prime(mid+offset))*(0.5*da)}

def gelu_tanh(x):
    import torch
    c=math.sqrt(2/math.pi)
    return .5*x*(1+torch.tanh(c*(x+0.044715*x*x*x)))

def gelu_tanh_prime(x):
    import torch
    c=math.sqrt(2/math.pi);t=torch.tanh(c*(x+0.044715*x*x*x))
    return .5*(1+t)+.5*x*(1-t*t)*c*(1+3*0.044715*x*x)

def evaluate_batch(z0,z1,w1,w2,b1,b2,g0,g1,native0=None,native1=None):
    """Per-row energies. F64 lifted smooth path; gate midpoint is fixed weighting.

    Optional native endpoint arrays are only legitimate for Dq. No ratio or
    clipping is performed; denominators are saved separately.
    """
    import torch
    arrays=(z0,z1,w1,w2,b1,b2,g0,g1)
    if any(x.dtype!=torch.float64 or x.device!=z0.device or not bool(torch.isfinite(x).all()) for x in arrays):raise ValueError('finite same-device F64 required')
    n,d=z0.shape;m=w1.shape[0]
    if z1.shape!=(n,d) or w1.shape!=(m,d) or w2.shape!=(d,m) or b1.shape!=(m,) or b2.shape!=(d,) or g0.shape!=(n,d) or g1.shape!=(n,d):raise ValueError('bad geometry')
    a0=z0@w1.T+b1;a1=z1@w1.T+b1;parts=quadrature_hidden(gelu_tanh,gelu_tanh_prime,a0,a1);direct=parts['direct']@w2.T
    gate=(g0+g1)*.5;row=lambda x:x.square().sum(dim=1)
    da_direct=(z1-z0)@w1.T
    result={'delta_z_sq':row(z1-z0),'delta_hidden_sq':row(parts['direct']),'target_sq':row(direct),'target_gate_sq':row(direct*gate),'da_direct_sq':row(da_direct),'da_subtraction_discrepancy_sq':row((a1-a0)-da_direct)}
    for name in ('left','mid','gl2'):
        error=(parts[name]-parts['direct'])@w2.T
        error_two_products=parts[name]@w2.T-direct
        result[name+'_err_sq']=row(error);result[name+'_gate_err_sq']=row(error*gate)
        result[name+'_two_products_err_sq']=row(error_two_products);result[name+'_error_computation_discrepancy_sq']=row(error_two_products-error)
        result[name+'_hidden_err_sq']=row(parts[name]-parts['direct'])
    if (native0 is None)!=(native1 is None):raise ValueError('both native endpoints required')
    if native0 is not None:
        if any(x.shape!=(n,d) or x.dtype!=torch.float64 or x.device!=z0.device or not bool(torch.isfinite(x).all()) for x in (native0,native1)):raise ValueError('invalid native endpoints')
        f0=gelu_tanh(a0)@w2.T+b2;f1=gelu_tanh(a1)@w2.T+b2;native_delta=native1-native0
        result.update(smooth_endpoint_delta_vs_direct_sq=row((f1-f0)-direct),endpoint0_native_err_sq=row(native0-f0),endpoint1_native_err_sq=row(native1-f1),endpoint0_native_energy=row(native0),endpoint1_native_energy=row(native1),native_delta_energy=row(native_delta),native_delta_vs_smooth_err_sq=row(native_delta-direct),native_delta_gate_energy=row(native_delta*gate),native_delta_vs_smooth_gate_err_sq=row((native_delta-direct)*gate))
    if any(not bool(torch.isfinite(x).all()) or bool((x<0).any()) for x in result.values()):raise FloatingPointError('nonfinite or negative energy')
    return result

def symmetric_gate_components(y0,y1,g0,g1):
    """Lifted-boundary identity; not native BF16 residual arithmetic."""
    a=(g1-g0)*((y1+y0)*0.5);b=((g1+g0)*0.5)*(y1-y0);direct=g1*y1-g0*y0
    summ=lambda x:(x*x).sum(axis=-1)
    ae=summ(a);be=summ(b);cross=2*(a*b).sum(axis=-1);energy=summ(direct)
    return {'gate_change_sq':ae,'state_change_sq':be,'twice_cross':cross,'gated_delta_sq':energy,'closure_signed':energy-ae-be-cross,'vector_closure_sq':summ(direct-a-b)}

def balanced_tubelet_anova(x):
    """Exact balanced two-way energy decomposition; x shape (time,space,output)."""
    x=np.asarray(x,dtype=np.float64)
    if x.ndim!=3 or min(x.shape)<1 or not np.isfinite(x).all():raise ValueError('finite balanced tubelet required')
    mu=x.mean(axis=(0,1));time=x.mean(axis=1)-mu;space=x.mean(axis=0)-mu
    interaction=x-mu[None,None,:]-time[:,None,:]-space[None,:,:]
    sq=lambda v:float(np.sum(v*v))
    values={'mean_energy':sq(mu),'time_energy':sq(time)/x.shape[0],'space_energy':sq(space)/x.shape[1],
            'interaction_energy':sq(interaction)/(x.shape[0]*x.shape[1]),'total_energy':sq(x)/(x.shape[0]*x.shape[1])}
    values['closure_signed']=values['total_energy']-sum(values[k] for k in ('mean_energy','time_energy','space_energy','interaction_energy'))
    return values

def check_tubelet_ids(ids,times=21,height=29,width=52,spatial_count=16):
    ids=np.asarray(ids)
    if ids.shape!=(times*spatial_count,) or not np.issubdtype(ids.dtype,np.integer):raise ValueError('tubelet size')
    grid=ids.reshape(times,spatial_count);positions=grid%(height*width);t=grid//(height*width)
    if not np.array_equal(t,np.broadcast_to(np.arange(times)[:,None],t.shape)) or not np.all(positions==positions[0]) or len(np.unique(positions[0]))!=spatial_count or np.any(np.diff(positions[0])<=0):raise ValueError('tubelet grid structure')
    return positions[0]
