import unittest
import numpy as np
from secant_math import join_indices,quadrature_hidden,symmetric_gate_components,balanced_tubelet_anova
class SecantTests(unittest.TestCase):
 def test_polynomial_exactness_and_bias_cancel(self):
  a=np.array([-2.,-.3,0.,2.]);b=np.array([1.,2.,0.,4.])
  for degree in (1,2,3,4):
   f=lambda x:x**degree+19.;g=lambda x:degree*x**(degree-1);v=quadrature_hidden(f,g,a,b)
   np.testing.assert_allclose(v['direct'],b**degree-a**degree,atol=1e-13)
   if degree<=2:np.testing.assert_allclose(v['mid'],v['direct'],atol=1e-13)
   np.testing.assert_allclose(v['gl2'],v['direct'],atol=1e-13)
  self.assertGreater(np.max(np.abs(quadrature_hidden(lambda x:x**4,lambda x:4*x**3,a,b)['mid']-(b**4-a**4))),1)
 def test_ids_join_and_tubelet(self):
  ids,a,b=join_indices([9,2,4],[4,7,2],total=10);np.testing.assert_array_equal(ids,[2,4]);np.testing.assert_array_equal(np.array([9,2,4])[a],np.array([4,7,2])[b])
  with self.assertRaises(ValueError):join_indices([1,1],[1],total=10)
  with self.assertRaises(ValueError):join_indices([1,2],[2,1],require_equal=True,total=10)
 def test_gate_cross_can_cancel(self):
  y0=np.array([[1.]]);y1=np.array([[2.]]);g0=np.array([[2.]]);g1=np.array([[1.]]);o=symmetric_gate_components(y0,y1,g0,g1)
  self.assertAlmostEqual(o['gated_delta_sq'][0],0);self.assertLess(o['twice_cross'][0],0);self.assertAlmostEqual(o['closure_signed'][0],0);self.assertAlmostEqual(o['vector_closure_sq'][0],0)
 def test_anova_pure_modes_and_mixture(self):
  t=np.array([-1.,0.,1.])[:,None,None];s=np.array([-1.,1.])[None,:,None]
  for x,key in ((np.broadcast_to(t,(3,2,1)),'time_energy'),(np.broadcast_to(s,(3,2,1)),'space_energy'),(t*s,'interaction_energy')):
   r=balanced_tubelet_anova(x);self.assertGreater(r[key],0);self.assertAlmostEqual(r['closure_signed'],0,places=12)
   self.assertAlmostEqual(sum(r[k] for k in ('mean_energy','time_energy','space_energy','interaction_energy') if k!=key),0,places=12)
  self.assertAlmostEqual(balanced_tubelet_anova(3+t+2*s+t*s)['closure_signed'],0,places=12)
 def test_lifted_native_delta_is_separate(self):
  x=np.array([1.001,1.003],dtype=np.float32);bits=x.view(np.uint32);native=((bits+0x7fff+((bits>>16)&1))&0xffff0000).view(np.float32);smooth=float(x[1]-x[0]);obs=float(native[1]-native[0])
  self.assertGreater((obs-smooth)**2,0);self.assertEqual(obs**2,0)
from secant_math import check_tubelet_ids
class TubeletTests(unittest.TestCase):
 def test_grid_and_identity(self):
  ids=(np.arange(3)[:,None]*12+np.array([1,7])[None,:]).reshape(-1)
  np.testing.assert_array_equal(check_tubelet_ids(ids,3,3,4,2),[1,7])
  ids[-1]+=1
  with self.assertRaises(ValueError):check_tubelet_ids(ids,3,3,4,2)
try:
 import torch
except ImportError:
 torch=None
@unittest.skipIf(torch is None,'torch unavailable on local host')
class TorchSecantTests(unittest.TestCase):
 def test_f64_full_batch_bias_and_native_boundary(self):
  from secant_math import evaluate_batch,gelu_tanh
  torch.manual_seed(8);d,m,n=3,5,4
  z0=torch.randn(n,d,dtype=torch.float64);z1=z0+.3*torch.randn(n,d,dtype=torch.float64)
  w1=torch.randn(m,d,dtype=torch.float64);w2=torch.randn(d,m,dtype=torch.float64);b1=torch.randn(m,dtype=torch.float64);b2=torch.randn(d,dtype=torch.float64)
  gate0=torch.randn(n,d,dtype=torch.float64);gate1=torch.randn(n,d,dtype=torch.float64)
  f0=gelu_tanh(z0@w1.T+b1)@w2.T+b2;f1=gelu_tanh(z1@w1.T+b1)@w2.T+b2
  n0=f0.to(torch.bfloat16).double();n1=f1.to(torch.bfloat16).double()
  r=evaluate_batch(z0,z1,w1,w2,b1,b2,gate0,gate1,n0,n1)
  target=(f1-f0).square().sum(dim=1);torch.testing.assert_close(r['target_sq'],target,rtol=1e-12,atol=1e-12)
  torch.testing.assert_close(r['native_delta_energy'],(n1-n0).square().sum(dim=1))
  self.assertGreater(float(r['native_delta_vs_smooth_err_sq'].sum()),0)
  changed=evaluate_batch(z0,z1,w1,w2,b1,b2+100,gate0,gate1)
  torch.testing.assert_close(changed['target_sq'],r['target_sq'],rtol=0,atol=0)
  self.assertLess(float(r['smooth_endpoint_delta_vs_direct_sq'].max()),1e-25)
  self.assertLess(float(r['da_subtraction_discrepancy_sq'].max()),1e-25)
  self.assertGreater(float(r['da_direct_sq'].sum()),0)
  for method in ('left','mid','gl2'):
   self.assertLess(float(r[method+'_error_computation_discrepancy_sq'].max()),1e-25)
   torch.testing.assert_close(r[method+'_err_sq'],r[method+'_two_products_err_sq'],rtol=1e-9,atol=1e-25)
@unittest.skipIf(torch is None,'torch unavailable on local host')
class RunnerContractTests(unittest.TestCase):
 def test_native_panel_alignment_with_real_torch(self):
  from runner_secant import native_panels
  spatial=torch.arange(16,dtype=torch.int64);tube=(torch.arange(21)[:,None]*1508+spatial).reshape(-1)
  shared=torch.zeros(1,5120,dtype=torch.bfloat16)
  def make(ids):
   return {'z':shared.expand(2048,-1),'w2_output_before_gate':shared.expand(2048,-1),'token_indices':ids,'tubelet_z':shared.expand(336,-1),'tubelet_w2_output_before_gate':shared.expand(336,-1),'tubelet_indices':tube,'tubelet_spatial_indices':spatial}
  d0=make(torch.arange(2048));d1=make(torch.arange(1024,3072));panels=native_panels(d0,d1)
  self.assertEqual(len(panels['tubelet'][0]),336);self.assertEqual(len(panels['uniform'][0]),1024)
  self.assertEqual(int(panels['uniform'][0][0]),1024)
  d1['tubelet_spatial_indices']=spatial+1
  with self.assertRaises(ValueError):native_panels(d0,d1)
 def test_guard_runs_before_weight_import(self):
  import sys,types
  from unittest.mock import patch
  import runner_secant
  guard=types.ModuleType('runtime_guard');guard.require_compute_allocation=lambda:(_ for _ in ()).throw(RuntimeError('NO_ALLOCATION'))
  guard.verify_frozen_scope=lambda *a:None;guard.RunReceipt=object;guard.sha256_file=lambda *a:None
  with patch.dict(sys.modules,{'runtime_guard':guard}),patch.object(sys,'argv',['runner_secant','--scope','x','--scope-sha','x']):
   with self.assertRaisesRegex(RuntimeError,'NO_ALLOCATION'):runner_secant.main()

class BudgetTests(unittest.TestCase):
 def test_actual_allocation_bounds(self):
  from runner_secant import validate_allocation
  s={'budget':{'cpus':4,'host_memory_gib':64,'wall_seconds':7200}}
  ok={'memory_mib':64*1024,'scheduler_job_record':'NumCPUs=4 TimeLimit=02:00:00'};validate_allocation(s,ok)
  for bad in ({'memory_mib':64*1024+1,'scheduler_job_record':'NumCPUs=4 TimeLimit=02:00:00'}, {'memory_mib':1024,'scheduler_job_record':'NumCPUs=5 TimeLimit=02:00:00'}, {'memory_mib':1024,'scheduler_job_record':'NumCPUs=4 TimeLimit=02:00:01'}):
   with self.assertRaises(ValueError):validate_allocation(s,bad)

if __name__=='__main__':unittest.main()
