"""Reviewer-owned arithmetic audit. Reads receipts/JSON only, never tensors/NPZ."""
import argparse
import hashlib
import json
import math
import statistics
from collections import Counter, defaultdict
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def finite_tree(obj):
    if isinstance(obj, float) and not math.isfinite(obj):
        raise ValueError('nonfinite JSON scalar')
    if isinstance(obj, dict):
        for value in obj.values():
            finite_tree(value)
    elif isinstance(obj, list):
        for value in obj:
            finite_tree(value)


def read(path):
    value = json.loads(path.read_text(encoding='utf8'))
    finite_tree(value)
    return value


def lines(path):
    result = [json.loads(line) for line in path.read_text(encoding='utf8').splitlines() if line.strip()]
    finite_tree(result)
    return result


def ratio(a, b):
    return a / b if b > 0 else None


def close(a, b):
    if a is None or b is None:
        assert a is b, (a, b)
    else:
        assert math.isclose(a, b, rel_tol=5e-12, abs_tol=5e-14), (a, b)


def describe(values):
    values = [x for x in values if x is not None]
    return {'n': len(values), 'min': min(values), 'median': statistics.median(values), 'max': max(values)} if values else {'n': 0}


def risk_summary(pairs):
    # Each pair is already an MSE (operator) or an SSE (secant), never mix them.
    num, den = sum(x for x, _ in pairs), sum(y for _, y in pairs)
    values = [x/y for x, y in pairs if y > 0]
    return {'sum_numerator': num, 'sum_denominator': den,
            'ratio_of_sums': ratio(num, den), 'individual_squared_ratio': describe(values),
            'individual_relative_rms': describe([math.sqrt(x) for x in values]),
            'zero_denominators': sum(y == 0 for _, y in pairs)}


def verified_inputs(scope_path, result_dir):
    scope, start, end = read(scope_path), read(result_dir/'START.json'), read(result_dir/'EXIT.json')
    digest = sha(scope_path)
    review = read(scope_path.parent/'INDEPENDENT_REVIEW.json')
    assert review['status'] == 'ACCEPTED' and review['scope_sha256'] == digest
    assert start['scope']['_verified_scope_sha256'] == digest and end['status'] == 'SUCCESS'
    if 'scope_sha256' in end:
        assert end['scope_sha256'] == digest
    return scope, end, {'scope_sha256': digest, 'start_sha256': sha(result_dir/'START.json'),
                        'exit_sha256': sha(result_dir/'EXIT.json'), 'reviewer': '/root/independent_math_review'}


def operator(scope_path, result_dir):
    scope, end, report = verified_inputs(scope_path, result_dir)
    assert scope['phase'] == 'NATIVE_OPERATOR_TRANSFER' and end['result']['sites'] == 160
    ledger_path = result_dir/'sites.jsonl'
    assert sha(ledger_path) == end['result']['site_index_sha256']
    ledger = lines(ledger_path)
    assert len(ledger) == 160 and {(r['step'], r['layer']) for r in ledger} == {(s,l) for s in range(4) for l in range(40)}
    names = ('constant','affine','linear_32','quadratic_32','linear_64','quadratic_64')
    held = ('03','05','06','08')
    risks, selection, anova = defaultdict(list), defaultdict(Counter), defaultdict(list)
    count = 0
    for item in ledger:
        path = result_dir/item['site_file']
        assert path.parent == result_dir and sha(path) == item['site_sha256']
        obj = read(path)
        assert (obj['step'],obj['layer']) == (item['step'],item['layer'])
        assert obj['source_means_sha256'] == item['means_sha256']
        assert set(obj['models']) == set(names)
        assert obj['expert'] == ('high' if obj['step'] < 2 else 'low')
        assert obj['source_split'] == {'CAL':['02','04','07','09'],'DEV':['00','01'],'HELD':list(held)}
        for name, model in obj['models'].items():
            if name != 'constant':
                grid = model['dev_grid']
                assert [g['solve']['multiplier'] for g in grid] == [1e-6,1e-4,1e-2,1.]
                scores = []
                for point in grid:
                    score = sum(point['dev'][x]['post_gate']['mse_total'] for x in ('00','01')) / 2
                    close(score, point['dev_equal_source_post_gate_mse'])
                    scores.append(score)
                chosen = grid[min(range(4),key=scores.__getitem__)]['solve']['multiplier']
                assert chosen == model['selected_multiplier']
                selected = next(g['held'] for g in model['held_grid_after_selection'] if g['multiplier'] == chosen)
                assert selected == model['held_metrics']
                selection[name][str(chosen)] += 1
            for source in held:
                measurements = model['source_metrics'][source] if name == 'constant' else model['held_metrics'][source]
                for panel, value in measurements.items():
                    assert value['mse_total'] >= 0 and value['target_energy'] >= 0 and value['oracle_mean_mse'] >= 0
                    for denominator in ('target_energy','oracle_mean_mse'):
                        close(value['mse_over_'+denominator],ratio(value['mse_total'],value[denominator]))
                        for group in ('all','source='+source,'step='+str(obj['step']),'expert='+obj['expert']):
                            risks[(name,panel,denominator,group)].append((value['mse_total'],value[denominator]))
                count += 1
        for panel, value in obj['source_anova'].items():
            w,b,m,t = (value[k] for k in ('within','between','grand_mean_energy','total_energy_direct'))
            close(t-(m+w+b),value['total_decomposition_residual'])
            direct_loso = sum(value['loso_risk_by_source'].values())/10
            close(direct_loso,value['loso_mean'])
            close(w+(10/9)**2*b,value['loso_identity'])
            close(value['loso_mean']-value['loso_identity'],value['loso_identity_residual'])
            for key,val in [('between_fraction',ratio(b,t)),('shared_mean_fraction',ratio(m,t)),('within_fraction',ratio(w,t)),('loso_over_energy',ratio(direct_loso,t))]:
                anova[panel+'/'+key].append(val)
    report.update(status='RECORDED_SCALAR_ARITHMETIC_REVIEWED',sites=160,held_model_source_site_rows=count,
                  risks={'/'.join(k):risk_summary(v) for k,v in risks.items()},selection_counts=dict(selection),
                  anova={k:describe(v) for k,v in anova.items()},site_ledger_sha256=sha(ledger_path),
                  limit='No tensor/NPZ or coefficients recomputed. Operator uses source-site MSEs; ratios of sums differ from medians of ratios. No blind confirmation or best-affine lower bound.')
    return report


def secant(scope_path, result_dir):
    scope, end, report = verified_inputs(scope_path, result_dir)
    assert scope['phase'] == 'NATIVE_SECANT_F64'
    result=end['result']
    assert result['status'] == 'NATIVE_SECANT_COMPLETE_DESCRIPTIVE_NUMERICS_UNASSESSED'
    for file,key in [('pairs.jsonl','pairs_ledger_sha256'),('weight_reads.jsonl','weight_ledger_sha256'),('environment.jsonl','environment_sha256')]:
        assert sha(result_dir/file) == result[key]
    weights = lines(result_dir/'weight_reads.jsonl')
    hashes = read(scope_path.parent/'weight_hashes.json')
    seen = set()
    for item in weights:
        key = item['expert']+'/'+{'Oq':'original','Dq':'distilled'}[item['arm']]+'/'+item['key']
        assert key not in seen and item['sha256'] == hashes[key]
        seen.add(key)
    assert len(weights) == 640 and seen == set(hashes)
    pairs = lines(result_dir/'pairs.jsonl')
    assert len(pairs) == 800 and {(x['source_id'],x['expert'],x['layer']) for x in pairs} == {(f'chip10_{s:02}',e,l) for s in range(10) for e in ('high','low') for l in range(40)}
    totals, risks, closures, samples = defaultdict(lambda:defaultdict(float)),defaultdict(list),defaultdict(list),Counter()
    for pair in pairs:
        assert pair['steps'] == ([0,1] if pair['expert'] == 'high' else [2,3]) and pair['numeric_status'] == 'UNASSESSED'
        for panel in ('tubelet','uniform'):
            p = pair['panels'][panel];n = p['matched_rows'];stats = p['sums']
            assert n > 0 and len(p['latent_time_counts']) == 21 and sum(p['latent_time_counts']) == n
            if panel == 'tubelet':assert n == 336 and p['latent_time_counts'] == [16]*21
            samples[panel] += n
            for arm in ('Oq','Dq'):
                values={k[len(arm)+2:]:v for k,v in stats.items() if k.startswith(arm+'__')}
                assert all(v >= 0 for v in values.values())
                for group in ('all','source='+pair['source_id'],'expert='+pair['expert']):
                    key=(panel,arm,group)
                    for name,value in values.items():totals[key][name] += value
                    for method in ('left','mid','gl2'):
                        for suffix,den in [('', 'target_sq'),('_gate','target_gate_sq'),('_hidden','delta_hidden_sq')]:
                            risks[key+(method+suffix,)].append((values[method+suffix+'_err_sq'],values[den]))
            g={k[len('gate_decomposition__'):]:v for k,v in stats.items() if k.startswith('gate_decomposition__')}
            closure=g['gated_delta_sq']-g['gate_change_sq']-g['state_change_sq']-g['twice_cross']
            # Summed pointwise closures and closure of sums differ by rounding; retain it.
            closures[panel+'/gate_summed_arithmetic_discrepancy'].append(closure-g['closure_signed'])
        assert set(pair['tubelet_endpoint_anova']) == {str(s) for s in pair['steps']}
        for parts in pair['tubelet_endpoint_anova'].values():
            for kind,value in parts.items():
                residual=value['total_energy']-sum(value[k] for k in ('mean_energy','time_energy','space_energy','interaction_energy'))
                # Python/NumPy summation orders can differ near an exactly zero
                # closure. Compare on the original energy scale, not a fixed
                # absolute tolerance on the cancellation residual itself.
                scale=sum(abs(value[k]) for k in ('total_energy','mean_energy','time_energy','space_energy','interaction_energy'))
                assert abs(residual-value['closure_signed']) <= 32*math.ulp(1.0)*scale, (residual,value['closure_signed'],scale)
                closures[kind+'/anova_reaggregation_discrepancy'].append(residual-value['closure_signed'])
                closures[kind+'/anova_closure'].append(residual)
    bounds={}
    for key,v in totals.items():
        if key[1] != 'Dq':continue
        for method in ('left','mid','gl2'):
            for suffix,den in [('', 'native_delta_energy'),('_gate','native_delta_gate_energy')]:
                a,b=v[method+suffix+'_err_sq'],v['native_delta_vs_smooth'+suffix+'_err_sq']
                lo,hi=(math.sqrt(a)-math.sqrt(b))**2,(math.sqrt(a)+math.sqrt(b))**2
                bounds['/'.join(key+(method+suffix,))]={'lower':ratio(lo,v[den]),'upper':ratio(hi,v[den]),'unassessed_measurements_not_IEEE_certificate':True}
    report.update(status='RECORDED_SCALAR_ARITHMETIC_REVIEWED',pair_count=800,weight_reads=640,samples=dict(samples),
                  risks={'/'.join(k):risk_summary(v) for k,v in risks.items()},native_triangle_bounds=bounds,
                  closure_diagnostics={k:describe(v) for k,v in closures.items()},
                  limit='No NPZ/tensor read. SSE sums weight variable uniform intersections by matched row count. Descriptive chord errors only; no shared constant A or global degree established.')
    return report


def main():
    p=argparse.ArgumentParser();p.add_argument('--kind',choices=['operator','secant'],required=True);p.add_argument('--scope',type=Path,required=True);p.add_argument('--result-dir',type=Path,required=True);p.add_argument('--report',type=Path,required=True);a=p.parse_args()
    result={'operator':operator,'secant':secant}[a.kind](a.scope.resolve(),a.result_dir.resolve())
    with a.report.open('x',encoding='utf8') as file:json.dump(result,file,indent=2,allow_nan=False)
    print(a.kind,'recorded scalar audit written',a.report)


if __name__ == '__main__':main()
