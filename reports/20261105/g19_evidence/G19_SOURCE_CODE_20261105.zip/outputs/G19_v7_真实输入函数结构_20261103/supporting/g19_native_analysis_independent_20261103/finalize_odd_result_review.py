"""Independent recorded-scalar comparison and binary SHA audit. No tensor loading."""
import csv
import hashlib
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT/'work/g19_native_odd_secant_20261103/odd_full_r1'
OUT = BASE/'output'
SECANT = ROOT/'work/g19_native_secant_20261103/secant_full_r2/output'

def read(p): return json.loads(p.read_text(encoding='utf8'))
def lines(p): return [json.loads(x) for x in p.read_text(encoding='utf8').splitlines() if x.strip()]
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        while b:=f.read(1024*1024): h.update(b)
    return h.hexdigest()

checks=0
def close(a,b):
    global checks
    if a is None or b is None: assert a is b,(a,b)
    else:
        assert math.isfinite(a) and math.isfinite(b),(a,b)
        assert math.isclose(a,b,rel_tol=3e-12,abs_tol=3e-14),(a,b)
    checks+=1

def desc(v): return {'min':min(v),'median':statistics.median(v),'max':max(v),'n':len(v)} if v else None
def compare_desc(a,b):
    if a is None: assert b is None
    else:
        assert set(a)==set(b)
        for k,v in a.items(): close(v,b[k])

summary_path=BASE/'ODD_DESCRIPTIVE_SUMMARY.json'
csv_path=BASE/'ODD_PAIR_SCALARS.csv'
assert sha(summary_path)=='6adab31cb2605a20457fddcb60659b226418c7460b25216f399bc8e4fe0641c1'
assert sha(csv_path)=='464d23d453fceefc5dd2a791d700d668b52ae8018720b416a09a061d447fa780'
summary=read(summary_path)
secant_exit=read(SECANT/'EXIT.json')
secant_sha=sha(SECANT/'pairs.jsonl')
assert secant_sha==secant_exit['result']['pairs_ledger_sha256']==summary['secant_ledger_sha256']=='beb5b39f534769ce877f14cec61046d916c9d14af4d0547b39f7a6cc3a83f5ca'
secant={(p['source_id'],p['expert'],p['layer']):p for p in lines(SECANT/'pairs.jsonl')}
pairs=lines(OUT/'pairs.jsonl'); assert len(pairs)==800
groups=defaultdict(list); canonical_rows={}; artifact_bytes=0; artifact_names=set()
max_scaled_closure=0; max_reduction_closure_disagreement=0; max_even_residual_relative_difference=0
all_cos=[]; reflection=[]; source_odd=defaultdict(lambda:[0.,0.])
for pair in pairs:
    k=(pair['source_id'],pair['expert'],pair['layer']); old=secant[k]
    assert pair['capture_sha256']==old['capture_sha256'] and pair['steps']==old['steps']
    artifact=OUT/pair['artifact']; assert artifact.parent==OUT and artifact.name not in artifact_names
    artifact_names.add(artifact.name)
    assert sha(artifact)==pair['artifact_sha256']; artifact_bytes+=artifact.stat().st_size
    for panel in ('tubelet','uniform'):
        q=pair['panels'][panel]; prior=old['panels'][panel]
        assert q['matched_rows']==prior['matched_rows'] and q['latent_time_counts']==prior['latent_time_counts']
        assert all(math.isfinite(v) for v in q['sums'].values())
        for arm in ('Oq','Dq'):
            v={key.split('__',1)[1]:value for key,value in q['sums'].items() if key.startswith(arm+'__')}
            r={'source':k[0],'expert':k[1],'layer':k[2],'panel':panel,'arm':arm,'matched_rows':q['matched_rows']}
            for short,prefix in (('','output_'),('midgate_','midgate_'),('endpoint_gate_','endpoint_gate_')):
                mapping={'target':'target_sq','odd':'odd_sq','even':'even_error_sq','cross':'twice_cross','direct_residual':'direct_odd_residual_sq'}
                for dest,src in mapping.items():
                    dst=(short+dest) if short or dest!='direct_residual' else 'odd_direct_residual'
                    r[dst]=v[prefix+src]
                if short!='endpoint_gate_': r[short+'closure_vector']=v[prefix+'vector_closure_sq']
            r['closure_signed']=v['output_closure_signed']
            r['reflection_sum']=v['preactivation_sum_sq'];r['reflection_delta']=v['preactivation_delta_sq']
            if arm=='Dq':
                for gate in ('','_gate'):
                    r['native_endpoint'+gate+'_energy']=v['native_endpoint1'+gate+'_energy']
                    r['native_endpoint'+gate+'_error']=v['native_endpoint1'+gate+'_error_sq']
            for label,field,sourcefield in [('output','target','target_sq'),('midgate','midgate_target','target_gate_sq')]:
                reference=prior['sums'][arm+'__'+sourcefield]
                assert r[field]==reference
                r['secant_'+label+'_target']=reference
                r['secant_'+label+'_target_difference']=0.
                r['secant_'+label+'_target_relative_difference']=0. if reference else None
            canonical_rows[(k[0],k[1],k[2],panel,arm)]=r;groups[(k[1],panel,arm)].append(r)
            for prefix in ('hidden_','output_','midgate_','endpoint_gate_'):
                t,o,e,c=[v[prefix+x] for x in ('target_sq','odd_sq','even_error_sq','twice_cross')]
                signed=v[prefix+'closure_signed']; reconstructed=t-o-e-c
                scale=t+o+e+abs(c)
                max_scaled_closure=max(max_scaled_closure,abs(reconstructed)/scale)
                max_reduction_closure_disagreement=max(max_reduction_closure_disagreement,abs(reconstructed-signed)/scale)
                max_even_residual_relative_difference=max(max_even_residual_relative_difference,abs(e-v[prefix+'direct_odd_residual_sq'])/max(e,t))
            if arm=='Dq':
                reflection.append(r['reflection_sum']/r['reflection_delta'])
                a=source_odd[(k[1],panel,k[0])];a[0]+=r['odd_direct_residual'];a[1]+=r['target']

assert len(artifact_names)==800 and {p.name for p in OUT.glob('*.npz')}==artifact_names
with csv_path.open(encoding='utf8',newline='') as f: csv_rows=list(csv.DictReader(f))
assert len(csv_rows)==3200
seen=set()
for row in csv_rows:
    key=(row['source'],row['expert'],int(row['layer']),row['panel'],row['arm']);assert key not in seen;seen.add(key)
    expected=canonical_rows[key]
    for field,val in expected.items():
        if isinstance(val,str):assert row[field]==val
        elif val is None:assert row[field]==''
        else:close(float(row[field]),val)
    assert all(not value for field,value in row.items() if field not in expected)

geometry_results={}
for key,rs in groups.items():
    g=summary['groups']['__'.join(key)]; assert g['records']==len(rs)==400
    assert g['pairs_with_zero_target']==sum(r['target']==0 for r in rs)
    ratio_pairs=[('odd_direct_residual','target'),('even','target'),('odd','target'),('cross','target'),('reflection_sum','reflection_delta'),('closure_vector','target'),('midgate_closure_vector','midgate_target')]
    for prefix in ('midgate_','endpoint_gate_'):
        ratio_pairs.extend((prefix+x,prefix+'target') for x in ('direct_residual','odd','even','cross'))
    if key[2]=='Dq':ratio_pairs.extend([('native_endpoint_error','native_endpoint_energy'),('native_endpoint_gate_error','native_endpoint_gate_energy')])
    for numerator,denominator in ratio_pairs:
        got=g[numerator+'_over_'+denominator];n=sum(r[numerator] for r in rs);d=sum(r[denominator] for r in rs)
        close(n,got['numerator_sum']);close(d,got['denominator_sum']);close(n/d if d>0 else None,got['ratio_of_sums'])
        vals=[r[numerator]/r[denominator] for r in rs if r[denominator]>0]
        compare_desc(desc(vals),got['median_of_pair_ratios']);assert got['zero_denominator_pairs']==sum(r[denominator]==0 for r in rs)
    for prefix in ('','midgate_','endpoint_gate_'):
        target=sum(r[prefix+'target'] for r in rs);odd=sum(r[prefix+'odd'] for r in rs);even=sum(r[prefix+'even'] for r in rs);cross=sum(r[prefix+'cross'] for r in rs)
        residual_field=prefix+'direct_residual' if prefix else 'odd_direct_residual'
        residual=sum(r[residual_field] for r in rs)
        cd=(odd+target-residual)/(2*math.sqrt(odd*target));cc=(odd+cross/2)/math.sqrt(odd*target)
        vals=[1-((r[prefix+'odd']+r[prefix+'target']-r[residual_field])/(2*math.sqrt(r[prefix+'odd']*r[prefix+'target'])))**2 for r in rs if r[prefix+'odd']>0 and r[prefix+'target']>0]
        expected={'cos_cross':cc,'cos_direct':cd,'cos_difference':cc-cd,'unconstrained_gain_from_direct':(odd+target-residual)/(2*odd),'unconstrained_gain_oracle_residual_fraction':1-cd*cd,'sum_relative_condition_factor':(math.sqrt(odd)+math.sqrt(even))/math.sqrt(target),'odd_even_cosine':cross/(2*math.sqrt(odd*even))}
        got=g[(prefix or 'output_')+'geometry']
        for field,val in expected.items():close(val,got[field])
        compare_desc(desc(vals),got['per_pair_free_gain_oracle_residual_fraction']);assert got['per_pair_oracle_unavailable']==400-len(vals)
        all_cos.append(cd);geometry_results['/'.join(key)+'/'+(prefix or 'output')]=expected
    compare_desc(desc([abs(r['closure_signed']) for r in rs]),g['signed_closure_absolute'])
    for label in ('output','midgate'):compare_desc(desc([0.]*400),g['secant_'+label+'_target_relative_difference'])

report={'status':'INDEPENDENT_RECORDED_RESULTS_AND_ARTIFACT_HASHES_VERIFIED','reviewer':'/root/independent_math_review',
    'scope_sha256':sha(BASE/'scope.json'),'summary_sha256':sha(summary_path),'csv_sha256':sha(csv_path),
    'checker_sha256':sha(Path(__file__)),'scalar_checker_sha256':sha(Path(__file__).with_name('review_odd_scalars.py')),
    'notes_sha256':sha(BASE/'FINAL_ODD_FINDINGS.md'),'pairs_ledger_sha256':sha(OUT/'pairs.jsonl'),'secant_authenticated_pairs_ledger_sha256':secant_sha,
    'npz_count':800,'npz_bytes':artifact_bytes,'csv_rows':3200,'numeric_comparisons':checks,'group_count':len(groups),
    'max_energy_closure_over_absolute_terms':max_scaled_closure,'max_reduction_closure_disagreement_over_absolute_terms':max_reduction_closure_disagreement,
    'max_even_vs_direct_residual_relative_difference':max_even_residual_relative_difference,'geometry':geometry_results,
    'Dq_reflection_pair_distribution':desc(reflection),
    'Dq_source_pooled_direct_odd_risk':{'/'.join(k):v[0]/v[1] for k,v in source_odd.items()},
    'limits':'Raw NPZ bytes hashed but arrays not loaded. Original weights/captures and model operations not rerun. No IEEE error certificate; finite descriptive source-level evidence, no deployment/low-rank claim.'}
with (BASE/'INDEPENDENT_RESULT_CHECKS.json').open('x',encoding='utf8') as f:json.dump(report,f,indent=2,allow_nan=False)
print(json.dumps({k:v for k,v in report.items() if k not in ('geometry','Dq_source_pooled_direct_odd_risk')},indent=2))
