"""Independent odd result arithmetic; JSON only, no model or array loading."""
import argparse
import json
import math
from collections import defaultdict
from pathlib import Path
from review_recorded_scalars import read, lines, sha, verified_inputs, ratio, risk_summary, describe


def geometry(total, odd, cross, residual, closure):
    if total <= 0 or odd <= 0:
        return {'status':'UNAVAILABLE_NONPOSITIVE_TARGET_OR_ODD'}
    denominator = math.sqrt(total*odd)
    dot_cross = odd+cross/2
    dot_direct = (odd+total-residual)/2
    c, d = dot_cross/denominator, dot_direct/denominator
    return {'status':'NUMERICALLY_UNCERTIFIED', 'cos_cross':c, 'cos_direct':d,
            'cross_oracle_residual_fraction':1-c*c, 'direct_oracle_residual_fraction':1-d*d,
            'cross_oracle_real_gain':dot_cross/odd, 'direct_oracle_real_gain':dot_direct/odd,
            'cos_discrepancy':c-d, 'formal_closure_cos_envelope':math.sqrt(closure/total),
            'cross_cos_outside_unit_interval':abs(c)>1, 'direct_cos_outside_unit_interval':abs(d)>1,
            'interpretation':'One arbitrary real gain for the whole specified concatenated vector; negative gain permitted. Not fitted/validated predictor; no clipping or IEEE certificate.'}


def run(scope_path, result_dir):
    scope,end,report=verified_inputs(scope_path,result_dir)
    assert scope['phase']=='NATIVE_ODD_SECANT'
    result=end['result']
    assert result['status']=='NATIVE_ODD_SECANT_COMPLETE_DESCRIPTIVE_NUMERICS_UNASSESSED'
    for filename,key in [('pairs.jsonl','pairs_ledger_sha256'),('weight_reads.jsonl','weight_ledger_sha256'),('environment.jsonl','environment_sha256')]:
        assert sha(result_dir/filename)==result[key]
    weights=lines(result_dir/'weight_reads.jsonl');expected=read(scope_path.parent/'weight_hashes.json');seen=set()
    for w in weights:
        key=w['expert']+'/'+{'Oq':'original','Dq':'distilled'}[w['arm']]+'/'+w['key']
        assert key not in seen and w['sha256']==expected[key]
        seen.add(key)
    assert len(weights)==640 and seen==set(expected)
    pairs=lines(result_dir/'pairs.jsonl')
    assert len(pairs)==800 and {(p['source_id'],p['expert'],p['layer']) for p in pairs}=={(f'chip10_{s:02}',e,l) for s in range(10) for e in ('high','low') for l in range(40)}
    assert (result['pair_count'],result['arm_count'],result['weight_read_count'])==(800,1600,640)
    groups=defaultdict(list);pair_geometry=[]
    for p in pairs:
        assert p['steps']==([0,1] if p['expert']=='high' else [2,3]) and p['numeric_status']=='UNASSESSED'
        for panel in ('tubelet','uniform'):
            q=p['panels'][panel];n=q['matched_rows'];assert n>0 and sum(q['latent_time_counts'])==n and len(q['latent_time_counts'])==21
            if panel=='tubelet':assert n==336 and q['latent_time_counts']==[16]*21
            for arm in ('Oq','Dq'):
                values={k[len(arm)+2:]:v for k,v in q['sums'].items() if k.startswith(arm+'__')}
                assert all(v>=0 for k,v in values.items() if not k.endswith(('twice_cross','closure_signed')))
                for kind in ('hidden','output','midgate','endpoint_gate'):
                    fields=('target_sq','odd_sq','even_error_sq','direct_odd_residual_sq','twice_cross','vector_closure_sq','closure_signed')
                    r={k:values[kind+'_'+k] for k in fields}
                    r['reflection_numerator']=values['preactivation_sum_sq'];r['reflection_denominator']=values['preactivation_delta_sq'];r['samples']=n
                    for group in ('all','expert='+p['expert'],'source='+p['source_id'],'expert_layer='+p['expert']+'/'+str(p['layer'])):
                        groups[(panel,arm,kind,group)].append(r)
                    pair_geometry.append({'source':p['source_id'],'expert':p['expert'],'layer':p['layer'],'panel':panel,'arm':arm,'kind':kind,
                        **geometry(r['target_sq'],r['odd_sq'],r['twice_cross'],r['direct_odd_residual_sq'],r['vector_closure_sq'])})
                if arm=='Dq':
                    for gate in ('','_gate'):
                        r={'target_sq':values['native_endpoint1'+gate+'_energy'],'direct_odd_residual_sq':values['native_endpoint1'+gate+'_error_sq'],'samples':n}
                        for group in ('all','expert='+p['expert'],'source='+p['source_id'],'expert_layer='+p['expert']+'/'+str(p['layer'])):
                            groups[(panel,arm,'native_endpoint'+gate,group)].append(r)
    summaries={}
    for key,rows in groups.items():
        sums={field:sum(r[field] for r in rows) for field in rows[0]}
        q={'pair_count':len(rows),'samples':int(sums['samples']),
           'direct_odd_risk':risk_summary([(r['direct_odd_residual_sq'],r['target_sq']) for r in rows])}
        if not key[2].startswith('native_'):
            q.update(geometry=geometry(sums['target_sq'],sums['odd_sq'],sums['twice_cross'],sums['direct_odd_residual_sq'],sums['vector_closure_sq']),
                even_risk= risk_summary([(r['even_error_sq'],r['target_sq']) for r in rows]),
                reflection= risk_summary([(r['reflection_numerator'],r['reflection_denominator']) for r in rows]),
                signed_cross_over_target=ratio(sums['twice_cross'],sums['target_sq']),
                vector_closure_over_target=ratio(sums['vector_closure_sq'],sums['target_sq']))
            individual=[geometry(r['target_sq'],r['odd_sq'],r['twice_cross'],r['direct_odd_residual_sq'],r['vector_closure_sq']) for r in rows]
            for field in ('cos_cross','cos_direct','cross_oracle_residual_fraction','direct_oracle_residual_fraction','cross_oracle_real_gain'):
                q[field+'_pair_distribution']=describe([v.get(field) for v in individual])
        summaries['/'.join(key)]=q
    report.update(status='RECORDED_ODD_SCALAR_ARITHMETIC_REVIEWED',pair_count=800,weight_read_count=640,groups=summaries,
                  pair_geometries=pair_geometry,limit='Complete JSON/ledger audit only. No original tensors, NPZ arrays or model calculations. Increment target and native endpoint target remain distinct. Uniform intersections have variable row counts. Oracle geometry is not a new prediction experiment.')
    return report


def main():
    p=argparse.ArgumentParser();p.add_argument('--scope',required=True,type=Path);p.add_argument('--result-dir',required=True,type=Path);p.add_argument('--report',required=True,type=Path);a=p.parse_args()
    out=run(a.scope.resolve(),a.result_dir.resolve())
    with a.report.open('x',encoding='utf8') as f:json.dump(out,f,indent=2,allow_nan=False)
    print('odd scalar review saved',a.report)


if __name__=='__main__':main()
