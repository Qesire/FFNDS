"""Plot completed, verified PAIR_ROWS.csv; no tensors or model inference.

Example: python plot_secant.py --input results/summary/PAIR_ROWS.csv --output-dir figures
Solid curves are medians of ten source-level ratios, not ratios of sums.
"""
import argparse
import csv
import hashlib
import math
import statistics
from collections import defaultdict
from pathlib import Path

EXPERTS = ('high', 'low')
PANELS = ('uniform', 'tubelet')
FIELDS = {'Left tangent': 'left_err_sq', 'Midpoint': 'mid_err_sq',
          'Two-point Gauss': 'gl2_err_sq',
          'Native–smooth discrepancy': 'native_delta_vs_smooth_err_sq'}


def load_series(path):
    data = Path(path).read_bytes()
    import io
    rows = list(csv.DictReader(io.StringIO(data.decode('utf-8-sig'), newline='')))
    grouped = defaultdict(dict)
    for row in rows:
        if row['arm'] != 'Dq':
            continue
        expert, panel, source = row['expert'], row['panel'], row['source_id']
        layer = int(row['layer'])
        if expert not in EXPERTS or panel not in PANELS or not 0 <= layer < 40:
            raise ValueError('unexpected expert, panel or layer')
        if source not in {f'chip10_{i:02}' for i in range(10)}:
            raise ValueError('unexpected source')
        key = (expert, panel, layer)
        if source in grouped[key]:
            raise ValueError(f'duplicate source: {key}, {source}')
        denominator = float(row['target_sq'])
        if not math.isfinite(denominator) or denominator <= 0:
            raise ValueError(f'invalid smooth target energy: {key}, {source}')
        values = {}
        for label, field in FIELDS.items():
            numerator = float(row[field])
            if not math.isfinite(numerator) or numerator < 0:
                raise ValueError(f'invalid {field}: {key}, {source}')
            values[label] = numerator / denominator
        grouped[key][source] = values
    expected = {(e, p, layer) for e in EXPERTS for p in PANELS for layer in range(40)}
    sources = {f'chip10_{i:02}' for i in range(10)}
    if set(grouped) != expected or any(set(v) != sources for v in grouped.values()):
        raise ValueError('incomplete Dq: require 40 layers × 10 sources × 2 panels × 2 experts')
    result = {}
    for key, values in grouped.items():
        result[key] = {label: statistics.median(v[label] for v in values.values())
                       for label in FIELDS}
    return result, hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    series, digest = load_series(args.input)
    # Lazy import permits lightweight schema checks where matplotlib is unavailable.
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    colors = {'Left tangent': '#c3423f', 'Midpoint': '#d28a19',
              'Two-point Gauss': '#166ba0', 'Native–smooth discrepancy': '#777777'}
    fig, axes = plt.subplots(2, 2, figsize=(12, 8.3), sharex=True, sharey=True)
    fig.subplots_adjust(left=.09, right=.98, top=.90, bottom=.20, hspace=.25, wspace=.14)
    zero_count = 0
    for i, expert in enumerate(EXPERTS):
        for j, panel in enumerate(PANELS):
            ax = axes[i, j]
            for label in FIELDS:
                values = [series[(expert, panel, layer)][label] for layer in range(40)]
                zero_count += sum(x == 0 for x in values)
                # A true zero is undefined on a logarithmic axis: show a gap, never a fake floor.
                shown = [x if x > 0 else float('nan') for x in values]
                ax.plot(range(40), shown, label=label, color=colors[label],
                        linewidth=1.8 if label != 'Native–smooth discrepancy' else 1.3)
            ax.axhline(1, color='#333333', linestyle=':', linewidth=1.0,
                       label='Zero-increment prediction (1)')
            ax.set_title(f'{expert.capitalize()} expert · {panel} panel')
            ax.set_yscale('log')
            ax.set_xlim(0, 39)
            ax.set_xticks([0, 10, 20, 30, 39])
            ax.grid(True, which='major', alpha=.22)
            if i == 1:
                ax.set_xlabel('Layer')
            if j == 0:
                ax.set_ylabel('Median source SSE / smooth increment energy')
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc='lower center', bbox_to_anchor=(.5, .065),
               ncol=3, frameon=False)
    fig.suptitle('Dq FFN increment: directional quadrature on observed endpoint chords',
                 fontsize=14)
    fig.text(.5, .025,
             'Each point: median of 10 source-level ratios; panels remain separate. '
             'Smooth FP64 target; native discrepancy is a diagnostic, not a certified floor.',
             ha='center', fontsize=8)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    for suffix in ('png', 'svg'):
        fig.savefig(args.output_dir / f'secant_layer_risk.{suffix}', dpi=180)
    plt.close(fig)
    print(f'input_sha256={digest} zero_medians_omitted_from_log_axis={zero_count}')


if __name__ == '__main__':
    main()
