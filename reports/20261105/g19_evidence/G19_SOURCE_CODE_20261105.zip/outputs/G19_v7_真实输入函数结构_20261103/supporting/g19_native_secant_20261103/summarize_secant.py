"""Metadata-only native secant summary; never read NPZ or run model inference."""
import argparse,csv,hashlib,json,math,statistics
from collections import defaultdict
from pathlib import Path

def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def ratio(a,b):return a/b if b>0 else None
def minkowski_bounds(a,b,denom):
 if a<0 or b<0:raise ValueError('negative squared norm')
 lo=(math.sqrt(a)-math.sqrt(b))**2;hi=(math.sqrt(a)+math.sqrt(b))**2
 return {'lower_sse':lo,'upper_sse':hi,'lower_over_native_energy':ratio(lo,denom),'upper_over_native_energy':ratio(hi,denom),'interpretation':'triangle bound on measured values; not IEEE-certified or observed exact error'}

def quantiles(values):
 values=sorted(x for x in values if x is not None)
 if not values:return {'n':0,'p10':None,'median':None,'p90':None}
 def q(p):
  f=(len(values)-1)*p;i=int(f);j=min(i+1,len(values)-1);return values[i]+(values[j]-values[i])*(f-i)
 return {'n':len(values),'p10':q(.1),'median':q(.5),'p90':q(.9)}
def aggregate(rows):
 out={'pairs':len(rows),'samples':sum(r['samples'] for r in rows)}
 fields=['target_sq','target_gate_sq','delta_hidden_sq','left_err_sq','mid_err_sq','gl2_err_sq','left_gate_err_sq','mid_gate_err_sq','gl2_gate_err_sq','left_hidden_err_sq','mid_hidden_err_sq','gl2_hidden_err_sq','delta_z_sq','da_direct_sq','da_subtraction_discrepancy_sq','left_two_products_err_sq','mid_two_products_err_sq','gl2_two_products_err_sq','left_error_computation_discrepancy_sq','mid_error_computation_discrepancy_sq','gl2_error_computation_discrepancy_sq']
 for field in fields:out[field+'_sum']=sum(r[field] for r in rows)
 for name in ('left','mid','gl2'):
  out[name+'_sse_over_target_ratio_of_sums']=ratio(out[name+'_err_sq_sum'],out['target_sq_sum'])
  out[name+'_gate_sse_over_target_ratio_of_sums']=ratio(out[name+'_gate_err_sq_sum'],out['target_gate_sq_sum'])
  out[name+'_hidden_sse_over_target_ratio_of_sums']=ratio(out[name+'_hidden_err_sq_sum'],out['delta_hidden_sq_sum'])
  out[name+'_pair_ratio_quantiles']=quantiles([ratio(r[name+'_err_sq'],r['target_sq']) for r in rows])
 for name in ('mid','gl2'):
  x=ratio(out[name+'_err_sq_sum'],out['left_err_sq_sum']);out[name+'_output_improvement_vs_left']=None if x is None else 1-x
  x=ratio(out[name+'_hidden_err_sq_sum'],out['left_hidden_err_sq_sum']);out[name+'_hidden_improvement_vs_left']=None if x is None else 1-x
 out['da_discrepancy_over_direct']=ratio(out['da_subtraction_discrepancy_sq_sum'],out['da_direct_sq_sum'])
 for name in ('left','mid','gl2'):
  out[name+'_error_computation_discrepancy_over_error']=ratio(out[name+'_error_computation_discrepancy_sq_sum'],out[name+'_err_sq_sum'])
 native=['native_delta_energy','native_delta_vs_smooth_err_sq','endpoint0_native_err_sq','endpoint1_native_err_sq','endpoint0_native_energy','endpoint1_native_energy','smooth_endpoint_delta_vs_direct_sq']
 if all(f in r for r in rows for f in native):
  for f in native:out[f+'_sum']=sum(r[f] for r in rows)
  out['native_delta_floor_over_native_energy']=ratio(out['native_delta_vs_smooth_err_sq_sum'],out['native_delta_energy_sum'])
  out['native_delta_floor_over_smooth_target']=ratio(out['native_delta_vs_smooth_err_sq_sum'],out['target_sq_sum'])
  for i in (0,1):out[f'endpoint{i}_error_over_native_energy']=ratio(out[f'endpoint{i}_native_err_sq_sum'],out[f'endpoint{i}_native_energy_sum'])
  for name in ('left','mid','gl2'):
   out[name+'_native_error_triangle_bounds']=minkowski_bounds(out[name+'_err_sq_sum'],out['native_delta_vs_smooth_err_sq_sum'],out['native_delta_energy_sum'])
   ga=sum(r['native_delta_vs_smooth_gate_err_sq'] for r in rows);gn=sum(r['native_delta_gate_energy'] for r in rows)
   out[name+'_native_gate_error_triangle_bounds']=minkowski_bounds(out[name+'_gate_err_sq_sum'],ga,gn)
 return out

def gates_aggregate(rows):
 keys=('gate_change_sq','state_change_sq','twice_cross','gated_delta_sq','closure_signed','vector_closure_sq')
 out={'pairs':len(rows),'samples':sum(r['samples'] for r in rows)}
 for k in keys:out[k+'_sum']=sum(r[k] for r in rows)
 for k in ('gate_change_sq','state_change_sq','twice_cross'):out[k+'_over_gated_delta']=ratio(out[k+'_sum'],out['gated_delta_sq_sum'])
 return out

def anova_aggregate(rows):
 keys=('mean_energy','time_energy','space_energy','interaction_energy','total_energy','closure_signed')
 out={'endpoints':len(rows)}
 for k in keys:out[k+'_sum']=sum(r[k] for r in rows)
 centered=sum(out[k+'_sum'] for k in ('time_energy','space_energy','interaction_energy'))
 for k in ('mean_energy','time_energy','space_energy','interaction_energy'):out[k+'_share_including_mean']=ratio(out[k+'_sum'],out['total_energy_sum'])
 for k in ('time_energy','space_energy','interaction_energy'):out[k+'_share_excluding_mean']=ratio(out[k+'_sum'],centered)
 return out

def group_records(rows,func,dimensions):
 tables={}
 for name,keys in dimensions.items():
  groups=defaultdict(list)
  for r in rows:groups[tuple(r[k] for k in keys)].append(r)
  tables[name]=[{**dict(zip(keys,key)),**func(value)} for key,value in sorted(groups.items())]
 return tables

def main():
 p=argparse.ArgumentParser();p.add_argument('--result-dir',type=Path,required=True);p.add_argument('--scope',type=Path,required=True);p.add_argument('--review',type=Path,required=True);p.add_argument('--output-dir',type=Path,required=True);a=p.parse_args()
 scope=json.loads(a.scope.read_text(encoding='utf8'));review=json.loads(a.review.read_text(encoding='utf8'));start=json.loads((a.result_dir/'START.json').read_text(encoding='utf8'));end=json.loads((a.result_dir/'EXIT.json').read_text(encoding='utf8'));digest=sha(a.scope)
 if scope.get('phase')!='NATIVE_SECANT_F64' or review.get('status')!='ACCEPTED' or review.get('scope_sha256')!=digest or start['scope'].get('_verified_scope_sha256')!=digest or end.get('status')!='SUCCESS':raise ValueError('unverified scope or unsuccessful run')
 res=end['result'];ledger=a.result_dir/'pairs.jsonl';weights=a.result_dir/'weight_reads.jsonl';env=a.result_dir/'environment.jsonl'
 if res.get('status')!='NATIVE_SECANT_COMPLETE_DESCRIPTIVE_NUMERICS_UNASSESSED' or sha(ledger)!=res['pairs_ledger_sha256'] or sha(weights)!=res['weight_ledger_sha256'] or sha(env)!=res['environment_sha256']:raise ValueError('receipt/ledger identity')
 records=[json.loads(line,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x))) for line in ledger.read_text(encoding='utf8').splitlines() if line.strip()]
 if len(records)!=800 or res['pair_count']!=800 or res['arm_count']!=1600 or res['weight_read_count']!=640:raise ValueError('pair/arm/weight coverage')
 expected={(f'chip10_{n:02}',e,l) for n in range(10) for e in ('high','low') for l in range(40)}
 if {(r['source_id'],r['expert'],r['layer']) for r in records}!=expected:raise ValueError('source/expert/layer coverage')
 pair=[];gate=[];anova=[]
 for r in records:
  expert=r['expert'];layer=r['layer'];source=r['source_id']
  if r['steps']!=([0,1] if expert=='high' else [2,3]) or r.get('numeric_status')!='UNASSESSED':raise ValueError('invalid path semantics')
  for panel in ('tubelet','uniform'):
   pinfo=r['panels'][panel];n=pinfo['matched_rows'];s=pinfo['sums'];counts=pinfo['latent_time_counts']
   if len(counts)!=21 or sum(counts)!=n or n<1 or (panel=='tubelet' and n!=336):raise ValueError('panel coverage')
   for arm in ('Oq','Dq'):
    row={'source_id':source,'expert':expert,'layer':layer,'panel':panel,'arm':arm,'samples':n}
    row.update({k[len(arm)+2:]:v for k,v in s.items() if k.startswith(arm+'__')})
    if arm=='Dq':
     for method in ('left','mid','gl2'):
      for suffix,den in (('', 'native_delta_energy'),('_gate','native_delta_gate_energy')):
       bounds=minkowski_bounds(row[method+suffix+'_err_sq'],row['native_delta_vs_smooth'+suffix+'_err_sq'],row[den])
       row[method+suffix+'_native_triangle_lower_sse']=bounds['lower_sse'];row[method+suffix+'_native_triangle_upper_sse']=bounds['upper_sse'];row[method+suffix+'_native_triangle_lower_ratio']=bounds['lower_over_native_energy'];row[method+suffix+'_native_triangle_upper_ratio']=bounds['upper_over_native_energy']
    pair.append(row)
   grow={'source_id':source,'expert':expert,'layer':layer,'panel':panel,'samples':n}
   grow.update({k[len('gate_decomposition__'):]:v for k,v in s.items() if k.startswith('gate_decomposition__')});gate.append(grow)
  for step,parts in r['tubelet_endpoint_anova'].items():
   for label in ('native_y_lift','gated_y_lift'):anova.append({'source_id':source,'expert':expert,'layer':layer,'step':int(step),'kind':label,**parts[label]})
 if len(pair)!=3200 or len(gate)!=1600 or len(anova)!=3200:raise ValueError('record coverage')
 dims={'overall':['panel','arm'],'by_expert':['expert','panel','arm'],'by_layer':['layer','panel','arm'],'by_source':['source_id','panel','arm'],'by_expert_layer':['expert','layer','panel','arm']}
 gdims={'overall':['panel'],'by_expert':['expert','panel'],'by_layer':['layer','panel'],'by_source':['source_id','panel'],'by_expert_layer':['expert','layer','panel']}
 adims={'overall':['kind'],'by_expert':['expert','kind'],'by_layer':['layer','kind'],'by_source':['source_id','kind'],'by_expert_layer':['expert','layer','kind']}
 result={'status':'DESCRIPTIVE_NOT_CERTIFIED','scope_sha256':digest,'pair_ledger_sha256':sha(ledger),'pair_count':len(records),'per_pair_observations':len(pair),'pair_groups':group_records(pair,aggregate,dims),'gate_groups':group_records(gate,gates_aggregate,gdims),'anova_groups':group_records(anova,anova_aggregate,adims),'limitations':['observed same-expert chords only; no global degree conclusion','two distinct panels not merged','F64 smooth extension; native rounding errors remain','gate split and balanced ANOVA use F64 lift, not native rounded residual','source clustering and nonuniform selection prevent naive token independence','zero denominators reported null, signed crosses/closure retained']}
 a.output_dir.mkdir(parents=True,exist_ok=False)
 (a.output_dir/'SECANT_SUMMARY.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf8')
 for name,rows in (('PAIR_ROWS.csv',pair),('GATE_ROWS.csv',gate),('ANOVA_ROWS.csv',anova)):
  columns=sorted(set().union(*(r.keys() for r in rows)))
  with (a.output_dir/name).open('w',encoding='utf8',newline='') as f:
   w=csv.DictWriter(f,fieldnames=columns);w.writeheader();w.writerows(rows)
 print('verified',len(records),'pairs',len(pair),'arm-panel rows')
if __name__=='__main__':main()
