"""Root one-shot dispatch for independently reviewed finite native operator or secant scope."""
import argparse,datetime,hashlib,json,re,shlex,subprocess
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('folder',type=Path);a=p.parse_args()
cwd=Path.cwd().resolve();folder=a.folder.resolve()
assert folder.is_relative_to(cwd/'work') and re.fullmatch('[A-Za-z0-9_]+',folder.name)
def read(p):return json.loads(p.read_text(encoding='utf8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
scope=read(folder/'scope.json');digest=sha(folder/'scope.json');review=read(folder/'INDEPENDENT_REVIEW.json')
phases={'NATIVE_OPERATOR_TRANSFER':'job_operator.sh','NATIVE_SECANT_F64':'job_secant.sh','NATIVE_ODD_SECANT':'job_odd.sh'}
assert scope['phase'] in phases and scope['status']=='REVIEW_CANDIDATE'
assert review['status']=='ACCEPTED' and review['scope_sha256']==digest and review['reviewer'] not in scope['authors']
assert digest in (folder/'ROOT_SELF_AUDIT.txt').read_text(encoding='utf8')
assert not (folder/'ACTIVE_RESEARCH.json').exists(),'Existing registration must be reconciled, never repeated'
budget=scope['budget'];assert budget['max_jobs']==budget['gpus_per_job']==1 and 0<budget['cpus']<=4 and budget['host_memory_gib']<=64 and budget['wall_seconds']<=7200 and budget['gpu_memory_gib']<=24 and budget['output_bytes']<=2*1024**3
dispatch=scope['scheduler'];assert dispatch=={'partition':'P107-A100','account':'competition','qos':'qos_p107-a100'}
identities={**scope['code_sha256'],**scope['frozen_inputs_sha256'],scope['config_file']:scope['config_sha256'],scope['input_manifest_file']:scope['manifest_sha256']}
for name,h in identities.items():
    path=(folder/name).resolve();assert path.is_relative_to(folder) and sha(path)==h
stage=folder.parent;remote='/public/home/scc/pb23061276/projects/wan-quant/work/'+stage.name+'/'+folder.name
assert scope['output_dir']==remote+'/output'
def run(argv):
    q=subprocess.run(argv,capture_output=True,text=True)
    if q.returncode:
        (stage/'LAST_DISPATCH_ERROR.json').write_text(json.dumps({'argv':argv,'stdout':q.stdout,'stderr':q.stderr,'returncode':q.returncode},indent=2),encoding='utf8')
        raise RuntimeError(q.stderr or q.stdout)
    return q.stdout.strip()
def ssh(s):return run(['plink','-batch','-load','107',s])
queue=[line for line in ssh("squeue -h -u pb23061276 -o '%i %T %b'").splitlines() if line.strip()]
gpu=0
for line in queue:
    m=re.search(r'gpu(?::[^\s:,]+)?:([0-9]+)',line)
    if not m and line.split()[-1] not in ('N/A','(null)','None'):raise ValueError('unknown GPU request')
    if m:gpu+=int(m[1])
assert len(queue)<2 and gpu<2,'two-job/two-GPU cap includes pending'
ssh('test ! -e '+shlex.quote(remote))
ssh('test -x '+shlex.quote(scope['python_executable']))
ledger=stage/'SUBMISSIONS.jsonl'
if ledger.exists():assert all(json.loads(line)['scope_sha256']!=digest for line in ledger.read_text().splitlines())
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
active={'state':'SCOPE_FROZEN_IN_ACTIVE','session_max_gpus':2,'max_concurrent_jobs':2,'registered_utc':now,
        'user_authorization':'Read real server tensors and generate missing trajectories; advanced mathematical evidence analysis',
        'scopes':{scope['scope_id']:{'state':'AUTHORIZED_FOR_ONE_JOB','max_jobs':1,'scope_sha256':digest,'review_sha256':sha(folder/'INDEPENDENT_REVIEW.json')}}}
(folder/'ACTIVE_RESEARCH.json').write_text(json.dumps(active,indent=2)+'\n',encoding='utf8')
checks={**identities,'scope.json':digest,'INDEPENDENT_REVIEW.json':sha(folder/'INDEPENDENT_REVIEW.json'),'ACTIVE_RESEARCH.json':sha(folder/'ACTIVE_RESEARCH.json')}
(folder/'sha256sums.txt').write_text(''.join(f'{h}  {f}\n' for f,h in sorted(checks.items())),encoding='ascii')
remote_parent=remote.rsplit('/',1)[0];ssh('mkdir -p '+shlex.quote(remote_parent))
run(['pscp','-q','-batch','-r','-load','107',str(folder.relative_to(cwd)),'107.ustc.edu.cn:'+remote_parent+'/'])
ssh('cd '+shlex.quote(remote)+' && sha256sum --quiet -c sha256sums.txt')
h,r=divmod(budget['wall_seconds'],3600);m,s=divmod(r,60)
argv=['sbatch','--parsable','--partition='+dispatch['partition'],'--account='+dispatch['account'],'--qos='+dispatch['qos'],
      '--nodes=1','--ntasks=1',f'--cpus-per-task={budget["cpus"]}',f'--mem={budget["host_memory_gib"]}G','--gres=gpu:A100:1',
      f'--time={h:02}:{m:02}:{s:02}','--signal=B:USR1@120','--no-requeue','--job-name='+scope['phase'].lower(),
      '--chdir='+remote,'--output='+remote+'/slurm-%j.out','--error='+remote+'/slurm-%j.err',remote+'/'+phases[scope['phase']],remote+'/scope.json',digest]
job=ssh(' '.join(shlex.quote(v) for v in argv));assert re.fullmatch('[1-9][0-9]*',job)
record={'job_id':job,'scope_id':scope['scope_id'],'scope_sha256':digest,'remote':remote,'submitted_utc':now,'state':'SUBMITTED_NOT_COMPLETED'}
with ledger.open('a',encoding='utf8') as f:f.write(json.dumps(record)+'\n')
(folder/'SLURM_SUBMITTED.txt').write_text(ssh('scontrol show job -o '+job)+'\n',encoding='utf8')
print(json.dumps(record),flush=True)
