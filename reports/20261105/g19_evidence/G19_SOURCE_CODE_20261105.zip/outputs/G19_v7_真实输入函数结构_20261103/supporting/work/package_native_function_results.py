"""Bundle completed reviewed scalar evidence, retaining references to large arrays."""
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEST = ROOT / "outputs/G19_v7_真实输入函数结构_20261103"
SCOPES = {
    "operator": ROOT / "work/g19_native_operator_transfer_20261103/operator10_r2",
    "secant": ROOT / "work/g19_native_secant_20261103/secant_full_r2",
    "odd": ROOT / "work/g19_native_odd_secant_20261103/odd_full_r1",
}


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def copy(source, relative):
    target = DEST / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def main():
    if DEST.exists():
        raise FileExistsError(DEST)
    report = ROOT / "work/g19_native_analysis_report_20261103.md"
    txt = report.read_text(encoding="utf-8")
    assert "ODD_FINAL_PENDING" not in txt and "DRAFT" not in txt
    for scope in SCOPES.values():
        assert json.loads((scope / "output/EXIT.json").read_text())["status"] == "SUCCESS"
        assert "JobState=COMPLETED" in (scope / "SCONTROL_FINAL.txt").read_text()
        assert (scope / "INDEPENDENT_RESULT_REVIEW.txt").exists()
    assert (SCOPES["odd"] / "plots/odd_output_geometry.png").exists()
    DEST.mkdir(parents=True)
    copy(report, "G19v7_真实输入函数结构与新方案.md")
    arrays = []
    allowed = {".json", ".jsonl", ".csv", ".txt", ".py", ".sh", ".md", ".png", ".svg"}
    for label, directory in SCOPES.items():
        for path in sorted(directory.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(directory)
            if "__pycache__" in rel.parts or "preview" in rel.parts:
                continue
            if label == "operator" and rel.parts[0] == "plots":
                continue
            if path.suffix == ".npz":
                arrays.append({
                    "experiment": label, "relative_path": rel.as_posix(),
                    "local_path": str(path), "bytes": path.stat().st_size,
                    "sha256": sha(path),
                    "remote_path": "/public/home/scc/pb23061276/projects/wan-quant/"
                    + directory.relative_to(ROOT).as_posix() + "/" + rel.as_posix(),
                })
            elif path.suffix in allowed:
                copy(path, Path("evidence") / label / rel)
    supplemental = [
        "work/g19_native_operator_transfer_20261103/summarize_operator.py",
        "work/g19_native_operator_transfer_20261103/report_numbers.py",
        "work/g19_native_operator_transfer_20261103/plot_operator.py",
        "work/g19_native_operator_transfer_20261103/gate_metric_geometry.py",
        "work/g19_native_operator_transfer_20261103/GATE_METRIC_GEOMETRY.json",
        "work/g19_native_operator_transfer_20261103/GATE_METRIC_GEOMETRY.csv",
        "work/g19_native_operator_transfer_20261103/GATE_METRIC_GEOMETRY_INDEPENDENT_REVIEW.txt",
        "work/g19_native_secant_20261103/summarize_secant.py",
        "work/g19_native_secant_20261103/plot_secant.py",
        "work/g19_native_secant_20261103/FULL_RESULT_FINDINGS.md",
        "work/g19_native_odd_secant_20261103/summarize_odd.py",
        "work/g19_native_odd_secant_20261103/plot_odd.py",
        "work/g19_native_analysis_independent_20261103/review_recorded_scalars.py",
        "work/g19_native_analysis_independent_20261103/review_odd_scalars.py",
        "work/g19_native_analysis_independent_20261103/finalize_odd_result_review.py",
        "work/g19_native_analysis_independent_20261103/SCALAR_POSTPROCESS_REVIEW.txt",
        "work/g19_native_analysis_independent_20261103/CHORD_STRUCTURE_THEORY_REVIEW.md",
        "work/g19_native_trajectory_20261103/MATHEMATICAL_LITERATURE_AUDIT_20261103.md",
        "work/register_submit_native_analysis_scope.py",
        "work/package_native_function_results.py",
    ]
    for filename in supplemental:
        path = ROOT / filename
        copy(path, Path("supporting") / path.parent.name / path.name)
    report_review = ROOT / "work/g19_native_analysis_independent_20261103/FINAL_REPORT_REVIEW.txt"
    assert report_review.exists()
    assert sha(report) in report_review.read_text(encoding="utf-8")
    copy(report_review, "FINAL_REPORT_REVIEW.txt")
    figures = {
        "operator_held_layer_curves": SCOPES["operator"] / "plots_r2",
        "operator_source_anova": SCOPES["operator"] / "plots_r2",
        "secant_layer_risk": SCOPES["secant"] / "figures",
        "odd_output_geometry": SCOPES["odd"] / "plots",
    }
    for name, directory in figures.items():
        for extension in ("png", "svg"):
            copy(directory / (name + "." + extension), Path("figures") / (name + "." + extension))
    old_failure = ROOT / "work/g19_native_operator_transfer_20261103/operator10_r1/failure"
    for path in old_failure.glob("*"):
        if path.is_file():
            copy(path, Path("startup_failure_129193") / path.name)
    (DEST / "EXTERNAL_ARRAYS.json").write_text(json.dumps({
        "meaning": "NPZ arrays retained locally and remotely; not embedded in this scalar-evidence bundle. Raw native captures and checkpoints are separately bound by each scope capture/weight manifest.",
        "count": len(arrays), "bytes": sum(x["bytes"] for x in arrays), "files": arrays,
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (DEST / "README.txt").write_text(
        "G19v7 真实输入函数结构，2026-11-03\n"
        "先读 G19v7_真实输入函数结构与新方案.md。\n"
        "evidence：三个完成作业的冻结代码、scope、START/EXIT、Slurm终态、标量ledger、独立复核、摘要及图。\n"
        "figures：四张经主代理视检的PNG/SVG；supporting：后处理代码与数学/文献审计。\n"
        "EXTERNAL_ARRAYS.json：本地与服务器保留的1760个NPZ及SHA；大数组不重复装包。\n"
        "更大的原生捕获/权重由scope中的capture_manifest与weight_manifest定位和绑定。\n"
        "CHORD_STRUCTURE_THEORY_REVIEW是运行期间的理论审阅；最终数值以本包完成回执和报告为准。\n"
        "本轮没有实现或声称验证G-Arnoldi候选、替代层速度和替代层视频质量。\n"
        "旧Chipmunk十源视频/指标证据包未修改；本包不重复包含视频。\n",
        encoding="utf-8")
    files = [{"path": p.relative_to(DEST).as_posix(), "bytes": p.stat().st_size, "sha256": sha(p)}
             for p in sorted(DEST.rglob("*")) if p.is_file()]
    manifest = {
        "status": "COMPLETE_DESCRIPTIVE_RESULTS_WITH_INDEPENDENT_ARITHMETIC_REVIEW",
        "job_ids": [129194, 129195, 129217],
        "scope_sha256": {key: sha(path / "scope.json") for key, path in SCOPES.items()},
        "files": files,
        "limits": ["Source-isolated exploratory analysis, not a new blind validation set.",
                   "Arithmetic/identity checks are not an IEEE interval certificate.",
                   "No new replacement-model runtime or video-quality claim."],
    }
    (DEST / "MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    archive = DEST.with_suffix(".zip")
    if archive.exists():
        raise FileExistsError(archive)
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in sorted(DEST.rglob("*")):
            if path.is_file():
                z.write(path, path.relative_to(DEST).as_posix())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(files) + 1
    digest = sha(archive)
    archive.with_suffix(".zip.sha256").write_text(digest + "  " + archive.name + "\n", encoding="utf-8")
    print(json.dumps({"folder": str(DEST), "zip": str(archive), "zip_sha256": digest,
                      "zip_bytes": archive.stat().st_size, "files": len(files) + 1,
                      "external_npz": len(arrays), "external_npz_bytes": sum(x["bytes"] for x in arrays)},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
