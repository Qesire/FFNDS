"""Postprocess completed frozen operator site JSON; never open capture/mean tensor files."""
import argparse,collections,csv,hashlib,json,math
from pathlib import Path
import numpy as np
MODELS=('constant','affine','linear_32','quadratic_32','linear_64','quadratic_64')
HELD=('03','05','06','08')

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf8'))
def summary(vals):
 vals=[float(v) for v in vals if v is not None]
 if not vals:return None
 if not all(math.isfinite(v) for v in vals):raise ValueError('nonfinite scalar')
 return {'min':min(vals),'median':float(np.median(vals)),'max':max(vals),'n':len(vals)}
def summarize(rows):
 fields=[k for k in rows[0] if k not in ('source','step','layer','expert')]
 result={'n_source_site_rows':len(rows),'metrics':{k:summary([r[k] for r in rows]) for k in fields}}
 if 'constant_pre_gate_mse_total' in rows[0]:
  result['ratios_of_sums_vs_medians_of_ratios']={}
  for model in MODELS:
   for panel in ('pre_gate','post_gate'):
    numerator=model+'_'+panel+'_mse_total'
    for denom in ('target_energy','oracle_mean_mse'):
     denominator=model+'_'+panel+'_'+denom;pairs=[(r[numerator],r[denominator]) for r in rows];sn=sum(x for x,_ in pairs);sd=sum(y for _,y in pairs);valid=[x/y for x,y in pairs if y>0]
     result['ratios_of_sums_vs_medians_of_ratios'][model+'__'+panel+'__'+denom]={'sum_numerator':sn,'sum_denominator':sd,'ratio_of_sums':sn/sd if sd>0 else None,'median_of_source_site_ratios':float(np.median(valid)) if valid else None,'ratios_available':len(valid),'denominator_zero_count':sum(y==0 for _,y in pairs)}
 return result
def main():
 ap=argparse.ArgumentParser();ap.add_argument('folder',type=Path);a=ap.parse_args();base=a.folder;out=base/'output';scope=read(base/'scope.json');review=read(base/'INDEPENDENT_REVIEW.json');start=read(out/'START.json');end=read(out/'EXIT.json');sha=digest(base/'scope.json')
 if review['status']!='ACCEPTED' or review['scope_sha256']!=sha or start['scope']['_verified_scope_sha256']!=sha or end['scope_sha256']!=sha or end['status']!='SUCCESS' or end['result']['sites']!=160:raise ValueError('scope or receipt mismatch')
 index=out/'sites.jsonl'
 if digest(index)!=end['result']['site_index_sha256']:raise ValueError('index SHA mismatch')
 ledger=[json.loads(x) for x in index.read_text(encoding='utf8').splitlines()];seen=set();records=[];lambda_counts={m:collections.Counter() for m in MODELS if m!='constant'};site_rows=[]
 for item in ledger:
  key=(item['step'],item['layer']);
  if key in seen:raise ValueError('duplicate site')
  seen.add(key);f=out/item['site_file']
  if f.parent!=out or digest(f)!=item['site_sha256']:raise ValueError('site JSON SHA mismatch')
  x=read(f)
  if (x['step'],x['layer'])!=key or x['source_means_sha256']!=item['means_sha256']:raise ValueError('site identity mismatch')
  models=x['models']
  if set(models)!=set(MODELS):raise ValueError('missing candidate')
  for m in lambda_counts:
   v=models[m]['selected_multiplier'];lambda_counts[m][str(v)]+=1
  a0=x['source_anova'];site={'step':x['step'],'layer':x['layer'],'expert':x['expert']}
  for model in lambda_counts:site[model+'_selected_lambda_multiplier']=models[model]['selected_multiplier']
  for panel in ('pre_gate','post_gate'):
   q=a0[panel]
   for field in ('within','between','grand_mean_energy','total_energy_direct','total_decomposition_residual','loso_mean','loso_identity','loso_identity_residual'):site[panel+'_'+field]=q[field]
  site_rows.append(site)
  for sid in HELD:
   row={'source':sid,'step':x['step'],'layer':x['layer'],'expert':x['expert']}
   for m in MODELS:
    obj=models[m];v=obj['source_metrics'][sid] if m=='constant' else obj['held_metrics'][sid]
    for panel in ('pre_gate','post_gate'):
     for field in ('mse_total','mse_centered','target_energy','oracle_mean_mse','mse_over_target_energy','mse_over_oracle_mean_mse'):row[m+'_'+panel+'_'+field]=v[panel][field]
   for panel in ('pre_gate','post_gate'):
    q=a0[panel];row[panel+'_bias_constant_mse']=q['bias_constant_risk_by_source'][sid];row[panel+'_loso_constant_mse']=q['loso_risk_by_source'][sid]
    for k in (32,64):row[f'quadratic_minus_linear_{k}_{panel}_mse']=row[f'quadratic_{k}_{panel}_mse_total']-row[f'linear_{k}_{panel}_mse_total']
    for m in ('affine','linear_32','quadratic_32','linear_64','quadratic_64'):row[m+'_minus_constant_'+panel+'_mse']=row[m+'_'+panel+'_mse_total']-row['constant_'+panel+'_mse_total'];row[m+'_minus_affine_'+panel+'_mse']=row[m+'_'+panel+'_mse_total']-row['affine_'+panel+'_mse_total']
   records.append(row)
 if seen!={(s,l) for s in range(4) for l in range(40)} or len(records)!=640:raise ValueError('incomplete 160-site coverage')
 def writecsv(path,rows):
  with path.open('w',newline='',encoding='utf8') as f:
   w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 writecsv(base/'OPERATOR_HELD_SITE_SOURCE.csv',records);writecsv(base/'OPERATOR_ANOVA_SITE.csv',site_rows)
 groups={'all':summarize(records)}
 for dim in ('source','step','layer','expert'):
  groups['by_'+dim]={str(k):summarize([r for r in records if r[dim]==k]) for k in sorted({r[dim] for r in records})}
 anova={'all':summarize(site_rows)}
 def lambda_breakdown(rows):
  return {m:dict(collections.Counter(str(r[m+'_selected_lambda_multiplier']) for r in rows)) for m in lambda_counts}
 lambda_groups={'all':lambda_breakdown(site_rows)}
 for dim in ('step','layer','expert'):
  lambda_groups['by_'+dim]={str(k):lambda_breakdown([r for r in site_rows if r[dim]==k]) for k in sorted({r[dim] for r in site_rows})}
 for dim in ('step','layer','expert'):
  anova['by_'+dim]={str(k):summarize([r for r in site_rows if r[dim]==k]) for k in sorted({r[dim] for r in site_rows})}
 report={'scope_sha256':sha,'sites':160,'held_sources':list(HELD),'selected_lambda_counts':lambda_groups,'held':groups,'anova':anova,'interpretation':'finite panel descriptive; site and token rows nested in sources, not independent replicates. Held exposure unverified. Quadratic is limited to CAL PCA subspace and finite four-ridge candidates; no best-affine or unrestricted quadratic conclusion. Oracle-mean is same-source descriptive baseline. Predictions and gate arithmetic are F64 lifted. This postprocessor opens scalar JSON, not source or derived mean tensors.'}
 p=base/'OPERATOR_DESCRIPTIVE_SUMMARY.json';p.write_text(json.dumps(report,indent=2)+'\n',encoding='utf8');print('summary_sha256',digest(p),'site_source_csv_sha256',digest(base/'OPERATOR_HELD_SITE_SOURCE.csv'),'anova_csv_sha256',digest(base/'OPERATOR_ANOVA_SITE.csv'))
if __name__=='__main__':main()
