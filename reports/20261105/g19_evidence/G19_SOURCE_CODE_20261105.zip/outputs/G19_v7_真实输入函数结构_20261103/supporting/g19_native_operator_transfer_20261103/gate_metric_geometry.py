"""Postprocess saved operator/site and secant scalar CSVs only; no model/tensors."""
import csv
import hashlib
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
SITE = HERE / 'operator10_r2' / 'OPERATOR_ANOVA_SITE.csv'
PAIR = HERE.parent / 'g19_native_secant_20261103' / 'secant_full_r2' / 'summary' / 'PAIR_ROWS.csv'


def read_csv(path):
    import io
    data = path.read_bytes()
    return list(csv.DictReader(io.StringIO(data.decode('utf-8-sig'), newline=''))), hashlib.sha256(data).hexdigest()


def positive(row, key, allow_zero=False):
    value = float(row[key])
    if not math.isfinite(value) or value < 0 or (value == 0 and not allow_zero):
        raise ValueError(f'invalid {key}: {value}')
    return value


def main():
    rows, site_hash = read_csv(SITE)
    pairs, pair_hash = read_csv(PAIR)
    expected = {(step, layer) for step in range(4) for layer in range(40)}
    found = set()
    output = []
    for r in rows:
        step, layer = int(r['step']), int(r['layer'])
        if (step, layer) in found or (step, layer) not in expected:
            raise ValueError('duplicate or unexpected operator site')
        found.add((step, layer))
        if r['expert'] != ('high' if step < 2 else 'low'):
            raise ValueError('unexpected expert')
        pre_m = positive(r, 'pre_gate_grand_mean_energy')
        post_m = positive(r, 'post_gate_grand_mean_energy', allow_zero=True)
        pre_c = positive(r, 'pre_gate_within', True) + positive(r, 'pre_gate_between', True)
        post_c = positive(r, 'post_gate_within', True) + positive(r, 'post_gate_between', True)
        if pre_c <= 0 or post_c <= 0:
            raise ValueError('zero centered energy')
        output.append(dict(operator_site_sha256=site_hash, secant_pairs_sha256=pair_hash,
                           step=step, layer=layer, expert=r['expert'],
                           pre_mean_energy=pre_m, pre_centered_energy=pre_c,
                           post_mean_energy=post_m, post_centered_energy=post_c,
                           pre_mean_fraction=pre_m/(pre_m+pre_c),
                           post_mean_fraction=post_m/(post_m+post_c),
                           K=(post_m/post_c)/(pre_m/pre_c)))
    if found != expected:
        raise ValueError('incomplete operator coverage')
    by_step = []
    for step in range(4):
        group = [r for r in output if r['step'] == step]
        k = [r['K'] for r in group]
        by_step.append(dict(step=step, expert=group[0]['expert'], layers=len(group),
                            K_median=statistics.median(k), K_min=min(k), K_max=max(k),
                            K_above_one=sum(x > 1 for x in k),
                            pre_mean_fraction_median=statistics.median(r['pre_mean_fraction'] for r in group),
                            post_mean_fraction_median=statistics.median(r['post_mean_fraction'] for r in group)))
    groups = defaultdict(list)
    for r in pairs:
        if r['arm'] == 'Dq':
            key = (r['expert'], r['panel'], r['source_id'])
            groups[key].append(r)
    expected_sources = {(e,p,f'chip10_{n:02}') for e in ('high','low') for p in ('uniform','tubelet') for n in range(10)}
    if set(groups) != expected_sources:
        raise ValueError('incomplete source groups')
    source_rows = []
    for (expert,panel,source), group in sorted(groups.items()):
        if len(group) != 40 or {int(r['layer']) for r in group} != set(range(40)):
            raise ValueError('incomplete source/layer coverage')
        num = sum(positive(r, 'gl2_err_sq', True) for r in group)
        den = sum(positive(r, 'target_sq') for r in group)
        source_rows.append(dict(expert=expert, panel=panel, source_id=source,
                                layers=40, gl2_sse_over_smooth_target=num/den))
    ranges = []
    for expert in ('high','low'):
        for panel in ('uniform','tubelet'):
            subset = [r for r in source_rows if r['expert']==expert and r['panel']==panel]
            lo = min(subset, key=lambda r:r['gl2_sse_over_smooth_target'])
            hi = max(subset, key=lambda r:r['gl2_sse_over_smooth_target'])
            ranges.append(dict(expert=expert, panel=panel,
                               min_ratio=lo['gl2_sse_over_smooth_target'], min_source=lo['source_id'],
                               max_ratio=hi['gl2_sse_over_smooth_target'], max_source=hi['source_id']))
    result = dict(inputs={'operator_site':str(SITE), 'operator_site_sha256':site_hash,
                          'secant_pairs':str(PAIR), 'secant_pairs_sha256':pair_hash},
                  interpretation='K is the post/pre mean-to-centered energy ratio under the observed gate metric; it is not a new bias. Expert, step and state are confounded.',
                  by_step=by_step, secant_source_gl2=source_rows, secant_source_ranges=ranges)
    (HERE/'GATE_METRIC_GEOMETRY.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf8')
    with (HERE/'GATE_METRIC_GEOMETRY.csv').open('w',encoding='utf8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(output[0]));w.writeheader();w.writerows(output)
    print(json.dumps({'by_step':by_step,'secant_source_ranges':ranges},indent=2))


if __name__ == '__main__':
    main()
