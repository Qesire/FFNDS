"""Plot only completed operator scalar summaries. No capture tensors are loaded."""
import argparse,csv,hashlib,json,math
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np

MODELS={'affine':('Full-input affine','#2166ac'),'linear_64':('PCA64 linear','#16806c'),'quadratic_64':('PCA64 quadratic','#b23a48')}
SOURCES=('03','05','06','08')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def number(row,key):
 try:v=float(row[key])
 except (KeyError,ValueError) as e:raise ValueError('missing numeric field '+key) from e
 if not math.isfinite(v):raise ValueError('nonfinite '+key)
 return v

def load(held_path,anova_path,summary_path):
 meta=json.loads(summary_path.read_text(encoding='utf8'))
 if meta.get('sites')!=160 or tuple(meta.get('held_sources',[]))!=SOURCES or not isinstance(meta.get('scope_sha256'),str) or len(meta['scope_sha256'])!=64:raise ValueError('requires completed 160-site summary')
 with held_path.open(encoding='utf8',newline='') as f:held=list(csv.DictReader(f))
 with anova_path.open(encoding='utf8',newline='') as f:anova=list(csv.DictReader(f))
 h={(int(r['step']),int(r['layer']),r['source']):r for r in held};a={(int(r['step']),int(r['layer'])):r for r in anova}
 if len(held)!=640 or len(h)!=640 or set(h)!={(s,l,i) for s in range(4) for l in range(40) for i in SOURCES}:raise ValueError('held coverage mismatch')
 if len(anova)!=160 or len(a)!=160 or set(a)!={(s,l) for s in range(4) for l in range(40)}:raise ValueError('anova coverage mismatch')
 return h,a,meta

def relative_values(h,step,layer,model):
 nums=[];dens=[]
 for sid in SOURCES:
  r=h[step,layer,sid];num=number(r,model+'_post_gate_mse_total');den=number(r,model+'_post_gate_target_energy')
  if num<0 or den<0:raise ValueError('negative squared error or energy')
  nums.append(num);dens.append(den)
 ratios=np.asarray([num/den if den>0 else np.nan for num,den in zip(nums,dens)])
 median=float(np.median(ratios)) if np.isfinite(ratios).all() else np.nan
 total=sum(nums)/sum(dens) if sum(dens)>0 else np.nan
 return ratios,median,total

def save(fig,path):
 fig.savefig(path.with_suffix('.png'),dpi=180,bbox_inches='tight');fig.savefig(path.with_suffix('.svg'),bbox_inches='tight');plt.close(fig)

def main():
 p=argparse.ArgumentParser();p.add_argument('--held',type=Path,required=True);p.add_argument('--anova',type=Path,required=True);p.add_argument('--summary',type=Path,required=True);p.add_argument('--outdir',type=Path,required=True);a=p.parse_args();h,an,meta=load(a.held,a.anova,a.summary)
 if a.outdir.exists() and any(a.outdir.iterdir()):raise FileExistsError('output directory is not empty')
 a.outdir.mkdir(parents=True,exist_ok=True);plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
 fig,axes=plt.subplots(2,2,figsize=(15,8.7),sharex=True,sharey=True,constrained_layout=True);layers=np.arange(40)
 for step,ax in enumerate(axes.flat):
  for model,(label,color) in MODELS.items():
   triples=[relative_values(h,step,l,model) for l in layers];source=np.stack([t[0] for t in triples]);med=np.array([t[1] for t in triples]);pooled=np.array([t[2] for t in triples])
   for j in range(len(SOURCES)):ax.plot(layers,source[:,j],color=color,alpha=.14,lw=.7)
   ax.plot(layers,med,color=color,lw=2,label=label);ax.plot(layers,pooled,color=color,lw=1.3,ls='--')
  ax.set_title(f'Step {step}  |  '+('high expert' if step<2 else 'low expert'));ax.grid(alpha=.16);ax.set_ylim(bottom=0);ax.set_xlabel('Transformer layer');ax.set_ylabel('Gated error / gated target energy')
 handles=[Line2D([],[],color=c,lw=2,label=n) for n,c in MODELS.values()]+[Line2D([],[],color='black',lw=2,label='Solid: median of 4 source ratios'),Line2D([],[],color='black',lw=1.3,ls='--',label='Dashed: ratio of source sums'),Line2D([],[],color='black',alpha=.25,lw=.8,label='Faint: each held-out source')]
 fig.legend(handles=handles,loc='outside lower center',ncol=3,frameon=False);fig.suptitle('Native operator transfer on held-out sources',fontsize=15)
 save(fig,a.outdir/'operator_held_layer_curves')
 fig,axes=plt.subplots(2,2,figsize=(15,8.4),sharex=True,sharey=True,constrained_layout=True)
 for step,ax in enumerate(axes.flat):
  for field,name,color in [('grand_mean_energy','Shared mean','#2166ac'),('between','Between-source means','#dc8e26'),('within','Within-source variation','#16806c')]:
   values=[]
   for layer in layers:
    r=an[step,layer];d=number(r,'post_gate_total_energy_direct');n=number(r,'post_gate_'+field)
    if d<0 or n<0:raise ValueError('negative ANOVA energy')
    values.append(n/d if d>0 else np.nan)
   ax.plot(layers,values,lw=1.8,label=name,color=color)
  ax.set_title(f'Step {step}  |  '+('high expert' if step<2 else 'low expert'));ax.set_xlabel('Transformer layer');ax.set_ylabel('Fraction of gated total energy');ax.grid(alpha=.16);ax.set_ylim(bottom=0)
 fig.legend(*axes.flat[0].get_legend_handles_labels(),loc='outside lower center',ncol=3,frameon=False);fig.suptitle('Ten-source native output energy decomposition',fontsize=15)
 save(fig,a.outdir/'operator_source_anova')
 data={'scope_sha256':meta['scope_sha256'],'inputs':{str(q):sha(q) for q in (a.held,a.anova,a.summary)},'outputs':{q.name:sha(q) for q in sorted(a.outdir.iterdir()) if q.is_file()},'notes':'Linear y axes; gaps for zero denominators. All four sources required for median; no clipping. Figures are descriptive.'};(a.outdir/'PLOT_MANIFEST.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')
if __name__=='__main__':main()
