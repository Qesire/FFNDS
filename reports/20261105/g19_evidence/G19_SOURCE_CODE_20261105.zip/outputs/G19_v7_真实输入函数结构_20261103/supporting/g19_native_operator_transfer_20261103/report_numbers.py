"""Arithmetic on verified completed scalar records only."""
import json,statistics,collections
from pathlib import Path
base=Path(__file__).parent/'operator10_r2'
rows=[json.loads(p.read_text()) for p in sorted((base/'output').glob('s??_b??.json'))]
assert len(rows)==160
def stats(v):
 v=sorted(v);return {'median':statistics.median(v),'min':v[0],'max':v[-1]}
out={}
for step in range(4):
 rr=[r for r in rows if r['step']==step];d={}
 for panel in ('pre_gate','post_gate'):
  qq=[r['source_anova'][panel] for r in rr]
  d[panel]={k:stats([q[k]/q['total_energy_direct'] for q in qq]) for k in ('grand_mean_energy','between','within','loso_mean')}
  d[panel]['b2_risk_over_total']=stats([statistics.mean(q['bias_constant_risk_by_source'].values())/q['total_energy_direct'] for q in qq])
  d[panel]['between_over_within']=stats([q['between']/q['within'] for q in qq])
 for k in (32,64):
  d['pca'+str(k)+'_input_variance']=stats([r['models']['linear_'+str(k)]['cal_projection_variance_fraction'] for r in rr])
  wins=0;changes=[]
  for r in rr:
   for sid in ('03','05','06','08'):
    m=r['models'];l=m['linear_'+str(k)]['held_metrics'][sid]['post_gate'];q=m['quadratic_'+str(k)]['held_metrics'][sid]['post_gate'];delta=(q['mse_total']-l['mse_total'])/l['target_energy'];changes.append(delta);wins+=int(delta<0)
  d['quadratic'+str(k)+'_vs_linear']={'wins_out_of_160':wins,'paired_difference_in_target_relative_risk':stats(changes)}
 out[str(step)]=d
out['numeric']={
 'max_system_residual':max(g['solve']['relative_system_residual'] for r in rows for m in r['models'].values() for g in m.get('dev_grid',[])),
 'max_regularized_condition':max(g['solve']['regularized_condition_number'] for r in rows for m in r['models'].values() for g in m.get('dev_grid',[])),
 'max_host_bytes':max(r['process_peak_rss_bytes'] for r in rows),'max_gpu_bytes':max(r['gpu_peak_allocated_bytes'] for r in rows),
 'max_anova_relative_closure':max(abs(q['total_decomposition_residual'])/q['total_energy_direct'] for r in rows for q in r['source_anova'].values())}
(base/'OPERATOR_REPORT_NUMBERS.json').write_text(json.dumps(out,indent=2)+'\n')
for k,v in out.items():print(k,json.dumps(v if k=='numeric' else {'post_gate':v['post_gate'],'pca64':v['pca64_input_variance'],'quadratic64':v['quadratic64_vs_linear']}))
