"""Summarize completed odd-secant scalar ledgers; no NPZ or tensor reads."""
import argparse,csv,hashlib,json,math,statistics
from pathlib import Path

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf8'))
def lines(p):return [json.loads(x) for x in p.read_text(encoding='utf8').splitlines() if x.strip()]
def ratio(a,b):return a/b if b>0 else None
def desc(vals):
 vals=[float(x) for x in vals if x is not None]
 if not vals:return None
 if any(not math.isfinite(x) for x in vals):raise ValueError('nonfinite scalar')
 return {'min':min(vals),'median':statistics.median(vals),'max':max(vals),'n':len(vals)}
def aggregate(rows):
 out={'records':len(rows),'pairs_with_zero_target':sum(x['target']==0 for x in rows)}
 pairs=[('odd_direct_residual','target'),('even','target'),('odd','target'),('cross','target'),('midgate_direct_residual','midgate_target'),('midgate_odd','midgate_target'),('midgate_even','midgate_target'),('midgate_cross','midgate_target'),('endpoint_gate_direct_residual','endpoint_gate_target'),('endpoint_gate_odd','endpoint_gate_target'),('endpoint_gate_even','endpoint_gate_target'),('endpoint_gate_cross','endpoint_gate_target'),('reflection_sum','reflection_delta'),('closure_vector','target'),('midgate_closure_vector','midgate_target')]
 if all(x['arm']=='Dq' for x in rows):pairs.extend([('native_endpoint_error','native_endpoint_energy'),('native_endpoint_gate_error','native_endpoint_gate_energy')])
 for n,d in pairs:
  vals=[ratio(x[n],x[d]) for x in rows];sa=sum(x[n] for x in rows);sb=sum(x[d] for x in rows)
  out[n+'_over_'+d]={'median_of_pair_ratios':desc(vals),'ratio_of_sums':ratio(sa,sb),'numerator_sum':sa,'denominator_sum':sb,'zero_denominator_pairs':sum(x[d]==0 for x in rows)}
 for prefix in ('','midgate_','endpoint_gate_'):
  target=sum(x[prefix+'target'] for x in rows);odd=sum(x[prefix+'odd'] for x in rows);even=sum(x[prefix+'even'] for x in rows);cross=sum(x[prefix+'cross'] for x in rows);residual=sum(x[prefix+'direct_residual' if prefix else 'odd_direct_residual'] for x in rows)
  pair_oracle=[]
  for row in rows:
   pt=row[prefix+'target'];po=row[prefix+'odd'];pr=row[prefix+'direct_residual' if prefix else 'odd_direct_residual']
   if pt>0 and po>0:
    pc=(po+pt-pr)/(2*math.sqrt(po*pt));pair_oracle.append(1-pc*pc)
  if target>0 and odd>0:
   dot_cross=odd+cross/2;dot_direct=(odd+target-residual)/2;den=math.sqrt(odd*target);cos_cross=dot_cross/den;cos_direct=dot_direct/den
   out[(prefix or 'output_')+'geometry']={'status':'AVAILABLE_NUMERICALLY_UNCERTIFIED','cos_cross':cos_cross,'cos_direct':cos_direct,'cos_difference':cos_cross-cos_direct,'unconstrained_gain_from_direct':dot_direct/odd,'unconstrained_gain_oracle_residual_fraction':1-cos_direct*cos_direct,'sum_relative_condition_factor':(math.sqrt(odd)+math.sqrt(even))/math.sqrt(target) if even>=0 else None,'odd_even_cosine':cross/(2*math.sqrt(odd*even)) if even>0 else None,'per_pair_free_gain_oracle_residual_fraction':desc(pair_oracle),'per_pair_oracle_unavailable':len(rows)-len(pair_oracle)}
  else:out[(prefix or 'output_')+'geometry']={'status':'UNAVAILABLE_ZERO_ENERGY'}
 out['signed_closure_absolute']=desc(abs(x['closure_signed']) for x in rows)
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('folder',type=Path);p.add_argument('--secant-ledger',type=Path);a=p.parse_args();base=a.folder;out=base/'output';scope=read(base/'scope.json');review=read(base/'INDEPENDENT_REVIEW.json');start=read(out/'START.json');end=read(out/'EXIT.json');digest=sha(base/'scope.json')
 if review['status']!='ACCEPTED' or review['scope_sha256']!=digest or start['scope']['_verified_scope_sha256']!=digest or end['status']!='SUCCESS' or end['result']['status']!='NATIVE_ODD_SECANT_COMPLETE_DESCRIPTIVE_NUMERICS_UNASSESSED':raise ValueError('incomplete receipt/review')
 result=end['result'];pairfile=out/'pairs.jsonl';weights=out/'weight_reads.jsonl';env=out/'environment.jsonl'
 if any(sha(f)!=result[k] for f,k in ((pairfile,'pairs_ledger_sha256'),(weights,'weight_ledger_sha256'),(env,'environment_sha256'))):raise ValueError('ledger SHA mismatch')
 pair=lines(pairfile);ws=lines(weights)
 if len(pair)!=800 or result['pair_count']!=800 or result['arm_count']!=1600 or len(ws)!=640 or result['weight_read_count']!=640:raise ValueError('count mismatch')
 expected={(f'chip10_{i:02d}',e,l) for i in range(10) for e in ('high','low') for l in range(40)};seen={(r['source_id'],r['expert'],r['layer']) for r in pair}
 if seen!=expected or len(seen)!=len(pair):raise ValueError('pair coverage mismatch')
 wantw={(e,l,a,f'blocks.{l}.ffn.{suffix}') for e in ('high','low') for l in range(40) for a in ('Oq','Dq') for suffix in ('0.weight','2.weight','0.bias','2.bias')}
 if {(x['expert'],x['layer'],x['arm'],x['key']) for x in ws}!=wantw:raise ValueError('weight coverage mismatch')
 weight_hashes=read(base/'weight_hashes.json')
 if sha(base/'weight_hashes.json')!=scope['frozen_inputs_sha256']['weight_hashes.json']:raise ValueError('weight manifest identity mismatch')
 for x in ws:
  model='original' if x['arm']=='Oq' else 'distilled';k=x['expert']+'/'+model+'/'+x['key']
  if x['sha256']!=weight_hashes[k] or x['identity_status']!='PRECOMMITTED_HASH_MATCH':raise ValueError('weight raw SHA mismatch')
 reference={}
 if a.secant_ledger:
  ref=lines(a.secant_ledger);reference={(r['source_id'],r['expert'],r['layer']):r for r in ref}
  if len(ref)!=800 or set(reference)!=expected:raise ValueError('secant coverage mismatch')
 rows=[]
 for r in pair:
  key=(r['source_id'],r['expert'],r['layer']);old=reference.get(key)
  if r['steps']!=([0,1] if r['expert']=='high' else [2,3]):raise ValueError('bad expert steps')
  if old and (old['capture_sha256']!=r['capture_sha256'] or old['steps']!=r['steps']):raise ValueError('secant input mismatch')
  for panel in ('tubelet','uniform'):
   obj=r['panels'][panel];v=obj['sums'];prior=old['panels'][panel] if old else None
   if prior and (prior['matched_rows']!=obj['matched_rows'] or prior['latent_time_counts']!=obj['latent_time_counts']):raise ValueError('secant panel mismatch')
   for arm in ('Oq','Dq'):
    get=lambda k:float(v[arm+'__'+k]);x={'source':r['source_id'],'expert':r['expert'],'layer':r['layer'],'panel':panel,'arm':arm,'matched_rows':obj['matched_rows'],'target':get('output_target_sq'),'odd':get('output_odd_sq'),'even':get('output_even_error_sq'),'cross':get('output_twice_cross'),'odd_direct_residual':get('output_direct_odd_residual_sq'),'closure_signed':get('output_closure_signed'),'closure_vector':get('output_vector_closure_sq'),'midgate_target':get('midgate_target_sq'),'midgate_direct_residual':get('midgate_direct_odd_residual_sq'),'midgate_odd':get('midgate_odd_sq'),'midgate_even':get('midgate_even_error_sq'),'midgate_cross':get('midgate_twice_cross'),'midgate_closure_vector':get('midgate_vector_closure_sq'),'endpoint_gate_target':get('endpoint_gate_target_sq'),'endpoint_gate_direct_residual':get('endpoint_gate_direct_odd_residual_sq'),'endpoint_gate_odd':get('endpoint_gate_odd_sq'),'endpoint_gate_even':get('endpoint_gate_even_error_sq'),'endpoint_gate_cross':get('endpoint_gate_twice_cross'),'reflection_sum':get('preactivation_sum_sq'),'reflection_delta':get('preactivation_delta_sq')}
    if arm=='Dq':x.update(native_endpoint_energy=get('native_endpoint1_energy'),native_endpoint_error=get('native_endpoint1_error_sq'),native_endpoint_gate_energy=get('native_endpoint1_gate_energy'),native_endpoint_gate_error=get('native_endpoint1_gate_error_sq'))
    if prior:
     for label,oddkey,refkey in [('output','target','target_sq'),('midgate','midgate_target','target_gate_sq')]:
      oldtarget=float(prior['sums'][arm+'__'+refkey]);x['secant_'+label+'_target']=oldtarget;x['secant_'+label+'_target_difference']=x[oddkey]-oldtarget;x['secant_'+label+'_target_relative_difference']=abs(x[oddkey]-oldtarget)/abs(oldtarget) if oldtarget else None
    if any(not math.isfinite(vv) for vv in x.values() if isinstance(vv,float)):raise ValueError('nonfinite value')
    rows.append(x)
 fields=sorted({k for x in rows for k in x});
 with (base/'ODD_PAIR_SCALARS.csv').open('w',encoding='utf8',newline='') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
 group={}
 for expert in ('high','low'):
  for panel in ('tubelet','uniform'):
   for arm in ('Oq','Dq'):
    key=expert+'__'+panel+'__'+arm;subset=[x for x in rows if (x['expert'],x['panel'],x['arm'])==(expert,panel,arm)];group[key]=aggregate(subset)
    if reference:
     for label in ('output','midgate'):group[key]['secant_'+label+'_target_relative_difference']=desc(x['secant_'+label+'_target_relative_difference'] for x in subset)
 report={'scope_sha256':digest,'pair_count':800,'weight_reads':640,'rows':len(rows),'groups':group,'secant_ledger_sha256':sha(a.secant_ledger) if a.secant_ledger else None,'interpretation':'F64-lifted finite Dq-state observed chords; direct odd residual separate from even; signed cross retained. The sum-relative condition factor upper-bounds relative error by kappa*epsilon only when each component has relative error <=epsilon; it is not evidence of actual amplification. Geometry uses un-clipped aggregated inner products; unconstrained gain and 1−cos² are an oracle for one arbitrary real gain, not a fitted deployment candidate, and negative cosine cannot be repaired by a positive gain. Pair median and energy-weighted ratio-of-sums differ; panel/source/layer observations not independent. The optional secant ledger SHA is recorded but must be separately authenticated against secant EXIT; matching compares capture SHA, token counts and aggregated target energies, while exact token identity requires separately saved NPZ. No BF16 deployment, Oq native trajectory or global-structure claim.'}
 p=base/'ODD_DESCRIPTIVE_SUMMARY.json';p.write_text(json.dumps(report,indent=2)+'\n',encoding='utf8');print('summary_sha256',sha(p),'csv_sha256',sha(base/'ODD_PAIR_SCALARS.csv'))
if __name__=='__main__':main()
