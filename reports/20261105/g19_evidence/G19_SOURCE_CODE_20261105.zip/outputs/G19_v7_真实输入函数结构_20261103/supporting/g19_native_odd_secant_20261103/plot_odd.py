"""Plot authenticated odd-secant scalar summary/CSV only; no tensor or NPZ reads."""
import argparse,csv,hashlib,json,math
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--summary',required=True,type=Path);p.add_argument('--rows',required=True,type=Path);p.add_argument('--review',required=True,type=Path);p.add_argument('--outdir',required=True,type=Path);a=p.parse_args()
 report=json.loads(a.summary.read_text(encoding='utf8')); review=a.review.read_text(encoding='utf8');summary_sha=sha(a.summary);csv_sha=sha(a.rows)
 if report.get('pair_count')!=800 or report.get('rows')!=3200 or summary_sha.lower() not in review.lower() or csv_sha.lower() not in review.lower():raise ValueError('independent review must bind both exact summary and CSV SHA')
 with a.rows.open(encoding='utf8',newline='') as f:rows=list(csv.DictReader(f))
 data={}
 for r in rows:
  if r['arm']!='Dq':continue
  key=(r['expert'],r['panel'],int(r['layer']));data.setdefault(key,[]).append(r)
 expected={(e,panel,l) for e in ('high','low') for panel in ('uniform','tubelet') for l in range(40)}
 if set(data)!=expected or any(len(rs)!=10 or {r['source'] for r in rs}!={f'chip10_{i:02d}' for i in range(10)} for rs in data.values()):raise ValueError('incomplete 10-source Dq geometry')
 if a.outdir.exists() and any(a.outdir.iterdir()):raise FileExistsError('output directory not empty')
 a.outdir.mkdir(parents=True,exist_ok=True); plt.rcParams.update({'font.size':10,'axes.spines.top':False,'svg.fonttype':'none'})
 fig,axes=plt.subplots(2,2,figsize=(15,9),sharex=True,constrained_layout=True);derived=[]
 for ax,(expert,panel) in zip(axes.flat,[(e,panel) for e in ('high','low') for panel in ('uniform','tubelet')]):
  table=[]
  for layer in range(40):
   rs=data[expert,panel,layer];sums={k:sum(float(r[k]) for r in rs) for k in ('target','odd','even','cross','odd_direct_residual')}
   if not all(math.isfinite(v) for v in sums.values()) or sums['target']<0 or sums['odd']<0 or sums['even']<0:raise ValueError('bad scalar energy')
   target,odd=sums['target'],sums['odd'];den=math.sqrt(odd*target) if odd>0 and target>0 else None
   item={'expert':expert,'panel':panel,'layer':layer,'odd_fraction':odd/target if target>0 else None,'even_fraction':sums['even']/target if target>0 else None,'signed_cross_fraction':sums['cross']/target if target>0 else None,'cos_direct':(odd+target-sums['odd_direct_residual'])/(2*den) if den else None,'cos_cross':(odd+sums['cross']/2)/den if den else None}
   table.append(item);derived.append(item)
  for key,label,color in [('odd_fraction','Odd / target','#2166ac'),('even_fraction','Even / target','#d58421'),('signed_cross_fraction','Signed 2 cross / target','#a83b48')]:ax.plot(range(40),[x[key] if x[key] is not None else float('nan') for x in table],color=color,label=label,lw=1.8)
  ax.axhline(0,color='black',lw=.7,alpha=.45);ax.axhline(1,color='black',lw=.7,alpha=.2);ax.grid(alpha=.15);ax.set_title(f'{expert.title()} expert · {panel} panel');ax.set_xlabel('Transformer layer');ax.set_ylabel('Energy fraction (ratio of source sums)')
  twin=ax.twinx();twin.plot(range(40),[x['cos_direct'] if x['cos_direct'] is not None else float('nan') for x in table],color='#414141',ls='--',lw=1.5,label='Cosine');twin.set_ylabel('Odd–target cosine (direct residual)')
 handles=[Line2D([],[],color='#2166ac',lw=1.8,label='Odd / target'),Line2D([],[],color='#d58421',lw=1.8,label='Even / target'),Line2D([],[],color='#a83b48',lw=1.8,label='Signed 2 cross / target'),Line2D([],[],color='#414141',ls='--',lw=1.5,label='Odd–target cosine')]
 fig.legend(handles=handles,loc='outside lower center',ncol=4,frameon=False);fig.suptitle('Dq fixed odd backbone: output cancellation geometry',fontsize=15)
 for ext in ('png','svg'):fig.savefig(a.outdir/('odd_output_geometry.'+ext),dpi=180,bbox_inches='tight')
 plt.close(fig)
 with (a.outdir/'odd_layer_geometry.csv').open('w',newline='',encoding='utf8') as f:w=csv.DictWriter(f,fieldnames=list(derived[0]));w.writeheader();w.writerows(derived)
 manifest={'scope_sha256':report['scope_sha256'],'summary_sha256':summary_sha,'rows_sha256':csv_sha,'independent_review_sha256':sha(a.review),'outputs':{x.name:sha(x) for x in sorted(a.outdir.iterdir()) if x.is_file()},'meaning':'Negative cross is opposition of output odd/even vectors, not evidence of individual neuron-pair cancellation. No fitted gain or BF16 deployment claim; no axes logarithms or clipping.'};(a.outdir/'PLOT_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
if __name__=='__main__':main()
