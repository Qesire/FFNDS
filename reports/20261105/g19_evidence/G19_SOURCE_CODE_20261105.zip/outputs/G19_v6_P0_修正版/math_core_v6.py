"""G19 v6 math core — 草案数值实现，待数学复审。

本文件不自创方法；每个函数标注其依据的章节号。
"""
import math
import numpy as np


# ---------- §3 参考分布 ----------
def reference_scale(d, alpha=1.0):
    """§3: k = sqrt(d/(d-1)), u = alpha*k*Pi*z, Pi = I - 11^T/d."""
    if d <= 1 or not math.isfinite(alpha) or alpha <= 0:
        raise ValueError('requires d>1 and finite alpha>0')
    return alpha * math.sqrt(d / (d - 1))


def project_rows(w):
    """§3: 行中心化，实现乘以 Pi。"""
    a = np.asarray(w, dtype=np.float64)
    if a.ndim != 2 or not np.isfinite(a).all():
        raise ValueError('finite 2D W1 required')
    return a - a.mean(axis=1, keepdims=True)


# ---------- §3 激活：源码 tanh-GELU ----------
def tanh_gelu(x):
    x = np.asarray(x, dtype=np.float64)
    return 0.5 * x * (1.0 + np.tanh(np.sqrt(2.0 / np.pi) * (x + 0.044715 * x ** 3)))


def tanh_gelu_prime(x):
    x = np.asarray(x, dtype=np.float64)
    c = np.sqrt(2.0 / np.pi)
    t = np.tanh(c * (x + 0.044715 * x ** 3))
    dx = c * (1.0 + 3.0 * 0.044715 * x ** 2)
    return 0.5 * (1.0 + t) + 0.5 * x * (1.0 - t * t) * dx


def exact_gelu(x):
    """§5: 精确 GELU = x*Phi(x)，仅用于独立解析控制。"""
    from math import erf
    x = np.asarray(x, dtype=np.float64)
    return x * 0.5 * (1.0 + np.vectorize(erf)(x / np.sqrt(2.0)))


def exact_gelu_prime(x):
    """§5: 精确 GELU 的导数 phi_e'(x) = Phi(x) + x*phi(x)。

    修复（2026-11-02）：原实现只返回 Phi(x)，漏掉 x*phi(x)，导致 §5 的闭式
    g_e(b,s)=Phi(b/t)+b/t^3*phi(b/t) 与求积相差最大 3.5e-2（fixture 报出）。
    此处按 §5 定义补全，闭式与求积随即可在 1e-12 内一致。
    """
    from math import erf
    x = np.asarray(x, dtype=np.float64)
    Phi = 0.5 * (1.0 + np.vectorize(erf)(x / np.sqrt(2.0)))
    phi = np.exp(-0.5 * x * x) / np.sqrt(2.0 * np.pi)
    return Phi + x * phi


def g_exact_closed(b, s):
    """§5: g_e(b,s) = Phi(b/t) + (b/t^3)*phi(b/t), t=sqrt(1+s^2)."""
    b = np.asarray(b, dtype=np.float64)
    s = np.asarray(s, dtype=np.float64)
    t = np.sqrt(1.0 + s * s)
    u = b / t
    from math import erf, exp
    Phi = 0.5 * (1.0 + np.vectorize(erf)(u / np.sqrt(2.0)))
    phi = np.exp(-0.5 * u * u) / np.sqrt(2.0 * np.pi)
    return Phi + b / t ** 3 * phi


# ---------- §4 Hermite 系数 ----------
def gauss_quad(nodes):
    """§4/§6: Gauss–Hermite 求积（标准正态权重）。

    数值稳定性修复（2026-11-02）：本环境的 numpy 版本中
    ``numpy.polynomial.hermite.hermgauss`` 在 n>=384 时权重溢出为 NaN
    （实测 n=384/512/640/768 全部 w=nan），会污染系数并导致 eigvalsh 不收敛。
    改用 ``scipy.special.roots_hermitenorm``——**同一条 Gauss–Hermite 规则**的概率论
    归一化版本，仅换节点生成方式，不改变求积定义：
        E[f(Z)] = sum_i w_i f(x_i),  w_i = w~_i / sqrt(2*pi)
    此实现不构成积分误差证明。
    """
    from scipy.special import roots_hermitenorm
    x, w = roots_hermitenorm(nodes)
    return x, w / np.sqrt(2.0 * np.pi)


def hermite_basis(z, Q):
    """正交归一化 Hermite：E[h_q^2]=1，即 He_q/sqrt(q!)。"""
    h = [np.ones_like(z), z]
    for q in range(2, Q + 1):
        h.append((z * h[-1] - np.sqrt(q - 1) * h[-2]) / np.sqrt(q))
    return np.stack(h[:Q + 1])


def coefficients(s, m, Q, nodes, activation='tanh'):
    """§4: a_jq = E[phi_t(m+sZ) He_q(Z)]/sqrt(q!), g_j = E[phi_t'(m+sZ)]."""
    z, w = gauss_quad(nodes)
    HS = hermite_basis(z, Q)
    vals = m[:, None] + s[:, None] * z[None, :]
    if activation == 'tanh':
        phi, dphi = tanh_gelu(vals), tanh_gelu_prime(vals)
    else:
        phi, dphi = exact_gelu(vals), exact_gelu_prime(vals)
    return phi @ (HS * w).T, dphi @ w


def a1_matrix(p, a1, V):
    """§4: A1 = sum_j beta_j g_j v_j^T = sum_j a_j1 p_j v_j^T, shape (d,d)."""
    return (p.T * a1) @ V


def hq_gramian(U, Gv, rho, q, aq):
    """§4: H_q = U^T D_q (Gv ⊙ rho^{⊙(q-1)}) D_q U, tr H_q = E_q."""
    if q < 1:
        raise ValueError('q>=1')
    K = Gv * (rho ** (q - 1))
    W = (aq[:, None] * K) * aq[None, :]
    return U.T @ W @ U


# ---------- §6 误差与判决 ----------
def spectral_stats(ev, ranks=(64, 128, 256, 512, 1024, 2048, 3072, 4096),
                   eps=(0.01, 0.05, 0.10), neg_tol=1e-9):
    ev = np.asarray(ev, dtype=np.float64).reshape(-1)
    if ev.size == 0 or not np.isfinite(ev).all():
        raise ValueError('eigenvalues missing or nonfinite')
    scale = max(float(np.max(np.abs(ev))), 1e-300)
    if float(np.min(ev)) < -neg_tol * scale:
        raise ValueError('PSD violation')
    ev = np.sort(np.maximum(ev, 0.0))[::-1]
    total = float(ev.sum())
    out = {'trace': total,
           'effective_rank': float(total ** 2 / float(np.sum(ev * ev))) if total > 0 else 0.0,
           'top10': ev[:10].tolist(),
           'tail_share': {str(r): (float(ev[r:].sum() / total) if total > 0 else None) for r in ranks},
           'zero_energy': total <= 0}
    req = {}
    for e in eps:
        if total <= 0:
            req[str(e)] = 0
            continue
        cand = [r for r in range(len(ev) + 1) if ev[r:].sum() <= e * total + 1e-12 * total]
        req[str(e)] = int(cand[0]) if cand else int(len(ev))
    out['r_required'] = req
    return out


def eta_quad(beta, delta, vnorm, nodes=None):
    """§6: |g_j - ghat_j| <= delta_j => ||A1 - Ahat1||_F <= ||B||_2*sqrt(sum_j delta_j^2 ||v_j||^2)."""
    delta = np.asarray(delta, dtype=np.float64)
    vnorm = np.asarray(vnorm, dtype=np.float64)
    B2 = float(np.linalg.norm(np.asarray(beta, dtype=np.float64), 2))
    return B2 * math.sqrt(float(np.sum(delta ** 2 * vnorm ** 2)))


def certified_reject(Lhat_r, eta, Ahat_fro, budget=0.05):
    """Conditional propagation only; eta must be a validated true error bound.

    This function does not establish provenance or certify an envelope.
    """
    if any(not math.isfinite(x) or x < 0 for x in (Lhat_r, eta, Ahat_fro, budget)):
        raise ValueError("nonnegative finite inputs required")
    if budget > 1:
        raise ValueError("budget must not exceed 1")
    if Lhat_r > Ahat_fro ** 2 * (1 + 1e-12):
        raise ValueError("tail energy exceeds total energy")
    num = max(math.sqrt(Lhat_r) - eta, 0.0) ** 2
    den = (Ahat_fro + eta) ** 2
    if den <= 0:
        return None
    return {'lower': num / den, 'denominator': den, 'reject_at_budget': num / den > budget}


def sobolev_tail_bound(Dk_upper, Ek_lower, Q, k):
    """Conditional bound: inputs must themselves be valid upper/lower bounds."""
    if isinstance(Q, bool) or isinstance(k, bool) or not isinstance(Q, int) or not isinstance(k, int) or k < 1 or Q < k:
        raise ValueError('requires integers Q >= k >= 1')
    if not math.isfinite(Dk_upper) or Dk_upper < 0:
        raise ValueError('invalid Dk upper bound')
    for q, value in Ek_lower.items():
        if isinstance(q, bool) or not isinstance(q, int) or q < k or q > Q or not math.isfinite(value) or value < 0:
            raise ValueError('invalid lower energy')
    def falling(q):
        return math.prod(range(q-k+1, q+1))
    used = sum(falling(q) * value for q, value in Ek_lower.items())
    num = Dk_upper - used
    if num < 0:
        raise ValueError('inconsistent negative derivative budget')
    den = falling(Q + 1)
    return {'R_Q_upper': num / den, 'Dk_used': Dk_upper, 'denominator': den}
