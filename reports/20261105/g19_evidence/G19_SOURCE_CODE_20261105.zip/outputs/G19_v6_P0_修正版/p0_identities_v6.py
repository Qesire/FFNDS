"""G19 v6 · P0 身份与数学准备（CPU，无 GPU，无新模型执行）。

对应《G19_v6_完整研究方案.md》§8 P0 行：读权重清单；验证反例、零能量、
实际偏置、矩阵方向；确认公式与实现一致。所有公式来自 math_core_v6（§3–§6）。
"""
import argparse, json, math, pathlib, struct, hashlib, time, sys, traceback, signal
sys.path.insert(0, str(pathlib.Path(__file__).parent / "deps"))
import numpy as np
from math_core_v6 import (reference_scale, project_rows, tanh_gelu, tanh_gelu_prime,
                          exact_gelu, exact_gelu_prime, g_exact_closed,
                          coefficients, a1_matrix, spectral_stats, eta_quad,
                          certified_reject, sobolev_tail_bound)

R = {}
HASH_DIR = None
ALLOWED = {"high:0:original:O32", "high:0:original:Oq", "low:15:original:O32"}
UNIT_TOL = 1e-8

class UnitDiagnosticError(ValueError):
    def __init__(self, diagnostics):
        self.diagnostics = diagnostics
        super().__init__("unit numerical acceptance failed")


def read_tensor(manifest, key):
    rec = manifest['tensors'][key]
    p = pathlib.Path(rec['path']); info = manifest['files'][str(p)]; sp = rec['spec']
    if sp.get('dtype') != 'F32':
        raise ValueError('original tensors must have F32 dtype')
    shape=sp.get('shape'); offsets=sp.get('data_offsets')
    if not isinstance(shape,list) or not shape or any(type(x) is not int or x <= 0 for x in shape): raise ValueError('invalid tensor shape')
    if not isinstance(offsets,list) or len(offsets)!=2 or any(type(x) is not int for x in offsets): raise ValueError('invalid offsets')
    if offsets[0] < 0 or offsets[1]-offsets[0] != math.prod(shape)*4: raise ValueError('invalid payload extent')
    st = p.stat()
    if st.st_size != info['size'] or st.st_mtime_ns != info['mtime_ns']:
        raise ValueError(f'weight stat mismatch {p}')
    with p.open('rb') as f:
        n = struct.unpack('<Q', f.read(8))[0]
        raw = f.read(n)
        if hashlib.sha256(raw).hexdigest() != info['header_sha256']:
            raise ValueError(f'header hash mismatch {p}')
        if json.loads(raw)[rec['key']] != sp:
            raise ValueError(f'spec mismatch {key}')
        lo, hi = sp['data_offsets']
        f.seek(8 + n + lo)
        buf = f.read(hi - lo)
    if len(buf) != hi - lo:
        raise ValueError(f'truncated {key}')
    x = np.frombuffer(buf, dtype='<f4').copy()
    R[key] = hashlib.sha256(buf).hexdigest()
    if HASH_DIR is not None:
        with (HASH_DIR / (str(len(R)) + '.json')).open('x',encoding='utf-8') as f:
            json.dump({'key':key,'sha256':R[key]},f)
    x = x.reshape(sp['shape']).astype(np.float64)
    if not np.isfinite(x).all():
        raise ValueError(f'nonfinite {key}')
    return x


def to_bf16(x):
    """§3 Oq：原始 F32 按 BF16 舍入（就近偶数）。"""
    u = np.asarray(x, dtype=np.float32).view(np.uint32).copy()
    r = (u + 0x7FFF + ((u >> 16) & 1)) & 0xFFFF0000
    return r.view(np.float32).astype(np.float64)


# ---------------- fixtures ----------------
def fixtures():
    """Acceptance checks fail closed; diagnostics are explicitly separate."""
    from math_core_v6 import gauss_quad
    z, w = gauss_quad(512)
    c = np.sqrt(2 / np.pi); u = c * (z + .044715*z**3)
    t = np.tanh(u); up = c*(1+3*.044715*z**2); upp = c*6*.044715*z
    def second(x):
        u = c*(x+.044715*x**3); t=np.tanh(u)
        up=c*(1+3*.044715*x**2); upp=c*6*.044715*x
        return (1-t*t)*up + .5*x*(1-t*t)*(upp-2*t*up*up)
    scales=np.array([.7,1.3]); kappa=np.array([second(si*z)@w for si in scales])
    errors=[]
    for h in (.02,.01):
        g=coefficients(scales,np.full(2,h),1,512)[1]
        errors.append(float(np.max(np.abs(g-.5-h*kappa))))
    bb=np.array([0.,.25,-.25]); ss=np.array([0.,1.,2.])
    exact=float(np.max(np.abs(coefficients(ss,bb,1,512,activation='exact')[1]-g_exact_closed(bb,ss))))
    rng=np.random.default_rng(7); W=project_rows(rng.normal(size=(40,12))); beta=reference_scale(12)*W
    scales3=np.linalg.norm(beta,axis=1); p=beta/scales3[:,None]; V=rng.normal(size=(40,12)); bias=rng.normal(size=40)*.1
    matrices=[]
    for n in (512,768):
        co,g=coefficients(scales3,bias,1,n); matrices.append((a1_matrix(p,co[:,1],V), beta.T@(g[:,None]*V)))
    rel=lambda x,y: float(np.linalg.norm(x-y)/max(np.linalg.norm(x),1e-300))
    route=max(rel(a,b) for a,b in matrices); grid=max(rel(matrices[0][i],matrices[1][i]) for i in (0,1))
    trace=abs(np.linalg.norm(matrices[0][0])**2-np.linalg.norm(matrices[0][1])**2)/np.linalg.norm(matrices[0][0])**2
    transpose=float(np.linalg.norm(matrices[0][0].T@np.ones(12))/np.linalg.norm(matrices[0][0]))
    # True +/- pair outputs: sum is even; difference is exactly linear.
    x=np.linspace(-3,3,201); plus=tanh_gelu(x)+tanh_gelu(-x); minus=tanh_gelu(x)-tanh_gelu(-x)
    checks={'exact_gelu':exact < 1e-10, 'linearization_cubic':errors[0] < 1e-4 and errors[1] < errors[0]*.2,
            'direct_stein':route < 1e-9, 'node_convergence':grid < 1e-9, 'trace':trace < 1e-9,
            'transpose':transpose < 1e-12, 'pair_even':np.max(np.abs(plus-plus[::-1])) < 1e-12,
            'pair_linear':np.max(np.abs(minus-x)) < 1e-12}
    if not all(checks.values()): raise AssertionError(f'fixture failures: {checks}; exact={exact}, errors={errors}, route={route}, grid={grid}')
    return {'checks':{k:bool(v) for k,v in checks.items()}, 'diagnostics':{'exact_error':exact,'taylor_errors':errors,'route_rel':route,'grid_rel':grid,'trace_rel':float(trace)}}


# ---------------- 真实单元 ----------------
def unit(manifest, expert, model, layer, arm, output_dir, nodes=512, Q=1):
    global HASH_DIR
    R.clear()
    HASH_DIR = output_dir / "tensor_hashes"
    HASH_DIR.mkdir()
    t0 = time.time()
    pref = f'{expert}/{model}/blocks.{layer}.ffn.'
    W1 = read_tensor(manifest, pref + '0.weight')
    W2 = read_tensor(manifest, pref + '2.weight')
    b1 = read_tensor(manifest, pref + '0.bias')
    b2 = read_tensor(manifest, pref + '2.bias')
    if W1.ndim != 2: raise ValueError("W1 must be a matrix")
    m, d = W1.shape
    if d <= 1 or W2.shape != (d,m) or b1.shape != (m,) or b2.shape != (d,): raise ValueError("invalid FFN tensor geometry")
    if arm == 'Oq':
        W1 = to_bf16(W1); W2 = to_bf16(W2); b1 = to_bf16(b1); b2 = to_bf16(b2)
    if not all(np.isfinite(x).all() for x in (W1,W2,b1,b2)):
        raise ValueError("nonfinite tensor after arm conversion")
    if not np.all(b1 == 0):
        bias_nonzero = True
    else:
        bias_nonzero = False
    wc = project_rows(W1)
    beta = reference_scale(d, 1.0) * wc
    s = np.linalg.norm(beta, axis=1)
    p = np.where(s[:, None] > 0, beta / np.where(s[:, None] > 0, s[:, None], 1.0), 0.0)
    V = W2.T
    a_b, g = coefficients(s, b1, Q, nodes)
    a_0, _ = coefficients(s, np.zeros_like(b1), Q, nodes)
    A_b = a1_matrix(p, a_b[:, 1], V)
    A_0 = a1_matrix(p, a_0[:, 1], V)
    H = A_b @ A_b.T
    ev = np.linalg.eigvalsh(H)[::-1]
    np.save(output_dir / 'raw_eigenvalues.npy', ev)
    st = spectral_stats(ev)
    # Node differences are diagnostics, not integration bounds.
    a_768, g768 = coefficients(s, b1, Q, 768)
    delta = np.abs(g - g768)
    vnorm = np.linalg.norm(V, axis=1)
    eta = eta_quad(beta, delta, vnorm)
    res = {
        'unit': f'{expert}/{layer}/{model}/{arm}', 'd': d, 'm': m,
        'b1_nonzero': bool(bias_nonzero),
        'b1_max_abs': float(np.abs(b1).max()),
        's_quantiles': [float(np.quantile(s, q)) for q in (0.0, 0.5, 0.9, 1.0)],
        'g_range': [float(g.min()), float(g.max())],
        'g_minus_half_max_abs': float(np.max(np.abs(g - 0.5))),
        'A1_fro': float(np.linalg.norm(A_b)),
        'A1_bias_effect_rel': float(np.linalg.norm(A_b - A_0) / np.linalg.norm(A_0)) if np.linalg.norm(A_0) > 0 else None,
        'A1_transpose_ones_rel': float(np.linalg.norm(A_b.T @ np.ones(d)) / max(np.linalg.norm(A_b), 1e-300)),
        'E1_trace_rel': float(abs(st['trace'] - np.linalg.norm(A_b) ** 2) / max(st['trace'], 1e-300)),
        'spectrum': st,
        'grid_discrepancy': {'derivative_route_indicator': eta, 'direct_matrix_rel': float(np.linalg.norm(A_b-a1_matrix(p,a_768[:,1],V))/max(np.linalg.norm(A_b),1e-300)), 'stein_matrix_rel': float(np.linalg.norm(beta.T@((g-g768)[:,None]*V))/max(np.linalg.norm(beta.T@(g[:,None]*V)),1e-300)), 'direct_vs_stein_rel': float(np.linalg.norm(A_b-beta.T@(g[:,None]*V))/max(np.linalg.norm(A_b),1e-300)), 'direct_vs_stein_trace_rel': float(abs(np.linalg.norm(A_b)**2-np.linalg.norm(beta.T@(g[:,None]*V))**2)/max(np.linalg.norm(A_b)**2,1e-300))},
        'numerical_screen': {str(r): st['tail_share'].get(str(r)) for r in (128,256,512,1024,2048)},
        'certificate': 'NOT_ESTABLISHED', 'raw_tensor_sha256': dict(R),
        'seconds': round(time.time() - t0, 2),
    }
    if st['zero_energy']:
        res['first_chaos_status'] = 'FIRST_CHAOS_UNINFORMATIVE'
        res['numerical_screen'] = None
        res['spectrum']['r_required'] = None
    if np.linalg.norm(A_0) == 0:
        res['A1_bias_effect_rel'] = None
    diagnostics = res['grid_discrepancy']
    checked = {k:v for k,v in diagnostics.items() if k != 'derivative_route_indicator'}
    checked['E1_trace_rel'] = res['E1_trace_rel']
    checked['A1_transpose_ones_rel'] = res['A1_transpose_ones_rel']
    res['acceptance'] = {'tolerance': UNIT_TOL, 'values': checked}
    if any(not math.isfinite(v) or v > UNIT_TOL for v in checked.values()):
        raise UnitDiagnosticError(res)
    return res


def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--manifest',required=True); ap.add_argument('--out',required=True)
    ap.add_argument('--units',default='high:0:original:O32,high:0:original:Oq,low:15:original:O32')
    a=ap.parse_args(); outdir=pathlib.Path(a.out); outdir.mkdir(parents=True,exist_ok=False)
    config_sha=hashlib.sha256(json.dumps(vars(a),sort_keys=True,separators=(',',':')).encode()).hexdigest()
    receipt={'config_sha256':config_sha,'scope':'DRAFT_NOT_FROZEN','status':'STARTED','config':vars(a),'code_sha256':{p.name:sha(p) for p in (pathlib.Path(__file__),pathlib.Path(__file__).with_name('math_core_v6.py'))}}
    def write_new(name, value):
        with (outdir/name).open('x',encoding='utf-8') as f: json.dump(value,f,indent=2)
    def terminate(signum, frame): raise SystemExit(f'terminated by signal {signum}')
    handled_signals = [signal.SIGTERM] + ([signal.SIGUSR1] if hasattr(signal, "SIGUSR1") else [])
    old_handlers = {sig: signal.signal(sig, terminate) for sig in handled_signals}
    try:
        write_new('START.json',receipt)
        specs=a.units.split(',')
        if not specs or len(specs)!=len(set(specs)) or any(spec not in ALLOWED for spec in specs):
            raise ValueError('units must be unique members of the P0 whitelist')
        receipt['manifest_sha256']=sha(a.manifest)
        man=json.loads(pathlib.Path(a.manifest).read_text(encoding='utf-8'))
        if man.get('schema') != 'G19_MANIFEST_V6': raise ValueError('manifest schema mismatch')
        receipt['fixtures']=fixtures()
        for i,spec in enumerate(specs):
            expert,layer,model,arm=spec.split(':')
            dest=outdir/f'unit_{i:03d}'; dest.mkdir()
            try:
                result=unit(man,expert,model,int(layer),arm,dest)
                (dest/'receipt.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
            except BaseException as exc:
                failure={'status':'FAILED','traceback':traceback.format_exc(),'raw_tensor_sha256':dict(R)}
                if isinstance(exc,UnitDiagnosticError): failure['diagnostics']=exc.diagnostics
                (dest/'receipt.json').write_text(json.dumps(failure,indent=2),encoding='utf-8')
                raise
        receipt['status']='SUCCESS'; receipt['exit_code']=0
    except BaseException:
        receipt['status']='FAILED'; receipt['exit_code']=1; receipt['traceback']=traceback.format_exc()
        raise
    finally:
        write_new('EXIT.json',receipt)
        for sig, handler in old_handlers.items(): signal.signal(sig, handler)

if __name__ == '__main__': main()

