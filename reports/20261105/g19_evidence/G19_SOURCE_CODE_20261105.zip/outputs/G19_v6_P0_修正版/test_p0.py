import json, sys, pathlib, unittest, subprocess, tempfile, hashlib, struct, signal
from unittest.mock import patch
import p0_identities_v6 as runner
import numpy as np
sys.path.insert(0,str(pathlib.Path(__file__).parent/'deps'))
from math_core_v6 import spectral_stats,sobolev_tail_bound,coefficients,project_rows,reference_scale,certified_reject
from p0_identities_v6 import fixtures
class Tests(unittest.TestCase):
 def test_fixtures(self): self.assertTrue(all(fixtures()['checks'].values()))
 def test_spectrum(self):
  a=spectral_stats([9,2],ranks=(1,))['tail_share']['1']; b=spectral_stats([900,200],ranks=(1,))['tail_share']['1']; self.assertAlmostEqual(a,2/11); self.assertAlmostEqual(a,b)
  self.assertIsNone(spectral_stats([0,0],ranks=(1,))['tail_share']['1'])
  with self.assertRaises(ValueError): spectral_stats([1,-.1])
 def test_gram_vs_svd(self):
  A=np.array([[3.,1.,0.],[0.,2.,1.],[1.,0.,.5]])
  ev=np.linalg.eigvalsh(A@A.T); sv=np.linalg.svd(A,compute_uv=False)**2
  for r in (1,2):
   got=spectral_stats(ev,ranks=(r,))['tail_share'][str(r)]
   self.assertAlmostEqual(got,sv[r:].sum()/sv.sum(),places=13)
   self.assertAlmostEqual(got,spectral_stats(ev*100,ranks=(r,))['tail_share'][str(r)],places=13)
 def test_sobolev(self):
  self.assertAlmostEqual(sobolev_tail_bound(6,{2:0},2,2)['R_Q_upper'],1)
  self.assertAlmostEqual(sobolev_tail_bound(2.6,{2:1},2,2)['R_Q_upper'],.1)
  for args in [(1,{2:1},2,2),(-1,{},2,2),(1,{},1,2),(float('nan'),{},2,2),(1,{2:-1},2,2)]:
   with self.assertRaises(ValueError): sobolev_tail_bound(*args)
 def test_pair_chaos(self):
  # The two functions phi(z)+phi(-z) and phi(z)-phi(-z).
  a,_=coefficients(np.array([1.,1.]),np.array([0.,0.]),6,256)
  parity=np.array([(-1.)**q for q in range(7)])
  even=a[0]*(1+parity); odd=a[0]*(1-parity)
  self.assertLess(np.sum(even[1::2]**2),1e-25)
  self.assertLess(np.sum(odd[2:]**2),1e-25)
  self.assertAlmostEqual(odd[1]**2,1.)
  self.assertGreater(np.sum(even[2:]**2),.01)
 def test_zero_and_direction(self):
  a,g=coefficients(np.zeros(2),np.array([.1,-.2]),2,128); self.assertLess(np.max(np.abs(a[:,1])),1e-14)
  beta=project_rows(np.array([[1.,2.,4.],[2.,-1.,3.]])); A=beta.T@np.array([[1.,2.,3.],[4.,0.,1.]])
  self.assertLess(np.linalg.norm(A.T@np.ones(3)),1e-12); self.assertGreater(np.linalg.norm(A@np.ones(3)),1)
 def synthetic_manifest(self,t,zero=False):
  names=['0.weight','2.weight','0.bias','2.bias']; arrays=[np.array([[1,0,-1],[0,1,-1]],dtype='<f4'),np.array([[1,0],[0,1],[1,1]],dtype='<f4'),np.array([.1,-.2],dtype='<f4'),np.zeros(3,dtype='<f4')]
  if zero: arrays=[np.zeros_like(a) for a in arrays]
  header={}; offset=0
  for name,a in zip(names,arrays):
   n=a.nbytes; header[name]={'dtype':'F32','shape':list(a.shape),'data_offsets':[offset,offset+n]}; offset+=n
  raw=json.dumps(header).encode(); f=pathlib.Path(t)/'tiny.safetensors'; f.write_bytes(struct.pack('<Q',len(raw))+raw+b''.join(a.tobytes() for a in arrays)); st=f.stat()
  manifest={'schema':'G19_MANIFEST_V6','files':{str(f):{'size':st.st_size,'mtime_ns':st.st_mtime_ns,'header_sha256':hashlib.sha256(raw).hexdigest()}},'tensors':{f'high/original/blocks.0.ffn.{name}':{'path':str(f),'key':name,'spec':header[name]} for name in names}}
  mf=pathlib.Path(t)/'manifest.json'; mf.write_text(json.dumps(manifest)); return mf
 def test_synthetic_end_to_end(self):
  with tempfile.TemporaryDirectory() as t:
   mf=self.synthetic_manifest(t); out=pathlib.Path(t)/'run'
   p=subprocess.run([sys.executable,str(pathlib.Path(__file__).with_name('p0_identities_v6.py')),'--manifest',str(mf),'--out',str(out),'--units','high:0:original:O32'],capture_output=True,text=True)
   self.assertEqual(p.returncode,0,p.stderr); unit=json.loads((out/'unit_000/receipt.json').read_text()); self.assertEqual(unit['certificate'],'NOT_ESTABLISHED'); self.assertEqual(len(unit['raw_tensor_sha256']),4); ev=np.load(out/'unit_000/raw_eigenvalues.npy'); self.assertEqual(ev.size,3)
   W=np.array([[1,0,-1],[0,1,-1]],float); V=np.array([[1,0,1],[0,1,1]],float); beta=reference_scale(3)*project_rows(W); scales=np.linalg.norm(beta,axis=1); co,_=coefficients(scales,np.array([.1,-.2],dtype=np.float32).astype(float),1,512); A=(beta.T/scales*co[:,1])@V; sv=np.linalg.svd(A,compute_uv=False)**2
   for rank in (1,2): self.assertAlmostEqual(spectral_stats(ev,ranks=(rank,))['tail_share'][str(rank)],sv[rank:].sum()/sv.sum(),places=12)
 def test_zero_unit(self):
  with tempfile.TemporaryDirectory() as t:
   mf=self.synthetic_manifest(t,zero=True); out=pathlib.Path(t)/'run'
   p=subprocess.run([sys.executable,str(pathlib.Path(__file__).with_name('p0_identities_v6.py')),'--manifest',str(mf),'--out',str(out),'--units','high:0:original:O32'],capture_output=True,text=True)
   self.assertEqual(p.returncode,0,p.stderr); unit=json.loads((out/'unit_000/receipt.json').read_text())
   self.assertEqual(unit['first_chaos_status'],'FIRST_CHAOS_UNINFORMATIVE'); self.assertIsNone(unit['numerical_screen']); self.assertIsNone(unit['spectrum']['r_required']); self.assertIsNone(unit['A1_bias_effect_rel'])
 def test_quantized_nonfinite(self):
  with tempfile.TemporaryDirectory() as t:
   mf=self.synthetic_manifest(t); man=json.loads(mf.read_text()); out=pathlib.Path(t)/'unit'; out.mkdir()
   with patch.object(runner,'to_bf16',side_effect=lambda x: np.full_like(x,np.inf)):
    with self.assertRaisesRegex(ValueError,'nonfinite tensor after arm conversion'): runner.unit(man,'high','original',0,'Oq',out)
 def test_fixture_failure_before_weights(self):
  with tempfile.TemporaryDirectory() as t:
   mf=self.synthetic_manifest(t); out=pathlib.Path(t)/'run'
   with patch.object(sys,'argv',['runner','--manifest',str(mf),'--out',str(out)]), patch.object(runner,'fixtures',side_effect=AssertionError('injected')), patch.object(runner,'read_tensor',side_effect=AssertionError('weight read')) as read:
    with self.assertRaisesRegex(AssertionError,'injected'): runner.main()
    read.assert_not_called()
   receipt=json.loads((out/'EXIT.json').read_text()); self.assertEqual(receipt['status'],'FAILED'); self.assertEqual(receipt['exit_code'],1)
 def test_unit_rejections_and_diagnostics(self):
  with tempfile.TemporaryDirectory() as t:
   mf=self.synthetic_manifest(t); man=json.loads(mf.read_text()); out=pathlib.Path(t)/'unit'; out.mkdir()
   with patch.object(runner,'UNIT_TOL',-1):
    with self.assertRaises(runner.UnitDiagnosticError) as exc: runner.unit(man,'high','original',0,'O32',out)
    self.assertIn('grid_discrepancy',exc.exception.diagnostics)
   key='high/original/blocks.0.ffn.0.weight'; man['tensors'][key]['spec']['dtype']='BF16'
   with self.assertRaises(ValueError): runner.read_tensor(man,key)
 def test_bad_whitelist_precedes_reads(self):
  with tempfile.TemporaryDirectory() as t:
   out=pathlib.Path(t)/'run'
   with patch.object(sys,'argv',['runner','--manifest','missing','--out',str(out),'--units','high:1:original:O32']), patch.object(runner,'read_tensor') as read:
    with self.assertRaises(ValueError): runner.main()
    read.assert_not_called()
   self.assertEqual(json.loads((out/'EXIT.json').read_text())['status'],'FAILED')
 def test_sigterm_receipt(self):
  with tempfile.TemporaryDirectory() as t:
   mf=self.synthetic_manifest(t); out=pathlib.Path(t)/'run'
   with patch.object(sys,'argv',['runner','--manifest',str(mf),'--out',str(out),'--units','high:0:original:O32']), patch.object(runner,'fixtures',side_effect=lambda: signal.raise_signal(signal.SIGTERM)):
    with self.assertRaises(SystemExit): runner.main()
   self.assertEqual(json.loads((out/'EXIT.json').read_text())['status'],'FAILED')
 def test_conditional_inputs(self):
  for args in [(-1,0,1,.05),(1,-1,1,.05),(1,0,1,float('nan')),(1,0,1,1.1),(2,0,1,.05)]:
   with self.assertRaises(ValueError): certified_reject(*args)
 def test_failure_receipt(self):
  with tempfile.TemporaryDirectory() as t:
   out=pathlib.Path(t)/'run'; p=subprocess.run([sys.executable,str(pathlib.Path(__file__).with_name('p0_identities_v6.py')),'--manifest',str(pathlib.Path(t)/'missing'),'--out',str(out)],capture_output=True)
   self.assertNotEqual(p.returncode,0); self.assertEqual(json.loads((out/'EXIT.json').read_text())['status'],'FAILED')
   q=subprocess.run([sys.executable,str(pathlib.Path(__file__).with_name('p0_identities_v6.py')),'--manifest','missing','--out',str(out)],capture_output=True); self.assertNotEqual(q.returncode,0)
if __name__=='__main__':
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(Tests); result=unittest.TextTestRunner(verbosity=2).run(suite)
 pathlib.Path(__file__).with_name('test_results.json').write_text(json.dumps({'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'successful':result.wasSuccessful()},indent=2))
 sys.exit(not result.wasSuccessful())

