"""Local-only audit of two complete origin-evidence runs; no remote access."""
import csv,hashlib,json,math
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parent.parent
RESULTS=Path(__file__).resolve().parent
SOURCE=ROOT/'g19_v7_origin_evidence_r1'
S3=ROOT/'g19_v7_formal_s3_results'/'s3_structure_units.csv'
SCOPE_SHA={'high':'c18b1ee02e16fa3daaecd6c51dddf9045e3f3539a41dfe7ba95a39e4bb34a042','low':'30a92ea0f656583a9bcfd50568f54cd7eef1745b548da30cc494c21e96bd90fa'}
S3_SHA='7e8c0d29e0df8a1d306835fc0e988ba81ba78202843a9857ea426c5c640da8a8'
LAYERS=(0,1,7,12,13,19,23,24,28,33,37,38)


def require(c,m):
    if not c: raise ValueError(m)
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def rows(path):
    with path.open(encoding='utf-8-sig') as f:return [json.loads(line) for line in f if line.strip()]
def close(a,b,rtol=1e-8,atol=1e-10):
    return math.isfinite(a) and math.isfinite(b) and abs(a-b)<=atol+rtol*max(abs(a),abs(b))
def ratio(a,b): return float(a/b) if b>0 else None


def quantiles(x,weights=None):
    """Quantiles over neurons; weights are explicit diagonal proxies, not full FFN energy."""
    x=np.asarray(x,dtype=float); valid=np.isfinite(x)
    if weights is None:
        x=x[valid]
        return None if not len(x) else {str(q):float(np.quantile(x,q)) for q in (.1,.5,.9)}
    w=np.asarray(weights,dtype=float); require(w.shape==x.shape and np.isfinite(w).all() and np.all(w>=0),'invalid quantile weights')
    valid &= w>0; x=x[valid]; w=w[valid]
    if not len(x) or w.sum()<=0: return None
    idx=np.argsort(x); x=x[idx]; w=w[idx]; cumulative=np.cumsum(w)/w.sum()
    return {str(q):float(x[min(int(np.searchsorted(cumulative,q,side='left')),len(x)-1)]) for q in (.1,.5,.9)}


def candidate_flag(row):
    """Never convert material negative residual/invalid geometry into favorable capture."""
    E=row['E2_input']; n=row['candidate_norm2']; cross=row['true_cross']; residual=row['frobenius_residual_raw']
    checks=('basis_orthogonality_max_abs','basis_support_sum_over_sqrt_d_max_abs','p_support_sum_over_sqrt_d_max_abs','geometry_tolerance','C_relative_error','E_relative_error','coefficient_relative_tolerance','diag_energy','edge_energy')
    if not all(math.isfinite(v) for v in (E,n,cross,residual)) or any(not math.isfinite(row[k]) or row[k]<0 for k in checks) or E<0 or n<0 or row['geometry_tolerance']==0 or row['coefficient_relative_tolerance']==0: return 'INVALID_NUMERIC'
    if not close(residual,E+n-2*cross,rtol=1e-8,atol=1e-10): return 'INCONSISTENT_RESIDUAL_IDENTITY'
    tol=1e-12+1e-9*max(E,n,abs(2*cross))
    if residual < -tol:return 'MATERIAL_NEGATIVE_RESIDUAL'
    if residual<0:return 'NEGATIVE_ROUNDOFF_UNRESOLVED'
    if any(row[key]>row['geometry_tolerance'] for key in ('basis_orthogonality_max_abs','basis_support_sum_over_sqrt_d_max_abs','p_support_sum_over_sqrt_d_max_abs')):return 'INVALID_GEOMETRY'
    if row['C_relative_error']>row['coefficient_relative_tolerance'] or row['E_relative_error']>row['coefficient_relative_tolerance']:return 'COEFFICIENT_MISMATCH'
    if not close(n,row['diag_energy']+row['edge_energy']):return 'INCONSISTENT_CAPTURE_IDENTITY'
    if n>E+tol:return 'CAPTURE_EXCEEDS_E2'
    if E>0 and (not close(row['diag_capture_over_E2'],row['diag_energy']/E) or not close(row['diag_plus_edge_capture_over_E2'],n/E) or not close(row['frobenius_residual_over_E2_raw'],residual/E)): return 'INCONSISTENT_NORMALIZATION'
    return 'NUMERICS_UNASSESSED'


def load_scope(expert):
    root=(SOURCE/expert).resolve(); file=root/'scope.json'; require(sha(file)==SCOPE_SHA[expert],expert+' scope SHA')
    scope=read(file); require(scope['phase']=='ORIGIN_EVIDENCE' and scope['status']=='FROZEN_REVIEWED',expert+' phase')
    review=read(root/'INDEPENDENT_REVIEW.json'); require(review['status']=='ACCEPTED' and review['scope_sha256']==SCOPE_SHA[expert] and review['reviewer'] not in scope['authors'],expert+' review')
    identities=dict(scope['code_sha256']); identities.update(scope['frozen_inputs_sha256']); identities[scope['config_file']]=scope['config_sha256']; identities[scope['input_manifest_file']]=scope['manifest_sha256']
    for name,digest in identities.items():
        path=(root/name).resolve(); require(path.is_relative_to(root) and sha(path)==digest,expert+' frozen input '+name)
    c=read(root/scope['config_file']); require(c['expert']==expert and c['layers']==list(range(40)),expert+' config')
    for k in ('expected_tensor_hashes_file','summary_file','assets_file','candidates_file'): require(c[k] in scope['frozen_inputs_sha256'],expert+' unbound '+k)
    return scope,c,read(root/c['expected_tensor_hashes_file']),read(root/c['assets_file']),read(root/c['summary_file']),read(root/c['candidates_file']),read(root/scope['input_manifest_file'])


def old_probe_index():
    require(sha(S3)==S3_SHA,'S3 probe source SHA mismatch'); result={}
    with S3.open(encoding='utf8',newline='') as f:
      for r in csv.DictReader(f):
        if r['candidate'] not in ('EDGE_FULL_RJD','EDGE_FULL_RJD_OQ_SHARED'): continue
        key=(r['expert'],int(r['layer']),r['arm'],'OQ_SHARED' if r['candidate'].endswith('_OQ_SHARED') else 'OWN')
        require(key not in result and r['operator_frob_probe_mean'] and r['n_operator_probes']=='16','invalid old probe receipt')
        result[key]={'operator_frob_probe_mean':float(r['operator_frob_probe_mean']),'operator_over_s3_q2_energy':float(r['operator_over_Q2_energy']),'s3_q2_energy_mean':float(r['q2_energy_mean']),'n_operator_probes':16}
    require(len(result)==72,'S3 old probe family incomplete')
    return result


def audit_expert(expert,old):
    scope,c,hashes,assets,summary,candidates,manifest=load_scope(expert); folder=RESULTS/expert
    start=read(folder/'START.json'); end=read(folder/'EXIT.json'); env=rows(folder/'environment.jsonl')
    require(start['scope']['_verified_scope_sha256']==SCOPE_SHA[expert] and start['scope']['scope_id']==scope['scope_id'],expert+' START')
    result=end['result']; require(end['status']=='SUCCESS' and end['exception'] is None and result['status']=='ORIGIN_EVIDENCE_COMPLETE_NUMERICS_UNASSESSED' and result['completed_layers']==list(range(40)) and len(result['completed_units'])==80 and set(result['completed_units'])=={f'{expert}/{i}/{a}' for i in range(40) for a in ('Oq','Dq')},expert+' EXIT')
    require(len(env)==1 and env[0]['scope_sha256']==SCOPE_SHA[expert] and env[0]['stream']=='DEVELOPMENT/800' and env[0]['numerical_status']=='UNASSESSED',expert+' environment')
    unit=rows(folder/'units.jsonl'); layers=rows(folder/'layers.jsonl'); weights=rows(folder/'weights.jsonl'); artifacts=rows(folder/'artifacts.jsonl'); cand=rows(folder/'candidates.jsonl')
    require(len(unit)==80 and {(x['layer'],x['arm']) for x in unit}=={(i,a) for i in range(40) for a in ('Oq','Dq')} and all(x['expert']==expert and x['numerical_status']=='UNASSESSED' for x in unit),expert+' units')
    require(len(layers)==40 and {x['layer'] for x in layers}==set(range(40)) and all(x['expert']==expert and x['status']=='COMPLETE' for x in layers),expert+' layers')
    needed={f'{expert}/{model}/blocks.{i}.ffn.{s}' for i in range(40) for model in ('original','distilled') for s in ('0.weight','0.bias','2.weight','2.bias')}
    seen=set(); require(len(weights)==320,expert+' tensors')
    for x in weights:
        k=f"{x['expert']}/{x['model']}/{x['key']}"; require(k in needed and k not in seen and x['identity_status']=='PRECOMMITTED_HASH_MATCH' and x['sha256']==hashes[k] and x['key'].startswith(f"blocks.{x['layer']}.ffn."),expert+' tensor SHA receipt'); seen.add(k)
        spec=manifest['tensors'][k]; lo,hi=spec['spec']['data_offsets']; require(x['path']==spec['path'] and x['dtype']==spec['spec']['dtype'] and x['bytes']==hi-lo,expert+' tensor manifest receipt')
    require(seen==needed,expert+' missing tensor')
    expect={(i,a) for i in range(40) for a in ('Oq','Dq')}; require(len(artifacts)==80 and {(x['layer'],x['arm']) for x in artifacts}==expect and all(x['expert']==expert and x['kind']=='PER_NEURON_QUADRATURE' for x in artifacts),expert+' NPZ receipts')
    amap={(x['layer'],x['arm']):x for x in artifacts}; unit_map={(x['layer'],x['arm']):x for x in unit}
    expected_cand={(i,'Oq','OWN') for i in LAYERS}|{(i,'Dq',g) for i in LAYERS for g in ('OWN','OQ_SHARED')}
    require(len(cand)==36 and {(x['layer'],x['arm'],x['geometry']) for x in cand}==expected_cand and all(x['expert']==expert for x in cand),expert+' candidate receipts')
    candidate_records=[]
    for x in cand:
        i=x['layer']; arm=x['arm']; geometry=x['geometry']; asset=candidates[f'{expert}/{i}/{arm}'][geometry]
        require(x['candidate_sha256']==asset['sha256'] and x['status']=='COEFFICIENT_CHECKS_PASSED_NUMERICS_UNASSESSED',expert+' candidate SHA/status')
        record=old[(expert,i,arm,geometry)]; residual=x['frobenius_residual_raw']; E2=x['E2_input']; flag=candidate_flag(x)
        require(close(E2,unit_map[(i,arm)]['E2_gaussian']),expert+' E2 candidate identity')
        candidate_records.append({'expert':expert,'layer':i,'arm':arm,'geometry':geometry,'numeric_flag':flag,'E2_gaussian':E2,'diag_capture_over_E2':x['diag_capture_over_E2'] if flag=='NUMERICS_UNASSESSED' else None,'diag_plus_edge_capture_over_E2':x['diag_plus_edge_capture_over_E2'] if flag=='NUMERICS_UNASSESSED' else None,'residual_frobenius_raw':residual,'residual_over_E2':x['frobenius_residual_over_E2_raw'] if flag=='NUMERICS_UNASSESSED' else None,'old_16probe_residual_mean':record['operator_frob_probe_mean'],'old_16probe_over_s3_q2_energy':record['operator_over_s3_q2_energy'],'old_probe_minus_exact_residual':record['operator_frob_probe_mean']-residual if flag=='NUMERICS_UNASSESSED' else None,'old_probe_is_stochastic_estimate':True})
    output=[]
    for i in range(40):
      require(unit_map[(i,'Oq')]['sign_bits_sha256']==unit_map[(i,'Dq')]['sign_bits_sha256'],expert+' shared signs mismatch')
      for arm in ('Oq','Dq'):
        x=unit_map[(i,arm)]; art=amap[(i,arm)]; name=art['path']; require(Path(name).name==name,expert+' NPZ path'); path=folder/name
        require(sha(path)==art['sha256'],expert+' NPZ SHA')
        with np.load(path,allow_pickle=False) as z:
            names=('sigma','bias','v_norm_sq','a','variance','tail2','tail4','a_zero_bias','variance_zero_bias','tail2_zero_bias','tail4_zero_bias','a_192','variance_192','tail2_192','tail4_192','a_zero_bias_192','variance_zero_bias_192','tail2_zero_bias_192','tail4_zero_bias_192')
            require(set(z.files)==set(names),expert+' NPZ fields'); a={k:np.array(z[k]) for k in names}
        m=len(a['sigma']); require(m==13824 and all(a[k].shape==((m,9) if k in ('a','a_192','a_zero_bias','a_zero_bias_192') else (m,)) and np.isfinite(a[k]).all() for k in names),expert+' NPZ geometry/finiteness')
        sigma=a['sigma']; bias=a['bias']; vn=a['v_norm_sq']; require(np.all(sigma>=0) and np.all(vn>=0) and all(np.all(a[k]>=0) for k in ('variance','tail2','tail4','variance_zero_bias','tail2_zero_bias','tail4_zero_bias')),expert+' invalid neuron values')
        zero=sigma==0
        require(all(np.all(a[k][zero,1:]==0) for k in ('a','a_192','a_zero_bias','a_zero_bias_192')) and all(np.all(a[k][zero]==0) for k in ('variance','tail2','tail4','variance_192','tail2_192','tail4_192','variance_zero_bias','tail2_zero_bias','tail4_zero_bias','variance_zero_bias_192','tail2_zero_bias_192','tail4_zero_bias_192')),expert+' zero-sigma handling')
        diagonal=(vn[:,None]*a['a'][:,1:]**2).sum(axis=0); E=np.asarray(x['E_q_1_to_8']); D=np.asarray(x['D_q_1_to_8']); cross=np.asarray(x['signed_cross_E_minus_D']); sign=np.asarray(x['sign_flip_E_q_1_to_8']); require(E.shape==(8,) and D.shape==(8,) and cross.shape==(8,) and sign.shape==(4,8) and all(np.isfinite(v).all() for v in (E,D,cross,sign)) and np.allclose(diagonal,D,rtol=1e-9,atol=1e-10) and np.allclose(E-D,cross,rtol=1e-9,atol=1e-9),expert+' q energy identity')
        tolerance=1e-12+1e-9*D; require(np.allclose(x['negative_energy_tolerance_abs_plus_relative'],tolerance,rtol=1e-12,atol=1e-20) and np.all(E>=-tolerance) and np.all(sign>=-tolerance[None,:]),expert+' chaos energy gate')
        diagvar=float(vn@a['variance']); dt2=float(vn@a['tail2']); dt4=float(vn@a['tail4']); require(all(close(val,x[key]) for val,key in ((diagvar,'Dvar'),(dt2,'Dtail2'),(dt4,'Dtail4'))),expert+' diagonal sums')
        source=summary[f'{expert}/{i}/{arm}']; require(x['s12_input']==source and x['A1_vs_S12']['s12_asset_sha256']==assets[f'{expert}/{i}/{arm}']['sha256'] and x['A1_vs_S12']['relative_fro']<=1e-8,expert+' S12 source')
        lin=x['linear_shortcut']; e1=lin['A1_fro_sq']; L=lin['L0_fro_sq']; diff=lin['A1_minus_L0_fro_sq']; twice=lin['twice_inner_L0_delta']; require(abs(E[0]-e1)<=1e-9*max(abs(E[0]),e1,1e-300) and close(e1,L+diff+twice),expert+' A1/L0 identity')
        flip=x['bias_sign_flip_counterfactual']; require(close(flip['E1_flip'],L+diff-twice) and close(flip['Vflip_est_signed'],source['V']-E[0]+flip['E1_flip']) and flip['status']=='ALG_PLUS_S12_MC_NOT_NATIVE',expert+' bias-flip identity')
        radial=x['E2_radial']; sphere=x['E2_fixed_F2_sphere']; require(close(x['E2_gaussian'],E[1]) and (sphere is None if E[1]<0 else sphere is not None and close(sphere,5119/5121*(E[1]-radial))),expert+' sphere identity')
        if E[1]>=0: require(radial<=E[1]+1e-12+1e-9*max(E[1],radial),expert+' invalid radial energy')
        bs=np.full(m,np.nan); np.divide(bias,sigma,out=bs,where=~zero)
        weights_var=vn*a['variance']; weights_tail2=vn*a['tail2']; weights_a2=vn*a['a'][:,2]**2
        r={'expert':expert,'layer':i,'arm':arm,'V_s12':source['V'],'T2_s12':source['T2'],'T4_s12':source['T4'],'Dvar':diagvar,'Dtail2':dt2,'Dtail4':dt4,'T2_over_V':ratio(source['T2'],source['V']),'T4_over_V':ratio(source['T4'],source['V']),'Dtail2_over_Dvar':ratio(dt2,diagvar),'Dtail4_over_Dvar':ratio(dt4,diagvar),'T2_over_Dtail2':ratio(source['T2'],dt2),'T4_over_Dtail4':ratio(source['T4'],dt4),'V_over_Dvar':ratio(source['V'],diagvar),'relative_tail2_ratio':ratio(source['T2']*diagvar,source['V']*dt2),'relative_tail4_ratio':ratio(source['T4']*diagvar,source['V']*dt4),'E1_over_D1':ratio(E[0],D[0]),'E2_over_D2':ratio(E[1],D[1]),'E_q_1_to_8':E.tolist(),'D_q_1_to_8':D.tolist(),'signed_cross_1_to_8':cross.tolist(),'sign_energy_4_by_8':sign.tolist(),'radial_over_E2':ratio(radial,E[1]),'sphere_F2_energy_raw':sphere,'sphere_numeric_flag':'NEGATIVE_OR_UNDEFINED_UNRESOLVED' if sphere is None or sphere<0 else 'NUMERICS_UNASSESSED','sphere_F2_over_gaussian_F2':ratio(sphere,E[1]) if sphere is not None and sphere>=0 else None,'A1_minus_L0_fro_over_L0_fro':math.sqrt(diff/L) if L>0 else None,'E1_flip_over_E1':ratio(flip['E1_flip'],E[0]),'Vflip_est_signed':flip['Vflip_est_signed'],'sigma_zero_count':int(zero.sum()),'sigma_quantiles':quantiles(sigma),'bias_over_sigma_quantiles_nonzero_sigma':quantiles(bs),'sigma_weighted_by_diagonal_variance':quantiles(sigma,weights_var),'bias_over_sigma_weighted_by_diagonal_variance':quantiles(bs,weights_var),'sigma_weighted_by_diagonal_tail2':quantiles(sigma,weights_tail2),'sigma_weighted_by_diagonal_q2':quantiles(sigma,weights_a2),'zero_sigma_fraction_of_diagonal_variance':ratio(float(weights_var[zero].sum()),diagvar),'quadrature_384_192':x['quadrature_relative_384_vs_192'],'numeric_status':'UNASSESSED','npz_sha256':art['sha256']}
        if source['V']<=0 or diagvar<=0 or dt2<=0: r['relative_tail2_ratio']=None
        if source['V']<=0 or diagvar<=0 or dt4<=0: r['relative_tail4_ratio']=None
        var0=float(vn@a['variance_zero_bias']); tail20=float(vn@a['tail2_zero_bias']); tail40=float(vn@a['tail4_zero_bias']); zbc=x['zero_bias_counterfactual']
        require(all(close(v,zbc[k]) for v,k in ((var0,'Dvar'),(tail20,'Dtail2'),(tail40,'Dtail4'))),expert+' zero-bias diagonal sums')
        r.update({'Dvar_zero_bias':var0,'Dtail2_over_Dvar_zero_bias':ratio(tail20,var0),'Dtail4_over_Dvar_zero_bias':ratio(tail40,var0),'E1_flip':flip['E1_flip'],'E1_original':float(E[0])})
        stored=x['matched_ratios']
        for out_key,stored_key in (('T2_over_V','T2_over_V'),('T4_over_V','T4_over_V'),('T2_over_Dtail2','T2_over_Dtail2'),('T4_over_Dtail4','T4_over_Dtail4'),('V_over_Dvar','V_over_Dvar'),('relative_tail2_ratio','relative_tail_ratio2'),('relative_tail4_ratio','relative_tail_ratio4')):
            aa,bb=r[out_key],stored[stored_key]; require((aa is None and bb is None) or (aa is not None and bb is not None and close(aa,bb)),expert+' matched ratio identity')
        for q in range(3,9):
            r[f'E{q}_over_D{q}']=ratio(E[q-1],D[q-1]); r[f'E{q}_over_V_s12']=ratio(E[q-1],source['V'])
        output.append(r)
    evidence={'job_id':start['allocation']['job_id'],'scope_sha256':SCOPE_SHA[expert],'layers':40,'units':80,'raw_tensor_receipts':320,'A1_checks':80,'candidate_checks':36,'numerical_status':'UNASSESSED','raw_tensor_limitation':'Tensor SHA verified by compute job; local analysis only has receipts and derived arrays.','elapsed_seconds':end['elapsed_seconds'],'source_sha256':{name:sha(folder/name) for name in ('START.json','EXIT.json','environment.jsonl','layers.jsonl','units.jsonl','weights.jsonl','artifacts.jsonl','candidates.jsonl')}}
    return output,candidate_records,evidence


def main():
    old=old_probe_index(); units=[]; candidates=[]; evidence={}
    for expert in ('high','low'):
        u,c,e=audit_expert(expert,old); units+=u; candidates+=c; evidence[expert]=e
    require(len(units)==160 and len(candidates)==72,'family incomplete')
    index={(u['expert'],u['layer'],u['arm']):u for u in units}; paired=[]
    fields=('T2_over_V','T4_over_V','Dtail2_over_Dvar','Dtail4_over_Dvar','Dtail2_over_Dvar_zero_bias','Dtail4_over_Dvar_zero_bias','E1_over_D1','E2_over_D2','radial_over_E2','sphere_F2_over_gaussian_F2','A1_minus_L0_fro_over_L0_fro','E1_flip_over_E1')+tuple(f'E{q}_over_D{q}' for q in range(3,9))
    for expert in ('high','low'):
      for layer in range(40):
        o=index[(expert,layer,'Oq')]; d=index[(expert,layer,'Dq')]; paired.append({'expert':expert,'layer':layer,**{k+'_Dq_minus_Oq':d[k]-o[k] if d[k] is not None and o[k] is not None else None for k in fields}})
    groups={}
    for expert in ('high','low'):
      for arm in ('Oq','Dq'):
        group=[u for u in units if u['expert']==expert and u['arm']==arm]
        groups[expert+'/'+arm]={k:quantiles([u[k] if u[k] is not None else np.nan for u in group]) for k in fields}
    for label,group in [('all/Oq',[u for u in units if u['arm']=='Oq']),('all/Dq',[u for u in units if u['arm']=='Dq']),('high/all',[u for u in units if u['expert']=='high']),('low/all',[u for u in units if u['expert']=='low'])]:
        groups[label]={k:quantiles([u[k] if u[k] is not None else np.nan for u in group]) for k in fields}
    payload={'status':'DESCRIPTIVE_NUMERICS_UNASSESSED','scope_sha256':SCOPE_SHA,'s3_old_probe_source_sha256':S3_SHA,'evidence':evidence,'groups':groups,'units':units,'paired_Dq_minus_Oq':paired,'candidate_comparisons':candidates,'limitations':['q1..8 are finite-order energies, never total variance.','GELU sigma=1 is only a scalar reference and cannot establish a training effect.','S12 T/V uses planning samples; diagonal quantities are matched proxies with distinct denominators.','Sphere calculation applies to fixed F2 under a synthetic uniform sphere, not the full FFN.','Four sign flips are a finite exploratory set, and ratio of sums is not expected random ratio.','S3 old 16 probes are stochastic estimates; new residuals are original-metric numerical contractions, not certified bounds.','Invalid geometry or negative residual is flagged, and excluded from capture comparisons.','Raw tensor bytes were hashed on compute nodes; local audit sees receipts and derived arrays.']}
    (RESULTS/'analysis.json').write_text(json.dumps(payload,indent=2,allow_nan=False)+'\n',encoding='utf8')
    scalar=['expert','layer','arm','V_s12','T2_over_V','T4_over_V','Dtail2_over_Dvar','Dtail4_over_Dvar','Dtail2_over_Dvar_zero_bias','Dtail4_over_Dvar_zero_bias','T2_over_Dtail2','T4_over_Dtail4','V_over_Dvar','relative_tail2_ratio','relative_tail4_ratio','E1_over_D1','E2_over_D2']+[f'E{q}_over_D{q}' for q in range(3,9)]+[f'E{q}_over_V_s12' for q in range(3,9)]+['radial_over_E2','sphere_F2_over_gaussian_F2','A1_minus_L0_fro_over_L0_fro','E1_original','E1_flip','E1_flip_over_E1','Vflip_est_signed','sigma_zero_count','numeric_status']
    for name,rr,columns in [('units.csv',units,scalar),('candidates.csv',candidates,list(candidates[0])),('paired.csv',paired,list(paired[0]))]:
        with (RESULTS/name).open('w',encoding='utf8',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=columns,extrasaction='ignore'); writer.writeheader(); writer.writerows(rr)
    print(json.dumps({'status':payload['status'],'units':len(units),'candidates':len(candidates),'candidate_flags':{s:sum(x['numeric_flag']==s for x in candidates) for s in sorted({x['numeric_flag'] for x in candidates})},'evidence':evidence}))

if __name__=='__main__':main()
