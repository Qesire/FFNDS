import unittest
import numpy as np
from analyze_origin import candidate_flag,quantiles,old_probe_index,load_scope,ratio
class OriginAnalysisTests(unittest.TestCase):
 def candidate(self):
  return {'E2_input':10.,'candidate_norm2':4.,'true_cross':4.,'frobenius_residual_raw':6.,'basis_orthogonality_max_abs':0.,'basis_support_sum_over_sqrt_d_max_abs':0.,'p_support_sum_over_sqrt_d_max_abs':0.,'geometry_tolerance':1e-9,'C_relative_error':0.,'E_relative_error':0.,'coefficient_relative_tolerance':1e-9,'diag_energy':3.,'edge_energy':1.,'diag_capture_over_E2':.3,'diag_plus_edge_capture_over_E2':.4,'frobenius_residual_over_E2_raw':.6}
 def test_negative_and_geometry_flags(self):
  x=self.candidate(); self.assertEqual(candidate_flag(x),'NUMERICS_UNASSESSED')
  y={**x,'true_cross':8.,'frobenius_residual_raw':-2.}; self.assertEqual(candidate_flag(y),'MATERIAL_NEGATIVE_RESIDUAL')
  y={**x,'basis_orthogonality_max_abs':1e-2}; self.assertEqual(candidate_flag(y),'INVALID_GEOMETRY')
  y={**x,'true_cross':float('nan')}; self.assertEqual(candidate_flag(y),'INVALID_NUMERIC')
 def test_weighted_quantiles_and_zero(self):
  x=np.array([1.,2.,99.]); self.assertEqual(quantiles(x,np.array([0.,5.,0.]))['0.5'],2.)
  self.assertIsNone(quantiles(x,np.zeros(3))); self.assertIsNone(ratio(1.,0.))
 def test_frozen_scopes_and_s3_probe_family(self):
  for e in ('high','low'): self.assertEqual(load_scope(e)[1]['expert'],e)
  old=old_probe_index(); self.assertEqual(len(old),72); self.assertEqual(old[('high',0,'Oq','OWN')]['n_operator_probes'],16)
if __name__=='__main__':unittest.main()
