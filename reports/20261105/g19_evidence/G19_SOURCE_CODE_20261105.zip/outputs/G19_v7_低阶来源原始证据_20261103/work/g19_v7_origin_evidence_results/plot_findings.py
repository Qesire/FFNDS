import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=Path(__file__).resolve().parent
j=json.loads((root/'analysis.json').read_text())
fig,ax=plt.subplots(2,2,figsize=(12,8.2),layout='constrained')
colors={'high':'#135ca5','low':'#c45b17'}
for expert,color in colors.items():
    u=sorted([x for x in j['units'] if x['expert']==expert and x['arm']=='Oq'],key=lambda x:x['layer'])
    layers=[x['layer'] for x in u]
    ax[0,0].plot(layers,[100*x['T2_over_V'] for x in u],color=color,label=f'{expert}: full FFN')
    ax[0,0].plot(layers,[100*x['Dtail2_over_Dvar'] for x in u],color=color,ls='--',label=f'{expert}: matched diagonal')
    ax[0,1].plot(layers,[x['V_over_Dvar'] for x in u],color=color,label=f'{expert}: variance / diagonal')
    ax[0,1].plot(layers,[x['T2_over_Dtail2'] for x in u],color=color,ls='--',label=f'{expert}: tail / diagonal')
    c=sorted([x for x in j['candidate_comparisons'] if x['expert']==expert and x['arm']=='Oq' and x['geometry']=='OWN'],key=lambda x:x['layer'])
    ax[1,1].plot([x['layer'] for x in c],[100*x['diag_plus_edge_capture_over_E2'] for x in c],marker='o',color=color,label=f'{expert}: squares + edges')
    ax[1,1].plot([x['layer'] for x in c],[100*x['diag_capture_over_E2'] for x in c],marker='.',color=color,ls='--',label=f'{expert}: squares only')
u=[x for x in j['units'] if x['arm']=='Oq']
rat=np.array([np.array(x['E_q_1_to_8'])/np.array(x['D_q_1_to_8']) for x in u])
sign=np.array([np.mean(x['sign_energy_4_by_8'],axis=0)/np.array(x['D_q_1_to_8']) for x in u])
q=np.arange(1,9)
ax[1,0].fill_between(q,np.quantile(rat,.1,axis=0),np.quantile(rat,.9,axis=0),color='#135ca5',alpha=.16,label='Oq layer p10–p90')
ax[1,0].plot(q,np.median(rat,axis=0),'o-',color='#135ca5',label='Oq layer median')
ax[1,0].plot(q,np.median(sign,axis=0),'s--',color='#777777',label='4 sign controls: mean, then layer median')
ax[0,0].set(title='A  Matched scalar baseline differs from full FFN',xlabel='Layer',ylabel='Quadratic tail / centered variance (%)',ylim=(0,3.7))
ax[0,1].set(title='B  Small relative tail comes mainly from variance gain',xlabel='Layer',ylabel='Energy ratio',yscale='log',ylim=(.9,14))
ax[1,0].set(title='C  Cross-neuron enhancement decays with degree',xlabel='Hermite degree q',ylabel='E_q / D_q',ylim=(.95,float(np.quantile(rat,.9,axis=0).max())*1.06),xticks=q)
ax[1,1].set(title='D  Direct capture of fixed S3 quadratic candidates',xlabel='Presampled layer',ylabel='Captured full quadratic energy (%)',ylim=(0,50))
for a in ax.flat:
    a.grid(alpha=.2)
    a.legend(fontsize=8,frameon=False)
fig.suptitle('G19 v7 origin evidence · all 80 Oq expert/layer units · Gaussian reference',fontsize=14)
fig.savefig(root/'origin_evidence.png',dpi=180)
fig.savefig(root/'origin_evidence.svg')
print(root/'origin_evidence.png')
