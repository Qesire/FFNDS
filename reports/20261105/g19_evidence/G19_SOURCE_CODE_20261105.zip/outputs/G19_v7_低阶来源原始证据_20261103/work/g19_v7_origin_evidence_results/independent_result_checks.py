"""Independent local receipt/NPZ arithmetic audit. Never imports author analysis."""
import csv, hashlib, json, math, statistics, re
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent; STAGE=HERE.parent/'g19_v7_origin_evidence_r1'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def lines(p):return [json.loads(t) for t in p.read_text(encoding='utf-8-sig').splitlines() if t.strip()]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def eq(a,b,rel=2e-11,absolute=1e-13):
 assert math.isfinite(a) and math.isfinite(b) and math.isclose(a,b,rel_tol=rel,abs_tol=absolute),(a,b)
def total(x):return float(np.sum(x,dtype=np.longdouble))
def qs(x):
 x=sorted(float(v) for v in x);n=len(x)
 return {str(q):x[int((n-1)*q)]+((n-1)*q-int((n-1)*q))*(x[min(int((n-1)*q)+1,n-1)]-x[int((n-1)*q)]) for q in (.1,.5,.9)}
def weighted_q(x,w):
 sel=np.isfinite(x)&(w>0);pairs=sorted(zip(x[sel].tolist(),w[sel].tolist()));s=math.fsum(y for _,y in pairs)
 if not s:return None
 ans={};partial=0.;qiter=iter((.1,.5,.9));q=next(qiter)
 for val,weight in pairs:
  partial+=weight
  while partial>=q*s:
   ans[str(q)]=float(val)
   try:q=next(qiter)
   except StopIteration:return ans
 raise AssertionError('quantile accumulation')
def summary(x):return {'n':len(x),'min':min(x),'median':statistics.median(x),'max':max(x)}
assert sha(HERE/'analyze_origin.py')=='0b6e0f23ac53b71da3a6b24e00553308d5b1cb6f7cd961f416bafb960e3b7ab1'
published=read(HERE/'analysis.json'); pu={(x['expert'],x['layer'],x['arm']):x for x in published['units']};pc={(x['expert'],x['layer'],x['arm'],x['geometry']):x for x in published['candidate_comparisons']}
assert len(pu)==160 and len(pc)==72
evidence={};out=[];cout=[];maxima={k:0. for k in ('GH_weighted_Dvar','GH_weighted_Dtail2','GH_weighted_Dtail4','zero_bias_odd_energy_fraction','A1_reproduction','candidate_coefficient_relative','candidate_geometry','GPU_peak_GiB')};npz_hash={};negative_count=0
old={}
with (HERE.parent/'g19_v7_formal_s3_results/s3_structure_units.csv').open(encoding='utf-8-sig',newline='') as f:
 for x in csv.DictReader(f):
  if x['candidate'] in ('EDGE_FULL_RJD','EDGE_FULL_RJD_OQ_SHARED'):old[x['expert'],int(x['layer']),x['arm'],'OQ_SHARED' if x['candidate'].endswith('_OQ_SHARED') else 'OWN']=x
for expert in ('high','low'):
 folder=HERE/expert;stage=STAGE/expert;scope=read(stage/'scope.json');start=read(folder/'START.json');end=read(folder/'EXIT.json')
 assert sha(stage/'scope.json')==published['scope_sha256'][expert]==start['scope']['_verified_scope_sha256']
 for name,digest in {**scope['code_sha256'],**scope['frozen_inputs_sha256'],scope['config_file']:scope['config_sha256'],scope['input_manifest_file']:scope['manifest_sha256']}.items():assert sha(stage/name)==digest
 assert end['status']=='SUCCESS' and end['exception'] is None and end['result']['status']=='ORIGIN_EVIDENCE_COMPLETE_NUMERICS_UNASSESSED'
 assert end['result']['completed_layers']==list(range(40)) and len(end['result']['completed_units'])==80
 job=str(start['allocation']['job_id']);slurm=[x for x in (HERE/'SLURM_FINAL.txt').read_text().splitlines() if re.search(r'\bJobId='+job+r'\b',x)]
 assert len(slurm)==1 and 'JobState=COMPLETED' in slurm[0] and 'ExitCode=0:0' in slurm[0]
 wr=lines(folder/'weights.jsonl');expected=read(stage/'expected_tensor_hashes.json');assert len(wr)==len({(x['model'],x['key']) for x in wr})==320
 for x in wr:assert x['identity_status']=='PRECOMMITTED_HASH_MATCH' and x['sha256']==expected[f"{expert}/{x['model']}/{x['key']}"]
 units=lines(folder/'units.jsonl');um={(x['layer'],x['arm']):x for x in units};assert len(units)==len(um)==80
 arts=lines(folder/'artifacts.jsonl');am={(x['layer'],x['arm']):x for x in arts};assert len(arts)==len(am)==len(list(folder.glob('*.npz')))==80
 source=read(stage/'s12_summary.json');a1assets=read(stage/'assets.json');candassets=read(stage/'s3_candidates.json')
 for layer in range(40):
  identity=json.dumps([2026110301,'DEVELOPMENT',expert,layer,800],separators=(',',':')).encode();entropy=np.frombuffer(hashlib.sha256(identity).digest(),dtype='<u4').tolist();gen=np.random.Generator(np.random.PCG64(np.random.SeedSequence(entropy)))
  bits=gen.integers(0,2,size=(13824,4),dtype=np.int8)*2-1;signhash=hashlib.sha256(bits.tobytes()).hexdigest()
  for arm in ('Oq','Dq'):
   r=um[layer,arm];pr=pu[expert,layer,arm];assert r['expert']==expert and r['sign_bits_sha256']==signhash
   art=am[layer,arm];p=folder/art['path'];h=sha(p);assert h==art['sha256']==pr['npz_sha256'];npz_hash[expert+'/'+art['path']]=h
   with np.load(p,allow_pickle=False) as f:a={k:f[k] for k in f.files}
   assert all(np.isfinite(v).all() for v in a.values());s=a['sigma'];b=a['bias'];v=a['v_norm_sq'];assert s.shape==b.shape==v.shape==(13824,) and a['a'].shape==(13824,9)
   z=s==0;assert np.all(s>=0) and np.all(v>=0)
   for suffix in ('','_192','_zero_bias','_zero_bias_192'):
    ak='a'+suffix;assert np.all(a[ak][z,1:]==0)
    for pre in ('variance','tail2','tail4'):assert np.all(a[pre+suffix]>=0) and np.all(a[pre+suffix][z]==0)
   d=np.asarray([total(v*a['a'][:,q]**2) for q in range(1,9)]);E=np.array(r['E_q_1_to_8']);sign=np.array(r['sign_flip_E_q_1_to_8']);assert E.shape==(8,) and sign.shape==(4,8)
   for actual,want in zip(r['D_q_1_to_8'],d):eq(actual,want)
   np.testing.assert_allclose(r['signed_cross_E_minus_D'],E-d,rtol=1e-8,atol=2e-9)
   assert np.all(E>=-(1e-12+1e-9*d)) and np.all(sign>=-(1e-12+1e-9*d)[None,:]);negative_count+=int((E<0).sum())+int((sign<0).sum())
   dv,t2,t4=(total(v*a[k]) for k in ('variance','tail2','tail4'));dv0,t20,t40=(total(v*a[k]) for k in ('variance_zero_bias','tail2_zero_bias','tail4_zero_bias'))
   for key,val in [('Dvar',dv),('Dtail2',t2),('Dtail4',t4)]:eq(r[key],val);eq(pr[key],val)
   for key,val in [('Dvar',dv0),('Dtail2',t20),('Dtail4',t40)]:eq(r['zero_bias_counterfactual'][key],val)
   obs=source[f'{expert}/{layer}/{arm}'];assert r['s12_input']==obs;V,T2,T4=obs['V'],obs['T2'],obs['T4']
   factors={'T2_over_V':T2/V,'T4_over_V':T4/V,'Dtail2_over_Dvar':t2/dv,'Dtail4_over_Dvar':t4/dv,'T2_over_Dtail2':T2/t2,'T4_over_Dtail4':T4/t4,'V_over_Dvar':V/dv,'relative_tail2_ratio':(T2/t2)/(V/dv),'relative_tail4_ratio':(T4/t4)/(V/dv),'Dtail2_over_Dvar_zero_bias':t20/dv0,'Dtail4_over_Dvar_zero_bias':t40/dv0}
   for k,val in factors.items():eq(pr[k],val)
   rawbs=np.divide(b,s,out=np.full_like(b,np.nan),where=~z)
   qchecks={'sigma_quantiles':qs(s),'bias_over_sigma_quantiles_nonzero_sigma':qs(rawbs[np.isfinite(rawbs)]),'sigma_weighted_by_diagonal_variance':weighted_q(s,v*a['variance']),'bias_over_sigma_weighted_by_diagonal_variance':weighted_q(rawbs,v*a['variance']),'sigma_weighted_by_diagonal_tail2':weighted_q(s,v*a['tail2']),'sigma_weighted_by_diagonal_q2':weighted_q(s,v*a['a'][:,2]**2)}
   for k,vals in qchecks.items():
    for q,val in vals.items():eq(pr[k][q],val)
   lin=r['linear_shortcut'];eq(E[0],lin['A1_fro_sq']);eq(lin['A1_fro_sq'],lin['L0_fro_sq']+lin['A1_minus_L0_fro_sq']+lin['twice_inner_L0_delta'])
   flip=r['bias_sign_flip_counterfactual'];eq(flip['E1_flip'],lin['L0_fro_sq']+lin['A1_minus_L0_fro_sq']-lin['twice_inner_L0_delta']);eq(flip['Vflip_est_signed'],V-E[0]+flip['E1_flip'])
   assert r['A1_vs_S12']['s12_asset_sha256']==a1assets[f'{expert}/{layer}/{arm}']['sha256'];maxima['A1_reproduction']=max(maxima['A1_reproduction'],r['A1_vs_S12']['relative_fro'])
   rad=r['E2_radial'];assert math.isfinite(rad) and 0<=rad<=E[1]+1e-8;eq(r['E2_gaussian'],E[1]);eq(r['E2_fixed_F2_sphere'],5119/5121*(E[1]-rad));eq(pr['radial_over_E2'],rad/E[1])
   for src,key,target in [('variance','weighted_Dvar','GH_weighted_Dvar'),('tail2','weighted_Dtail2','GH_weighted_Dtail2'),('tail4','weighted_Dtail4','GH_weighted_Dtail4')]:
    val=abs(total(v*a[src])-total(v*a[src+'_192']))/max(total(v*a[src]),1e-300);eq(r['quadrature_relative_384_vs_192'][key],val,rel=1e-3,absolute=2e-14);maxima[target]=max(maxima[target],val)
   oddzero=total(v*np.sum(a['a_zero_bias'][:,[3,5,7]]**2,axis=1))/dv0;maxima['zero_bias_odd_energy_fraction']=max(maxima['zero_bias_odd_energy_fraction'],oddzero)
   maxima['GPU_peak_GiB']=max(maxima['GPU_peak_GiB'],r['gpu_peak_allocated_bytes']/1024**3)
   record={'expert':expert,'layer':layer,'arm':arm,**factors,'E1_over_D1':E[0]/d[0],'E2_over_D2':E[1]/d[1],'E4_over_D4':E[3]/d[3],'E6_over_D6':E[5]/d[5],'E8_over_D8':E[7]/d[7],'radial_over_E2':rad/E[1],'sphere_F2_over_gaussian_F2':r['E2_fixed_F2_sphere']/E[1],'A1_minus_L0_fro_over_L0_fro':math.sqrt(lin['A1_minus_L0_fro_sq']/lin['L0_fro_sq']),'E1_flip_over_E1':flip['E1_flip']/E[0],'sigma_weighted_median':qchecks['sigma_weighted_by_diagonal_variance']['0.5'],'E1_exceeds_all4_signs':bool(E[0]>max(sign[:,0])),'E2_exceeds_all4_signs':bool(E[1]>max(sign[:,1])),'q1to8_over_V':float(E.sum()/V),'q3to8_over_T2':float(E[2:].sum()/T2),'zero_sigma_count':int(z.sum())}
   out.append(record)
 cr=lines(folder/'candidates.jsonl');assert len(cr)==36
 for r in cr:
  i,arm,geometry=r['layer'],r['arm'],r['geometry'];E2=um[i,arm]['E2_gaussian'];norm=r['diag_energy']+r['edge_energy'];cross=r['true_cross'];res=E2+norm-2*cross;pr=pc[expert,i,arm,geometry]
  assert r['candidate_sha256']==candassets[f'{expert}/{i}/{arm}'][geometry]['sha256'];eq(r['E2_input'],E2);eq(r['candidate_norm2'],norm);eq(r['frobenius_residual_raw'],res);eq(r['diag_capture_over_E2'],r['diag_energy']/E2);eq(r['diag_plus_edge_capture_over_E2'],norm/E2);eq(r['frobenius_residual_over_E2_raw'],res/E2);eq(cross,norm)
  assert res>=0 and norm<=E2 and pr['numeric_flag']=='NUMERICS_UNASSESSED'
  maxima['candidate_coefficient_relative']=max(maxima['candidate_coefficient_relative'],r['C_relative_error'],r['E_relative_error']);maxima['candidate_geometry']=max(maxima['candidate_geometry'],r['basis_orthogonality_max_abs'],r['basis_support_sum_over_sqrt_d_max_abs'],r['p_support_sum_over_sqrt_d_max_abs'])
  op=old[expert,i,arm,geometry];eq(pr['old_16probe_residual_mean'],float(op['operator_frob_probe_mean']));eq(pr['old_16probe_over_s3_q2_energy'],float(op['operator_over_Q2_energy']))
  cout.append({'expert':expert,'layer':i,'arm':arm,'geometry':geometry,'diagonal_capture':r['diag_energy']/E2,'edge_capture':r['edge_energy']/E2,'total_capture':norm/E2,'residual_ratio':res/E2,'old_probe_relative_error':float(op['operator_frob_probe_mean'])/res-1,'old_Q2_energy_relative_error':float(op['q2_energy_mean'])/E2-1})
 files=('START.json','EXIT.json','environment.jsonl','layers.jsonl','units.jsonl','weights.jsonl','artifacts.jsonl','candidates.jsonl');recordsha={f:sha(folder/f) for f in files};assert recordsha==published['evidence'][expert]['source_sha256']
 evidence[expert]={'job_id':job,'elapsed_seconds':end['elapsed_seconds'],'RSS_GiB':end['process_peak_rss_bytes']/1024**3,'scope_sha256':sha(stage/'scope.json'),'receipts_sha256':recordsha}
assert len(npz_hash)==160 and len(out)==160 and len(cout)==72
metrics=tuple(k for k in out[0] if k not in ('expert','layer','arm','E1_exceeds_all4_signs','E2_exceeds_all4_signs','zero_sigma_count'))
groups={}
for label,data in [('all/Oq',[r for r in out if r['arm']=='Oq']),('all/Dq',[r for r in out if r['arm']=='Dq']),('high/Oq',[r for r in out if r['expert']=='high' and r['arm']=='Oq']),('low/Oq',[r for r in out if r['expert']=='low' and r['arm']=='Oq'])]:groups[label]={k:summary([r[k] for r in data]) for k in metrics}
cgroups={}
for label,data in [('own48',[r for r in cout if r['geometry']=='OWN']),('shared24',[r for r in cout if r['geometry']=='OQ_SHARED'])]:cgroups[label]={k:summary([r[k] for r in data]) for k in ('diagonal_capture','edge_capture','total_capture','residual_ratio','old_probe_relative_error','old_Q2_energy_relative_error')}
report={'status':'INDEPENDENT_LOCAL_REAGGREGATION_PASS','counts':{'npz':160,'units':160,'candidates':72,'weight_receipts':640,'A1_checks':160,'negative_E_or_sign_values':negative_count,'sigma_zero_total':sum(r['zero_sigma_count'] for r in out),'E1_exceeds_all4_signs':sum(r['E1_exceeds_all4_signs'] for r in out),'E2_exceeds_all4_signs':sum(r['E2_exceeds_all4_signs'] for r in out)},'diagnostic_maxima':maxima,'groups':groups,'candidate_groups':cgroups,'units':out,'candidate_units':cout,'evidence':evidence,'npz_sha256':npz_hash,'limitations':['No local raw weight or real candidate tensor re-execution; E_q and radial are checked as compute-node contractions and identities.','S12 reused MC and FP64/GH diagnostics remain unassessed numerically; no new confirmation.','Four sign draws are paired counterfactual examples, not a trained-versus-untrained causal test.']}
(HERE/'INDEPENDENT_RESULT_CHECKS.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps({'counts':report['counts'],'diagnostic_maxima':maxima,'Oq':groups['all/Oq'],'candidate_groups':cgroups},indent=2))
