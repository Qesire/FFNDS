from pathlib import Path
import json, numpy as np
P=Path(__file__).resolve().parent
u=json.loads((P/'analysis.json').read_text(encoding='utf8'))['units']; units={(x['expert'],x['layer'],x['arm']):x for x in u};assert len(units)==160
q=lambda x: [float(v) for v in np.quantile(np.array(x,dtype=float),[0,.5,1])]
def wq(x,w):
 i=np.argsort(x);x=x[i];w=w[i];return [float(x[min(np.searchsorted(np.cumsum(w),t*w.sum()),len(x)-1)]) for t in (.1,.5,.9)]
out={}
for e in ('high','low'):
 for arm in ('Oq','Dq'):
  key=e+'/'+arm; a=[units[e,i,arm] for i in range(40)]; arr=[np.load(P/e/f'{e}_{i:02}_{arm}_neurons.npz') for i in range(40)]
  sig=np.concatenate([n['sigma'] for n in arr]);b=np.concatenate([n['bias'] for n in arr]);w=np.concatenate([n['v_norm_sq']*n['variance'] for n in arr]);t=np.concatenate([n['v_norm_sq']*n['tail2'] for n in arr]); m=sig>0; absbs=np.abs(b[m]/sig[m]);
  odd=[sum(x['E_q_1_to_8'][i] for i in (2,4,6))/x['T2_s12'] for x in a]; flip=[x['E1_flip_over_E1'] for x in a]; den=[x['Vflip_est_signed']/x['V_s12'] for x in a]
  out[key]={'sigma_unweighted_p10_p50_p90':list(map(float,np.quantile(sig,[.1,.5,.9]))),'sigma_var_weighted_p10_p50_p90':wq(sig,w),'sigma_tail2_weighted_p10_p50_p90':wq(sig,t),'abs_bias_over_sigma_var_weighted_p10_p50_p90':wq(absbs,w[m]),'A1_L0_min_median_max':q([x['A1_minus_L0_fro_over_L0_fro'] for x in a]),'odd3_5_7_over_T2_min_median_max':q(odd),'odd3_5_7_share_E3_to_E8_min_median_max':q([sum(x['E_q_1_to_8'][i] for i in (2,4,6))/sum(x['E_q_1_to_8'][2:8]) for x in a]),'flip_E1_ratio_min_median_max':q(flip),'flip_V_est_over_V_min_median_max':q(den),'zero_bias_minus_actual_Dtail2_fraction_min_median_max':q([x['Dtail2_over_Dvar_zero_bias']-x['Dtail2_over_Dvar'] for x in a]),'Q2_T_over_V_min_median_max':q([x['T2_over_V'] for x in a]),'Q4_T_over_V_min_median_max':q([x['T4_over_V'] for x in a])}
 for i in range(40):arr[i].close()
 paired=[(units[e,i,'Oq'],units[e,i,'Dq']) for i in range(40)]
 out[e+'/paired']={k:{'min_median_max':q([b[k]-a[k] for a,b in paired]),'D_greater_count':sum(b[k]>a[k] for a,b in paired)} for k in ('T2_over_V','T4_over_V','Dtail2_over_Dvar','A1_minus_L0_fro_over_L0_fro','E1_flip_over_E1')}
(P/'ORIGIN_PAIRED_NUMBERS.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps(out,ensure_ascii=False,indent=2))
