import json
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parent
j=json.loads((ROOT/'analysis.json').read_text())
def stats(x):
    x=np.asarray(x,dtype=float)
    return dict(zip(('min','p10','median','p90','max'),map(float,np.quantile(x,[0,.1,.5,.9,1]))))
fields=['T2_over_V','T4_over_V','Dtail2_over_Dvar','Dtail4_over_Dvar','T2_over_Dtail2','T4_over_Dtail4','V_over_Dvar','relative_tail2_ratio','E1_over_D1','E2_over_D2','E3_over_D3','E4_over_D4','E6_over_D6','E8_over_D8','radial_over_E2','sphere_F2_over_gaussian_F2','A1_minus_L0_fro_over_L0_fro','E1_flip_over_E1','Dtail2_over_Dvar_zero_bias']
out={}
for label,pred in [('all/Oq',lambda u:u['arm']=='Oq'),('all/Dq',lambda u:u['arm']=='Dq'),('high/Oq',lambda u:u['expert']=='high' and u['arm']=='Oq'),('low/Oq',lambda u:u['expert']=='low' and u['arm']=='Oq')]:
    units=[u for u in j['units'] if pred(u)]
    result={k:stats([u[k] for u in units]) for k in fields}
    result['tail2_above_diagonal_count']=sum(u['T2_over_Dtail2']>1 for u in units)
    result['tail4_above_diagonal_count']=sum(u['T4_over_Dtail4']>1 for u in units)
    for q in range(1,9):
        result[f'original_over_mean_4sign_q{q}']=stats([u['E_q_1_to_8'][q-1]/np.asarray(u['sign_energy_4_by_8'])[:,q-1].mean() for u in units])
        result[f'mean_4sign_over_D_q{q}']=stats([np.asarray(u['sign_energy_4_by_8'])[:,q-1].mean()/u['D_q_1_to_8'][q-1] for u in units])
    for key in ['sigma_quantiles','sigma_weighted_by_diagonal_variance','bias_over_sigma_quantiles_nonzero_sigma','bias_over_sigma_weighted_by_diagonal_variance']:
        result[key+'_unit_medians']=stats([u[key]['0.5'] for u in units])
    result['known_q3to8_over_T2']=stats([sum(u['E_q_1_to_8'][2:])/u['T2_s12'] for u in units])
    result['known_odd_q3q5q7_over_T2']=stats([sum(u['E_q_1_to_8'][q-1] for q in [3,5,7])/u['T2_s12'] for u in units])
    result['quadrature_weighted_Dvar_rel']=stats([u['quadrature_384_192']['weighted_Dvar'] for u in units])
    result['quadrature_weighted_Dtail2_rel']=stats([u['quadrature_384_192']['weighted_Dtail2'] for u in units])
    result['quadrature_weighted_Dtail4_rel']=stats([u['quadrature_384_192']['weighted_Dtail4'] for u in units])
    out[label]=result
out['candidates']={}
for label,pred in [('own',lambda c:c['geometry']=='OWN'),('own_Oq',lambda c:c['geometry']=='OWN' and c['arm']=='Oq'),('own_Dq',lambda c:c['geometry']=='OWN' and c['arm']=='Dq'),('shared_Dq',lambda c:c['geometry']=='OQ_SHARED')]:
    cc=[c for c in j['candidate_comparisons'] if pred(c)]
    out['candidates'][label]={k:stats([c[k] for c in cc]) for k in ['diag_capture_over_E2','diag_plus_edge_capture_over_E2','residual_over_E2','old_16probe_over_s3_q2_energy']}
    out['candidates'][label]['old_probe_relative_to_direct_residual']=stats([c['old_16probe_residual_mean']/c['residual_frobenius_raw'] for c in cc])
out['all_units']={'zero_sigma_total':sum(u['sigma_zero_count'] for u in j['units'])}
(ROOT/'findings_stats.json').write_text(json.dumps(out,indent=2)+'\n')
for group in ['all/Oq','all/Dq','high/Oq','low/Oq']:
    print(group)
    for k in fields:
        s=out[group][k]; print(f'{k}: median={s["median"]:.9g} range=[{s["min"]:.9g}, {s["max"]:.9g}]')
    print('tail2 above diagonal',out[group]['tail2_above_diagonal_count'])
print('CANDIDATES',json.dumps(out['candidates'],indent=2))
