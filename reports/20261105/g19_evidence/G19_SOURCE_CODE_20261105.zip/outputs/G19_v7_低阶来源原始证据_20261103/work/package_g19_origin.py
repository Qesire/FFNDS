from pathlib import Path
import hashlib,json,shutil,zipfile
from datetime import datetime,timezone

root=Path(__file__).resolve().parent.parent
name='G19_v7_低阶来源原始证据_20261103'
dest=root/'outputs'/name
source=root/'work/g19_v7_origin_evidence_r1'
results=root/'work/g19_v7_origin_evidence_results'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(4*1024**2),b''):h.update(b)
    return h.hexdigest()
def copy(p):
    target=dest/p.relative_to(root)
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(p,target)

assert (dest/'FINAL_REPORT_REVIEW.txt').is_file(),'Wait for final independent report review'
assert sha(dest/'G19_v7_低阶来源与表示选择_新证据报告.md')=='5c86b990dde3dcd36350afddc7a04182e910d2d40e76c81506ef831208b45580'
for folder in (source,results):
    for p in sorted(folder.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.npz':copy(p)
copy(Path(__file__).resolve())
for expert in ('high','low'):
    for fname in ('blocks.jsonl','EXIT.json','START.json','environment.jsonl','units.jsonl','weights.jsonl','artifacts.jsonl'):
        copy(root/'work/g19_v7_formal_s12_results'/expert/fname)
copy(root/'work/g19_v7_formal_s3_results/s3_structure_units.csv')
for fname in ('origin_evidence.png','origin_evidence.svg'):
    shutil.copy2(results/fname,dest/fname)

completion={'state':'COMPLETED_NO_RETRY_AUTHORIZATION','date':'2026-11-03','jobs':{'128628':{'expert':'high','node':'anode23','slurm_state':'COMPLETED','exit_code':'0:0','allocated_seconds':518},'128629':{'expert':'low','node':'anode21','slurm_state':'COMPLETED','exit_code':'0:0','allocated_seconds':467}},'scope_runs_used':2,'scope_runs_remaining':0,'function_units':160,'raw_tensor_SHA_receipts':640,'saved_A1_checks':160,'saved_candidate_checks':72,'numeric_status':'UNASSESSED','native_tensor_experiment':'NOT_RUN','independent_result_review_sha256':sha(results/'INDEPENDENT_RESULT_REVIEW.txt'),'final_report_review_sha256':sha(dest/'FINAL_REPORT_REVIEW.txt'),'analysis_sha256':sha(results/'analysis.json'),'frozen_active_note':'Historical ACTIVE files are preserved as prelaunch registration; both one-job allocations are consumed.'}
(dest/'COMPLETION.json').write_text(json.dumps(completion,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
readme='''交付与复算说明

本目录主报告给出理论、原始证据与新的研究方案。origin_evidence.png/svg 为全层结果图。

两个 ZIP 解压到同一父目录后，会合并到同名 G19_v7_低阶来源原始证据_20261103 目录：
1. 证据包：报告、图、全部本次源码/冻结scope/登记/日志/独立审查、完整结果JSON/CSV、所用S12原始块和S3候选汇总、native资产定位。无需逐神经元数组即可阅读。
2. 逐神经元数组包：160份计算节点产生且本地独立SHA核验的NPZ（847,033,098字节）。这些是由真实权重派生的系数和边际统计，不是模型权重本身。

所有大权重、A1矩阵与S3候选矩阵留在学校服务器。具体路径与哈希在work/g19_v7_origin_evidence_r1/input_manifest.json、assets.json、s3_candidates.json和各运行receipt中。
不含私钥、凭据或依赖安装目录。旧ACTIVE保持调度前历史身份；本次两项作业均已消费，状态以COMPLETION.json和实际EXIT/Slurm为准。

本地复算（Python3.12、NumPy2.5.4已实测；绘图另需Matplotlib）：
  python work/g19_v7_origin_evidence_results/analyze_origin.py
  python work/g19_v7_origin_evidence_results/summarize_findings.py
  python work/g19_v7_origin_evidence_results/independent_result_checks.py
  python work/g19_v7_origin_evidence_results/interpret_origin.py
  python work/g19_v7_origin_evidence_results/plot_findings.py
这些命令不连接服务器，也不重新运行模型；需要先把数组包合并解压。不要运行调度脚本来复算本地汇总。

独立本地重聚合可核对边际Dq、Dvar、Dtail、分位数及receipt恒等式；无法仅凭这些NPZ重建跨通道E_q、球面迹向量或候选矩阵。后者来自已登记计算节点对原始权重和已存张量的FP64收缩，数值证书尚未建立。

旧正式实验完整包仍保存在 outputs/G19_v7_正式实验_20261102.zip，SHA256=32e8b8f21377cfde12f57e06cddc2f795007b0e35da30c319aa06c13475e3d15。这里仅带入本轮使用的S12/S3材料，未把旧实验重新表述为新运行。
'''
(dest/'REPRODUCE.txt').write_text(readme,encoding='utf8')
raw=sorted(p for e in ('high','low') for p in (results/e).glob('*.npz'))
assert len(raw)==160 and sum(p.stat().st_size for p in raw)==847033098
files=[p for p in dest.rglob('*') if p.is_file() and p.name!='DELIVERY_MANIFEST.json']
manifest={'created_utc':datetime.now(timezone.utc).isoformat(),'metadata_files':[{'path':p.relative_to(dest).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)],'array_files':[{'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in raw]}
(dest/'DELIVERY_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
archives=[]
for label,paths,compression in [('证据包',sorted(p for p in dest.rglob('*') if p.is_file()),zipfile.ZIP_DEFLATED),('逐神经元数组包',raw,zipfile.ZIP_STORED)]:
    zp=root/'outputs'/f'G19_v7_低阶来源_{label}_20261103.zip'
    with zipfile.ZipFile(zp,'x',compression=compression,allowZip64=True) as z:
        for p in paths:
            rel=p.relative_to(dest) if p.is_relative_to(dest) else p.relative_to(root)
            z.write(p,arcname=(Path(name)/rel).as_posix())
    with zipfile.ZipFile(zp) as z:assert z.testzip() is None
    archives.append({'path':str(zp),'bytes':zp.stat().st_size,'sha256':sha(zp),'files':len(paths),'crc_check':'PASS'})
receipt={'status':'COMPLETE','report':str(dest/'G19_v7_低阶来源与表示选择_新证据报告.md'),'archives':archives,'counts':completion}
(root/'outputs/G19_v7_低阶来源_交付清单_20261103.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(receipt,ensure_ascii=False,indent=2))
