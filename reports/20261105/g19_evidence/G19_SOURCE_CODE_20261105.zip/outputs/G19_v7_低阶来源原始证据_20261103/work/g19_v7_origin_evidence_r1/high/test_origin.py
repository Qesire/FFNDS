import itertools,math,unittest,sys,types
from unittest.mock import patch
import numpy as np
from origin_math import scalar_quadrature,block_energies,sphere_q2,matched_ratios,check_energy_nonnegative,check_a1_consistency

class TestOrigin(unittest.TestCase):
 def test_quadrature_zero_bias_odd_and_zero_scale(self):
  s=np.array([0.,1.,2.]); result=scalar_quadrature(s,np.zeros(3),192)
  np.testing.assert_allclose(result['a'][0,1:],0,atol=0); np.testing.assert_allclose(result['a'][:,1],s/2,atol=1e-13)
  np.testing.assert_allclose(result['a'][:,[3,5,7]],0,atol=1e-13)
  self.assertEqual(result['var'][0],0); self.assertGreater(result['tail2'][1],0)
 def test_gram_q2_and_sign_expectation(self):
  rng=np.random.default_rng(2); p=rng.normal(size=(4,5)); p/=np.linalg.norm(p,axis=1)[:,None]; V=rng.normal(size=(4,3)); a=rng.normal(size=(4,9));
  patterns=np.array(list(itertools.product([-1.,1.],repeat=4))); collected=[]
  for group in np.array_split(patterns,4):
   signs=np.column_stack((np.ones(4),group.T)); energies=sum((block_energies(p,V,a,signs,start,min(start+2,4),np) for start in range(0,4,2)))
   explicit=np.sum((V@V.T)*np.outer(a[:,2],a[:,2])*(p@p.T)**2)
   self.assertAlmostEqual(energies[1,0],explicit,places=10); collected.extend(energies[1,1:].tolist())
  diagonal=np.sum((V*V).sum(1)*a[:,2]**2)
  self.assertAlmostEqual(np.mean(collected),diagonal,places=10)
 def test_sphere_radial_and_directional(self):
  n=4; self.assertAlmostEqual(sphere_q2(1.,1/n,n),(n-1)/(n+2)); self.assertAlmostEqual(sphere_q2(1.,1.,n),0.)
  with self.assertRaises(ValueError): sphere_q2(1.,2.,n)
  rng=np.random.default_rng(3); v=rng.normal(size=(200000,n)); v*=math.sqrt(n)/np.linalg.norm(v,axis=1)[:,None]
  empirical=np.mean(((v[:,0]**2-1)/math.sqrt(2))**2)
  self.assertAlmostEqual(empirical,sphere_q2(1.,1/n,n),delta=.01)
 def test_ratios_are_distinct(self):
  x=matched_ratios(10.,2.,1.,20.,8.,2.); self.assertAlmostEqual(x['T2_over_Dtail2'],.25); self.assertAlmostEqual(x['relative_tail_ratio2'],.5); self.assertAlmostEqual(x['V_over_Dvar'],.5)
  self.assertIsNone(matched_ratios(0,0,0,0,0,0)['relative_tail_ratio2'])
 def test_bias_sign_flip_coefficients(self):
  sigma=np.array([.3,1.,2.]); bias=np.array([.1,-.7,1.3]); plus=scalar_quadrature(sigma,bias,192)['a']; minus=scalar_quadrature(sigma,-bias,192)['a']
  np.testing.assert_allclose(minus[:,1],sigma-plus[:,1],rtol=1e-12,atol=1e-13)
  for q in range(2,9): np.testing.assert_allclose(minus[:,q],(-1)**q*plus[:,q],rtol=1e-10,atol=1e-13)
 def test_guard_precedes_real_access(self):
  import runner_origin
  guard=types.ModuleType('runtime_guard')
  def deny(): raise RuntimeError('SYNTHETIC_LOGIN_REJECTED')
  guard.require_compute_allocation=deny; guard.verify_frozen_scope=lambda *args: self.fail('guard must run first'); guard.RunReceipt=object
  with patch.dict(sys.modules,{'runtime_guard':guard}), patch.object(sys,'argv',['runner_origin.py','--scope','fixture','--scope-sha','0'*64]):
   with self.assertRaisesRegex(RuntimeError,'SYNTHETIC_LOGIN_REJECTED'): runner_origin.main()
 def test_energy_and_a1_fail_gates(self):
  E=np.ones((8,5)); D=np.ones(8); E[2,1]=-1e-10
  check_energy_nonnegative(E,D); E[2,1]=-1e-3
  with self.assertRaises(ValueError): check_energy_nonnegative(E,D)
  self.assertEqual(check_a1_consistency(0.,1.,1.,1.),0.)
  with self.assertRaises(ValueError): check_a1_consistency(1e-10,1.,1.,1.)
  with self.assertRaises(ValueError): check_a1_consistency(0.,1.,1.01,1.)
 def test_fixed_candidate_coverage(self):
  from runner_origin import candidate_geometries
  c={'high/0/Oq':{'OWN':{'sha256':'a'}},'high/0/Dq':{'OWN':{'sha256':'b'},'OQ_SHARED':{'sha256':'c'}}}
  self.assertEqual([x[0] for x in candidate_geometries(c,'high',0,'Oq')],['OWN'])
  self.assertEqual([x[0] for x in candidate_geometries(c,'high',0,'Dq')],['OWN','OQ_SHARED'])
  self.assertEqual(candidate_geometries(c,'high',2,'Oq'),())
  del c['high/0/Dq']['OQ_SHARED']
  with self.assertRaises(ValueError): candidate_geometries(c,'high',0,'Dq')

if __name__=='__main__': unittest.main()
