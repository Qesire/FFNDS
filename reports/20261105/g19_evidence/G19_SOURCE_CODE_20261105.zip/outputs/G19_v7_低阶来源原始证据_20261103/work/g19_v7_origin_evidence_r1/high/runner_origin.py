"""Compute-node-only origin evidence. No FFN Monte Carlo and no auto-submit."""
import argparse,hashlib,json,math,re,time
from pathlib import Path
import numpy as np
from origin_math import scalar_quadrature,block_energies,sphere_q2,matched_ratios,check_energy_nonnegative,check_a1_consistency

SELECTED_LAYERS=(0,1,7,12,13,19,23,24,28,33,37,38)


def candidate_geometries(candidates,expert,layer,label):
    if layer not in SELECTED_LAYERS: return ()
    entry=candidates[f'{expert}/{layer}/{label}']; expected=('OWN',) if label=='Oq' else ('OWN','OQ_SHARED')
    if set(entry)!=set(expected): raise ValueError('incomplete frozen candidate set')
    return tuple((name,entry[name]) for name in expected)


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()


def frozen_json(root,scope,name):
    if not isinstance(name,str) or name not in scope.get('frozen_inputs_sha256',{}): raise ValueError('unbound input')
    path=(root/name).resolve()
    if not path.is_relative_to(root) or sha(path)!=scope['frozen_inputs_sha256'][name]: raise ValueError('input identity mismatch')
    return json.loads(path.read_text(encoding='utf8'))


def validate_config(c):
    if c.get('expert') not in ('high','low') or c.get('layers')!=list(range(40)) or c.get('seed')!=2026110301 or c.get('gh_nodes')!=384 or c.get('block_rows')!=512 or c.get('sign_count')!=4 or not c.get('output_dir'): raise ValueError('incorrect finite origin scope')


def expected_keys(expert):
    return {f'{expert}/{model}/blocks.{layer}.ffn.{suffix}' for layer in range(40) for model in ('original','distilled') for suffix in ('0.weight','0.bias','2.weight','2.bias')}


def emit(path,obj):
    with path.open('a',encoding='utf8') as f: f.write(json.dumps(obj,allow_nan=False,separators=(',',':'))+'\n')


def load_a1(entry,d):
    if not isinstance(entry,dict) or set(entry)!={'path','sha256'} or not re.fullmatch('[0-9a-f]{64}',entry['sha256']): raise ValueError('invalid S12 asset identity')
    path=Path(entry['path']);
    if not path.is_absolute(): raise ValueError('absolute A1 path required')
    before=path.stat()
    if sha(path)!=entry['sha256']: raise ValueError('S12 A1 SHA mismatch')
    a=np.load(path,mmap_mode='r',allow_pickle=False)
    if a.shape!=(d,d) or a.dtype!=np.float64 or not np.isfinite(a).all(): raise ValueError('invalid S12 A1')
    after=path.stat()
    if (after.st_size,after.st_mtime_ns)!=(before.st_size,before.st_mtime_ns): raise ValueError('A1 changed during read')
    return a


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--scope',type=Path,required=True); ap.add_argument('--scope-sha',required=True); args=ap.parse_args()
    from runtime_guard import require_compute_allocation,verify_frozen_scope,RunReceipt
    alloc=require_compute_allocation(); root=Path(__file__).resolve().parent; scope=verify_frozen_scope(root,args.scope,args.scope_sha)
    if scope.get('phase')!='ORIGIN_EVIDENCE': raise ValueError('wrong scope phase')
    c=json.loads((root/scope['config_file']).read_text(encoding='utf8')); validate_config(c); expert=c['expert']
    if c['expected_tensor_hashes_file']!=scope['expected_tensor_hashes_file']: raise ValueError('hash manifest mismatch')
    hashes=frozen_json(root,scope,c['expected_tensor_hashes_file']); assets=frozen_json(root,scope,c['assets_file']); summary=frozen_json(root,scope,c['summary_file']); candidates=frozen_json(root,scope,c['candidates_file'])
    if any(not isinstance(hashes.get(k),str) or not re.fullmatch('[0-9a-f]{64}',hashes[k]) for k in expected_keys(expert)): raise ValueError('missing precommitted tensor identities')
    for layer in SELECTED_LAYERS:
        for label in ('Oq','Dq'): candidate_geometries(candidates,expert,layer,label)
    manifest=json.loads((root/scope['input_manifest_file']).read_text(encoding='utf8'))
    from weights_v7 import load_tensor,rne_lift
    from statistics_v7 import rng_for
    from candidate_verify import verify_candidate
    import scipy,torch
    if not torch.cuda.is_available() or torch.cuda.device_count()!=1: raise RuntimeError('one GPU required')
    mem=torch.cuda.get_device_properties(0).total_memory
    if mem<32*1024**3: raise RuntimeError('at least 32 GiB required')
    torch.cuda.set_per_process_memory_fraction(min(.95,40*1024**3/mem),0); torch.set_num_threads(scope['budget']['cpus']); torch.backends.cuda.matmul.allow_tf32=False; torch.backends.cudnn.allow_tf32=False
    out=Path(c['output_dir'])
    with RunReceipt(out,scope,alloc) as receipt:
      receipt.result={'status':'PARTIAL','completed_layers':[],'completed_units':[],'stream':'DEVELOPMENT/800'}
      emit(out/'environment.jsonl',{'scope_sha256':args.scope_sha,'expert':expert,'stream':'DEVELOPMENT/800','seed':c['seed'],'torch':torch.__version__,'numpy':np.__version__,'scipy':scipy.__version__,'gpu':torch.cuda.get_device_name(),'tf32':False,'numerical_status':'UNASSESSED','sign_note':'four fixed Rademacher W2 column flips; identical across Oq/Dq at each expert-layer'})
      try:
       for layer in c['layers']:
        receipt.check_deadline(); t0=time.monotonic(); models={}; print(f'START expert={expert} layer={layer}',flush=True)
        for model in ('original','distilled'):
         data={}
         for suffix in ('0.weight','0.bias','2.weight','2.bias'):
          receipt.check_deadline(); key=f'{expert}/{model}/blocks.{layer}.ffn.{suffix}'; arr,rec=load_tensor(manifest,expert,model,layer,suffix,hashes[key])
          if rec['identity_status']!='PRECOMMITTED_HASH_MATCH': raise ValueError('first-read identity not allowed')
          data[suffix]=rne_lift(arr) if model=='original' else arr; emit(out/'weights.jsonl',{'expert':expert,'model':model,'layer':layer,**rec})
         models[model]=data
        d=models['original']['0.weight'].shape[1]; m=models['original']['0.weight'].shape[0]
        if (d,m)!=(5120,13824): raise ValueError('unexpected FFN geometry')
        gen=rng_for(c['seed'],'DEVELOPMENT',expert,layer,800); signbits=gen.integers(0,2,size=(m,4),dtype=np.int8)*2-1
        signs=torch.as_tensor(np.column_stack((np.ones(m,dtype=np.int8),signbits)),device='cuda',dtype=torch.float64)
        for model,label in (('original','Oq'),('distilled','Dq')):
         receipt.check_deadline(); unit_start=time.monotonic(); w=models[model]
         with torch.no_grad():
          W=torch.as_tensor(w['0.weight'],device='cuda',dtype=torch.float64); beta=(W-W.mean(1,keepdim=True))*math.sqrt(d/(d-1)); del W
          norms=torch.linalg.vector_norm(beta,dim=1); p=beta/norms.clamp_min(1e-300)[:,None]; V=torch.as_tensor(w['2.weight'],device='cuda',dtype=torch.float64).T
          sigma=norms.cpu().numpy(); bias=w['0.bias'].astype(np.float64); vn=(V*V).sum(1).cpu().numpy()
          real=scalar_quadrature(sigma,bias,384); real192=scalar_quadrature(sigma,bias,192); zero=scalar_quadrature(sigma,np.zeros_like(bias),384); zero192=scalar_quadrature(sigma,np.zeros_like(bias),192)
          a=torch.as_tensor(real['a'],device='cuda',dtype=torch.float64)
          E=torch.zeros((8,5),device='cuda',dtype=torch.float64)
          for first in range(0,m,c['block_rows']):
           receipt.check_deadline(); E+=block_energies(p,V,a,signs,first,min(m,first+c['block_rows']),torch)
          E=E.cpu().numpy(); diag=(vn[:,None]*real['a'][:,1:]**2).sum(axis=0)
          negative_tolerance=check_energy_nonnegative(E,diag)
          actual=E[:,0]; cross=actual-diag
          t=a[:,2]@V; radial=float((t*t).sum()/(d-1)); sphere=sphere_q2(float(actual[1]),radial,d-1) if actual[1]>=0 else None
          for geometry,candidate in candidate_geometries(candidates,expert,layer,label):
           receipt.check_deadline()
           verification=verify_candidate(p,a[:,2],V,float(actual[1]),candidate)
           emit(out/'candidates.jsonl',{'expert':expert,'layer':layer,'arm':label,'geometry':geometry,**verification})
          A=(p.T*a[:,1])@V; L0=.5*(beta.T@V); delta=A-L0
          reference=load_a1(assets[f'{expert}/{layer}/{label}'],d); ref=torch.as_tensor(np.array(reference),device='cuda',dtype=torch.float64); diff=A-ref
          refnorm=float(ref.square().sum()); diffnorm=float(diff.square().sum()); maxdiff=float(diff.abs().max())
          a1norm=float(A.square().sum()); a1rel=check_a1_consistency(diffnorm,refnorm,float(actual[0]),a1norm)
          a1check={'difference_fro_sq':diffnorm,'reference_fro_sq':refnorm,'relative_fro':a1rel,'max_abs':maxdiff,'s12_asset_sha256':assets[f'{expert}/{layer}/{label}']['sha256'],'numeric_status':'UNASSESSED'}
          shortcut={'A1_fro_sq':float(A.square().sum()),'E1_gram_minus_A1_fro_sq':float(actual[0]-float(A.square().sum())),'L0_fro_sq':float(L0.square().sum()),'A1_minus_L0_fro_sq':float(delta.square().sum()),'twice_inner_L0_delta':float(2*(L0*delta).sum()),'meaning':'L0=.5*beta.T@V; A1 includes Gaussian derivative and real bias; delta need not be attributed solely to bias'}
          Dvar=float(vn@real['var']); Dt2=float(vn@real['tail2']); Dt4=float(vn@real['tail4']); Dvar0=float(vn@zero['var']); Dt20=float(vn@zero['tail2']); Dt40=float(vn@zero['tail4'])
          obs=summary[f'{expert}/{layer}/{label}']; ratios=matched_ratios(obs['V'],obs['T2'],obs['T4'],Dvar,Dt2,Dt4)
          E1flip=float((2*L0-A).square().sum())
          flip={'E1_flip':E1flip,'Vflip_est_signed':obs['V']-float(actual[0])+E1flip,'T2_absolute_prediction':obs['T2'],'T4_absolute_prediction':obs['T4'],'status':'ALG_PLUS_S12_MC_NOT_NATIVE','meaning':'simultaneous b1 sign reversal; high-order absolute Gaussian energies invariant; V uses S12 Monte Carlo estimate'}
          def discrepancy(x,y): return float(np.linalg.norm(x-y)/max(np.linalg.norm(x),1e-300))
          def weighted_diff(key):
           x=float(vn@real[key]); y=float(vn@real192[key]); return abs(x-y)/max(abs(x),1e-300)
          ghdiag={'a':discrepancy(real['a'],real192['a']),'a_by_order':[discrepancy(real['a'][:,q],real192['a'][:,q]) for q in range(9)],'variance':discrepancy(real['var'],real192['var']),'tail2':discrepancy(real['tail2'],real192['tail2']),'tail4':discrepancy(real['tail4'],real192['tail4']),'weighted_Dvar':weighted_diff('var'),'weighted_Dtail2':weighted_diff('tail2'),'weighted_Dtail4':weighted_diff('tail4'),'zero_bias_a':discrepancy(zero['a'],zero192['a']),'zero_bias_a_by_order':[discrepancy(zero['a'][:,q],zero192['a'][:,q]) for q in range(9)]}
          path=out/f'{expert}_{layer:02d}_{label}_neurons.npz'
          np.savez_compressed(path,sigma=sigma,bias=bias,v_norm_sq=vn,a=real['a'],variance=real['var'],tail2=real['tail2'],tail4=real['tail4'],a_zero_bias=zero['a'],variance_zero_bias=zero['var'],tail2_zero_bias=zero['tail2'],tail4_zero_bias=zero['tail4'],a_192=real192['a'],variance_192=real192['var'],tail2_192=real192['tail2'],tail4_192=real192['tail4'],a_zero_bias_192=zero192['a'],variance_zero_bias_192=zero192['var'],tail2_zero_bias_192=zero192['tail2'],tail4_zero_bias_192=zero192['tail4'])
          emit(out/'artifacts.jsonl',{'expert':expert,'layer':layer,'arm':label,'kind':'PER_NEURON_QUADRATURE','path':path.name,'sha256':sha(path)})
          emit(out/'units.jsonl',{'expert':expert,'layer':layer,'arm':label,'E_q_1_to_8':actual.tolist(),'D_q_1_to_8':diag.tolist(),'signed_cross_E_minus_D':cross.tolist(),'sign_flip_E_q_1_to_8':E[:,1:].T.tolist(),'negative_energy_tolerance_abs_plus_relative':negative_tolerance.tolist(),'sign_bits_sha256':hashlib.sha256(signbits.tobytes()).hexdigest(),'sign_control':'same four flips for both arms; mean energy expectation over all signs is Dq, not an expected ratio','E2_gaussian':float(actual[1]),'E2_radial':radial,'E2_fixed_F2_sphere':sphere,'sphere_interpretation':'centered fixed F2 on uniform sphere in Pi support; not full FFN','Dvar':Dvar,'Dtail2':Dt2,'Dtail4':Dt4,'zero_bias_counterfactual':{'Dvar':Dvar0,'Dtail2':Dt20,'Dtail4':Dt40},'bias_sign_flip_counterfactual':flip,'s12_input':obs,'matched_ratios':ratios,'quadrature_relative_384_vs_192':ghdiag,'A1_vs_S12':a1check,'linear_shortcut':shortcut,'numerical_status':'UNASSESSED','elapsed_seconds':time.monotonic()-unit_start,'gpu_peak_allocated_bytes':torch.cuda.max_memory_allocated()})
          if torch.cuda.max_memory_allocated()>40*1024**3: raise MemoryError('GPU memory budget exceeded')
          receipt.result['completed_units'].append(f'{expert}/{layer}/{label}')
          del diff
          del beta,norms,p,V,a,t,A,L0,delta,ref,reference
        receipt.result['completed_layers'].append(layer); emit(out/'layers.jsonl',{'expert':expert,'layer':layer,'status':'COMPLETE','elapsed_seconds':time.monotonic()-t0}); print(f'DONE expert={expert} layer={layer}',flush=True)
        del models,signs; torch.cuda.empty_cache()
       receipt.result['status']='ORIGIN_EVIDENCE_COMPLETE_NUMERICS_UNASSESSED'
      except TimeoutError:
       receipt.result['status']='PARTIAL_TIMELIMIT'; raise

if __name__=='__main__': main()
