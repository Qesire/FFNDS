#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import math
import os
import re
import threading
import time
from pathlib import Path
from typing import Any

import torch
import torch.nn.functional as F

_LOCK = threading.RLock()
_CONTEXT: dict[str, Any] | None = None
_INSTALLED = False
_ORIGINAL = None
_PLAN: dict[str, Any] | None = None
_STATIC_SCALES: dict[str, torch.Tensor] | None = None
_CALL_COUNTS: dict[str, int] = {}


def _stable_seed(*parts: Any) -> int:
    raw = "\x1f".join(map(str, parts)).encode("utf-8")
    return int.from_bytes(hashlib.sha256(raw).digest()[:8], "big") & ((1 << 63) - 1)


def _atomic_torch_save(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.tmp.{os.getpid()}")
    torch.save(payload, tmp)
    os.replace(tmp, path)


def _append_jsonl(path: str | Path | None, payload: dict[str, Any]) -> None:
    if not path:
        return
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a", encoding="utf-8") as f:
        f.write(json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n")
        f.flush()
        os.fsync(f.fileno())


def _sanitize(value: Any) -> str:
    text = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value))
    return text[:80] or "unknown"


def _role(value: Any) -> str:
    value = str(value or "").lower()
    return {
        "calibration": "fit",
        "fit": "fit",
        "validation": "select",
        "select": "select",
        "test": "audit",
        "audit": "audit",
        "smoke": "smoke",
        "vbench": "vbench",
    }.get(value, value)


def set_context(record: dict[str, Any]) -> None:
    global _CONTEXT
    context = dict(record)
    context["role"] = _role(context.get("role"))
    context.setdefault("source_group", context.get("videoid", "unknown"))
    context.setdefault("repeat_seed", context.get("seed", 0))
    context.setdefault("videoid", context.get("source_group", "unknown"))
    if "prompt_sha256" not in context:
        context["prompt_sha256"] = hashlib.sha256(str(context.get("prompt", "")).encode("utf-8")).hexdigest()
    if context["role"] not in {"fit", "select", "audit", "smoke", "vbench"}:
        raise RuntimeError(f"invalid Prox capture role: {context['role']!r}")
    with _LOCK:
        _CONTEXT = context


def clear_context() -> None:
    global _CONTEXT
    with _LOCK:
        _CONTEXT = None


def _load_plan() -> dict[str, Any] | None:
    global _PLAN, _STATIC_SCALES
    if _PLAN is not None:
        return _PLAN
    path = os.environ.get("PROX_METHOD_PLAN", "")
    if not path:
        return None
    p = Path(path)
    if p.suffix == ".pt":
        plan = torch.load(p, map_location="cpu", weights_only=False)
    else:
        plan = json.loads(p.read_text(encoding="utf-8"))
    if not isinstance(plan, dict) or plan.get("artifact") not in {"prox_wan_selected_plan_v1", "prox_wan_runtime_plan_v1"}:
        raise RuntimeError(f"invalid Prox method plan: {path}")
    plan_cache = str(plan.get("hif4_cache_path", "")).strip()
    env_cache = os.environ.get("PROX_HIF4_CACHE_PATH", "").strip()
    if plan_cache and env_cache:
        if Path(plan_cache).expanduser().resolve() != Path(env_cache).expanduser().resolve():
            raise RuntimeError(
                f"selected plan cache differs from runtime cache: plan={plan_cache} runtime={env_cache}"
            )
    scale_path = plan.get("static_scales_path")
    if scale_path:
        sp = Path(scale_path)
        if not sp.is_absolute():
            sp = p.parent / sp
        scales = torch.load(sp, map_location="cpu", weights_only=False)
        if not isinstance(scales, dict):
            raise RuntimeError("static scales artifact must be a dict")
        _STATIC_SCALES = scales
    else:
        _STATIC_SCALES = {}
    _PLAN = plan
    return plan


def _step_index(infer: Any) -> int:
    scheduler = getattr(infer, "scheduler", None)
    step = getattr(scheduler, "step_index", None)
    if step is None:
        raise RuntimeError("Wan scheduler.step_index is unavailable")
    step = int(step)
    if step not in range(4):
        raise RuntimeError(f"expected four-step distill index 0..3, got {step}")
    return step


def _timestep(infer: Any, step: int) -> float | int | None:
    scheduler = getattr(infer, "scheduler", None)
    for name in ("timesteps", "infer_timesteps"):
        value = getattr(scheduler, name, None)
        if value is not None:
            try:
                t = value[step]
                if isinstance(t, torch.Tensor):
                    t = t.detach().cpu().item()
                return float(t) if isinstance(t, float) else int(t)
            except Exception:
                pass
    for name in ("timestep", "current_timestep"):
        value = getattr(scheduler, name, None)
        if value is not None:
            if isinstance(value, torch.Tensor):
                value = value.detach().cpu().item()
            return value
    return None


def _expert_for_step(step: int) -> str:
    boundary = int(os.environ.get("PROX_BOUNDARY_STEP_INDEX", "2"))
    if boundary != 2:
        raise RuntimeError("this suite freezes Wan2.2 dual-expert boundary_step_index=2")
    return "high_noise_model" if step < boundary else "low_noise_model"


def _target_blocks() -> set[int]:
    text = os.environ.get("PROX_CAPTURE_BLOCKS", "all").strip().lower()
    if text in {"", "all"}:
        return set(range(40))
    out = {int(x.strip()) for x in text.split(",") if x.strip()}
    if not out or min(out) < 0 or max(out) >= 40:
        raise RuntimeError(f"invalid PROX_CAPTURE_BLOCKS={text!r}")
    return out


def _sample_z(z: torch.Tensor, gate: torch.Tensor, context: dict[str, Any], expert: str, step: int, block: int) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, int]:
    flat = z.detach().reshape(-1, z.shape[-1])
    if flat.shape[-1] != 5120:
        raise RuntimeError(f"unexpected Wan FFN input shape {tuple(z.shape)}")
    k = min(int(os.environ.get("PROX_CAPTURE_SAMPLE_TOKENS", "128")), flat.shape[0])
    if k <= 0:
        raise RuntimeError("PROX_CAPTURE_SAMPLE_TOKENS must be positive")
    # Tile experiments require local token order. Select one deterministic
    # contiguous flattened-token window and reuse it across all blocks of the
    # same source/step/condition by deliberately excluding block from the seed.
    gen = torch.Generator(device="cpu").manual_seed(
        _stable_seed(context["source_group"], context["repeat_seed"], expert, step, context.get("condition", "cond"))
    )
    alignment = int(os.environ.get("PROX_CAPTURE_TOKEN_ALIGNMENT", "64"))
    if alignment <= 0 or k % alignment != 0:
        raise RuntimeError("sample-token count must be a positive multiple of PROX_CAPTURE_TOKEN_ALIGNMENT")
    max_tile = max((int(flat.shape[0]) - k) // alignment, 0)
    tile = 0 if max_tile == 0 else int(torch.randint(0, max_tile + 1, (1,), generator=gen).item())
    start = tile * alignment
    indices = torch.arange(start, start + k, dtype=torch.int64)
    z_cpu = flat.index_select(0, indices.to(flat.device)).to(device="cpu", dtype=torch.bfloat16).contiguous()
    g = gate.detach().squeeze()
    if g.ndim == 1:
        if g.shape[0] != 5120:
            raise RuntimeError(f"unexpected scalar-step gate shape {tuple(g.shape)}")
        gate_cpu = g.to(device="cpu", dtype=torch.bfloat16).contiguous()
    else:
        gf = g.reshape(-1, g.shape[-1])
        if gf.shape != flat.shape:
            raise RuntimeError(f"tokenwise gate shape {tuple(g.shape)} does not align with z {tuple(z.shape)}")
        gate_cpu = gf.index_select(0, indices.to(gf.device)).to(device="cpu", dtype=torch.bfloat16).contiguous()
    return z_cpu, gate_cpu, indices.to(torch.int64), int(flat.shape[0])


def _threshold_key(plan: dict[str, Any], expert: str, step: int, block: int) -> str:
    gran = plan["arm"]["threshold_granularity"]
    if gran == "layer":
        return str(block)
    if gran == "expert_layer":
        return f"{expert}|{block}"
    if gran == "step_layer":
        return f"{expert}|{step}|{block}"
    if gran == "topk":
        return "topk"
    raise RuntimeError(f"unsupported threshold granularity: {gran}")


def _topk_mask(scores: torch.Tensor, sparsity: float) -> torch.Tensor:
    n = scores.shape[-1]
    keep = max(1, int(round((1.0 - sparsity) * n)))
    idx = torch.topk(scores, keep, dim=-1, largest=True, sorted=False).indices
    mask = torch.zeros_like(scores, dtype=torch.bool)
    mask.scatter_(-1, idx, True)
    return mask


def _group_mask(scores: torch.Tensor, arm: dict[str, Any], threshold: float | None) -> torch.Tensor:
    group_size = int(arm.get("group_size", 1))
    agg = arm.get("group_agg", "rms")
    t, c = scores.shape
    if group_size <= 1:
        reduced = scores
    else:
        groups = (t + group_size - 1) // group_size
        padded = groups * group_size
        if padded > t:
            pad = torch.zeros((padded - t, c), dtype=scores.dtype, device=scores.device)
            x = torch.cat([scores, pad], dim=0).view(groups, group_size, c)
            valid = torch.cat([
                torch.ones((t, 1), dtype=scores.dtype, device=scores.device),
                torch.zeros((padded - t, 1), dtype=scores.dtype, device=scores.device),
            ]).view(groups, group_size, 1)
        else:
            x = scores.view(groups, group_size, c)
            valid = torch.ones((groups, group_size, 1), dtype=scores.dtype, device=scores.device)
        if agg == "rms":
            reduced = torch.sqrt((x.square() * valid).sum(dim=1) / valid.sum(dim=1).clamp_min(1))
        elif agg == "max":
            reduced = torch.where(valid.bool(), x, torch.full_like(x, -torch.inf)).amax(dim=1)
        else:
            raise RuntimeError(f"unsupported group aggregation {agg!r}")
    if arm["threshold_granularity"] == "topk":
        group = _topk_mask(reduced, float(arm["s2"]))
    else:
        if threshold is None:
            raise RuntimeError("channel threshold missing")
        group = reduced >= float(threshold)
    if group_size <= 1:
        return group[:t]
    return group.repeat_interleave(group_size, dim=0)[:t]


def _input_mask(z2: torch.Tensor, arm: dict[str, Any], threshold: float | None) -> torch.Tensor:
    if arm["threshold_granularity"] == "topk":
        return _topk_mask(z2.abs(), float(arm["s1"]))
    if threshold is None:
        raise RuntimeError("input threshold missing")
    return z2.abs() >= float(threshold)


def _scale_for(plan: dict[str, Any], expert: str, step: int, block: int, device: torch.device) -> torch.Tensor | None:
    sal = plan["arm"].get("proxy_salience", "H")
    if sal == "H":
        return None
    assert _STATIC_SCALES is not None
    for key in (f"{expert}|{step}|{block}", f"{expert}|{block}", str(block)):
        if key in _STATIC_SCALES:
            return _STATIC_SCALES[key].to(device=device, dtype=torch.float32)
    raise RuntimeError(f"static channel scale missing for {expert}|{step}|{block}")


def _save_capture(call: dict[str, Any], infer: Any, gate: torch.Tensor) -> None:
    context = call["context"]
    expert, step, block = call["expert"], call["step"], call["block"]
    z_cpu, gate_cpu, indices, original = _sample_z(call["z"], gate, context, expert, step, block)
    spool = Path(os.environ["PROX_CAPTURE_SPOOL"])
    condition = str(context.get("condition", getattr(getattr(infer, "scheduler", None), "infer_condition", "cond")))
    name = "__".join([
        _sanitize(context["role"]),
        _sanitize(context["source_group"]),
        str(int(context["repeat_seed"])),
        f"s{step:02d}",
        f"b{block:02d}",
        _sanitize(condition),
    ]) + ".pt"
    path = spool / name
    if path.exists():
        raise RuntimeError(f"duplicate activation record path: {path}")
    mask_x_sample = None
    mask_h_sample = None
    if call.get("mask_x") is not None:
        mask_x_sample = call["mask_x"].reshape(-1, call["mask_x"].shape[-1]).index_select(0, indices.to(call["mask_x"].device)).to(device="cpu", dtype=torch.bool).contiguous()
    if call.get("mask_h") is not None:
        mask_h_sample = call["mask_h"].reshape(-1, call["mask_h"].shape[-1]).index_select(0, indices.to(call["mask_h"].device)).to(device="cpu", dtype=torch.bool).contiguous()
    plan = _load_plan() if call.get("mask_h") is not None else None
    record = {
        "schema": "prox_wan_activation_record_v1",
        "role": context["role"],
        "source_group": str(context["source_group"]),
        "repeat_seed": int(context["repeat_seed"]),
        "videoid": str(context["videoid"]),
        "prompt_sha256": str(context["prompt_sha256"]),
        "condition": condition,
        "expert": expert,
        "step_index": step,
        "timestep": _timestep(infer, step),
        "block_index": block,
        "z": z_cpu,
        "gate": gate_cpu,
        "token_indices": indices,
        "num_tokens_original": original,
        "sampling_mode": "deterministic_contiguous_flattened_window_v1",
        "captured_at_unix": time.time(),
        "runtime_model_cls": str(getattr(infer, "config", {}).get("model_cls", "unknown")),
        "runtime_mask_x": mask_x_sample,
        "runtime_mask_h": mask_h_sample,
        "runtime_plan_arm_id": None if plan is None else plan.get("arm_id"),
        "runtime_proxy_semantics": None if plan is None else "archived v4.9.2 HIF4CacheRuntime FFN.0 on masked input",
    }
    _atomic_torch_save(path, record)


def _runtime_stats(call: dict[str, Any], mask_x: torch.Tensor | None, mask_h: torch.Tensor | None) -> None:
    context = call["context"]
    payload = {
        "artifact": "prox_wan_runtime_mask_event_v1",
        "role": context["role"],
        "source_group": context["source_group"],
        "repeat_seed": int(context["repeat_seed"]),
        "expert": call["expert"],
        "step_index": call["step"],
        "block_index": call["block"],
        "input_sparsity": None if mask_x is None else float(1.0 - mask_x.float().mean().item()),
        "channel_sparsity": None if mask_h is None else float(1.0 - mask_h.float().mean().item()),
        "active_channels_mean": None if mask_h is None else float(mask_h.float().sum(dim=-1).mean().item()),
    }
    _append_jsonl(os.environ.get("PROX_RUNTIME_STATS"), payload)


def install_patch() -> None:
    global _INSTALLED, _ORIGINAL
    if _INSTALLED:
        return
    if os.environ.get("PROX_PATCH_ENABLE", "0") != "1":
        return
    from lightx2v.models.networks.wan.infer.transformer_infer import WanTransformerInfer

    original = WanTransformerInfer.infer_ffn
    _ORIGINAL = original
    targets = _target_blocks()

    def wrapped(self, phase, x, attn_out, c_shift_msa, c_scale_msa, c_gate_msa=None):
        mode = os.environ.get("PROX_PATCH_MODE", "capture").lower()
        block = int(getattr(self, "block_idx", -1))
        if block not in targets:
            return original(self, phase, x, attn_out, c_shift_msa, c_scale_msa, c_gate_msa)
        with _LOCK:
            context = None if _CONTEXT is None else dict(_CONTEXT)
        if context is None:
            raise RuntimeError("Prox runtime context was not set before Wan inference")
        step = _step_index(self)
        expert = _expert_for_step(step)
        call: dict[str, Any] = {"context": context, "expert": expert, "step": step, "block": block, "z": None, "mask_h": None, "mask_x": None}
        apply0 = phase.ffn_0.apply
        apply2 = phase.ffn_2.apply

        def ffn0_apply(z):
            call["z"] = z.detach()
            if mode in {"emulate", "capture_emulate", "calibrate_emulate"}:
                plan = _load_plan()
                if plan is None:
                    raise RuntimeError("emulation mode requires PROX_METHOD_PLAN")
                arm = plan["arm"]
                expected_mode = os.environ.get("PROX_RUNTIME_NATIVE_PROXY_MODE", "hif4_qdq")
                if arm.get("proxy_weight_mode") != expected_mode:
                    raise RuntimeError(f"selected proxy mode {arm.get('proxy_weight_mode')} cannot be emulated by native runtime mode {expected_mode}")
                key = _threshold_key(plan, expert, step, block)
                tx = None if key == "topk" else plan["thresholds"]["input"].get(key)
                th = None if key == "topk" else plan["thresholds"]["channel"].get(key)
                z2 = z.reshape(-1, z.shape[-1])
                mx = _input_mask(z2, arm, tx)
                proxy_pre = apply0((z2 * mx).reshape_as(z))
                proxy_h = F.gelu(proxy_pre, approximate="tanh").reshape(-1, proxy_pre.shape[-1]).float()
                scale = _scale_for(plan, expert, step, block, proxy_h.device)
                score = proxy_h.abs() if scale is None else proxy_h.abs() * scale
                mh = _group_mask(score, arm, th)
                call["mask_x"] = mx
                call["mask_h"] = mh
            return apply0(z)

        def ffn2_apply(h):
            if call["z"] is None:
                raise RuntimeError("FFN-2 observed before FFN-0 in Prox patch")
            if mode in {"capture", "capture_emulate", "calibrate_emulate"}:
                _save_capture(call, self, c_gate_msa)
            mh = call["mask_h"]
            if mh is not None:
                h2 = h.reshape(-1, h.shape[-1]) * mh.to(dtype=h.dtype)
                h = h2.reshape_as(h)
            _runtime_stats(call, call["mask_x"], call["mask_h"])
            return apply2(h)

        phase.ffn_0.apply = ffn0_apply
        phase.ffn_2.apply = ffn2_apply
        try:
            out = original(self, phase, x, attn_out, c_shift_msa, c_scale_msa, c_gate_msa)
        finally:
            phase.ffn_0.apply = apply0
            phase.ffn_2.apply = apply2
        if call["z"] is None:
            raise RuntimeError(
                "Prox patch did not observe phase.ffn_0.apply; disable mxfp8_fuse_enable and fused FFN paths during capture/emulation"
            )
        key = f"{context['role']}|{context['source_group']}|{context['repeat_seed']}|{step}|{block}"
        _CALL_COUNTS[key] = _CALL_COUNTS.get(key, 0) + 1
        if _CALL_COUNTS[key] != 1:
            raise RuntimeError(f"duplicate FFN call for frozen no-CFG trajectory key {key}")
        return out

    WanTransformerInfer.infer_ffn = wrapped
    _INSTALLED = True


def patch_status() -> dict[str, Any]:
    return {
        "installed": _INSTALLED,
        "mode": os.environ.get("PROX_PATCH_MODE", "capture"),
        "context_set": _CONTEXT is not None,
        "calls": len(_CALL_COUNTS),
    }
