"""Numerical primitives for low-order origin diagnostics; no tensor access."""
import math
import numpy as np


def scalar_quadrature(sigma,bias,nodes=384,chunk=512):
    """Per-neuron GH coefficients plus directly integrated centered/tail squares."""
    from scipy.special import roots_hermitenorm
    from core_math import basis,tanh_gelu
    s=np.asarray(sigma,dtype=np.float64); b=np.asarray(bias,dtype=np.float64)
    if s.ndim!=1 or b.shape!=s.shape or np.any(s<0) or not np.isfinite(s).all() or not np.isfinite(b).all() or type(nodes)!=int or nodes<2 or chunk<1: raise ValueError('invalid quadrature input')
    z,w=roots_hermitenorm(nodes); w=w/np.sqrt(2*np.pi); h=basis(z,8)
    a=np.empty((len(s),9)); var=np.empty(len(s)); tail2=np.empty(len(s)); tail4=np.empty(len(s))
    for start in range(0,len(s),chunk):
        end=min(start+chunk,len(s)); vals=tanh_gelu(b[start:end,None]+s[start:end,None]*z); coef=(vals*w)@h
        zero=s[start:end]==0; coef[zero,1:]=0
        a[start:end]=coef
        var[start:end]=((vals-coef[:,0,None])**2)@w
        tail2[start:end]=((vals-coef[:,:3]@h[:,:3].T)**2)@w
        tail4[start:end]=((vals-coef[:,:5]@h[:,:5].T)**2)@w
        var[start:end][zero]=0; tail2[start:end][zero]=0; tail4[start:end][zero]=0
    if not all(np.isfinite(x).all() for x in (a,var,tail2,tail4)): raise ValueError('nonfinite quadrature')
    return {'a':a,'var':var,'tail2':tail2,'tail4':tail4}


def block_energies(p,V,a,signs,start,end,xp):
    """8x5 summed q energies for 1 original and 4 fixed sign flips.
    p=(m,d), V=(m,o), a=(m,9), signs=(m,5) with first column 1.
    Uses NumPy or torch; caller accumulates disjoint row blocks.
    """
    if p.ndim!=2 or V.ndim!=2 or a.shape!=(p.shape[0],9) or V.shape[0]!=p.shape[0] or signs.shape!=(p.shape[0],5) or not 0<=start<end<=p.shape[0]: raise ValueError('bad geometry')
    rho=p[start:end]@p.T; gram=V[start:end]@V.T; power=rho
    result=[]
    for q in range(1,9):
        weights=a[:,q,None]*signs
        result.append((weights[start:end]*((gram*power)@weights)).sum(0))
        power=power*rho
    return xp.stack(result,0)


def sphere_q2(E2,radial,dimension):
    """Centered Gaussian H2 norm and fixed-radius sphere F2 norm, support dim n."""
    if type(dimension)!=int or dimension<1 or not math.isfinite(E2) or not math.isfinite(radial) or E2<0 or radial<0: raise ValueError('bad sphere inputs')
    if radial>E2+1e-12+1e-9*max(E2,radial): raise ValueError('radial energy materially exceeds E2')
    return dimension/(dimension+2)*(E2-radial)


def matched_ratios(V,T2,T4,Dvar,Dtail2,Dtail4):
    vals=(V,T2,T4,Dvar,Dtail2,Dtail4)
    if not all(math.isfinite(x) for x in vals) or min(vals)<0: raise ValueError('bad matched scalar')
    div=lambda x,y:x/y if y>0 else None
    ans={'T2_over_Dtail2':div(T2,Dtail2),'T4_over_Dtail4':div(T4,Dtail4),'V_over_Dvar':div(V,Dvar),'T2_over_V':div(T2,V),'T4_over_V':div(T4,V),'Dtail2_over_Dvar':div(Dtail2,Dvar),'Dtail4_over_Dvar':div(Dtail4,Dvar)}
    ans['relative_tail_ratio2']=div(ans['T2_over_V'],ans['Dtail2_over_Dvar']) if ans['T2_over_V'] is not None and ans['Dtail2_over_Dvar'] is not None else None
    ans['relative_tail_ratio4']=div(ans['T4_over_V'],ans['Dtail4_over_Dvar']) if ans['T4_over_V'] is not None and ans['Dtail4_over_Dvar'] is not None else None
    return ans


def check_energy_nonnegative(E,diagonal):
    """Keep roundoff-sized signed values; reject large negative energies."""
    E=np.asarray(E,dtype=float); diagonal=np.asarray(diagonal,dtype=float)
    if E.shape!=(8,5) or diagonal.shape!=(8,) or not np.isfinite(E).all() or not np.isfinite(diagonal).all() or np.any(diagonal<0): raise ValueError('invalid chaos energy')
    tolerance=1e-12+1e-9*diagonal
    if np.any(E < -tolerance[:,None]): raise ValueError('chaos energy is materially negative')
    return tolerance


def check_a1_consistency(diff_sq,reference_sq,gram_e1,a1_sq):
    """Independent matrix identity checks; diagnostics remain non-certified."""
    if not all(math.isfinite(x) for x in (diff_sq,reference_sq,gram_e1,a1_sq)) or min(diff_sq,reference_sq,a1_sq)<0: raise ValueError('invalid A1 consistency inputs')
    rel=math.sqrt(diff_sq/reference_sq) if reference_sq>0 else (0. if diff_sq==0 else math.inf)
    if rel>1e-8: raise ValueError('A1 mismatch against S12')
    if abs(gram_e1-a1_sq)>1e-9*max(abs(gram_e1),a1_sq,1e-300): raise ValueError('Gram E1 mismatch against A1')
    return rel
