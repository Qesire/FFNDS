#!/usr/bin/env python3
from __future__ import annotations

"""Read-only replay of the archived v4.9.2 HiF4 cache runtime.

This module does not patch or modify LightX2V.  It instantiates the exact
``HIF4CacheRuntime`` class shipped by the archived engineering package and
uses its public ``apply`` method for local FFN replay.
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import torch


@dataclass
class _BiasCarrier:
    bias: torch.Tensor | None

    def _get_actual_bias(self) -> torch.Tensor | None:
        return self.bias


class CacheRuntimeReplay:
    def __init__(self, cache_path: str | Path) -> None:
        path = Path(cache_path).expanduser().resolve()
        if not path.is_file():
            raise FileNotFoundError(path)
        from HiFloat4.ptq.adapters.lightx2v_wan_distill import HIF4CacheRuntime

        self.path = path
        self.runtime = HIF4CacheRuntime(path)
        self.meta = dict(self.runtime.meta)

    def record(self, expert: str, module_name: str) -> dict[str, Any]:
        rec = self.runtime.records.get(expert, {}).get(module_name)
        if not isinstance(rec, dict):
            raise KeyError(f"cache record missing: {expert}.{module_name}")
        return rec

    def weight(self, expert: str, module_name: str) -> torch.Tensor:
        value = self.record(expert, module_name).get("weight_qdq")
        if not torch.is_tensor(value):
            raise TypeError(f"cache record has no weight_qdq: {expert}.{module_name}")
        return value

    def effective_weight(self, expert: str, module_name: str) -> torch.Tensor:
        """Return the linear operator after folding the cache smooth scale.

        HIF4CacheRuntime computes F.linear(x / scale, weight_qdq).  For
        salience terms that inspect W directly, the equivalent weight is
        weight_qdq / scale along the input-feature axis.
        """
        record = self.record(expert, module_name)
        weight = self.weight(expert, module_name).float()
        scale = record.get("smooth_scale")
        if not torch.is_tensor(scale):
            return weight
        scale = scale.float().reshape(-1)
        if weight.ndim != 2 or weight.shape[1] != scale.numel():
            raise RuntimeError(
                f"smooth_scale shape mismatch for {expert}.{module_name}: "
                f"weight={tuple(weight.shape)} scale={tuple(scale.shape)}"
            )
        return weight / scale.view(1, -1)

    def apply(
        self,
        x: torch.Tensor,
        *,
        expert: str,
        step_index: int,
        block_index: int,
        module_name: str,
        bias: torch.Tensor | None,
    ) -> torch.Tensor:
        result = self.runtime.apply(
            _BiasCarrier(bias),
            x,
            expert=expert,
            step_index=int(step_index),
            block_index=int(block_index),
            module_name=module_name,
        )
        if result is None:
            raise RuntimeError(f"cache runtime returned None: {expert}.{module_name}")
        return result

    def audit(self) -> dict[str, Any]:
        records = {
            expert: len(self.runtime.records.get(expert, {}))
            for expert in ("high_noise_model", "low_noise_model")
        }
        return {
            "artifact": "prox_archived_hif4_cache_replay_binding_v1",
            "cache_path": str(self.path),
            "cache_meta": self.meta,
            "record_counts": records,
            "implementation": "archived_v4.9.2.HIF4CacheRuntime.apply",
            "lightx2v_modified": False,
        }
