#!/usr/bin/env python3
from __future__ import annotations

"""Run Prox capture around the exact archived LightX2V v4.9.2 contract.

This entrypoint intentionally does not construct ``LightX2VPipeline`` and does
not call ``create_generator``.  Model construction, effective-config assembly,
scheduler creation and expert checkpoint selection are delegated verbatim to
``HiFloat4.ptq.adapters.lightx2v_wan_distill`` from the previously validated
v4.9.2 engineering package.  Prox only supplies per-sample capture context.
"""

import argparse
import hashlib
import importlib
import inspect
import json
import os
import sys
from pathlib import Path
from typing import Any

from archived_cache_contract import validate_meta, validate_records
from io_utils import atomic_json


def _sha256(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _load_manifest(path: str | Path) -> list[dict[str, Any]]:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    if isinstance(payload, list):
        rows = payload
    elif isinstance(payload, dict):
        for key in ("records", "samples", "data", "items"):
            if isinstance(payload.get(key), list):
                rows = payload[key]
                break
        else:
            rows = list(payload.values()) if payload and all(isinstance(v, dict) for v in payload.values()) else []
    else:
        rows = []
    if not rows or not all(isinstance(x, dict) for x in rows):
        raise RuntimeError(f"unsupported or empty manifest: {path}")
    return [dict(x) for x in rows]


def _normalise_record(raw: dict[str, Any], index: int) -> dict[str, Any]:
    role_raw = str(raw.get("role", raw.get("split", ""))).lower()
    role = {"calibration": "fit", "validation": "select", "test": "audit"}.get(role_raw, role_raw)
    if role not in {"fit", "select", "audit", "smoke", "vbench"}:
        raise RuntimeError(f"record {index}: invalid role {role_raw!r}")
    prompt = str(raw.get("prompt", "")).strip()
    if not prompt:
        raise RuntimeError(f"record {index}: empty prompt")
    image = raw.get("image_path")
    if image is None:
        images = raw.get("img_paths")
        if isinstance(images, list) and images:
            image = images[0]
    if image is None:
        raise RuntimeError(f"record {index}: missing image_path/img_paths")
    image = str(Path(str(image)).resolve())
    if not Path(image).is_file():
        raise FileNotFoundError(image)
    seed = int(raw.get("seed", raw.get("repeat_seed", 0)))
    source_group = str(raw.get("source_group", raw.get("videoid", f"record_{index}")))
    videoid = str(raw.get("videoid", source_group))
    return {
        **raw,
        "role": role,
        "prompt": prompt,
        "image_path": image,
        "seed": seed,
        "repeat_seed": seed,
        "source_group": source_group,
        "videoid": videoid,
        "prompt_sha256": str(raw.get("prompt_sha256", hashlib.sha256(prompt.encode("utf-8")).hexdigest())),
    }


def _bootstrap_archived_source_tree(args: argparse.Namespace) -> dict[str, str]:
    base_kit = Path(args.base_kit_root).resolve()
    tools = base_kit / "tools"
    bootstrap_file = tools / "hifx4_source_bootstrap.py"
    if not bootstrap_file.is_file():
        raise FileNotFoundError(bootstrap_file)

    os.environ["HIFX4_KIT_ROOT"] = str(base_kit)
    os.environ["ROOT"] = str(Path(args.project_root).resolve())
    os.environ["LIGHTX2V_REPO"] = str(Path(args.lightx2v_repo).resolve())
    os.environ["WAN_W4A4_REPO"] = str(Path(args.wan_w4a4_repo).resolve())
    os.environ["HIF4_MAIN_REPO"] = str(Path(args.hif4_main_repo).resolve())
    if str(tools) not in sys.path:
        sys.path.insert(0, str(tools))
    bootstrap = importlib.import_module("hifx4_source_bootstrap")
    return dict(bootstrap.bootstrap_source_tree(str(bootstrap_file)))


def _load_archived_adapter(args: argparse.Namespace):
    source_tree = _bootstrap_archived_source_tree(args)
    module = importlib.import_module("HiFloat4.ptq.adapters.lightx2v_wan_distill")

    base_kit = Path(args.base_kit_root).resolve()
    expected_adapter = base_kit / "payload/HiFloat4/ptq/adapters/lightx2v_wan_distill.py"
    expected_contract = base_kit / "payload/HiFloat4/ptq/adapters/lightx2v_wan_distill_contract.json"
    vendored_contract = Path(args.contract_json).resolve()
    imported_adapter = Path(inspect.getfile(module)).resolve()
    imported_contract = imported_adapter.with_name("lightx2v_wan_distill_contract.json")

    for path in (expected_adapter, expected_contract, vendored_contract, imported_adapter, imported_contract):
        if not path.is_file():
            raise FileNotFoundError(path)

    hashes = {
        "base_kit_adapter": _sha256(expected_adapter),
        "imported_adapter": _sha256(imported_adapter),
        "base_kit_contract": _sha256(expected_contract),
        "vendored_contract": _sha256(vendored_contract),
        "imported_contract": _sha256(imported_contract),
    }
    if hashes["imported_adapter"] != hashes["base_kit_adapter"]:
        raise RuntimeError(
            "installed HiFloat4 LightX2V adapter differs from archived v4.9.2 adapter: "
            f"imported={imported_adapter} expected={expected_adapter}"
        )
    if len({hashes["base_kit_contract"], hashes["vendored_contract"], hashes["imported_contract"]}) != 1:
        raise RuntimeError("LightX2V v4.9.2 contract copies are not byte-identical")

    disk_contract = json.loads(expected_contract.read_text(encoding="utf-8"))
    if dict(module.DISTILL_RUNTIME_CONTRACT) != disk_contract:
        raise RuntimeError("imported LightX2V adapter contract differs from archived contract")

    required = (
        "HIF4CacheRuntime",
        "activate_lightx2v_hooks",
        "deactivate_lightx2v_hooks",
        "build_lightx2v_distill_pipeline",
        "validate_effective_pipeline_config_against_contract",
        "validate_distill_weight_layout",
    )
    missing = [name for name in required if not hasattr(module, name)]
    if missing:
        raise RuntimeError(f"archived adapter API missing: {missing}")

    audit = {
        "artifact": "prox_archived_lightx2v_v492_adapter_binding_v1",
        "passed": True,
        "source_tree": source_tree,
        "imported_adapter": str(imported_adapter),
        "base_kit_adapter": str(expected_adapter),
        "imported_contract": str(imported_contract),
        "base_kit_contract": str(expected_contract),
        "vendored_contract": str(vendored_contract),
        "sha256": hashes,
        "model_cls": disk_contract["model_cls"],
        "task": disk_contract["task"],
        "scheduler": disk_contract["scheduler"],
        "denoising_step_list": disk_contract["denoising_step_list"],
        "boundary_step_index": disk_contract["boundary_step_index"],
        "use_image_encoder": disk_contract["use_image_encoder"],
    }
    return module, audit


class ArchivedV492PipelineAdapter:
    def __init__(self, args: argparse.Namespace):
        module, binding_audit = _load_archived_adapter(args)
        self._module = module
        contract = dict(module.DISTILL_RUNTIME_CONTRACT)

        layout = module.validate_distill_weight_layout(
            base_model_dir=args.base_model_dir,
            high_noise_ckpt=args.high_noise_ckpt,
            low_noise_ckpt=args.low_noise_ckpt,
            check_hash=False,
        )
        self.runtime = module.HIF4CacheRuntime(args.hif4_cache_path)
        self.cache_binding = validate_meta(
            self.runtime.meta, module=module, layout=layout, contract=contract
        )
        self.cache_record_counts = validate_records(self.runtime)
        module.activate_lightx2v_hooks(runtime=self.runtime)
        try:
            self.pipe = module.build_lightx2v_distill_pipeline(
                base_model_dir=args.base_model_dir,
                high_noise_ckpt=args.high_noise_ckpt,
                low_noise_ckpt=args.low_noise_ckpt,
                device_id=0,
                height=int(contract["target_height"]),
                width=int(contract["target_width"]),
                num_frames=int(contract["target_video_length"]),
                fps=int(contract["fps"]),
                attention=str(contract["attention"]),
                cpu_offload=bool(contract["cpu_offload"]),
                offload_granularity=str(contract["offload_granularity"]),
                t5_cpu_offload=bool(contract["t5_cpu_offload"]),
                vae_cpu_offload=bool(contract["vae_cpu_offload"]),
            )
        except Exception:
            module.deactivate_lightx2v_hooks()
            raise

        actual = getattr(getattr(self.pipe, "runner", None), "config", None)
        if actual is None:
            self.close()
            raise RuntimeError("archived LightX2V adapter did not expose runner.config")
        module.validate_effective_pipeline_config_against_contract(actual)

        scheduler = getattr(getattr(self.pipe, "runner", None), "scheduler", None)
        audit = {
            **binding_audit,
            "artifact": "prox_archived_lightx2v_v492_pipeline_resolution_v1",
            "base_model_dir": str(Path(args.base_model_dir).resolve()),
            "high_noise_ckpt": str(Path(args.high_noise_ckpt).resolve()),
            "low_noise_ckpt": str(Path(args.low_noise_ckpt).resolve()),
            "hif4_cache_path": str(Path(args.hif4_cache_path).resolve()),
            "hif4_cache_binding": self.cache_binding,
            "hif4_cache_record_counts": self.cache_record_counts,
            "scheduler_class": None if scheduler is None else scheduler.__class__.__name__,
            "resolved": {
                key: actual.get(key) if hasattr(actual, "get") else actual[key]
                for key in (
                    "model_cls", "task", "infer_steps", "target_video_length",
                    "target_height", "target_width", "fps", "attention",
                    "denoising_step_list", "boundary_step_index",
                    "use_image_encoder", "vae_stride",
                )
                if (hasattr(actual, "get") and actual.get(key, None) is not None) or (not hasattr(actual, "get") and key in actual)
            },
        }
        private_root = os.environ.get("PROX_PRIVATE_JOB_ROOT", "").strip()
        if private_root:
            atomic_json(Path(private_root) / "archived_lightx2v_v492.audit.json", audit)
        print(json.dumps(audit, ensure_ascii=False, sort_keys=True), flush=True)

    def generate(self, record: dict[str, Any], output_path: str) -> Any:
        # Deliberately identical to the archived generator call.
        return self.pipe.generate(
            seed=int(record["seed"]),
            image_path=str(record["image_path"]),
            prompt=str(record["prompt"]),
            negative_prompt=str(record.get("negative_prompt", "")),
            save_result_path=str(output_path),
        )

    def runtime_report(self) -> dict[str, Any]:
        return dict(self.runtime.report())

    def close(self, runtime_report_path: str = "") -> None:
        if getattr(self, "runtime", None) is not None and runtime_report_path:
            self.runtime.write_report(runtime_report_path)
        if getattr(self, "_module", None) is not None:
            self._module.deactivate_lightx2v_hooks()


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Run Prox capture using the exact archived v4.9.2 LightX2V distill adapter."
    )
    p.add_argument("--manifest", required=True)
    p.add_argument("--project-root", required=True)
    p.add_argument("--base-kit-root", required=True)
    p.add_argument("--lightx2v-repo", required=True)
    p.add_argument("--wan-w4a4-repo", required=True)
    p.add_argument("--hif4-main-repo", required=True)
    p.add_argument("--base-model-dir", required=True)
    p.add_argument("--high-noise-ckpt", required=True)
    p.add_argument("--low-noise-ckpt", required=True)
    p.add_argument("--hif4-cache-path", required=True)
    p.add_argument("--hif4-runtime-report", required=True)
    p.add_argument("--contract-json", required=True)
    p.add_argument("--scratch", required=True)
    p.add_argument("--start", type=int, default=0)
    p.add_argument("--limit", type=int, default=0)
    p.add_argument("--keep-videos", action="store_true")
    p.add_argument("--record-output-names", action="store_true")
    p.add_argument("--jsonl-output", default="")
    p.add_argument("--output", required=True)
    return p.parse_args()


def main() -> None:
    args = parse_args()
    if os.environ.get("PROX_PATCH_ENABLE") != "1":
        raise RuntimeError("PROX_PATCH_ENABLE=1 is required")

    from prox_capture_runtime import clear_context, patch_status, set_context

    if not patch_status()["installed"]:
        raise RuntimeError("Prox LightX2V runtime patch was not installed by sitecustomize")
    rows = [_normalise_record(r, i) for i, r in enumerate(_load_manifest(args.manifest))]
    rows = rows[args.start : None if args.limit <= 0 else args.start + args.limit]
    if not rows:
        raise RuntimeError("selected manifest range is empty")

    scratch = Path(args.scratch)
    scratch.mkdir(parents=True, exist_ok=True)
    adapter = ArchivedV492PipelineAdapter(args)
    completed: list[dict[str, Any]] = []
    runtime_snapshot: dict[str, Any] = {}
    try:
        for i, record in enumerate(rows):
            set_context(record)
            if args.record_output_names:
                output_name = str(record.get("output_name", "")).strip()
                if not output_name or Path(output_name).name != output_name or not output_name.lower().endswith(".mp4"):
                    raise RuntimeError(f"record {i}: invalid output_name={output_name!r}")
                out = scratch / output_name
            else:
                out = scratch / f"{i:04d}_{record['role']}_{record['source_group']}_{record['seed']}.mp4"
            try:
                adapter.generate(record, str(out))
            finally:
                clear_context()
            item = {
                "status": "ok" if out.exists() and out.stat().st_size > 0 else "missing_output",
                "role": record["role"],
                "dimension": record.get("dimension"),
                "prompt": record["prompt"],
                "image_name": record.get("image_name", Path(record["image_path"]).name),
                "image_path": record["image_path"],
                "source_group": record["source_group"],
                "seed": record["seed"],
                "videoid": record["videoid"],
                "save_path": str(out.resolve()),
                "output_exists": out.exists(),
                "output_size": out.stat().st_size if out.exists() else 0,
            }
            if item["status"] != "ok":
                raise RuntimeError(f"LightX2V did not produce a non-empty video: {out}")
            completed.append(item)
            if args.jsonl_output:
                jp = Path(args.jsonl_output)
                jp.parent.mkdir(parents=True, exist_ok=True)
                with jp.open("a", encoding="utf-8") as jf:
                    jf.write(json.dumps(item, ensure_ascii=False, sort_keys=True) + "\n")
                    jf.flush()
                    os.fsync(jf.fileno())
            if out.exists() and not args.keep_videos:
                out.unlink()
        runtime_snapshot = adapter.runtime_report()
        if int(runtime_snapshot.get("linear_forward_calls", 0)) <= 0:
            raise RuntimeError("archived HIF4 runtime reported no linear_forward_calls")
        if int(runtime_snapshot.get("activation_qdq_calls", 0)) <= 0:
            raise RuntimeError("archived HIF4 runtime reported no activation_qdq_calls")
    finally:
        adapter.close(args.hif4_runtime_report)

    atomic_json(args.output, {
        "artifact": "prox_wan_archived_lightx2v_v492_capture_run_v1",
        "passed": True,
        "num_records": len(completed),
        "patch": patch_status(),
        "completed": completed,
        "hif4_cache_path": str(Path(args.hif4_cache_path).resolve()),
        "hif4_runtime_report": runtime_snapshot,
        "hif4_runtime_report_path": str(Path(args.hif4_runtime_report).resolve()),
        "cache_binding_validator": "tools.archived_cache_contract.validate_meta",
        "lightx2v_runtime": "exact archived v4.9.2 adapter, HIF4CacheRuntime and contract",
        "scope": "full four-step LightX2V trajectory; FFN sparse execution is numerically emulated unless a sparse kernel is separately installed",
    })


if __name__ == "__main__":
    main()
