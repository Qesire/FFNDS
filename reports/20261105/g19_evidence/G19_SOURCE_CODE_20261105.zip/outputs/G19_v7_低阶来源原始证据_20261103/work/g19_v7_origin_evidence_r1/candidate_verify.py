"""Compute-node-only verification of existing S3 EDGE_FULL_RJD candidate tensors.

Numerical checks are not strict error bounds. E2 must come from a separately
identified evaluation of the same Q2 tensor and numeric convention. This module
never chooses candidate geometry, fits a new representation, or writes artifacts.
"""
import hashlib
import math
import re


def _hash_stream(f):
    f.seek(0); digest=hashlib.sha256()
    for buf in iter(lambda:f.read(1024*1024),b''): digest.update(buf)
    return digest.hexdigest()


def _load_checked(asset,device):
    """Require scheduler guard before opening even the candidate file."""
    from runtime_guard import require_compute_allocation
    require_compute_allocation()
    import torch
    if not isinstance(asset,dict) or not isinstance(asset.get('path'),str) or not re.fullmatch(r'[0-9a-f]{64}',asset.get('sha256','')): raise ValueError('asset path and lowercase SHA256 required')
    with open(asset['path'],'rb') as f:
        before=_hash_stream(f)
        if before!=asset['sha256']: raise ValueError('candidate SHA256 mismatch')
        f.seek(0); obj=torch.load(f,weights_only=True,map_location=device)
        if _hash_stream(f)!=before: raise ValueError('candidate changed during load')
    return obj,before


def verify_candidate(p,a2,V,E2,asset,*,relative_tolerance=1e-9,geometry_tolerance=1e-9):
    """Verify exact stored coefficients in original metric; inputs are torch float64.

    p:(m,d), a2:(m,), V:(m,out); E2 is the independently derived Q2 energy.
    asset={'path':..., 'sha256':...}. EDGE_FULL has k=d-1 and floor(k/2)
    distinct strictly ordered edges. Results are numerical, not certified bounds.
    Fails closed on coefficient or geometry mismatch. No clipping of raw residual.
    """
    import torch
    if any(not math.isfinite(v) or v<=0 for v in (relative_tolerance,geometry_tolerance)): raise ValueError('invalid tolerances')
    if any(not isinstance(x,torch.Tensor) for x in (p,a2,V)) or p.ndim!=2 or a2.ndim!=1 or V.ndim!=2: raise ValueError('invalid tensor geometry')
    m,d=p.shape
    if d<2 or m<1 or a2.shape!=(m,) or V.shape[0]!=m or V.shape[1]<1 or any(x.dtype!=torch.float64 or x.device!=p.device or not torch.isfinite(x).all().item() for x in (p,a2,V)): raise ValueError('finite matching float64 tensors required')
    if not isinstance(E2,(int,float)) or isinstance(E2,bool) or not math.isfinite(E2) or E2<0: raise ValueError('E2 must be nonnegative finite')
    with torch.no_grad():
        # Support and normalization are needed for the Hermite matrix identity.
        norms=torch.linalg.vector_norm(p,dim=1)
        if torch.any((torch.abs(norms-1)>geometry_tolerance)&(norms!=0)).item() or torch.any((norms==0)&(a2!=0)).item(): raise ValueError('invalid normalized p rows')
        p_perp=float(torch.max(torch.abs(p.sum(dim=1))/math.sqrt(d)).item())
        if p_perp>geometry_tolerance: raise ValueError('p rows outside centered support')
        obj,digest=_load_checked(asset,p.device)
        if not isinstance(obj,dict) or obj.get('status')!='OK' or obj.get('kind')!='edges': raise ValueError('not an EDGE candidate')
        B,C,E,edges=(obj.get(k) for k in ('B','C','E','edges')); k=d-1; n=k//2; o=V.shape[1]
        if any(not isinstance(x,torch.Tensor) or x.dtype!=torch.float64 or x.device!=p.device or not torch.isfinite(x).all().item() for x in (B,C,E)): raise ValueError('candidate tensors must be finite float64')
        if B.shape!=(d,k) or C.shape!=(k,o) or E.shape!=(n,o) or not isinstance(edges,(list,tuple)) or len(edges)!=n: raise ValueError('EDGE_FULL geometry mismatch')
        pairs=[]
        for edge in edges:
            if not isinstance(edge,(list,tuple)) or len(edge)!=2 or any(type(x) is not int for x in edge): raise ValueError('invalid edge')
            i,j=edge
            if not 0<=i<j<k: raise ValueError('invalid edge indices')
            pairs.append((i,j))
        if len(set(pairs))!=n: raise ValueError('duplicate edges')
        gram=B.T@B; gram.diagonal().sub_(1)
        orth_max=float(gram.abs().max().item()); del gram
        support_max=float(torch.max(torch.abs(B.sum(dim=0))/math.sqrt(d)).item())
        if orth_max>geometry_tolerance or support_max>geometry_tolerance: raise ValueError('candidate basis violates orthogonality/support tolerance')
        H=p@B; weighted=a2[:,None]*V
        C_true=(H*H).T@weighted
        Cnorm=float(torch.linalg.vector_norm(C_true).item()); Cstored=float(torch.linalg.vector_norm(C).item())
        Cdiff=float(torch.linalg.vector_norm(C-C_true).item()); Crel=Cdiff/max(Cnorm,Cstored,1e-300)
        Ccross=float(torch.sum(C*C_true).item()); Eerr2=0.; Etrue2=0.; Estored2=0.; Ecross=0.
        for start in range(0,n,64):
            part=pairs[start:start+64]; ii=[x[0] for x in part]; jj=[x[1] for x in part]
            E_true=math.sqrt(2)*(H[:,ii]*H[:,jj]).T@weighted; Es=E[start:start+len(part)]
            Eerr2+=float(torch.sum((Es-E_true)**2).item()); Etrue2+=float(torch.sum(E_true*E_true).item())
            Estored2+=float(torch.sum(Es*Es).item()); Ecross+=float(torch.sum(Es*E_true).item())
        Erel=math.sqrt(Eerr2)/max(math.sqrt(Etrue2),math.sqrt(Estored2),1e-300)
        if not all(math.isfinite(x) for x in (Cnorm,Cstored,Cdiff,Crel,Ccross,Eerr2,Etrue2,Estored2,Ecross,Erel)): raise ValueError('nonfinite coefficient statistics')
        if Crel>relative_tolerance or Erel>relative_tolerance: raise ValueError(f'candidate coefficient mismatch C_relative={Crel} E_relative={Erel}')
        diag_norm2=Cstored*Cstored; candidate_norm2=diag_norm2+Estored2; cross=Ccross+Ecross
        residual=float(E2+candidate_norm2-2*cross)
        if not math.isfinite(residual): raise ValueError('nonfinite residual')
        return {'status':'COEFFICIENT_CHECKS_PASSED_NUMERICS_UNASSESSED','numerical_status':'UNASSESSED_NOT_CERTIFIED','candidate_sha256':digest,
                'E2_input':float(E2),'C_relative_error':Crel,'E_relative_error':Erel,
                'coefficient_relative_tolerance':relative_tolerance,'geometry_tolerance':geometry_tolerance,
                'basis_orthogonality_max_abs':orth_max,'basis_support_sum_over_sqrt_d_max_abs':support_max,'p_support_sum_over_sqrt_d_max_abs':p_perp,
                'diag_energy':diag_norm2,'edge_energy':Estored2,'candidate_norm2':candidate_norm2,'true_cross':cross,
                'diag_capture_over_E2':diag_norm2/E2 if E2>0 else None,'diag_plus_edge_capture_over_E2':candidate_norm2/E2 if E2>0 else None,
                'frobenius_residual_raw':residual,'frobenius_residual_over_E2_raw':residual/E2 if E2>0 else None,
                'negative_residual_diagnostic':residual<0,'zero_energy':E2==0,'edge_count':n,'directions':k,
                'caveat':'Floating-point identities and given E2 are numerical only; no interval or rounding certificate.'}

