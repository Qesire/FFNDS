import hashlib, math, sys, tempfile, types, unittest
from pathlib import Path
from unittest.mock import patch
import torch
import candidate_verify as v
T=torch.float64

class Tests(unittest.TestCase):
 def geometry(self):
  torch.manual_seed(5); d=4; raw=torch.randn((d,3),dtype=T); raw-=raw.mean(dim=0,keepdim=True); B=torch.linalg.qr(raw).Q
  p=torch.randn((6,d),dtype=T); p-=p.mean(dim=1,keepdim=True); p/=p.norm(dim=1,keepdim=True)
  a=torch.randn(6,dtype=T); V=torch.randn((6,2),dtype=T); Ms=torch.stack([p.T@torch.diag(a*V[:,j])@p for j in range(2)])
  C=torch.stack([torch.diag(B.T@M@B) for M in Ms],dim=1); E=torch.stack([math.sqrt(2)*(B[:,0]@M@B[:,2]) for M in Ms])[None,:]
  obj={'status':'OK','kind':'edges','B':B,'C':C,'E':E,'edges':[(0,2)]}; E2=float(torch.sum(Ms*Ms))
  return p,a,V,Ms,E2,obj
 def save(self,folder,obj):
  path=Path(folder)/'candidate.pt';torch.save(obj,path);return {'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
 def invoke(self,p,a,V,E2,asset):
  g=types.ModuleType('runtime_guard');g.require_compute_allocation=lambda:{'synthetic':True}
  with patch.dict(sys.modules,{'runtime_guard':g}): return v.verify_candidate(p,a,V,E2,asset)
 def test_exact_original_metric(self):
  p,a,V,Ms,E2,obj=self.geometry()
  with tempfile.TemporaryDirectory() as tmp:
   result=self.invoke(p,a,V,E2,self.save(tmp,obj));B=obj['B'];C=obj['C'];E=obj['E'];approx=[]
   for j in range(2):
    M=B@torch.diag(C[:,j])@B.T+(E[0,j]/math.sqrt(2))*(torch.outer(B[:,0],B[:,2])+torch.outer(B[:,2],B[:,0]));approx.append(M)
   true_residual=float(torch.sum((Ms-torch.stack(approx))**2))
   self.assertAlmostEqual(result['frobenius_residual_raw'],true_residual,places=11)
   self.assertAlmostEqual(result['diag_plus_edge_capture_over_E2'],result['candidate_norm2']/E2)
   self.assertEqual(result['edge_count'],1);self.assertEqual(result['numerical_status'],'UNASSESSED_NOT_CERTIFIED')
 def test_coefficient_corruption_fails(self):
  p,a,V,Ms,E2,obj=self.geometry();obj['E']=obj['E']+.01
  with tempfile.TemporaryDirectory() as tmp:
   with self.assertRaisesRegex(ValueError,'coefficient mismatch'): self.invoke(p,a,V,E2,self.save(tmp,obj))
 def test_nonorthogonal_and_invalid_edge_fail(self):
  p,a,V,Ms,E2,obj=self.geometry();obj['B']=obj['B'].clone();obj['B'][:,1]+=obj['B'][:,0]*.01
  with tempfile.TemporaryDirectory() as tmp:
   with self.assertRaisesRegex(ValueError,'orthogonality'): self.invoke(p,a,V,E2,self.save(tmp,obj))
  p,a,V,Ms,E2,obj=self.geometry();obj['edges']=[(2,0)]
  with tempfile.TemporaryDirectory() as tmp:
   with self.assertRaisesRegex(ValueError,'edge indices'): self.invoke(p,a,V,E2,self.save(tmp,obj))
 def test_hash_mismatch_and_guard_first(self):
  p,a,V,Ms,E2,obj=self.geometry()
  with tempfile.TemporaryDirectory() as tmp:
   asset=self.save(tmp,obj);asset['sha256']='0'*64
   with self.assertRaisesRegex(ValueError,'SHA256 mismatch'): self.invoke(p,a,V,E2,asset)
   fake=types.ModuleType('runtime_guard');fake.require_compute_allocation=lambda: (_ for _ in ()).throw(RuntimeError('NO_ALLOCATION'))
   with patch.dict(sys.modules,{'runtime_guard':fake}), patch('builtins.open') as opened:
    with self.assertRaisesRegex(RuntimeError,'NO_ALLOCATION'): v.verify_candidate(p,a,V,E2,asset)
    opened.assert_not_called()
 def test_negative_residual_never_clipped(self):
  p,a,V,Ms,E2,obj=self.geometry()
  with tempfile.TemporaryDirectory() as tmp:
   result=self.invoke(p,a,V,0.,self.save(tmp,obj));self.assertLess(result['frobenius_residual_raw'],0);self.assertTrue(result['negative_residual_diagnostic']);self.assertIsNone(result['diag_capture_over_E2'])
 def test_invalid_inputs(self):
  p,a,V,Ms,E2,obj=self.geometry()
  with tempfile.TemporaryDirectory() as tmp:
   asset=self.save(tmp,obj)
   with self.assertRaisesRegex(ValueError,'E2'): self.invoke(p,a,V,float('nan'),asset)
   with self.assertRaisesRegex(ValueError,'float64'): self.invoke(p.float(),a,V,E2,asset)
   q=p+torch.ones_like(p)*.001; q=q/q.norm(dim=1,keepdim=True)
   with self.assertRaisesRegex(ValueError,'centered'): self.invoke(q,a,V,E2,asset)
if __name__=='__main__': unittest.main(verbosity=2)
