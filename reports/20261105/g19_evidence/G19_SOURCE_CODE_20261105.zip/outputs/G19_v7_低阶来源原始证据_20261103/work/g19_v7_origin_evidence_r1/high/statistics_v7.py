"""Paired asymptotic statistics; not finite-sample or numerical certificates."""
import math, hashlib, json
import numpy as np
from statistics import NormalDist


def rng_for(seed,namespace,expert,layer,stream=0):
    if namespace not in ('DEVELOPMENT','PLANNING','CONFIRMATION'): raise ValueError('unknown namespace')
    if type(seed)!=int or seed<0 or type(layer)!=int or layer<0 or type(stream)!=int or stream<0 or not isinstance(expert,str) or not expert: raise ValueError('invalid stream identity')
    identity=json.dumps([seed,namespace,expert,layer,stream],separators=(',',':')).encode()
    entropy=np.frombuffer(hashlib.sha256(identity).digest(),dtype='<u4').tolist()
    return np.random.Generator(np.random.PCG64(np.random.SeedSequence(entropy)))


def _triplet(Y,D,C,n=None):
    Y,D,C=(np.asarray(x,dtype=float) for x in (Y,D,C))
    if Y.ndim!=1 or Y.shape!=D.shape or D.shape!=C.shape or len(Y)<2 or (n is not None and len(Y)!=n) or not all(np.isfinite(x).all() for x in (Y,D,C)): raise ValueError('invalid paired blocks')
    return Y,D,C


def cv_pilot(Y,D,C,c,*,cost_raw,cost_cv,delta,alpha,K):
    """Exactly 512 independent blocks: fit 128, select 128, plan 256.
    c must match the estimand and fixed control; returned lambda is frozen.
    """
    Y,D,C=_triplet(Y,D,C,512)
    if not np.isfinite(c) or c<0 or not np.isfinite(cost_raw) or not np.isfinite(cost_cv) or min(cost_raw,cost_cv)<=0: raise ValueError('bad control or costs')
    denom=D[:128].mean()
    if denom<=0: raise ValueError('pilot denominator nonpositive')
    theta=Y[:128].mean()/denom; varc=np.var(C[:128],ddof=1)
    lam=float(np.cov(Y[:128]-theta*D[:128],C[:128],ddof=1)[0,1]/varc) if varc>1e-24 else 0.
    y,d,cobs=Y[128:256],D[128:256],C[128:256]
    if d.mean()<=0: raise ValueError('selection denominator nonpositive')
    raw=float(np.var(y-theta*d,ddof=1)/d.mean()**2*cost_raw)
    adjusted=float(np.var(y-lam*(cobs-c)-theta*d,ddof=1)/d.mean()**2*cost_cv)
    selected=bool(raw>0 and adjusted<=.9*raw and np.isfinite(adjusted)); lam=lam if selected else 0.
    y,d,cobs=Y[256:],D[256:],C[256:]; u=y-lam*(cobs-c)
    if d.mean()<=0: raise ValueError('planning denominator nonpositive')
    ratio=u.mean()/d.mean(); sd=float(np.std((u-ratio*d)/d.mean(),ddof=1))
    return {'theta_ref':float(theta),'lambda':lam,'cv_selected':selected,'raw_cost_variance':raw,'cv_cost_variance':adjusted,'planning_ratio':float(ratio),'s_psi':sd,'plan':plan_n(sd,delta,alpha,K),'split':[128,128,256], 'status':'STATISTICAL_APPROX'}


def plan_n(s_psi,delta,alpha,K):
    if not np.isfinite(s_psi) or s_psi<0 or not np.isfinite(delta) or delta<=0 or not 0<alpha<1 or type(K)!=int or K<1: raise ValueError('bad planning arguments')
    c=NormalDist().inv_cdf(1-alpha/(2*K)); reserve=delta/10; effective=delta-2*reserve
    raw=math.ceil(((c+NormalDist().inv_cdf(.9))*2*s_psi/effective)**2)
    required=1 << (max(1024,raw)-1).bit_length()
    return {'n_required':required,'n_run_cap':min(required,16384),'status':'UNDERPOWERED' if required>16384 else 'PLANNED','numerical_reserve_not_bound':reserve}


def fieller_set(U,D,alpha=.025,K=1):
    """Full asymptotic Fieller set represented by closed intervals; None means infinity.
    denominator_positive is separate and required for confirmatory interpretation.
    """
    U=np.asarray(U,dtype=float); D=np.asarray(D,dtype=float)
    if U.ndim!=1 or U.shape!=D.shape or len(U)<2 or not np.isfinite(U).all() or not np.isfinite(D).all() or not 0<alpha<1 or type(K)!=int or K<1: raise ValueError('bad paired data')
    n=len(U); u=float(U.mean()); d=float(D.mean()); V=np.cov(U,D,ddof=1); c=NormalDist().inv_cdf(1-alpha/(2*K)); k=c*c/n
    a=d*d-k*V[1,1]; b=-2*u*d+2*k*V[0,1]; cc=u*u-k*V[0,0]
    intervals,disc_clamped = fieller_quadratic(a,b,cc)
    return {'intervals':intervals,'denominator_positive':bool(d-c*math.sqrt(V[1,1]/n)>0),'point':u/d if d!=0 else None,'status':'STATISTICAL_APPROX','discriminant_clamped':disc_clamped,'decision_eligible':bool(not disc_clamped and d-c*math.sqrt(V[1,1]/n)>0 and len(intervals)==1 and all(x is not None for x in intervals[0]))}


def fieller_quadratic(a,b,cc):
    """Solve a*t²+b*t+c <= 0; None interval endpoints denote infinity."""
    if not all(math.isfinite(x) for x in (a,b,cc)): raise ValueError('nonfinite quadratic')
    disc=b*b-4*a*cc
    # Cancellation at a double root can produce a spurious empty set.
    disc_tol=64*np.finfo(float).eps*(abs(b*b)+abs(4*a*cc))
    disc_clamped = bool(disc < 0 and -disc <= disc_tol)
    if disc_clamped: disc=0.
    if a==0:
        if b==0: intervals=[[None,None]] if cc<=0 else []
        else:
            root=-cc/b; intervals=[[None,root]] if b>0 else [[root,None]]
    elif disc<0:
        intervals=[[None,None]] if a<0 else []
    elif disc==0 and a<0:
        intervals=[[None,None]]
    else:
        if disc==0:
            roots=[-b/(2*a)]*2
        else:
            q=-.5*(b+math.copysign(math.sqrt(disc),b))
            roots=sorted((q/a,cc/q))
        intervals=[[roots[0],roots[1]]] if a>0 else [[None,roots[0]],[roots[1],None]]
    return intervals,disc_clamped


def stratified_mean_variance(strata,mc_variances,population_sizes):
    """All selected layers must be present; independent per-layer MC errors."""
    if not(len(strata)==len(mc_variances)==len(population_sizes)) or not strata: raise ValueError('bad strata')
    N=sum(population_sizes); mean=0.; variance=0.
    for vals,mc,Nh in zip(strata,mc_variances,population_sizes):
        vals=np.asarray(vals,dtype=float); mc=np.asarray(mc,dtype=float); n=len(vals)
        if vals.ndim!=1 or mc.shape!=vals.shape or n<2 or type(Nh)!=int or Nh<n or not np.isfinite(vals).all() or not np.isfinite(mc).all() or np.any(mc<0): raise ValueError('missing/invalid strata')
        W=Nh/N; f=n/Nh; mean+=W*vals.mean(); variance+=W*W*((1-f)*np.var(vals,ddof=1)/n+f*mc.mean()/n)
    return {'mean':float(mean),'variance':float(variance),'status':'STATISTICAL_APPROX'}

def apply_cv(Y,C,c,lambda_frozen):
    """Apply pre-frozen pilot lambda to independent confirmation blocks; keep signed values."""
    Y=np.asarray(Y,dtype=float); C=np.asarray(C,dtype=float)
    if Y.shape!=C.shape or not np.isfinite(Y).all() or not np.isfinite(C).all() or not np.isfinite(c) or c<0 or not np.isfinite(lambda_frozen): raise ValueError('invalid fixed control')
    return Y-lambda_frozen*(C-c)
