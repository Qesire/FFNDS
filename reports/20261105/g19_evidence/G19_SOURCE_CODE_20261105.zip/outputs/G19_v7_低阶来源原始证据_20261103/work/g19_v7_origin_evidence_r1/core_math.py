"""G19 v7 numerical primitives. Draft; diagnostics do not establish certificates.
Arrays use row samples; W1=(m,d), W2=(d_out,m), A=(d,d_out).
"""
import math
import numpy as np


def tanh_gelu(x):
    x=np.asarray(x,dtype=np.float64)
    return .5*x*(1+np.tanh(np.sqrt(2/np.pi)*(x+.044715*x**3)))


def tanh_gelu_prime(x):
    x=np.asarray(x,dtype=np.float64); c=np.sqrt(2/np.pi)
    t=np.tanh(c*(x+.044715*x**3)); return .5*(1+t)+.5*x*(1-t*t)*c*(1+3*.044715*x*x)


def bf16_round(x):
    """F32 -> BF16 RNE -> F64 lift. Nonfinite/overflow rejected."""
    x=np.asarray(x)
    if x.dtype != np.float32 or not np.isfinite(x).all(): raise ValueError('finite float32 required')
    u=x.view(np.uint32).copy(); rounded=(u+np.uint32(0x7fff)+((u>>16)&1)) & np.uint32(0xffff0000)
    y=rounded.view(np.float32)
    if not np.isfinite(y).all(): raise ValueError('BF16 overflow')
    return y.astype(np.float64)


def bf16_decode(bits):
    u=np.asarray(bits)
    if u.dtype != np.uint16: raise ValueError('uint16 BF16 payload required')
    y=(u.astype(np.uint32)<<16).view(np.float32)
    if not np.isfinite(y).all(): raise ValueError('nonfinite BF16')
    return y.astype(np.float64)


def project_gaussian(z,alpha=1.):
    z=np.asarray(z,dtype=np.float64); d=z.shape[-1]
    if d<2 or not np.isfinite(z).all() or not math.isfinite(alpha) or alpha<=0: raise ValueError('bad input')
    return alpha*math.sqrt(d/(d-1))*(z-z.mean(axis=-1,keepdims=True))


def basis(x,Q):
    if type(Q) is not int or Q<0: raise ValueError('bad order')
    x=np.asarray(x,dtype=np.float64); h=[np.ones_like(x)]
    if Q: h.append(x)
    for q in range(2,Q+1): h.append((x*h[-1]-math.sqrt(q-1)*h[-2])/math.sqrt(q))
    return np.stack(h,axis=-1)


def coefficients(s,b,Q,nodes):
    """Returns (a[m,Q+1], g[m]); GH is a numerical diagnostic."""
    from scipy.special import roots_hermitenorm
    s=np.asarray(s,dtype=float); b=np.asarray(b,dtype=float)
    if s.ndim!=1 or s.shape!=b.shape or np.any(s<0) or not np.isfinite(s).all() or not np.isfinite(b).all() or type(nodes) is not int or nodes<2: raise ValueError('bad coefficients input')
    z,w=roots_hermitenorm(nodes); w=w/np.sqrt(2*np.pi); h=basis(z,Q)
    x=b[:,None]+s[:,None]*z
    a=(tanh_gelu(x)*w)@h; g=tanh_gelu_prime(x)@w
    if not np.isfinite(a).all() or not np.isfinite(g).all(): raise ValueError("nonfinite quadrature output")
    return a,g


def a1_matrix(beta,V,coeffs):
    beta=np.asarray(beta,dtype=float); V=np.asarray(V,dtype=float); a=np.asarray(coeffs,dtype=float)
    if beta.ndim!=2 or V.ndim!=2 or a.ndim!=2 or a.shape[1]<2 or beta.shape[0]!=V.shape[0] or a.shape[0]!=beta.shape[0]: raise ValueError('bad geometry')
    s=np.linalg.norm(beta,axis=1); p=np.divide(beta,s[:,None],out=np.zeros_like(beta),where=s[:,None]>0)
    return (p.T*a[:,1])@V


def evaluate_ffn(z,W1,W2,b1,b2,alpha=1.):
    z=np.asarray(z,dtype=float); W1=np.asarray(W1,dtype=float); W2=np.asarray(W2,dtype=float); b1=np.asarray(b1,dtype=float); b2=np.asarray(b2,dtype=float)
    if W1.ndim!=2 or W2.ndim!=2 or W2.shape[1]!=W1.shape[0] or b1.shape!=(W1.shape[0],) or b2.shape!=(W2.shape[0],) or z.shape[-1]!=W1.shape[1]: raise ValueError('bad geometry')
    if not all(np.isfinite(x).all() for x in (z,W1,W2,b1,b2)): raise ValueError('nonfinite')
    return tanh_gelu(project_gaussian(z,alpha)@W1.T+b1)@W2.T+b2


def hermite_approx(z,beta,V,b2,coeffs):
    """Fixed polynomial <=Q, including b2; zero-scale neurons use only a0."""
    z=np.asarray(z,dtype=float); beta=np.asarray(beta,dtype=float); V=np.asarray(V,dtype=float); a=np.asarray(coeffs,dtype=float)
    s=np.linalg.norm(beta,axis=1); p=np.divide(beta,s[:,None],out=np.zeros_like(beta),where=s[:,None]>0)
    h=basis(z@p.T,a.shape[1]-1); vals=np.sum(h*a,axis=-1)
    # For s=0, higher coefficients should be zero; enforce constant polynomial exactly.
    vals=np.where(s>0,vals,a[:,0]); return vals@V+np.asarray(b2)


def sobolev_tail_bound(Dk_upper,Ek_lower,Q,k):
    if type(Q)!=int or type(k)!=int or Q<k or k<1 or not np.isfinite(Dk_upper) or Dk_upper<0: raise ValueError('bad bound')
    if any(type(q)!=int or not k<=q<=Q or not np.isfinite(v) or v<0 for q,v in Ek_lower.items()): raise ValueError('bad energy')
    fall=lambda q: math.prod(range(q-k+1,q+1))
    budget=Dk_upper-sum(fall(q)*v for q,v in Ek_lower.items())
    if budget<0: raise ValueError('inconsistent bounds')
    return {'upper':budget/fall(Q+1),'status':'CONDITIONAL_ON_INPUT_BOUNDS'}


def _sq(x):
    x=np.asarray(x)
    if not np.isfinite(x).all(): raise ValueError('nonfinite function output')
    result=np.sum(x*x,axis=-1)
    if not np.isfinite(result).all(): raise ValueError('nonfinite squared norm')
    return result


def pick_freeze_block(F,z,w,P,Ahat=None):
    """Rows are independent blocks; F maps rows to rows. P must lie in Pi support."""
    z=np.asarray(z,dtype=float); w=np.asarray(w,dtype=float); P=np.asarray(P,dtype=float); d=z.shape[-1]
    if z.shape!=w.shape or not np.isfinite(z).all() or not np.isfinite(w).all() or P.shape!=(d,d) or not np.isfinite(P).all() or not np.allclose(P,P.T,atol=1e-9,rtol=0) or not np.allclose(P@P,P,atol=1e-9,rtol=0) or not np.allclose(P@np.ones(d),0,atol=1e-9,rtol=0): raise ValueError('invalid fixed projection')
    mix=z@P+w@(np.eye(d)-P)
    y=.25*(_sq(F(z)-F(mix))+_sq(F(-z)-F(-mix)))
    out={'estimand':'FIXED_P_INFORMATION_LOSS','Y':y}
    if Ahat is not None:
        Ahat=np.asarray(Ahat,dtype=float); delta=(z-mix)@Ahat
        out.update(C=.5*_sq(delta),c=float(np.sum(((np.eye(d)-P)@Ahat)**2)))
    return out


class FixedProjectionBasis:
    """Validate orthonormal support basis once; no dense projector is built."""
    def __init__(self, basis, atol=1e-9):
        q=np.array(basis,dtype=np.float64,copy=True)
        if q.ndim!=2 or q.shape[0]<2 or q.shape[1]>q.shape[0]-1 or not np.isfinite(q).all() or not np.isfinite(atol) or atol<=0: raise ValueError('invalid basis')
        if not np.allclose(q.T@q,np.eye(q.shape[1]),atol=atol,rtol=0) or not np.allclose(q.sum(axis=0),0,atol=atol,rtol=0): raise ValueError('basis must be orthonormal in Pi support')
        q.setflags(write=False); self._q=q

    @property
    def basis(self):
        return self._q.view()

    def block(self,F,z,w,Ahat=None):
        z=np.asarray(z,dtype=float); w=np.asarray(w,dtype=float); q=self._q
        if z.shape!=w.shape or z.ndim<1 or z.shape[-1]!=q.shape[0] or not np.isfinite(z).all() or not np.isfinite(w).all(): raise ValueError('invalid blocks')
        mix=w+(z-w)@q@q.T
        out={'estimand':'FIXED_P_INFORMATION_LOSS','Y':.25*(_sq(F(z)-F(mix))+_sq(F(-z)-F(-mix)))}
        if Ahat is not None:
            Ahat=np.asarray(Ahat,dtype=float)
            if Ahat.ndim!=2 or Ahat.shape[0]!=q.shape[0] or not np.isfinite(Ahat).all(): raise ValueError('invalid Ahat')
            out.update(C=.5*_sq((z-mix)@Ahat),c=float(np.sum((Ahat-q@(q.T@Ahat))**2)))
        return out


def representation_error_block(F,G,z,w):
    """Direct same-input error, not fixed-P conditional loss."""
    return {'estimand':'ACTUAL_REPRESENTATION_MSE','U':sum(_sq(F(t)-G(t)) for t in (z,-z,w,-w))/4}


def paired_block(Fo32,Foq,Fd,z,w,Ahat=None):
    """One vector of scalar outputs per independent (z,w) block."""
    ts=(z,-z,w,-w); o=[Fo32(t) for t in ts]; q=[Foq(t) for t in ts]; d=[Fd(t) for t in ts]
    delta=[di-qi for di,qi in zip(d,q)]; rounding=[qi-oi for qi,oi in zip(q,o)]; total=[di-oi for di,oi in zip(d,o)]
    v=lambda f: .25*(_sq(f[0]-f[2])+_sq(f[1]-f[3]))
    avg=lambda xs: sum(xs)/4
    out={'D':v(q),'U_checkpoint':avg([_sq(x) for x in delta]),'U_round':avg([_sq(x) for x in rounding]),'U_total':avg([_sq(x) for x in total]),'cross':avg([2*np.sum(x*y,axis=-1) for x,y in zip(delta,rounding)]),'mean_diff_sample':avg(delta),'mean_diff_norm_unbiased':np.sum((delta[0]+delta[1])*(delta[2]+delta[3]),axis=-1)/4}
    if Ahat is not None:
        residual=[f-t@Ahat for f,t in zip(q,ts)]; out['D_residual']=v(residual)
    return out

def polynomial_residual_block(F,G,z,w):
    """G must be fixed and belong to Gaussian polynomial subspace <=Q.
    Expected U and D_residual upper-bound true tail under that condition;
    block values and finite-sample means are not deterministic upper bounds.
    """
    residual=[F(t)-G(t) for t in (z,-z,w,-w)]
    return {'assumption':'G_FIXED_POLYNOMIAL_DEGREE_LE_Q', 'status':'ALG_EXACT_EXPECTATION_RELATION_ONLY',
            'U':sum(_sq(r) for r in residual)/4,
            'D_residual':.25*(_sq(residual[0]-residual[2])+_sq(residual[1]-residual[3]))}


def affine_error_control(z,w,a,B):
    """For actual-error estimands, E ||a+B^T z||^2=||a||²+||B||F²."""
    return {'C':sum(_sq(np.asarray(t)@B+a) for t in (z,-z,w,-w))/4,
            'c':float(_sq(a)+np.sum(np.asarray(B)**2)), 'estimand':'ACTUAL_REPRESENTATION_MSE'}
