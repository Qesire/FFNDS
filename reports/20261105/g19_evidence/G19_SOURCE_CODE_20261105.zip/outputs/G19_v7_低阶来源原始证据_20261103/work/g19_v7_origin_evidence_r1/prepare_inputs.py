"""Freeze local evidence inputs and isolated guard; never execute model work."""
from pathlib import Path
import hashlib,json,shutil
root=Path(__file__).resolve().parent; work=root.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):return [json.loads(s) for s in p.read_text(encoding='utf8').splitlines()]
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8',newline='\n')
source=work/'g19_v7_formal_checkpoint_confirm_r1'
for f in ('core_math.py','weights_v7.py','statistics_v7.py','input_manifest.json','assets.json','expected_tensor_hashes.json'):
    shutil.copyfile(source/f,root/f)
guard=(source/'runtime_guard.py').read_text(encoding='utf8')
marker="        'S4_CHECKPOINT_CONFIRMATION': {'runner_confirm.py','job_confirm.sh'},"
assert marker in guard
guard=guard.replace(marker,marker+"\n        'ORIGIN_EVIDENCE': {'runner_origin.py','origin_math.py','candidate_verify.py','job_origin.sh','core_math.py'},")
(root/'runtime_guard.py').write_text(guard,encoding='utf8',newline='\n')
job=(source/'job_confirm.sh').read_text(encoding='utf8').replace('g19_v7_confirm','g19_v7_origin').replace('runner_confirm.py','runner_origin.py')
(root/'job_origin.sh').write_text(job,encoding='utf8',newline='\n')
summary={}; evidence={}; s3={}
remote='/public/home/scc/pb23061276/projects/wan-quant/work/g19_v7_formal_s3_r1'
for e in ('high','low'):
    folder=work/'g19_v7_formal_s12_results'/e
    records=rows(folder/'blocks.jsonl')
    assert len(records)==40*512
    evidence[e]={'blocks_sha256':sha(folder/'blocks.jsonl'),'exit_sha256':sha(folder/'EXIT.json'),'s12_stream':'PLANNING/40','blocks_per_layer':512}
    for l in range(40):
        br=[r for r in records if r['layer']==l]
        assert len(br)==512
        for arm in ('Oq','Dq'):
            summary[f'{e}/{l}/{arm}']={name:sum(r[key] for r in br)/512 for name,key in [('V','D_'+arm),('T2','Q2_'+arm),('T4','Q4_'+arm)]}
    for h in range(4):
        shard=f'{e}_s{h}'; folder=work/'g19_v7_formal_s3_results'/shard
        ex=json.loads((folder/'EXIT.json').read_text(encoding='utf8'));assert ex['status']=='SUCCESS'
        for a in rows(folder/'artifacts.jsonl'):
            if a['path'].endswith('_EDGE_FULL_RJD.pt') or a['path'].endswith('_EDGE_FULL_RJD_shared.pt'):
                parts=a['path'].split('_');l=int(parts[0]);arm=parts[1]
                key=f'{e}/{l}/{arm}'; label='OQ_SHARED' if a['path'].endswith('_shared.pt') else 'OWN'
                s3.setdefault(key,{})[label]={'path':remote+f'/{shard}/runs/s3_01/'+a['path'],'sha256':a['sha256']}
assert len(summary)==160 and len(s3)==48 and sum(len(v) for v in s3.values())==72
write(root/'s12_summary.json',summary);write(root/'source_evidence.json',evidence);write(root/'s3_candidates.json',s3)
shutil.copyfile(Path('C:/Users/H/Downloads/G19v7 低阶结构的来源与 FFN 表示选择.md'),root/'SUPPLEMENT_SOURCE.md')
print(json.dumps({'units':len(summary),'candidate_units':len(s3),'candidate_assets':sum(len(v) for v in s3.values()),'supplement_sha256':sha(root/'SUPPLEMENT_SOURCE.md')}))
