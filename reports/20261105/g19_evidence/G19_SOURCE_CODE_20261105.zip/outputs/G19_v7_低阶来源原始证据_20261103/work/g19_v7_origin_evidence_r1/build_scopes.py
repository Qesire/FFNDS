"""Create two finite review proposals, not ACTIVE or execution."""
from pathlib import Path
import json,hashlib,shutil
root=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8',newline='\n')
code=['runner_origin.py','origin_math.py','candidate_verify.py','runtime_guard.py','weights_v7.py','core_math.py','statistics_v7.py','job_origin.sh','test_origin.py','test_candidate_verify.py','AUTHOR_SELF_AUDIT.txt']
inputs=['assets.json','expected_tensor_hashes.json','s12_summary.json','source_evidence.json','s3_candidates.json','SUPPLEMENT_SOURCE.md']
index=[]
for e in ('high','low'):
    p=root/e;p.mkdir(exist_ok=False)
    for f in code+inputs+['input_manifest.json']:shutil.copyfile(root/f,p/f)
    config={'expert':e,'layers':list(range(40)),'seed':2026110301,'gh_nodes':384,'block_rows':512,'sign_count':4,'output_dir':f'/public/home/scc/pb23061276/projects/wan-quant/work/g19_v7_origin_evidence_r1/{e}/runs/origin_01','assets_file':'assets.json','expected_tensor_hashes_file':'expected_tensor_hashes.json','summary_file':'s12_summary.json','candidates_file':'s3_candidates.json'}
    write(p/'config.json',config)
    s={'scope_id':f'G19_V7_ORIGIN_{e.upper()}_R1_20261103','status':'FROZEN_REVIEWED','phase':'ORIGIN_EVIDENCE','authors':['/root','/root/terra_v7_runner','/root/terra_p0_implementation'],
       'active_registry_file':'ACTIVE_RESEARCH.json','activation_requires':'Exact independent ACCEPTED plus finite post-review ACTIVE; draft is not active',
       'config_file':'config.json','config_sha256':sha(p/'config.json'),'input_manifest_file':'input_manifest.json','manifest_sha256':sha(p/'input_manifest.json'),
       'expected_tensor_hashes_file':'expected_tensor_hashes.json','code_sha256':{f:sha(p/f) for f in code},'frozen_inputs_sha256':{f:sha(p/f) for f in inputs},
       'budget':{'max_jobs':1,'gpus_per_job':1,'session_max_gpus':2,'cpus':4,'host_memory_gib':64,'gpu_allocation_peak_gib':40,'wall_seconds':1800,'soft_seconds':1650,'min_free_disk_gib':5,'output_budget_gib':2},
       'finite_stage_jobs':2,'max_stage_gpu_hours':1,'unit_count':80,'units':[{'expert':e,'layer':l,'arm':a} for l in range(40) for a in ('Oq','Dq')],
       'reference':'Same Gaussian alpha1 and lifted Oq/Dq weights as S12, true bias and tanh GELU; no new native forward or video generation',
       'questions_with_opposing_predictions':[
           {'id':'MATCHED_ACTIVATION_VS_COUPLING','baseline':'Scale/bias/write-norm matched independent sign expectation gives Dvar and Dtail; random W2 column flips preserve W2 output Gram and singular values','opposing_predictions':'Tail-only cancellation yields T/Dtail small with V/Dvar near1; low-order amplification yields V/Dvar large without corresponding tail suppression; both may coexist'},
           {'id':'BIAS_LINEAR_PART','baseline':'L0=.5 beta.T V versus actual A1; whole bias sign reversal leaves q>=2 energies invariant','opposing_predictions':'If biases materially affect slope, A1 differs from L0 and E1flip differs while high-order absolute energies stay unchanged; relative tails may change purely through denominator'},
           {'id':'GAUSSIAN_RADIUS','baseline':'Exact Gaussian F2 trace/traceless decomposition under same covariance','opposing_predictions':'Large radial fraction predicts fixedF2 energy lost on uniform sphere; small radial fraction refutes a radial explanation of the observed F2 energy, but not angular/native mismatch'},
           {'id':'S3_PROBE_VS_REPRESENTATION','baseline':'Read72 saved EDGE_FULL own/shared candidates and recompute all coefficients in original metric','opposing_predictions':'If low capture was noisy-probe artifact, direct coefficient energy materially contradicts old probes; if low capture is real, independent coefficient reconstruction confirms large missingF2 energy'}],
       'computations':['Per-neuron real and zero-bias GH384/192 q0..8, stable direct variance/tail2/tail4','Full q1..8 Hermite kernel energies, diagonal terms and signed cross terms; 4 fixed W2 sign controls','Rehash and reproduce all80 A1 assets per expert','Fixed-F2 sphere radial/traceless energy; not wholeFFN spherical risk','Read/recompute36 S3 candidate assets per expert, full5119basis and2559edges','Compare actual S12 V/T2/T4 with matched diagonal D quantities and report all four suppression/amplification factors','Algebraic whole-bias-sign-flip prediction using saved S12 variance, not new forward'],
       'candidate_scope':{'layers':[0,1,7,12,13,19,23,24,28,33,37,38],'Oq':['OWN_EDGE_FULL_RJD'],'Dq':['OWN_EDGE_FULL_RJD','OQ_SHARED_EDGE_FULL_RJD'],'assets_this_job':36},
       'data_contract':{'all_weights_precommitted':True,'all_A1_candidates_precommitted':True,'sign_namespace':'DEVELOPMENT','sign_seed':2026110301,'sign_stream':800,'signs_shared_between_checkpoints':True,'new_FFN_MC_blocks':0,'existing_MC':'S12 PLANNING/40 512 blocks per expert-layer; exploratory reuse with source hashes'},
       'interpretation_limits':['Final weights identify alignment, not causal contribution of training','Dtail/Dvar is ratio of sign-ensemble expectations, not expected random-sign ratio','Zero-bias and whole-bias-reversal are different counterfactuals','q1..8 energy is not total variance unless tail closure demonstrated','FixedF2 sphere energy is not best fullFFN sphere approximation','Coefficient and Gram checks use FP64, numerical status UNASSESSED, no rigorous error certificate','All inference is exploratory; no fresh confirmation or native/video/speedup claim','Actual 107 native corpus identity/location remains separate provenance investigation'],
       'failure_policy':'Each exactscope one job only; no automatic retries or layer replacement. Identity/coefficient/geometry failure terminates with partial receipt. Keep signed finite residuals and diagnostics, never replace missing cases by zero.'}
    write(p/'scope.json',s);index.append({'folder':e,'scope_id':s['scope_id'],'scope_sha256':sha(p/'scope.json')})
write(root/'SCOPE_INDEX.json',index);print(json.dumps(index))
