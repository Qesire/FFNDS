"""Tiny synthetic checks of imported measurement component. No research data/model."""
import importlib.util, json, hashlib, math, sys, unittest
from pathlib import Path
import numpy as np

base=Path(__file__).resolve().parent
module=base/'G19_input_relations/measurement/secant_channel_stats.py'
spec=importlib.util.spec_from_file_location('reviewed_measurement',module)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

# Import test definitions but not their __main__, which would overwrite the package.
sys.path.insert(0,str(module.parent))
test_path=module.with_name('check_secant_channel_stats.py')
testspec=importlib.util.spec_from_file_location('package_test_defs',test_path)
testmod=importlib.util.module_from_spec(testspec);testspec.loader.exec_module(testmod)
run=unittest.TextTestRunner(verbosity=1).run(unittest.defaultTestLoader.loadTestsFromModule(testmod))
assert run.wasSuccessful()

lo0,lo1=-.7,-.1
hi0,hi1=.1,.7
static0=np.array([[lo0,hi0],[lo0,hi0]])
static1=np.array([[lo1,hi1],[lo1,hi1]])
dynamic0=np.array([[lo0,hi0],[hi0,lo0]])
dynamic1=np.array([[lo1,hi1],[hi1,lo1]])
static=m.SecantChannelStats(2).update_endpoints(static0,static1)
dynamic=m.SecantChannelStats(2).update_endpoints(dynamic0,dynamic1)
for name in ('A','B','C'):
    assert np.isclose(getattr(static,name).sum(),getattr(dynamic,name).sum(),rtol=1e-14)
parts_static=m.variance_decomposition(static);parts_dynamic=m.variance_decomposition(dynamic)
assert parts_static['within_channel_slope_variance']<1e-14
assert parts_dynamic['between_channel_mean_variance']<1e-14

# Identical per-channel A/B/C, different cross-channel output residual.
plus0=np.array([[lo0,lo0],[hi0,hi0]]);plus1=np.array([[lo1,lo1],[hi1,hi1]])
minus0=dynamic0;minus1=dynamic1
plus=m.SecantChannelStats(2).update_endpoints(plus0,plus1)
minus=m.SecantChannelStats(2).update_endpoints(minus0,minus1)
for name in ('A','B','C'):np.testing.assert_allclose(getattr(plus,name),getattr(minus,name),rtol=1e-14,atol=1e-15)
alpha=np.full(2,.5);W=np.ones((2,1))
rp=(m.gelu_tanh(plus1)-m.gelu_tanh(plus0)-(plus1-plus0)*alpha)@W
rm=(m.gelu_tanh(minus1)-m.gelu_tanh(minus0)-(minus1-minus0)*alpha)@W
assert float(np.sum(rp**2))>.1 and float(np.sum(rm**2))<1e-28

# Moment residual cancellation can silently produce zero without clipping.
cal=m.SecantChannelStats(1).update_deltas(np.ones((2,1)),np.full((2,1),.5))
da=np.ones((2,1));dh=np.array([[.5+1e-9],[.5-1e-9]])
held=m.SecantChannelStats(1).update_deltas(da,dh)
score=m.evaluate_static_alpha(held,m.fit_static_alpha(cal))
direct=float(np.sum((dh-.5*da)**2))
assert direct>0 and score['hidden_sse']==0 and score['roundoff_clipped_channel_count']==0

# Peano/Gauss constant on phi(a)=a^5, interval [-1/2,1/2].
node=1/(2*math.sqrt(3));exact=(.5)**5-(-.5)**5
gl2=.5*(5*(-node)**4+5*node**4)
assert math.isclose(exact-gl2,math.factorial(5)/4320,rel_tol=1e-14)

# Same complete midpoint/chord marginals; only their pairing changes.
def derivative(a):
    c=math.sqrt(2/math.pi);u=c*(a+.044715*a**3);t=np.tanh(u)
    return .5*(1+t)+.5*a*(1-t*t)*c*(1+3*.044715*a*a)
def gl2_sse(mid,delta):
    h=delta/(2*math.sqrt(3))
    exact=m.gelu_tanh(mid+delta/2)-m.gelu_tanh(mid-delta/2)
    approx=.5*delta*(derivative(mid-h)+derivative(mid+h))
    return float(np.sum((exact-approx)**2))
mid=np.array([0.,2.]);d_a=np.array([2.,.1]);d_b=d_a[::-1]
joint_a=gl2_sse(mid,d_a);joint_b=gl2_sse(mid,d_b)
assert joint_b>1000*joint_a

report={'status':'PASS','synthetic_only':True,'model_experiments':0,'original_package_unchanged':True,
 'numpy_version':np.__version__,'package_synthetic_tests':run.testsRun,
 'measurement_sha256':hashlib.sha256(module.read_bytes()).hexdigest(),
 'same_global_ABC_static_vs_dynamic':{'static':parts_static,'dynamic':parts_dynamic},
 'same_channel_ABC_different_output_risk':{'plus_sse':float(np.sum(rp**2)),'minus_sse':float(np.sum(rm**2))},
 'silent_positive_residual_loss':{'true_f64_direct_sse':direct,'moment_sse':score['hidden_sse'],'clipped_count':score['roundoff_clipped_channel_count']},
 'gl2_a5_remainder':exact-gl2,'expected_120_over_4320':120/4320,
 'same_midpoint_and_chord_marginals_different_joint':{'joint_a_hidden_sse':joint_a,'joint_b_hidden_sse':joint_b,'ratio_b_over_a':joint_b/joint_a}}
(base/'INDEPENDENT_MICROCHECKS.json').write_text(json.dumps(report,indent=2,allow_nan=False),encoding='utf8')
print(json.dumps(report,indent=2))
