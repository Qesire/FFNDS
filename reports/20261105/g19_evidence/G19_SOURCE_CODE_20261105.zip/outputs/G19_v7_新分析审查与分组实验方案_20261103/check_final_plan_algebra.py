"""Synthetic final-plan algebra checks; no source activations or models."""
import json, math
from pathlib import Path
import numpy as np

X=np.array([[1.,0.],[0.,2.],[1.,-1.]])
y=np.array([1.,2.,-.5]);T=np.array([[2.,.3],[0.,.5]]);lam=.7
b=np.linalg.solve(X.T@X+lam*np.eye(2),X.T@y)
Z=X@T
c=np.linalg.solve(Z.T@Z+lam*T.T@T,Z.T@y)
naive=np.linalg.solve(Z.T@Z+lam*np.eye(2),Z.T@y)
assert np.allclose(T@c,b,rtol=1e-13,atol=1e-14)
assert np.linalg.norm(Z@naive-X@b)>.1

# Arbitrary iterate: dual objective is evaluated at the primal residual.
a=np.array([.2,-.1]);r=y-X@a
primal=float(r@r+lam*(a@a))
dual=float(2*y@r-r@r-(X.T@r)@(X.T@r)/lam)
gap=float(np.sum((lam*a-X.T@r)**2)/lam)
assert math.isclose(primal-dual,gap,rel_tol=1e-14)

report={'status':'PASS_SYNTHETIC_ONLY','basis_change_prediction_max_abs':float(np.max(abs(Z@c-X@b))),
 'naive_isotropic_penalty_prediction_difference_norm':float(np.linalg.norm(Z@naive-X@b)),
 'ridge_primal_dual_gap':gap,'direct_primal_minus_dual':primal-dual,
 'zero_failures_n16_one_sided_95_upper':1-.05**(1/16),
 'zero_failures_n59_one_sided_95_upper':1-.05**(1/59),
 'Dq_dense_trajectories':24*2,'Oq_dense_trajectories':6*2,'conditional_E4_candidate_trajectories':16*2,
 'minimum_new_generations_if_all_phases_execute':24*2+6*2+16*2,
 'total_with_additional_32_clean_dense_timing_controls':24*2+6*2+16*2+16*2,
 'model_experiments':0}
Path(__file__).with_name('FINAL_PLAN_ALGEBRA_CHECKS.json').write_text(json.dumps(report,indent=2),encoding='utf8')
print(json.dumps(report,indent=2))
