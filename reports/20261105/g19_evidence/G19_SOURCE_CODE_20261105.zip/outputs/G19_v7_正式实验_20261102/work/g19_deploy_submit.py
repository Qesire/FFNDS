"""Transfer reviewed immutable snapshots and submit each exactly once via Slurm.
Login-node commands are metadata/checksum/scheduler only, never model computation.
"""
import argparse,datetime,hashlib,json,re,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('stage',type=Path);p.add_argument('--folders',nargs='+',required=True);p.add_argument('--dependency-high');p.add_argument('--dependency-low');args=p.parse_args()
root=args.stage.resolve(); cwd=Path.cwd().resolve()
assert root.is_relative_to(cwd/'work')
assert re.fullmatch(r'g19_v7_formal_[a-z0-9_]+',root.name)
index={r['folder']:r for r in json.loads((root/'SCOPE_INDEX.json').read_text(encoding='utf8'))}
ledger=root/'SUBMISSIONS.jsonl'
submitted=[] if not ledger.exists() else [json.loads(s) for s in ledger.read_text(encoding='utf8').splitlines()]
done={s['folder'] for s in submitted}
remote='/public/home/scc/pb23061276/projects/wan-quant/work/'+root.name
def run(argv):
    q=subprocess.run(argv,check=True,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if q.stderr.strip(): print(q.stderr.strip(),flush=True)
    return q.stdout.strip()
def ssh(command):return run(['plink','-batch','-load','107',command])
deps={'high':args.dependency_high,'low':args.dependency_low}
for dep in deps.values(): assert dep is None or re.fullmatch('[0-9]+',dep)
for folder in args.folders:
    assert folder in index and folder not in done and re.fullmatch('[a-z0-9_]+',folder)
    r=root/folder; item=index[folder]; scope=json.loads((r/'scope.json').read_text(encoding='utf8'))
    review=json.loads((r/'INDEPENDENT_REVIEW.json').read_text(encoding='utf8'))
    digest=hashlib.sha256((r/'scope.json').read_bytes()).hexdigest()
    active=json.loads((r/'ACTIVE_RESEARCH.json').read_text(encoding='utf8'))
    assert digest==item['scope_sha256']==review['scope_sha256'] and review['status']=='ACCEPTED'
    assert active['scopes'][scope['scope_id']]['scope_sha256']==digest
    script='job_s3.sh' if scope['phase']=='S3_STRUCTURE_DEVELOPMENT' else 'job_confirm.sh'
    expert='high' if folder.startswith('high') else 'low'
    ssh('mkdir -p '+remote)
    run(['pscp','-q','-batch','-r','-load','107',str(r.relative_to(cwd)),'107.ustc.edu.cn:'+remote+'/'])
    checks=ssh('cd '+remote+'/'+folder+' && sha256sum --quiet -c sha256sums.txt')
    if checks: print(checks,flush=True)
    dep=deps[expert]; option='' if dep is None else ' --dependency=afterany:'+dep
    job=ssh('cd '+remote+'/'+folder+' && sbatch --parsable'+option+' '+script+' '+digest)
    assert re.fullmatch('[0-9]+',job),job
    rec={'folder':folder,'job_id':job,'scope_id':scope['scope_id'],'scope_sha256':digest,'dependency':dep,'remote':remote+'/'+folder,'submitted_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    with ledger.open('a',encoding='utf8') as f:f.write(json.dumps(rec)+'\n')
    deps[expert]=job;done.add(folder);print(json.dumps(rec),flush=True)
print(json.dumps({'last_jobs_by_lane':deps}),flush=True)
