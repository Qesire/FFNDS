"""Package reviewed formal sources, raw scalar evidence and scientific limits."""
import csv,datetime,hashlib,json,math,re,shutil,statistics,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent.parent
work=root/'work'; out=root/'outputs/G19_v7_正式实验_20261102'
out.mkdir(exist_ok=False)
stages=[('g19_v7_formal_s12_r1','g19_v7_formal_s12_results'),('g19_v7_formal_s3_r1','g19_v7_formal_s3_results'),('g19_v7_formal_checkpoint_confirm_r1','g19_v7_formal_checkpoint_confirm_results')]
allowed={'.py','.json','.jsonl','.csv','.txt','.md','.sh','.out','.err'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def copy_tree_small(src,dst):
    for p in src.rglob('*'):
        rel=p.relative_to(src)
        if not p.is_file() or p.suffix not in allowed or any(x in ('deps','__pycache__','.pytest_cache','runs') for x in rel.parts):continue
        target=dst/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
for source,results in stages:
    copy_tree_small(work/source,out/'work'/source)
    copy_tree_small(work/results,out/'work'/results)
for name in ('g19_deploy_submit.py','g19_register_reviewed_stage.py','g19_fetch_formal_logs.py','prepare_g19_next_guards.py','package_g19_formal_results.py'):
    shutil.copyfile(work/name,out/'work'/name)
for name in ('G19_v7_重设计实验方案.md','G19_v7_设计登记.json'):
    shutil.copyfile(root/'outputs'/name,out/name)
s12=load(work/stages[0][1]/'independent_descriptive_summary.json')
s4=load(work/stages[2][1]/'analysis.json')
assert len(s4['rows'])==80
rows=list(csv.DictReader((work/stages[1][1]/'s3_structure_units.csv').open(encoding='utf8')))
families=['FULL_Q2','ORTH_FULL_RJD','EDGE_FULL_RJD','ORTH_SUBSPACE_512','EDGE_SUBSPACE_384_E256']
struct=[]
for family in families:
    r=[x for x in rows if x['candidate']==family and x['available']=='True']
    assert len(r)==48
    struct.append((family,statistics.median(float(x['ratio_mse_over_V']) for x in r),int(r[0]['candidate_main_macs'])))
by_expert={e:{k:sum(r['expert']==e and r['decision']==k for r in s4['rows']) for k in s4['decisions']} for e in ('high','low')}
inconclusive=[r for r in s4['rows'] if r['decision']=='INCONCLUSIVE']
scheduler={}
for _,results in stages:
    for p in (work/results).glob('scheduler*.txt'):
        for line in p.read_text(encoding='utf-8-sig').splitlines():
            if line.startswith('JobId='):
                parts=dict(re.findall(r'(\w+)=([^\s]+)',line));scheduler[parts['JobId']]=parts
assert len(scheduler)==12 and all(x['JobState']=='COMPLETED' and x['ExitCode']=='0:0' for x in scheduler.values())
def seconds(t):
    h,m,s=map(int,t.split(':'));return 3600*h+60*m+s
gpu_seconds=sum(seconds(x['RunTime']) for x in scheduler.values())
nodes=sorted({x['NodeList'] for x in scheduler.values()})
# Check the actual scheduler intervals, not just the requested concurrency.
events=[]
for r in scheduler.values():
    events.extend([(datetime.datetime.fromisoformat(r['StartTime']),1),(datetime.datetime.fromisoformat(r['EndTime']),-1)])
running=peak=0
for _,delta in sorted(events,key=lambda x:(x[0],x[1])):
    running+=delta;peak=max(peak,running)
assert peak<=2
assert all((work/res/'INDEPENDENT_RESULT_REVIEW.txt').is_file() for res in (stages[1][1],stages[2][1]))
job_info={'jobs':[{k:r[k] for k in ('JobId','JobState','ExitCode','NodeList','StartTime','EndTime','RunTime')} for r in scheduler.values()],
          'gpu_seconds_from_one_gpu_job_intervals':gpu_seconds,'gpu_hours':gpu_seconds/3600,'maximum_simultaneous_jobs_from_scheduler_intervals':peak,'nodes':nodes}
(out/'EXECUTION_SUMMARY.json').write_text(json.dumps(job_info,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
overall=s12['overall']
def median(key):return overall[key]['median']*100
report=f'''G19 v7 正式实验执行与结果（2026-11-02）

本轮登记的 12 个 Slurm 作业已全部结束，调度器均为 COMPLETED、ExitCode=0:0。真实权重与 GPU 计算只发生在 {', '.join(nodes)} 的 A100 上；登录节点仅承担传输、元数据核对与作业提交。由实际起止时间重建的最大并发数为 {peak}；单 GPU 作业占用合计 {gpu_seconds/3600:.3f} GPU 小时。

作业完成不等于全部科学问题解决。S3 的 48 个非正交候选仍未解；结果文件保留 INCOMPLETE，不将正常进程退出包装成全部候选成功。

| 阶段 | 实际覆盖 | 作业 | 状态 |
|---|---|---|---|
| S1/S2 全层普查与规划 | 2 专家 ×40层 ×O32/Oq/Dq，240单元；每层对512个独立块 | 127908、127909 | 全量完成，属于规划/描述数据 |
| S3 结构发展实验 | 预抽12层 ×2专家 ×Oq/Dq，48单元；每层对64块及16个独立算子探针 | 127939、127940、127943–127948 | 正交/稀疏边结果完整；非正交分支未解 |
| S4 检查点独立确认 | 固定80层对，每对1024块，共81920块 | 127956、127957 | 收集完整；固定规则统计分析完成 |

O32 是原始存储 F32；Oq 是原权重显式 BF16 最近偶数舍入后提升；Dq 是蒸馏检查点存储 BF16 的解码提升。保留真实 bias、tanh-GELU 和 d=5120,m=13824 的尺寸。参考输入为 u=√(d/(d−1))Πz、z 为标准 Gaussian，alpha=1；不是原生视频输入分布或 BF16 推理评测。

全层结果：低次数性质与输入低秩性质必须分开。

Oq 的二阶直接近似 MSE/V 中位数为 {median('Q2_Oq_MSE_ratio'):.3f}%，四阶为 {median('Q4_Oq_MSE_ratio'):.4f}%；对应 RMS 中位数为 {median('Q2_Oq_RMS_ratio'):.3f}% 和 {median('Q4_Oq_RMS_ratio'):.3f}%。不能把 1.7% MSE 写成 1.7% RMS。

rank1024 固定一阶主子空间的信息损失中位数为 32.089% 的总方差。同一总方差分母下的一阶谱尾中位数为18.506%；逐层差值中位数为14.428个百分点。因此仅靠一阶谱集中程度不能预测整个非线性FFN的输入压缩损失。两检查点的谱/Q2标量非常接近，也不等于同输入输出相同。

结构实验：当前便宜候选尚不能复现完整二阶表示。

以下为全部48个单元的开发样本点估计中位数；每项误差除以同一批参考函数方差。主MAC包含候选的线性旁路；完整Q2使用最佳融合主MAC作为基线。成本列不是实测延时或端到端加速。

| 候选 | MSE/V中位数 | 主MAC/次 |
|---|---:|---:|
'''
labels={'FULL_Q2':'完整Q2','ORTH_FULL_RJD':'全5119维随机共同正交基','EDGE_FULL_RJD':'全维共同基+2559条耦合边','ORTH_SUBSPACE_512':'512方向正交候选','EDGE_SUBSPACE_384_E256':'384方向+256条耦合边'}
for family,error,mac in struct:report+=f'| {labels[family]} | {100*error:.3f}% | {mac/1e6:.3f}M |\n'
report+='''
在相同主MAC预算下，384方向+256边相对512方向的48个点估计都改善，误差下降的中位数为0.141个百分点。改善幅度仍不足以把当前候选提升到完整Q2的误差水平；这不能推出所有稀疏耦合结构都不行。16个算子探针是发展诊断，不构成严格上界或同时置信保证。

48个非正交rank512候选的四次带符号矩阵铅笔尝试均遇到复特征值；24个共享非正交候选因上游缺失而未解。不能据此否定全部非正交共同基、合同分块或低计算结构。当前实验识别的是这些具体构造的能力边界。

一个更有辨别力的结果来自检查点差分：对于全维稀疏边候选，分别拟合两套几何后计算ΔQ2，误差相对真实ΔQ2能量的中位数约57.70；固定Oq几何、只重新拟合Dq系数后，该比值约0.9085。两种方式的总FFN误差却几乎相同。这里的57.70是误差/能量比，不是57.70%，也不表示真实检查点变化很大。

其机制可直接写成 P_D M_D−P_O M_O=P_D ΔM+(P_D−P_O)M_O：分别拟合会把表示空间的变化作用到共同的大背景上，污染很小的真实差分。固定同一Frobenius正交投影P，则残差为(I−P)ΔM，理想精确算术下具有收缩性。因此比较蒸馏机制时应保留共享表示对照；“各自重构误差相近”不足以证明学到了相同结构。此处经验比值仍来自开发样本，不是独立确认。

检查点独立确认：固定2%相对RMS容忍度。

检验量为 E||F_Dq−F_Oq||² / Var(F_Oq)，阈值0.0004。固定K=80、alpha=0.025，使用成对样本的渐近Fieller集合及Bonferroni校正；分母资格、无界/分裂集合和阈值跨越均显式保留。控制变量lambda在规划数据冻结，确认数据来自新随机流CONFIRMATION/400，所有调整值不截零。

| 专家 | 区间整体低于阈值 | 区间整体高于阈值 | 尚不确定 |
|---|---:|---:|---:|
'''
for e,c in by_expert.items():report+=f"| {e} | {c['STAT_EQUIVALENT']} | {c['STAT_ABOVE_TOLERANCE']} | {c['INCONCLUSIVE']} |\n"
c=s4['decisions'];report+=f"| 合计 | {c['STAT_EQUIVALENT']} | {c['STAT_ABOVE_TOLERANCE']} | {c['INCONCLUSIVE']} |\n"
for r in inconclusive:
    lo,hi=r['fieller']['intervals'][0]
    report+=f"\n不确定的是 {r['expert']} 第{r['layer']}层（零起算）：相对RMS点估计 {100*math.sqrt(r['adjusted_point']):.5f}%，由Fieller集合换算的RMS区间约 [{100*math.sqrt(max(0,lo)):.5f}%, {100*math.sqrt(hi):.5f}%]。保留不确定结论，未追加抽样。\n"
report+='''
这些是 Gaussian 参考下的近似统计结论，数值状态仍为 UNASSESSED。每对完成1024块不等于已证明充分功效；GH差异与FP64抽查不是误差包络。对任意固定近似a,B，都有 E[||a||²+(||zB||²+||wB||²)/2]=||a||²+||B||F²；所以GH/A1近似本身只影响控制效率。未认证项包括有限精度计算、FP32输入舍入、forward与参考数学函数的偏差。不能把上述42/37分类升级为严格数值证明、原生分布等价或视频质量结论。

实际使用的数学工具与边界。

已执行带bias的Hermite/Gaussian正交展开、完整一阶Gram谱、固定投影pick-freeze信息损失、完整支持空间上的随机共同对角化、稀疏二次耦合、带符号矩阵铅笔/非正交Gram修正、独立双向算子探针，以及比值影响函数控制变量与Fieller推断。工具直接作用于服务器真实权重。没有把未运行的合同块分解、数值认证或原生性能评测写成已完成。

本轮对最初目标的含义是：应继续寻找能真正降低计算的表示，但不能从低阶误差小直接推出便宜可实现，也不能以低输入秩作为唯一方向。当前全维标量共同基缺乏足够表达力；耦合项提供了小而一致的开发信号。非正交分支需要解决带符号几何的表示问题，不能用筛掉失败样本后的成功均值替代结论。本轮未批准或实现新的生产替换结构。

可复核材料。

work/ 下包含三阶段冻结代码、输入清单、逐scope独立预审、有限ACTIVE、作业编号、START/EXIT、Slurm日志、每块标量记录、逐层CSV、结果前冻结分析脚本和独立结果审查。每个阶段均按作者自审→独立审查→有限登记→校验身份→计算节点执行的顺序推进。结果检查涉及640条原权重payload身份，以及各阶段重复读取的对应回执。

约60GB的S12 A1/投影矩阵及S3候选张量留在服务器，未打入本地包；包内artifacts.jsonl与资产清单保存绝对远端路径及SHA256。执行器在计算节点重新校验输入资产；独立本地审查核验回执一致性，不声称已经下载全部大数组逐字节复核。原始权重没有修改。对完整Q2/共同基没有生产算子延时、吞吐或原生质量测量。
'''
(out/'G19_v7_正式实验报告.md').write_text(report,encoding='utf8')
manifest={str(p.relative_to(out)).replace('\\','/'):sha(p) for p in sorted(out.rglob('*')) if p.is_file()}
(out/'SHA256_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
archive=out.with_suffix('.zip')
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(out.rglob('*')):
        if p.is_file():z.write(p,str(p.relative_to(out.parent)))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps({'report':str(out/'G19_v7_正式实验报告.md'),'archive':str(archive),'zip_bytes':archive.stat().st_size,'zip_sha256':sha(archive),'files':len(manifest),'gpu_hours':gpu_seconds/3600,'max_concurrent_jobs':peak,'checkpoint_decisions':by_expert},ensure_ascii=False))
