"""G19 v7 formal S1/S2 planning runner; no real-weight access outside Slurm."""
import argparse,hashlib,json,math,time
from pathlib import Path
import numpy as np
from runtime_guard import verify_frozen_scope,require_compute_allocation,RunReceipt
from weights_v7 import load_tensor,rne_lift
from statistics_v7 import rng_for
from core_math import coefficients


def validate_config(c):
    if c['expert'] not in ('high','low') or c['layers']!=list(range(40)) or c['blocks']!=512 or c['batch']!=32 or c['gh_nodes']!=384 or c['rank']!=1024 or type(c['seed']) is not int or c['seed']<0:
        raise ValueError('scope must specify one expert, 40 layers, 512 blocks, batch32, GH384 and rank1024')
    if not isinstance(c['output_dir'],str) or not c['output_dir']: raise ValueError('output_dir required')
    if c['expected_tensor_hashes_file']!='expected_tensor_hashes.json': raise ValueError('expected tensor hash file is required')


def paired_scalars_numpy(o,q,d):
    """Independent blocks × (z,-z,w,-w) × output; reference for tiny tests."""
    o,q,d=(np.asarray(x,dtype=np.float64) for x in (o,q,d))
    if o.ndim!=3 or o.shape[1]!=4 or o.shape!=q.shape or q.shape!=d.shape: raise ValueError('bad response shape')
    sq=lambda a: np.sum(a*a,axis=-1)
    var=lambda a:(sq(a[:,0]-a[:,2])+sq(a[:,1]-a[:,3]))/4
    delta=d-q; rounding=q-o; total=d-o
    return {'D_O32':var(o),'D_Oq':var(q),'D_Dq':var(d),'U_checkpoint':sq(delta).mean(1),'U_round':sq(rounding).mean(1),'U_total':sq(total).mean(1),'cross':(2*delta*rounding).sum(-1).mean(1),'mean_diff_norm_unbiased':((delta[:,0]+delta[:,1])*(delta[:,2]+delta[:,3])).sum(-1)/4}


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()


def emit(path,row):
    with path.open('a',encoding='utf8') as f: f.write(json.dumps(row,allow_nan=False,separators=(',',':'))+'\n')


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--scope',type=Path,required=True); ap.add_argument('--scope-sha',required=True); args=ap.parse_args()
    allocation=require_compute_allocation(); root=Path(__file__).resolve().parent
    scope=verify_frozen_scope(root,args.scope,args.scope_sha)
    c=json.loads((root/scope['config_file']).read_text(encoding='utf8')); validate_config(c)
    manifest=json.loads((root/scope['input_manifest_file']).read_text(encoding='utf8'))
    hash_file=scope['expected_tensor_hashes_file']
    if c['expected_tensor_hashes_file']!=hash_file or hash_file not in scope['frozen_inputs_sha256'] or sha(root/hash_file)!=scope['frozen_inputs_sha256'][hash_file]: raise RuntimeError('tensor hash file must be scope bound')
    known=json.loads((root/hash_file).read_text(encoding='utf8'))
    import torch
    import torch.nn.functional as TF
    import scipy
    if not torch.cuda.is_available() or torch.cuda.device_count()!=1: raise RuntimeError('exactly one GPU required')
    total_mem=torch.cuda.get_device_properties(0).total_memory
    if total_mem<32*1024**3: raise RuntimeError('GPU requires at least 32GiB')
    torch.cuda.set_per_process_memory_fraction(min(.95,40*1024**3/total_mem),0)
    torch.set_num_threads(scope['budget']['cpus']); torch.backends.cuda.matmul.allow_tf32=False; torch.backends.cudnn.allow_tf32=False
    out=Path(c['output_dir']); expert=c['expert']; labels=('O32','Oq','Dq')
    with RunReceipt(out,scope,allocation) as receipt:
      receipt.result={'status':'PARTIAL','completed_layers':[],'completed_units':[],'namespace':'PLANNING','inference':'NOT_CONFIRMATION'}
      emit(out/'environment.jsonl',{'scope_sha256':args.scope_sha,'torch':torch.__version__,'numpy':np.__version__,'scipy':scipy.__version__,'device':torch.cuda.get_device_name(),'gpu_memory_bytes':total_mem,'tf32':False,'budget':scope['budget'],'stream':'PLANNING/40','block_split':[128,128,256],'numerical_status':'UNASSESSED'})
      try:
       for layer in c['layers']:
        receipt.check_deadline(); layer_start=time.monotonic(); read_start=time.monotonic(); print(f'START expert={expert} layer={layer}',flush=True)
        models={}
        for model in ('original','distilled'):
         data={}
         for suffix in ('0.weight','0.bias','2.weight','2.bias'):
          receipt.check_deadline(); key=f'{expert}/{model}/blocks.{layer}.ffn.{suffix}'
          arr,rec=load_tensor(manifest,expert,model,layer,suffix,known.get(key)); data[suffix]=arr
          emit(out/'weights.jsonl',{'expert':expert,'model':model,'layer':layer,**rec})
         models[model]=data
        read_seconds=time.monotonic()-read_start
        raw=[models['original'],{key:rne_lift(value) for key,value in models['original'].items()},models['distilled']]
        arms=[{key:torch.as_tensor(value,device='cuda',dtype=torch.float32) for key,value in x.items()} for x in raw]
        d=arms[0]['0.weight'].shape[1]; m=arms[0]['0.weight'].shape[0]; rank=c['rank']
        if (d,m)!=(5120,13824): raise ValueError('unexpected model geometry')
        def fw(z,w,dtype=torch.float32):
         z=z.to(dtype); u=(z-z.mean(-1,keepdim=True))*math.sqrt(d/(d-1))
         return TF.linear(TF.gelu(TF.linear(u,w['0.weight'].to(dtype),w['0.bias'].to(dtype)),approximate='tanh'),w['2.weight'].to(dtype),w['2.bias'].to(dtype))
        analytic=[]
        with torch.no_grad():
         for label,w in zip(labels,arms):
          receipt.check_deadline(); W=w['0.weight'].double(); beta=(W-W.mean(1,keepdim=True))*math.sqrt(d/(d-1)); s=beta.norm(dim=1); p=beta/s.clamp_min(1e-300)[:,None]; V=w['2.weight'].double().T; del W,beta
          gh_start=time.monotonic(); coeff=[]; half=[]
          for start in range(0,m,512):
           receipt.check_deadline(); end=min(m,start+512); ss=s[start:end].cpu().numpy(); bb=w['0.bias'][start:end].double().cpu().numpy()
           aa,_=coefficients(ss,bb,4,384); ah,_=coefficients(ss,bb,4,192); coeff.append(aa); half.append(ah)
          aa=np.concatenate(coeff); ah=np.concatenate(half); zero=s.cpu().numpy()==0; aa[zero,1:]=0; ah[zero,1:]=0
          if not np.isfinite(aa).all() or not np.isfinite(ah).all(): raise ValueError('nonfinite quadrature')
          gh_delta=float(np.linalg.norm(aa-ah)/max(np.linalg.norm(aa),1e-300)); gh_order_delta=[float(np.linalg.norm(aa[:,j]-ah[:,j])/max(np.linalg.norm(aa[:,j]),1e-300)) for j in range(5)]; a=torch.as_tensor(aa,device='cuda',dtype=torch.float64)
          gh_seconds=time.monotonic()-gh_start; torch.cuda.synchronize(); a1_start=time.monotonic()
          A=(p.T*a[:,1])@V; mu=a[:,0]@V+w['2.bias'].double(); torch.cuda.synchronize(); a1_seconds=time.monotonic()-a1_start
          if not torch.isfinite(A).all() or not torch.isfinite(mu).all(): raise ValueError('nonfinite A1 or mean')
          eig_start=time.monotonic(); gram=A@A.T; eig,U=torch.linalg.eigh(gram); eig=eig.flip(0); U=U.flip(1); neg=float(eig.clamp(max=0).abs().sum()); mass=float(eig.abs().sum()); torch.cuda.synchronize(); eig_seconds=time.monotonic()-eig_start
          if neg>1e-8*max(mass,1e-300): raise ValueError('A1 Gram negative eigen mass')
          eig_raw=eig; eig=eig.clamp_min(0); B=U[:,:rank]; bsum=float(B.sum(0).abs().max()); orth=float((B.T@B-torch.eye(rank,device='cuda',dtype=torch.float64)).abs().max())
          if bsum>1e-7 or orth>1e-8: raise ValueError('PH1 basis invalid')
          write_start=time.monotonic(); path=out/f'{expert}_{layer:02d}_{label}_A1.npy'; np.save(path,A.cpu().numpy()); emit(out/'artifacts.jsonl',{'layer':layer,'arm':label,'kind':'A1','path':path.name,'sha256':sha(path)})
          path=out/f'{expert}_{layer:02d}_{label}_spectrum.npy'; np.save(path,eig_raw.cpu().numpy()); emit(out/'artifacts.jsonl',{'layer':layer,'arm':label,'kind':'H1_EIGENVALUES_RAW','path':path.name,'sha256':sha(path)})
          path=out/f'{expert}_{layer:02d}_{label}_PH1.npy'; np.save(path,B.cpu().numpy()); emit(out/'artifacts.jsonl',{'layer':layer,'arm':label,'kind':'PH1_BASIS','path':path.name,'sha256':sha(path)})
          total_a=float(A.square().sum()); raw_control=float(A.square().sum()-(B.T@A).square().sum())
          if raw_control < -1e-10*max(total_a,1e-300): raise ValueError('negative analytical control expectation')
          ccontrol=max(0.,raw_control)
          emit(out/'units.jsonl',{'expert':expert,'layer':layer,'arm':label,'A1_energy':total_a,'rank_tail_energy':float(eig[rank:].sum()),'rank_tail_energy_raw':{str(r):float(eig_raw[r:].sum()) for r in (256,512,1024,2048)},'rank_tail_energy_policy':'raw signed eigenvalues; selected tail clamps only numerically small negative values','mean_norm_sq':float(mu.square().sum()),'gh_coefficient_relative_delta_384_192':gh_delta,'gh_coefficient_delta_by_order':gh_order_delta,'negative_eigen_mass':neg,'basis_sum_max_abs':bsum,'basis_orth_max_abs':orth,'numerical_status':'UNASSESSED','control_expectation':ccontrol,'control_expectation_before_roundoff_clamp':raw_control,'seconds':{'GH':gh_seconds,'A1':a1_seconds,'eigh':eig_seconds,'array_write_and_hash':time.monotonic()-write_start}})
          analytic.append({'p':p,'V':V,'a':a,'A':A,'mu':mu,'B':B,'control':ccontrol})
          del gram,eig,eig_raw,U,s,coeff,half,aa,ah
        with torch.no_grad():
         for arm_i,base_i,name in ((2,1,'checkpoint'),(1,0,'round')):
          diff=analytic[arm_i]['A']-analytic[base_i]['A']; den=analytic[base_i]['A'].square().sum(); md=analytic[arm_i]['mu']-analytic[base_i]['mu'];
          path=out/f'{expert}_{layer:02d}_{name}_mean_difference.npy'; np.save(path,md.cpu().numpy()); emit(out/'artifacts.jsonl',{'layer':layer,'comparison':name,'kind':'ANALYTIC_MEAN_DIFFERENCE','path':path.name,'sha256':sha(path)})
          emit(out/'analytic_pairs.jsonl',{'expert':expert,'layer':layer,'comparison':name,'A1_difference_sq':float(diff.square().sum()),'A1_reference_sq':float(den),'A1_relative_fro':float(diff.norm()/den.sqrt()) if den>0 else None,'mean_difference_sq':float(md.square().sum()),'affine_control_expectation':float(md.square().sum()+diff.square().sum())})
          if name=='checkpoint': checkpoint_B=diff; checkpoint_a=md
         del diff,md
        gen=rng_for(c['seed'],'PLANNING',expert,layer,40); mc_start=time.monotonic(); control_seconds=0.
        for first in range(0,c['blocks'],c['batch']):
         receipt.check_deadline(); n=min(c['batch'],c['blocks']-first); rawz=gen.standard_normal((n,2,d)).astype(np.float32)
         z=torch.as_tensor(rawz[:,0],device='cuda'); w=torch.as_tensor(rawz[:,1],device='cuda'); T=torch.stack((z,-z,w,-w),dim=1).reshape(n*4,d)
         with torch.no_grad():
          values=[fw(T,arm).double().reshape(n,4,d) for arm in arms]
          o,q,dist=values; delta=dist-q; rounding=q-o; total=dist-o
          sq=lambda x:x.square().sum(-1)
          var=lambda x:(sq(x[:,0]-x[:,2])+sq(x[:,1]-x[:,3]))/4
          result={'D_O32':var(o),'D_Oq':var(q),'D_Dq':var(dist),'U_checkpoint':sq(delta).mean(1),'U_round':sq(rounding).mean(1),'U_total':sq(total).mean(1),'cross':(2*delta*rounding).sum(-1).mean(1),'mean_diff_norm_unbiased':((delta[:,0]+delta[:,1])*(delta[:,2]+delta[:,3])).sum(-1)/4}
          torch.cuda.synchronize(); control_start=time.monotonic()
          result['C_checkpoint']=checkpoint_a.square().sum()+(sq(z.double()@checkpoint_B)+sq(w.double()@checkpoint_B))/2
          torch.cuda.synchronize(); control_seconds+=time.monotonic()-control_start
          for label,arm,an,y in zip(labels,arms,analytic,values):
           td=T.double(); h=td@an['p'].T; H2=(h.square()-1)/math.sqrt(2); H3=(h**3-3*h)/math.sqrt(6); H4=(h**4-6*h.square()+3)/math.sqrt(24)
           linear=td@an['A']; pred2=an['mu']+linear+(H2*an['a'][:,2])@an['V']; pred4=pred2+(H3*an['a'][:,3]+H4*an['a'][:,4])@an['V']
           yy=y.reshape(n*4,d); result['Q2_'+label]=sq(yy-pred2).reshape(n,4).mean(1); result['Q4_'+label]=sq(yy-pred4).reshape(n,4).mean(1)
           residual=(yy-linear).reshape(n,4,d); result['D_residual_'+label]=var(residual)
           if label in ('Oq','Dq'):
            B=an['B']; zd=z.double(); wd=w.double(); mixed=zd@B@B.T+wd-(wd@B)@B.T
            pm=fw(mixed.float(),arm).double(); nm=fw(-mixed.float(),arm).double()
            result['Y_PH1_'+label]=(sq(y[:,0]-pm)+sq(y[:,1]-nm))/4
            result['C_PH1_'+label]=sq((zd-mixed)@an['A'])/2
            result['mixed_input_fp32_rounding_sq_'+label]=sq(mixed-mixed.float().double())
            if first==0:
             mixed_spot=fw(torch.stack((mixed[0],-mixed[0])),arm,torch.float64)
             mixed_32=torch.stack((pm[0],nm[0]))
             emit(out/'fp64_spots.jsonl',{'expert':expert,'layer':layer,'arm':label,'rows':2,'kind':'PH1_MIX_AND_ANTITHETIC','squared_error':sq(mixed_spot-mixed_32).cpu().tolist(),'reference_norm_sq':sq(mixed_spot).cpu().tolist(),'numerical_status':'UNASSESSED'})
           del h,H2,H3,H4,pred2,pred4,linear,residual
          if first==0:
           for label,arm,y in zip(labels,arms,values):
            spot=fw(T[[0,2]],arm,torch.float64); spot32=y.reshape(n*4,d)[[0,2]]
            emit(out/'fp64_spots.jsonl',{'expert':expert,'layer':layer,'arm':label,'rows':2,'squared_error':sq(spot-spot32).cpu().tolist(),'reference_norm_sq':sq(spot).cpu().tolist(),'numerical_status':'UNASSESSED'})
          cpu={key:value.cpu().numpy() for key,value in result.items()}
          if not all(np.isfinite(x).all() for x in cpu.values()): raise ValueError('nonfinite block statistic')
          for j in range(n): emit(out/'blocks.jsonl',{'expert':expert,'layer':layer,'block_id':first+j,'stream':'PLANNING/40','split':'FIT' if first+j<128 else 'SELECT' if first+j<256 else 'PLAN',**{key:float(value[j]) for key,value in cpu.items()}})
          if torch.cuda.max_memory_allocated()>40*1024**3: raise MemoryError('GPU memory budget exceeded')
        receipt.result['completed_layers'].append(layer); receipt.result['completed_units'].extend(f'{expert}/{layer}/{label}' for label in labels)
        emit(out/'layers.jsonl',{'expert':expert,'layer':layer,'status':'COMPLETE','blocks':512,'elapsed_seconds':time.monotonic()-layer_start,'read_seconds':read_seconds,'MC_seconds':time.monotonic()-mc_start,'checkpoint_control_seconds_measured_with_sync':control_seconds,'gpu_peak_allocated_bytes':torch.cuda.max_memory_allocated()})
        print(f'DONE expert={expert} layer={layer} elapsed={time.monotonic()-layer_start:.1f}',flush=True)
        del arms,models,raw,analytic,values,o,q,dist,delta,rounding,total,T,z,w,checkpoint_B,checkpoint_a,p,V,a,A,mu,B,arm,an,y; torch.cuda.empty_cache()
       receipt.result['status']='FORMAL_PLANNING_COMPLETE_NOT_CONFIRMATION'
      except TimeoutError:
       receipt.result['status']='PARTIAL_TIMELIMIT'; raise

if __name__=='__main__': main()
