"""Static scope packaging only. ACTIVE is registered after independent review."""
import hashlib,json,shutil
from pathlib import Path
root=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
code=['runner_v7.py','runtime_guard.py','weights_v7.py','core_math.py','statistics_v7.py',
      'structure_v7.py','job_v7.sh','test_math_stats.py','test_runtime_guard.py','test_structure.py','test_formal_runner.py']
for expert in ['high','low']:
    config={'expert':expert,'layers':list(range(40)),'arms':['O32','Oq','Dq'],
            'blocks':512,'batch':32,'gh_nodes':384,'rank':1024,'seed':2026110207,
            'rng_namespace':'PLANNING','rng_stream':40,
            'output_dir':f'/public/home/scc/pb23061276/projects/wan-quant/work/g19_v7_formal_s12_r1/{expert}/runs/s12_01',
            'expected_tensor_hashes_file':'expected_tensor_hashes.json'}
    folder=root/expert;folder.mkdir(exist_ok=True)
    for f in code+['input_manifest.json','expected_tensor_hashes.json','ROOT_SELF_AUDIT.txt','RUNNER_SELF_AUDIT.txt']:
        shutil.copy2(root/f,folder/f)
    (folder/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf8')
    scope={
      'scope_id':f'G19_V7_S12_{expert.upper()}_R1','status':'FROZEN_REVIEWED',
      'phase':'S12_FORMAL_CENSUS_AND_PLANNING','authors':['/root','/root/terra_v7_runner'],
      'activation_requires':'Exact independent ACCEPTED review and post-review finite ACTIVE registry; not activated by this draft packaging',
      'active_registry_file':'ACTIVE_RESEARCH.json',
      'config_file':'config.json','config_sha256':sha(folder/'config.json'),
      'input_manifest_file':'input_manifest.json','manifest_sha256':sha(folder/'input_manifest.json'),
      'expected_tensor_hashes_file':'expected_tensor_hashes.json',
      'frozen_inputs_sha256':{'expected_tensor_hashes.json':sha(folder/'expected_tensor_hashes.json')},
      'code_sha256':{f:sha(folder/f) for f in code},
      'budget':{'max_jobs':1,'gpus_per_job':1,'session_max_gpus':2,'cpus':4,'host_memory_gib':64,
                'gpu_allocation_peak_gib':40,'wall_seconds':1800,'soft_seconds':1650,
                'min_free_disk_gib':80,'estimated_array_output_gib':28.125,'output_budget_gib':35},
      'units':[{'expert':expert,'layer':l,'arm':a} for l in range(40) for a in ['O32','Oq','Dq']],
      'unit_count':120,'checkpoint_pair_count':40,
      'reference':'Gaussian u=sqrt(d/(d-1))*Pi*z alpha=1; actual tanh-GELU and all biases; continuous function probe, not native BF16',
      'questions':[
        'How do first-chaos information concentration and actual fixed-PH1 loss differ across all40 layers?',
        'Is nonlinear variance small, or substantial but explained by low-degree terms?',
        'Can checkpoints with similar energies/spectra still exhibit material paired function differences?',
        'Which stratified deep analyses can discriminate inexpensive quadratic structure?'],
      'hypotheses_with_opposing_predictions':[
        {'id':'LINEAR_DOMINANT','prediction':'Small residual variance and PH1 risk tracks first-chaos tail'},
        {'id':'NONLINEAR_LOW_DEGREE','prediction':'Residual variance substantial but Q2/Q4 fixed-polynomial error much smaller; PH1 alone insufficient'},
        {'id':'SPECTRALLY_SIMILAR_FUNCTION_DIFFERENT','prediction':'Small A1-energy changes coexist with nonzero checkpoint paired discrepancy'}],
      'data_contract':{'blocks_per_pair':512,'base_rows_per_block':12,'mixed_rows_per_block':4,
                       'independent_unit':'one Gaussian (z,w) block, all signs/arms paired',
                       'namespace':'PLANNING','stream':40,'split':[128,128,256],
                       'confirmation':False,'observational_selection':'All512 can support exploration. Any S3 mechanism selected from these data requires fresh planning and confirmation streams; last256 are not retrospectively independent of such selection.'},
      'artifacts':['All120 FP64 A1 matrices','All120 raw H1 eigenvalue arrays','All120 rank1024 PH1 bases',
                   'Raw per-block paired and PF statistics','Per-tensor raw SHA and file/header provenance',
                   'Per-stage elapsed times and memory','Base/mixed FP64 and GH384/192 numerical indicators'],
      'controls':['O32 versus Oq rounding','Dq versus Oq checkpoint','raw cross identity',
                  'fixed-P information loss versus direct polynomial error',
                  'fixed linear PF control','fixed affine checkpoint-error control'],
      'numeric_policy':'Finite and geometry gates mandatory; GH and FP64 spot differences UNASSESSED, not rigorous bounds. Tiny negative eigenvalues retained raw; diagnostic clamped quantities explicitly labeled.',
      'input_policy':'64 previously read tensor hashes precommitted; every covered byte payload must match. Other layers establish FIRST_READ_IDENTITY; future confirmation binds all returned hashes.',
      'cost_policy':'Explicit block counts plus linear/projection/Hermite work; checkpoint-control synchronized overhead and total MC wall are descriptive, not isolated benchmark guarantees.',
      'claim_limits':['Formal registered discovery/planning experiment, not statistical confirmation','No numerical certificate','No all-architecture impossibility','No native/video/speedup claim'],
      'failure_policy':'No automatic retry or layer replacement. Partial/timeout/failure preserved; any continuation needs a separately reviewed finite scope.',
      'next_stage':'S3 independent structural comparison; later S4 fixed independent confirmation; neither activated by this scope'}
    (folder/'scope.json').write_text(json.dumps(scope,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print(expert,sha(folder/'scope.json'))
