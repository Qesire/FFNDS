import unittest
import numpy as np
from runner_v7 import validate_config,paired_scalars_numpy
from core_math import paired_block,affine_error_control

class FormalTests(unittest.TestCase):
    def config(self):
        return dict(expert='high',layers=list(range(40)),blocks=512,batch=32,gh_nodes=384,rank=1024,seed=123,output_dir='/unused',expected_tensor_hashes_file='expected_tensor_hashes.json')
    def test_scope_config(self):
        c=self.config(); validate_config(c)
        for key,val in [('expert','both'),('layers',[0,12]),('blocks',64),('batch',16),('gh_nodes',192),('rank',512)]:
            bad=self.config(); bad[key]=val
            with self.assertRaises(ValueError): validate_config(bad)
    def test_paired_stats_match_core(self):
        rng=np.random.default_rng(432); z=rng.normal(size=(8,3)); w=rng.normal(size=(8,3))
        o=lambda x:x+0.3; q=lambda x:2*x+0.2; d=lambda x:x*x+0.5
        ref=paired_block(o,q,d,z,w); T=np.stack([z,-z,w,-w],axis=1)
        got=paired_scalars_numpy(o(T),q(T),d(T))
        for k in ['U_checkpoint','U_round','U_total','cross','mean_diff_norm_unbiased']:
            np.testing.assert_allclose(got[k],ref[k])
        np.testing.assert_allclose(got['D_Oq'],ref['D'])
        np.testing.assert_allclose(got['U_total'],got['U_checkpoint']+got['U_round']+got['cross'])
    def test_shape_rejected(self):
        with self.assertRaises(ValueError): paired_scalars_numpy(np.ones((4,2)),np.ones((4,2)),np.ones((4,2)))
    def test_checkpoint_affine_control(self):
        rng=np.random.default_rng(41); z=rng.normal(size=(10,3)); w=rng.normal(size=(10,3)); a=rng.normal(size=4); B=rng.normal(size=(3,4))
        expected=affine_error_control(z,w,a,B)
        direct=(a*a).sum()+((z@B)**2).sum(1)/2+((w@B)**2).sum(1)/2
        np.testing.assert_allclose(direct,expected['C'])
        self.assertAlmostEqual(float((a*a).sum()+(B*B).sum()),expected['c'])

if __name__=='__main__':unittest.main()
