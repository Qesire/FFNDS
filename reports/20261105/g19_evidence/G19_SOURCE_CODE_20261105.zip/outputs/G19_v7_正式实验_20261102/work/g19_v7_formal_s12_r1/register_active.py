"""Register exactly reviewed finite scopes; no submission or model computation."""
import hashlib,json,datetime
from pathlib import Path
root=Path(__file__).resolve().parent
scopes={}
for expert in ('high','low'):
    folder=root/expert
    digest=hashlib.sha256((folder/'scope.json').read_bytes()).hexdigest()
    review=json.loads((folder/'INDEPENDENT_REVIEW.json').read_text(encoding='utf8'))
    scope=json.loads((folder/'scope.json').read_text(encoding='utf8'))
    if review['status']!='ACCEPTED' or review['scope_sha256']!=digest or review['reviewer'] in scope['authors']:
        raise RuntimeError('Independent exact-scope approval required before ACTIVE registration')
    scopes[scope['scope_id']]={'state':'AUTHORIZED_FOR_ONE_JOB','scope_sha256':digest,'max_jobs':1,
                              'expert':expert,'units':scope['unit_count'],'review_sha256':hashlib.sha256((folder/'INDEPENDENT_REVIEW.json').read_bytes()).hexdigest()}
active={'schema':'G19_FINITE_ACTIVE_V1','state':'SCOPE_FROZEN_IN_ACTIVE',
        'user_authorization':'2026-11-02: 开始正式实验。',
        'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'session_max_gpus':2,'max_concurrent_jobs':2,'gpus_per_job':1,
        'stage':'S12 full-layer discovery/planning; no S3 or confirmation autoactivation',
        'scopes':scopes}
for expert in ('high','low'):
    folder=root/expert
    with (folder/'ACTIVE_RESEARCH.json').open('x',encoding='utf8') as f:json.dump(active,f,ensure_ascii=False,indent=2)
    files=[p for p in folder.iterdir() if p.is_file() and p.name!='sha256sums.txt']
    (folder/'sha256sums.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(files)),encoding='utf8')
with (root/'ACTIVE_RESEARCH.json').open('x',encoding='utf8') as f:json.dump(active,f,ensure_ascii=False,indent=2)
print(json.dumps({'state':active['state'],'scopes':scopes},ensure_ascii=True))
