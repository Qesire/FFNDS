"""Local audit/analysis of S12 ledgers; produces draft fixed-family plans.
No S12 evidence is changed; raw tensor/matrix bytes remain on the remote host.
"""
import csv,hashlib,json,math,sys
from collections import Counter
from pathlib import Path
import numpy as np
BASE=Path(__file__).resolve().parent
WORK=BASE.parent
sys.path.insert(0,str(WORK/'g19_v7_formal_s12_r1'))
from statistics_v7 import cv_pilot
OUT=WORK/'g19_v7_formal_checkpoint_confirm_r1'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))
def rows(path):
    with path.open(encoding='utf-8-sig') as f: return [json.loads(line) for line in f if line.strip()]
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()
def save(path,value):
    path.write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def require(cond,msg):
    if not cond: raise ValueError(msg)
def key3(r): return r['layer'],r['arm']


def main():
    OUT.mkdir(exist_ok=True); expected_hash={}; asset_map={}; means={}; table=[]; plans={}; validations={}
    scheduler=(BASE/'scheduler_completed.txt').read_text(encoding='utf8')
    for expert,job in [('high','127908'),('low','127909')]:
        source=BASE/expert; start=read(source/'START.json'); ex=read(source/'EXIT.json'); scope=start['scope']; result=ex['result']
        require(ex['status']=='SUCCESS' and ex['exception'] is None and result['status']=='FORMAL_PLANNING_COMPLETE_NOT_CONFIRMATION',expert+' exit')
        require(result['completed_layers']==list(range(40)),expert+' completed layers')
        require(set(result['completed_units'])=={f'{expert}/{i}/{arm}' for i in range(40) for arm in ('O32','Oq','Dq')} and len(result['completed_units'])==120,expert+' completed units')
        require(str(start['allocation']['job_id'])==job and any('JobId='+job+' ' in ln and 'JobState=COMPLETED' in ln and 'ExitCode=0:0' in ln for ln in scheduler.splitlines()),expert+' scheduler')
        config_path=WORK/'g19_v7_formal_s12_r1'/expert/scope['config_file']; require(sha(config_path)==scope['config_sha256'],expert+' config hash')
        config=read(config_path); remote=config['output_dir']; require(remote.startswith('/public/') and config['expert']==expert and config['layers']==list(range(40)),expert+' config identity')
        layers=rows(source/'layers.jsonl'); units=rows(source/'units.jsonl'); pairs=rows(source/'analytic_pairs.jsonl'); weights=rows(source/'weights.jsonl'); artifacts=rows(source/'artifacts.jsonl'); blocks=rows(source/'blocks.jsonl'); env=rows(source/'environment.jsonl'); spots=rows(source/'fp64_spots.jsonl')
        require(len(env)==1 and env[0]['scope_sha256']==scope['_verified_scope_sha256'] and env[0]['stream']=='PLANNING/40',expert+' env')
        require(len(layers)==40 and {r['layer'] for r in layers}==set(range(40)) and all(r['expert']==expert and r['status']=='COMPLETE' and r['blocks']==512 for r in layers),expert+' layers')
        require(len(units)==120 and {key3(r) for r in units}=={(i,a) for i in range(40) for a in ('O32','Oq','Dq')},expert+' units')
        require(all(r['expert']==expert for r in units),expert+' units expert')
        uindex={key3(r):r for r in units}
        require(len(pairs)==80 and {(r['layer'],r['comparison']) for r in pairs}=={(i,c) for i in range(40) for c in ('checkpoint','round')},expert+' pairs')
        require(len(spots)==200 and all(r['expert']==expert and r['numerical_status']=='UNASSESSED' and all(math.isfinite(x) and x>=0 for name in ('squared_error','reference_norm_sq') for x in r[name]) for r in spots),expert+' numeric spot receipts')
        require({(r['layer'],r['arm'],r.get('kind','BASE')) for r in spots}=={(i,a,k) for i in range(40) for a,k in [('O32','BASE'),('Oq','BASE'),('Dq','BASE'),('Oq','PH1_MIX_AND_ANTITHETIC'),('Dq','PH1_MIX_AND_ANTITHETIC')]},expert+' spot coverage')
        pindex={(r['layer'],r['comparison']):r for r in pairs}
        expected_weights={f'{expert}/{model}/blocks.{i}.ffn.{suffix}' for i in range(40) for model in ('original','distilled') for suffix in ('0.weight','0.bias','2.weight','2.bias')}
        require(len(weights)==320,expert+' weight count')
        wd={}
        for r in weights:
            k=f"{r['expert']}/{r['model']}/{r['key']}"; require(k in expected_weights and k not in wd,expert+' bad tensor key')
            require(r['key'].startswith(f"blocks.{r['layer']}.ffn."),expert+' tensor layer identity')
            require(r['dtype']==('F32' if r['model']=='original' else 'BF16') and len(r['sha256'])==64 and int(r['sha256'],16)>=0,expert+' dtype/hash')
            require(r['identity_status'] in ('FIRST_READ_IDENTITY','PRECOMMITTED_HASH_MATCH'),expert+' identity status')
            wd[k]=r['sha256']
        require(set(wd)==expected_weights,expert+' tensor coverage'); expected_hash.update(wd)
        ai={}
        for r in artifacts:
            key=(r['layer'],r.get('arm'),r.get('comparison'),r['kind']); require(key not in ai,expert+' duplicate artifact'); ai[key]=r
            require(Path(r['path']).name==r['path'] and len(r['sha256'])==64 and int(r['sha256'],16)>=0,expert+' malformed asset receipt')
        expected_artifacts={(i,a,None,k) for i in range(40) for a in ('O32','Oq','Dq') for k in ('A1','H1_EIGENVALUES_RAW','PH1_BASIS')} | {(i,None,c,'ANALYTIC_MEAN_DIFFERENCE') for i in range(40) for c in ('checkpoint','round')}
        require(set(ai)==expected_artifacts,expert+' complete artifact receipt coverage')
        for i in range(40):
            for arm in ('Oq','Dq'):
                a=ai[(i,arm,None,'A1')]; asset_map[f'{expert}/{i}/{arm}']={'path':remote+'/'+a['path'],'sha256':a['sha256']}
            a=ai[(i,None,'checkpoint','ANALYTIC_MEAN_DIFFERENCE')]; means[f'{expert}/{i}']={'path':remote+'/'+a['path'],'sha256':a['sha256']}
        require(len(blocks)==20480,expert+' blocks')
        grouped={i:[] for i in range(40)}
        for r in blocks:
            require(r['expert']==expert and r['layer'] in grouped and r['stream']=='PLANNING/40',expert+' block identity')
            require(all(math.isfinite(v) for v in r.values() if type(v)==float),expert+' nonfinite block field')
            grouped[r['layer']].append(r)
        layer_plan={}; cv_count=under_count=0
        for i in range(40):
            rr=sorted(grouped[i],key=lambda x:x['block_id']); require([r['block_id'] for r in rr]==list(range(512)),expert+f' block coverage {i}')
            require(all(r['split']==('FIT' if r['block_id']<128 else 'SELECT' if r['block_id']<256 else 'PLAN') for r in rr),expert+' split')
            names=['D_Oq','D_Dq','U_checkpoint','U_round','U_total','cross','C_checkpoint','Q2_Oq','Q4_Oq','Q2_Dq','Q4_Dq','D_residual_Oq','D_residual_Dq','Y_PH1_Oq','Y_PH1_Dq']
            arrays={name:np.array([r[name] for r in rr],dtype=np.float64) for name in names}
            require(all(np.isfinite(v).all() for v in arrays.values()),expert+' nonfinite')
            require(np.allclose(arrays['U_total'],arrays['U_checkpoint']+arrays['U_round']+arrays['cross'],rtol=1e-10,atol=1e-10),expert+' energy identity')
            D=arrays['D_Oq']; Y=arrays['U_checkpoint']; C=arrays['C_checkpoint']; c=pindex[(i,'checkpoint')]['affine_control_expectation']
            require(D.mean()>0 and math.isfinite(c) and c>=0,expert+' denominator/control')
            # Main-MAC proxy: 8 FFN evaluations, each 2*d*m, plus two d*d control products.
            # This is not an observed wall-time benchmark.
            cost_ratio=1+5120/(8*13824)
            pilot=cv_pilot(Y,D,C,c,cost_raw=1.,cost_cv=cost_ratio,delta=.0001,alpha=.025,K=80)
            n=pilot['plan']['n_run_cap']; nreq=pilot['plan']['n_required']; status=pilot['plan']['status']; cv_count+=int(pilot['cv_selected']); under_count+=int(status=='UNDERPOWERED')
            layer_plan[str(i)]={'n':n,'lambda':pilot['lambda'],'c':c,'n_required':nreq,'status':status,'cv_selected':pilot['cv_selected'],'pilot':pilot}
            rec={'expert':expert,'layer':i,'blocks':512,'checkpoint_ratio':float(Y.mean()/D.mean()),'round_ratio':float(arrays['U_round'].mean()/D.mean()),'D_Oq_mean':float(D.mean()),'D_Dq_mean':float(arrays['D_Dq'].mean()),'control_c':c,'selected_lambda':pilot['lambda'],'cv_selected':pilot['cv_selected'],'n_required':nreq,'n_run':n,'planning_status':status}
            for arm in ('Oq','Dq'):
                denom=float(arrays['D_'+arm].mean()); require(denom>0,expert+' denominator')
                unit=uindex[(i,arm)]; rec['h1_tail1024_over_E1_'+arm]=float(unit['rank_tail_energy']/unit['A1_energy']) if unit['A1_energy']>0 else None
                for col in ('Q2','Q4','D_residual','Y_PH1'): rec[col+'_over_V_'+arm]=float(arrays[col+'_'+arm].mean()/denom)
            table.append(rec)
        plans[expert]={'expert':expert,'family':'CHECKPOINT_80','alpha':.025,'K':80,'theta_equivalence':.0004,'layers':layer_plan,'planning_method':{'function':'statistics_v7.cv_pilot','block_split':[128,128,256],'delta':.0001,'cost_raw':1.0,'cost_cv':1+5120/(8*13824),'cost_model_status':'MAIN_MAC_PROXY_NOT_MEASURED','cost_interpretation':'Per block raw 8 FFN forwards times 2*d*m MAC; two control applications add 2*d*d MAC. This is not actual wall time or evidence of a speedup.','source':'S12 PLANNING/40; independent confirmation uses CONFIRMATION/400'}}
        validations[expert]={'scheduler_job':job,'scheduler':'COMPLETED_0_0','layers':len(layers),'units':len(units),'blocks':len(blocks),'tensor_receipts':len(weights),'first_read_tensor_receipts':sum(r['identity_status']=='FIRST_READ_IDENTITY' for r in weights),'precommitted_tensor_receipts':sum(r['identity_status']=='PRECOMMITTED_HASH_MATCH' for r in weights),'max_gh_relative_delta_384_192':max(r['gh_coefficient_relative_delta_384_192'] for r in units),'max_spot_squared_error_over_reference_squared_norm':max(err/ref for r in spots for err,ref in zip(r['squared_error'],r['reference_norm_sq']) if ref>0),'numerical_status':'UNASSESSED_DIAGNOSTICS_NOT_BOUND','selected_cv_pairs':cv_count,'underpowered_pairs':under_count,'elapsed_seconds':ex['elapsed_seconds'],'note':'Receipt verification only: remote raw tensors and .npy asset bytes were not available locally and must be hash checked on compute node.'}
    require(len(expected_hash)==640 and len(asset_map)==160 and len(means)==80,'cross expert coverage')
    for expert,p in plans.items(): save(OUT/f'plan_{expert}.json',p)
    save(OUT/'expected_tensor_hashes.json',expected_hash); save(OUT/'assets.json',asset_map); save(OUT/'mean_assets.json',means)
    with (BASE/'analysis.csv').open('w',newline='',encoding='utf8') as f:
        writer=csv.DictWriter(f,fieldnames=list(table[0])); writer.writeheader(); writer.writerows(table)
    summary={'status':'DESCRIPTIVE_PLANNING_ONLY_NUMERICS_UNASSESSED','validations':validations,'units':'Ratios are ratios of means of 512 paired-block scalar values, not confidence intervals. Q2/Q4 direct error ratio and PH1 information loss are distinct estimands. D_residual is conservative residual variance, not exact higher-order energy.','cost_model':'main-MAC proxy (16*d*m+2*d*d)/(16*d*m); not measured wall time','rows':table}
    save(BASE/'analysis.json',summary)
    print(json.dumps({'validations':validations,'counts':{'tensor_hashes':len(expected_hash),'A1_assets':len(asset_map),'mean_assets':len(means)}}))

if __name__=='__main__': main()
