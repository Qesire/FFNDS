import json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import runtime_guard as g
from runner_confirm import frozen_json,validate_scope

class ConfirmGuardTests(unittest.TestCase):
 def fixture(self,p,phase='S4_CHECKPOINT_CONFIRMATION',omit=None):
  names=['runner_confirm.py','job_confirm.sh','runtime_guard.py','weights_v7.py','statistics_v7.py']
  inputs=['tensor_hashes.json','assets.json','mean_assets.json','plan.json']
  for name in names+['config.json','manifest.json']+inputs:(p/name).write_text('{}',encoding='utf8')
  scope={'status':'FROZEN_REVIEWED','authors':['author'],'phase':phase,'scope_id':'s4_high','code_sha256':{n:g.sha256_file(p/n) for n in names if n!=omit},'config_file':'config.json','config_sha256':g.sha256_file(p/'config.json'),'input_manifest_file':'manifest.json','manifest_sha256':g.sha256_file(p/'manifest.json'),'expected_tensor_hashes_file':'tensor_hashes.json','frozen_inputs_sha256':{n:g.sha256_file(p/n) for n in inputs},'active_registry_file':'ACTIVE_RESEARCH.json','budget':{'gpus_per_job':1,'max_jobs':1,'wall_seconds':1800,'soft_seconds':1650,'cpus':4,'host_memory_gib':64,'min_free_disk_gib':1}}
  path=p/'scope.json'; path.write_text(json.dumps(scope),encoding='utf8'); digest=g.sha256_file(path)
  (p/'INDEPENDENT_REVIEW.json').write_text(json.dumps({'status':'ACCEPTED','reviewer':'reviewer','scope_sha256':digest}),encoding='utf8')
  active={'state':'SCOPE_FROZEN_IN_ACTIVE','session_max_gpus':2,'max_concurrent_jobs':2,'scopes':{'s4_high':{'scope_sha256':digest,'state':'AUTHORIZED_FOR_ONE_JOB','max_jobs':1}}}
  (p/'ACTIVE_RESEARCH.json').write_text(json.dumps(active),encoding='utf8')
  return path,digest,active,scope
 def test_phase_and_input_tamper(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp); path,digest,_,scope=self.fixture(p)
   with patch.object(g.shutil,'disk_usage',return_value=type('U',(),{'free':2*1024**3})()):
    self.assertEqual(g.verify_frozen_scope(p,path,digest)['phase'],'S4_CHECKPOINT_CONFIRMATION')
    self.assertEqual(frozen_json(p,scope,'assets.json'),{})
    with self.assertRaisesRegex(RuntimeError,'not scope-bound'): frozen_json(p,scope,'other.json')
    (p/'assets.json').write_text('{"tampered":true}')
    with self.assertRaisesRegex(RuntimeError,'Identity mismatch'): g.verify_frozen_scope(p,path,digest)
    with self.assertRaisesRegex(RuntimeError,'input path/hash mismatch'): frozen_json(p,scope,'assets.json')
 def test_required_module(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp); path,digest,_,_=self.fixture(p,omit='runner_confirm.py')
   with self.assertRaisesRegex(RuntimeError,'bind every execution module'): g.verify_frozen_scope(p,path,digest)
 def test_wrong_phase(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp); path,digest,_,scope=self.fixture(p,phase='S12_FORMAL_CENSUS_AND_PLANNING')
   with self.assertRaisesRegex(RuntimeError,'bind every execution module'): g.verify_frozen_scope(p,path,digest)
   with self.assertRaisesRegex(ValueError,'not checkpoint confirmation'): validate_scope(scope,{'expected_tensor_hashes_file':'tensor_hashes.json'})
 def test_active_exact(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp); path,digest,active,_=self.fixture(p)
   for field,value in [('state','PROPOSED'),('session_max_gpus',3),('max_concurrent_jobs',3)]:
    bad=dict(active); bad[field]=value; (p/'ACTIVE_RESEARCH.json').write_text(json.dumps(bad))
    with self.assertRaisesRegex(RuntimeError,'ACTIVE authorization'): g.verify_frozen_scope(p,path,digest)
   active['scopes']['s4_high']['scope_sha256']='0'*64; (p/'ACTIVE_RESEARCH.json').write_text(json.dumps(active))
   with self.assertRaisesRegex(RuntimeError,'ACTIVE authorization'): g.verify_frozen_scope(p,path,digest)
 def test_review_and_module_hash(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp); path,digest,_,_=self.fixture(p)
   with self.assertRaisesRegex(RuntimeError,'Scope SHA256'): g.verify_frozen_scope(p,path,'0'*64)
   (p/'INDEPENDENT_REVIEW.json').write_text(json.dumps({'status':'ACCEPTED','reviewer':'author','scope_sha256':digest}))
   with self.assertRaisesRegex(RuntimeError,'distinct reviewer'): g.verify_frozen_scope(p,path,digest)
   (p/'INDEPENDENT_REVIEW.json').write_text(json.dumps({'status':'ACCEPTED','reviewer':'reviewer','scope_sha256':digest})); (p/'runner_confirm.py').write_text('changed')
   with self.assertRaisesRegex(RuntimeError,'Identity mismatch'): g.verify_frozen_scope(p,path,digest)

if __name__=='__main__': unittest.main()
