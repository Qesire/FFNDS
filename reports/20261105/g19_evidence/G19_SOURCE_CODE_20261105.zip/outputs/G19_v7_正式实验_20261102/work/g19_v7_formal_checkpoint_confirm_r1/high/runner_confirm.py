"""Checkpoint-only preplanned independent confirmation; draft, never self-submit."""
import argparse,hashlib,json,math,re,time
from pathlib import Path
import numpy as np


def validate_scope(scope,config):
    if scope.get('phase')!='S4_CHECKPOINT_CONFIRMATION': raise ValueError('scope is not checkpoint confirmation')
    if config.get('expected_tensor_hashes_file')!=scope.get('expected_tensor_hashes_file') or not scope.get('expected_tensor_hashes_file'): raise ValueError('tensor hash identity differs from scope')


def validate_config(config,plan):
    if config.get('expert') not in ('high','low'): raise ValueError('one valid expert required')
    layers=config.get('layers')
    if not isinstance(layers,list) or not layers or any(type(x)!=int or not 0<=x<40 for x in layers) or layers!=sorted(set(layers)):
        raise ValueError('layers must be sorted, unique and pre-frozen')
    if type(config.get('seed'))!=int or config['seed']<0 or config.get('batch') not in (32,64) or not isinstance(config.get('output_dir'),str) or not config['output_dir']:
        raise ValueError('invalid seed, batch or output path')
    if plan.get('expert')!=config['expert'] or plan.get('family')!='CHECKPOINT_80' or plan.get('K')!=80 or plan.get('alpha')!=.025 or plan.get('theta_equivalence')!=.0004:
        raise ValueError('plan family differs from frozen confirmation family')
    if set(plan.get('layers',{}))!={str(i) for i in range(40)}: raise ValueError('plan must specify all 40 layers for this expert')
    for item in plan['layers'].values():
        n=item.get('n'); lam=item.get('lambda'); value=item.get('c')
        if type(n)!=int or not 1024<=n<=16384 or n&(n-1): raise ValueError('n must be preplanned power of two in 1024..16384')
        if type(lam) not in (int,float) or not math.isfinite(lam) or type(value) not in (int,float) or not math.isfinite(value) or value<0: raise ValueError('invalid fixed control')


def validate_hash_coverage(expert,layers,hashes):
    for layer in layers:
        for model in ('original','distilled'):
            for suffix in ('0.weight','0.bias','2.weight','2.bias'):
                key=f'{expert}/{model}/blocks.{layer}.ffn.{suffix}'
                if not isinstance(hashes.get(key),str) or not re.fullmatch(r'[0-9a-f]{64}',hashes[key]): raise ValueError('missing precommitted weight hash: '+key)


def block_stats_numpy(oq,dq):
    """Reference only: rows blocks, columns z,-z,w,-w."""
    q,d=(np.asarray(x,dtype=np.float64) for x in (oq,dq))
    if q.ndim!=3 or q.shape[1]!=4 or d.shape!=q.shape: raise ValueError('bad shape')
    sq=lambda x:(x*x).sum(-1); delta=d-q
    return {'D_Oq':(sq(q[:,0]-q[:,2])+sq(q[:,1]-q[:,3]))/4,
            'U_checkpoint':sq(delta).mean(1),
            'mean_diff_norm_unbiased':((delta[:,0]+delta[:,1])*(delta[:,2]+delta[:,3])).sum(-1)/4}


def adjusted_values(U,C,lam,c):
    if lam==0: return U
    if C is None: raise ValueError('control observations required')
    return U-lam*(C-c)


def sha256(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()


def frozen_json(root,scope,name):
    if not isinstance(name,str) or name not in scope.get('frozen_inputs_sha256',{}): raise RuntimeError('input not scope-bound')
    path=(root/name).resolve()
    if not path.is_relative_to(root) or sha256(path)!=scope['frozen_inputs_sha256'][name]: raise RuntimeError('input path/hash mismatch')
    return json.loads(path.read_text(encoding='utf8'))


def load_asset(entry,shape):
    if not isinstance(entry,dict) or set(entry)!={'path','sha256'} or not re.fullmatch(r'[0-9a-f]{64}',entry['sha256']): raise ValueError('bad asset record')
    path=Path(entry['path'])
    if not path.is_absolute(): raise ValueError('asset path must be absolute')
    before=path.stat()
    if sha256(path)!=entry['sha256']: raise ValueError('asset identity mismatch')
    x=np.load(path,allow_pickle=False,mmap_mode='r')
    if x.shape!=shape or x.dtype!=np.float64 or not np.isfinite(x).all(): raise ValueError('invalid frozen numerical asset')
    after=path.stat()
    if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns): raise ValueError('asset changed during verification')
    return x


def emit(path,obj):
    with path.open('a',encoding='utf8') as f: f.write(json.dumps(obj,allow_nan=False,separators=(',',':'))+'\n')


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--scope',type=Path,required=True); ap.add_argument('--scope-sha',required=True); args=ap.parse_args()
    from runtime_guard import require_compute_allocation,verify_frozen_scope,RunReceipt
    allocation=require_compute_allocation(); root=Path(__file__).resolve().parent
    scope=verify_frozen_scope(root,args.scope,args.scope_sha)
    config=json.loads((root/scope['config_file']).read_text(encoding='utf8'))
    validate_scope(scope,config)
    plan=frozen_json(root,scope,config['plan_file']); assets=frozen_json(root,scope,config['assets_file']); means=frozen_json(root,scope,config['mean_assets_file']); hashes=frozen_json(root,scope,config['expected_tensor_hashes_file'])
    validate_config(config,plan); expert=config['expert']; validate_hash_coverage(expert,config['layers'],hashes)
    manifest=json.loads((root/scope['input_manifest_file']).read_text(encoding='utf8'))
    from weights_v7 import load_tensor,rne_lift
    from statistics_v7 import rng_for
    import scipy,torch
    import torch.nn.functional as TF
    if not torch.cuda.is_available() or torch.cuda.device_count()!=1: raise RuntimeError('exactly one visible GPU required')
    total_mem=torch.cuda.get_device_properties(0).total_memory
    if total_mem<32*1024**3: raise RuntimeError('GPU requires >=32GiB')
    torch.cuda.set_per_process_memory_fraction(min(.95,40*1024**3/total_mem),0); torch.set_num_threads(scope['budget']['cpus'])
    torch.backends.cuda.matmul.allow_tf32=False; torch.backends.cudnn.allow_tf32=False
    out=Path(config['output_dir'])
    with RunReceipt(out,scope,allocation) as receipt:
      receipt.result={'status':'PARTIAL','completed_layers':[],'current_layer':None,'completed_blocks_in_current_layer':0,'family':'CHECKPOINT_80','namespace':'CONFIRMATION/400'}
      emit(out/'environment.jsonl',{'expert':expert,'layers':config['layers'],'scope_sha256':args.scope_sha,'stream':'CONFIRMATION/400','family':'CHECKPOINT_80','alpha':.025,'K':80,'theta_equivalence':.0004,'torch':torch.__version__,'scipy':scipy.__version__,'numpy':np.__version__,'gpu':torch.cuda.get_device_name(),'tf32':False,'budget':scope['budget'],'numerical_status':'UNASSESSED'})
      try:
       for layer in config['layers']:
        receipt.check_deadline(); started=time.monotonic(); entry=plan['layers'][str(layer)]; n=entry['n']; lam=entry['lambda']; expected_c=entry['c']
        receipt.result['current_layer']=layer; receipt.result['completed_blocks_in_current_layer']=0
        print(f'START expert={expert} layer={layer} n={n}',flush=True)
        models={}
        for model in ('original','distilled'):
         data={}
         for suffix in ('0.weight','0.bias','2.weight','2.bias'):
          receipt.check_deadline(); key=f'{expert}/{model}/blocks.{layer}.ffn.{suffix}'
          arr,rec=load_tensor(manifest,expert,model,layer,suffix,hashes[key])
          if rec['identity_status']!='PRECOMMITTED_HASH_MATCH': raise RuntimeError('precommitted hash required')
          emit(out/'weights.jsonl',{'expert':expert,'model':model,'layer':layer,**rec}); data[suffix]=rne_lift(arr) if model=='original' else arr
         models[model]=data
        arms=[{key:torch.as_tensor(value,device='cuda',dtype=torch.float32) for key,value in models[x].items()} for x in ('original','distilled')]
        d=arms[0]['0.weight'].shape[1]; m=arms[0]['0.weight'].shape[0]
        if (d,m)!=(5120,13824): raise ValueError('unexpected model geometry')
        def fw(z,model,dtype=torch.float32):
         z=z.to(dtype); u=(z-z.mean(-1,keepdim=True))*math.sqrt(d/(d-1))
         return TF.linear(TF.gelu(TF.linear(u,model['0.weight'].to(dtype),model['0.bias'].to(dtype)),approximate='tanh'),model['2.weight'].to(dtype),model['2.bias'].to(dtype))
        ao=load_asset(assets[f'{expert}/{layer}/Oq'],(d,d)); ad=load_asset(assets[f'{expert}/{layer}/Dq'],(d,d)); am=load_asset(means[f'{expert}/{layer}'],(d,))
        B=torch.as_tensor(np.array(ad),device='cuda',dtype=torch.float64)-torch.as_tensor(np.array(ao),device='cuda',dtype=torch.float64); a=torch.as_tensor(np.array(am),device='cuda',dtype=torch.float64)
        actual_c=float(a.square().sum()+B.square().sum())
        if not math.isfinite(actual_c) or abs(actual_c-expected_c)>1e-9*max(1e-20,abs(expected_c),abs(actual_c)): raise ValueError('control expectation disagrees with frozen plan')
        emit(out/'layer_plan.jsonl',{'expert':expert,'layer':layer,'n':n,'lambda':lam,'c_plan':expected_c,'c_recomputed':actual_c,'control_mode':'SKIPPED_ZERO_LAMBDA' if lam==0 else 'AFFINE','assets':{'Oq':assets[f'{expert}/{layer}/Oq']['sha256'],'Dq':assets[f'{expert}/{layer}/Dq']['sha256'],'mean_difference':means[f'{expert}/{layer}']['sha256']}})
        gen=rng_for(config['seed'],'CONFIRMATION',expert,layer,400)
        with (out/'blocks.jsonl').open('a',encoding='utf8',buffering=1024*1024) as file:
         for first in range(0,n,config['batch']):
          receipt.check_deadline(); count=min(config['batch'],n-first); raw=gen.standard_normal((count,2,d)).astype(np.float32)
          z=torch.as_tensor(raw[:,0],device='cuda'); w=torch.as_tensor(raw[:,1],device='cuda'); T=torch.stack((z,-z,w,-w),dim=1).reshape(count*4,d)
          with torch.no_grad():
           q,dist=[fw(T,arm).double().reshape(count,4,d) for arm in arms]; delta=dist-q; sq=lambda x:x.square().sum(-1)
           D=(sq(q[:,0]-q[:,2])+sq(q[:,1]-q[:,3]))/4; U=sq(delta).mean(1)
           M=((delta[:,0]+delta[:,1])*(delta[:,2]+delta[:,3])).sum(-1)/4
           C=a.square().sum()+(sq(z.double()@B)+sq(w.double()@B))/2 if lam!=0 else None
           adjusted=adjusted_values(U,C,lam,expected_c)
           if first==0:
            for label,arm,y in zip(('Oq','Dq'),arms,(q,dist)):
             spot=fw(T[[0,2]],arm,torch.float64); ref=y.reshape(count*4,d)[[0,2]]
             emit(out/'fp64_spots.jsonl',{'expert':expert,'layer':layer,'arm':label,'rows':'independent_z_w','squared_error':sq(spot-ref).cpu().tolist(),'reference_norm_sq':sq(spot).cpu().tolist(),'numerical_status':'UNASSESSED'})
           d_np=D.cpu().numpy(); u_np=U.cpu().numpy(); m_np=M.cpu().numpy(); adj_np=adjusted.cpu().numpy(); c_np=C.cpu().numpy() if C is not None else None
           if not all(np.isfinite(x).all() for x in (d_np,u_np,m_np,adj_np)) or (c_np is not None and not np.isfinite(c_np).all()): raise ValueError('nonfinite confirmation block')
           for j in range(count):
            row={'expert':expert,'layer':layer,'block_id':first+j,'stream':'CONFIRMATION/400','D_Oq':float(d_np[j]),'U_checkpoint':float(u_np[j]),'C_checkpoint':None if c_np is None else float(c_np[j]),'C_mode':'SKIPPED_ZERO_LAMBDA' if c_np is None else 'AFFINE','mean_diff_norm_unbiased':float(m_np[j]),'signed_adjusted_U':float(adj_np[j])}
            file.write(json.dumps(row,allow_nan=False,separators=(',',':'))+'\n')
           file.flush(); receipt.result['completed_blocks_in_current_layer']=first+count
           if torch.cuda.max_memory_allocated()>40*1024**3: raise MemoryError('GPU budget exceeded')
        receipt.result['completed_layers'].append(layer); emit(out/'layers.jsonl',{'expert':expert,'layer':layer,'status':'COMPLETE','n':n,'elapsed_seconds':time.monotonic()-started,'gpu_peak_allocated_bytes':torch.cuda.max_memory_allocated()})
        print(f'DONE expert={expert} layer={layer} n={n} elapsed={time.monotonic()-started:.1f}',flush=True)
        del arms,models,ao,ad,am,B,a,q,dist,delta,T,z,w; torch.cuda.empty_cache()
       receipt.result['status']='CONFIRMATION_COLLECTION_COMPLETE'
      except TimeoutError:
       receipt.result['status']='PARTIAL_TIMELIMIT'; raise

if __name__=='__main__': main()
