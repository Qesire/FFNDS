#!/bin/bash
#SBATCH --job-name=g19_v7_confirm
#SBATCH --partition=Students
#SBATCH --account=stu
#SBATCH --qos=qos_stu_medium_2gpu
#SBATCH --gres=gpu:A100:1
#SBATCH --cpus-per-task=4
#SBATCH --mem=64G
#SBATCH --time=00:30:00
#SBATCH --signal=B:USR1@120
#SBATCH --output=slurm-%j.out
#SBATCH --error=slurm-%j.err
set -euo pipefail
[[ $# -eq 1 && "$1" =~ ^[0-9a-f]{64}$ ]] || { echo 'Expected exact reviewed scope SHA256' >&2; exit 64; }
[[ -n "${SLURM_JOB_ID:-}" ]] || { echo 'Submit with sbatch: login-node execution forbidden' >&2; exit 65; }
case "$(hostname -s)" in
  tradmin*|login*|head*|gateway*) echo 'Login node execution forbidden' >&2; exit 66;;
esac
[[ -n "${SLURM_SUBMIT_DIR:-}" ]] || exit 67
cd -- "$SLURM_SUBMIT_DIR"
export OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4
export PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
# Stdlib guard in runner independently checks live scontrol allocation before torch/weights.
exec /public/home/scc/pb23061276/miniconda3/envs/wan/bin/python -B -u runner_confirm.py --scope scope.json --scope-sha "$1"
