"""Freeze checkpoint collection proposals; never activate, submit or read weights."""
from pathlib import Path
import hashlib,json,shutil
root=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8',newline='\n')
remote='/public/home/scc/pb23061276/projects/wan-quant/work/g19_v7_formal_checkpoint_confirm_r1'
analysis=root.parent/'g19_v7_formal_s12_results'
shutil.copyfile(analysis/'analyze_s12.py',root/'analyze_s12_source.py')
evidence={e:{f:sha(analysis/e/f) for f in ('START.json','EXIT.json','blocks.jsonl','analytic_pairs.jsonl','artifacts.jsonl','weights.jsonl')} for e in ('high','low')}
write(root/'s12_evidence.json',evidence)
files=['runner_confirm.py','runtime_guard.py','weights_v7.py','statistics_v7.py','job_confirm.sh','test_confirm.py','test_confirm_guard.py','SELF_AUDIT.txt','analyze_s12_source.py']
for f in files: assert (root/f).is_file(),f
index=[]
for expert in ('high','low'):
    folder=root/expert; folder.mkdir(exist_ok=False)
    for f in files+['input_manifest.json','assets.json','mean_assets.json','expected_tensor_hashes.json','s12_evidence.json']:
        shutil.copyfile(root/f,folder/f)
    shutil.copyfile(root/f'plan_{expert}.json',folder/'plan.json')
    plan=json.loads((folder/'plan.json').read_text(encoding='utf8'))
    assert len(plan['layers'])==40 and all(v['n']==1024 for v in plan['layers'].values())
    config={'expert':expert,'layers':list(range(40)),'seed':2026110207,'batch':32,'output_dir':remote+f'/{expert}/runs/confirm_01','plan_file':'plan.json','assets_file':'assets.json','mean_assets_file':'mean_assets.json','expected_tensor_hashes_file':'expected_tensor_hashes.json'}
    write(folder/'config.json',config)
    scope={'scope_id':f'G19_V7_S4_CHECKPOINT_{expert.upper()}_R1','status':'FROZEN_REVIEWED','phase':'S4_CHECKPOINT_CONFIRMATION','authors':['/root','/root/terra_v7_runner'],
      'active_registry_file':'ACTIVE_RESEARCH.json','activation_requires':'Exact independent ACCEPTED followed by finite ACTIVE registration; draft not active',
      'config_file':'config.json','config_sha256':sha(folder/'config.json'),'input_manifest_file':'input_manifest.json','manifest_sha256':sha(folder/'input_manifest.json'),
      'expected_tensor_hashes_file':'expected_tensor_hashes.json','frozen_inputs_sha256':{f:sha(folder/f) for f in ('plan.json','assets.json','mean_assets.json','expected_tensor_hashes.json','s12_evidence.json')},
      'code_sha256':{f:sha(folder/f) for f in files},
      'budget':{'max_jobs':1,'gpus_per_job':1,'session_max_gpus':2,'cpus':4,'host_memory_gib':64,'gpu_allocation_peak_gib':40,'wall_seconds':1800,'soft_seconds':1650,'min_free_disk_gib':5,'output_budget_gib':2},
      'unit_count':40,'units':[{'expert':expert,'layer':i,'comparison':'Dq_minus_Oq'} for i in range(40)],
      'finite_stage_jobs':2,'max_stage_gpu_hours':1,'max_concurrent_jobs_all_stages':2,
      'family':{'name':'CHECKPOINT_80','K':80,'alpha':.025,'theta_equivalence':.0004,'delta_planning':.0001,'interval':'asymptotic Bonferroni Fieller; sample covariance denominator n-1; include all/split/unbounded sets','statistical_null':'E||F_Dq-F_Oq||^2 / Var(F_Oq) >= .0004 for equivalence upper-bound test'},
      'inference_rules':{'finite_bounded_positive_denominator_required':True,'numerical_certification':'UNASSESSED','statistical_interpretation_only':'When eligible upper endpoint < .0004, statistical equivalence under Gaussian reference; lower endpoint > .0004, statistically above chosen tolerance; crossing/ineligible INCONCLUSIVE. No finite-sample or rigorous numerical guarantee.'},
      'reference':'Gaussian u=sqrt(d/(d-1))*Pi*z alpha=1; real tanh GELU/all biases; explicit BF16-RNE original Oq versus stored-BF16 Dq lifted, FP32 TF32off forward, not native BF16 inference',
      'data_contract':{'namespace':'CONFIRMATION','stream':400,'n_each_pair':1024,'total_blocks_this_job':40960,'independent_unit':'Gaussian(z,w) block with 4 signs and both checkpoints paired','optional_stopping':False,'candidate_selection':'All80 pairs fixed before S12; this scope confirms checkpoint distance only, no S3 structure claims'},
      'planning':'S12 PLANNING40:128 FIT,128 SELECT,256 PLAN. lambda minimizes ratio influence variance; SELECT >=10% main-MAC cost variance benefit. Raw MAC16dm/control extra2d² proxy, not timing. s_plan=2*s_psi heuristic, power-of-two min1024 max16384; all current required1024. delta/10 reserve is not a numerical bound.',
      'control':'Fixed a=mu_Dq-mu_Oq,B=A_Dq-A_Oq,c=||a||²+||B||F²; C=||a||²+.5(||zB||²+||wB||²); signed U-lambda(C-c), no clipping; lambda0 skips C explicitly',
      'identity':'Every raw tensor and every S12 numerical asset has precommitted SHA; compute node rechecks before use; no FIRST_READ permitted',
      'claim_limits':['Only checkpoint-distance80 family, no architecture acceptance','Asymptotic Gaussian-reference inference, no finite-sample certificate','FP64 spots and quadrature indicators not numerical bounds','No native activation/video-quality/speedup assertion'],
      'failure_policy':'One job per exactscope, no retries or changed sample count. Preserve partial and failed outputs. Full-family reporting includes missing and ineligible pairs; no selected-only all80 claim.'}
    write(folder/'scope.json',scope); index.append({'folder':expert,'scope_id':scope['scope_id'],'scope_sha256':sha(folder/'scope.json')})
write(root/'SCOPE_INDEX.json',index); print(json.dumps(index))
