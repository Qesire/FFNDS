import hashlib,tempfile,unittest
from pathlib import Path
import numpy as np
from runner_confirm import validate_scope,validate_config,validate_hash_coverage,block_stats_numpy,adjusted_values,load_asset

class Tests(unittest.TestCase):
    def test_scope_phase_and_hash_binding(self):
        scope={'phase':'S4_CHECKPOINT_CONFIRMATION','expected_tensor_hashes_file':'hashes.json'}; config={'expected_tensor_hashes_file':'hashes.json'}
        validate_scope(scope,config)
        with self.assertRaises(ValueError): validate_scope({**scope,'phase':'S3'},config)
        with self.assertRaises(ValueError): validate_scope(scope,{'expected_tensor_hashes_file':'other.json'})
    def config(self):
        return {'expert':'high','layers':list(range(40)),'seed':1,'batch':64,'output_dir':'/tmp/result'}
    def plan(self):
        return {'expert':'high','family':'CHECKPOINT_80','alpha':.025,'K':80,'theta_equivalence':.0004,'layers':{str(i):{'n':1024,'lambda':0.,'c':1.} for i in range(40)}}
    def test_fixed_plan(self):
        c=self.config(); p=self.plan(); validate_config(c,p)
        for key,bad in [('n',1000),('n',32768),('lambda',float('nan')),('c',-1)]:
            q=self.plan(); q['layers']['3'][key]=bad
            with self.assertRaises(ValueError): validate_config(c,q)
        p=self.plan(); p['K']=1
        with self.assertRaises(ValueError): validate_config(c,p)
    def test_fixed_shard(self):
        c=self.config(); c['layers']=[1,3]; validate_config(c,self.plan()); c['layers']=[3,1]
        with self.assertRaises(ValueError): validate_config(c,self.plan())
    def test_hash_coverage(self):
        hashes={f'high/{model}/blocks.0.ffn.{suffix}':'a'*64 for model in ('original','distilled') for suffix in ('0.weight','0.bias','2.weight','2.bias')}
        validate_hash_coverage('high',[0],hashes); hashes.pop(next(iter(hashes)))
        with self.assertRaises(ValueError): validate_hash_coverage('high',[0],hashes)
    def test_block_and_signed_control(self):
        z=np.array([[1.,2.],[-1.,-2.],[3.,4.],[-3.,-4.]])[None,:,:]; q=z; d=z+np.array([1.,-2.])
        r=block_stats_numpy(q,d); np.testing.assert_allclose(r['D_Oq'],4.); np.testing.assert_allclose(r['U_checkpoint'],5.); np.testing.assert_allclose(r['mean_diff_norm_unbiased'],5.)
        np.testing.assert_equal(adjusted_values(np.array([1.]),np.array([10.]),1.,0.),[-9.])
        np.testing.assert_equal(adjusted_values(np.array([1.]),None,0.,0.),[1.])
        with self.assertRaises(ValueError): adjusted_values(np.array([1.]),None,1.,0.)
    def test_asset_sha_and_shape(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'a.npy'; np.save(p,np.eye(2)); h=hashlib.sha256(p.read_bytes()).hexdigest(); x=load_asset({'path':str(p),'sha256':h},(2,2)); np.testing.assert_equal(x,np.eye(2)); del x
            with self.assertRaises(ValueError):load_asset({'path':str(p),'sha256':'0'*64},(2,2))
            with self.assertRaises(ValueError):load_asset({'path':str(p),'sha256':h},(3,3))

if __name__=='__main__': unittest.main()
