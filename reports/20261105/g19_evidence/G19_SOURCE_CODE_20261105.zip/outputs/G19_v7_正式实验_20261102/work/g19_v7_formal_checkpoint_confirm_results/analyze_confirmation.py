"""Frozen-family S4 receipt audit and paired Fieller analysis.
No GPU or remote access. Run only after both complete JSON result sets are local.
"""
import csv,hashlib,importlib.util,json,math
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parent.parent
RESULTS=Path(__file__).resolve().parent
SOURCE=ROOT/'g19_v7_formal_checkpoint_confirm_r1'
SCOPE_SHA={'high':'2dfef29fdd9a54de7e22c6b18a69b8ea3d23134d15936fbe00a0d16d072eed0f','low':'fa895bfced538f77c6f87639313449947209d3c65c8c741cf5d3d6e63431e75a'}
STAT_SHA='b1c9e7cf23e4d40a36b2cc1155b242a606973596c556cd1a863619d5c0c1014d'
LIMIT=.0004


def require(condition,message):
    if not condition: raise ValueError(message)

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def rows(path):
    with path.open(encoding='utf-8-sig') as f: return [json.loads(line) for line in f if line.strip()]

def near(a,b): return math.isfinite(a) and math.isfinite(b) and abs(a-b)<=1e-9*max(1e-20,abs(a),abs(b))

def decision(fieller,limit=LIMIT):
    if not fieller.get('decision_eligible') or not fieller.get('denominator_positive'): return 'INCONCLUSIVE'
    intervals=fieller.get('intervals',[])
    if len(intervals)!=1 or len(intervals[0])!=2: return 'INCONCLUSIVE'
    lo,hi=intervals[0]
    if lo is None or hi is None or not math.isfinite(lo) or not math.isfinite(hi) or lo>hi: return 'INCONCLUSIVE'
    if hi<limit: return 'STAT_EQUIVALENT'
    if lo>limit: return 'STAT_ABOVE_TOLERANCE'
    return 'INCONCLUSIVE'


def checked_scope(expert):
    root=SOURCE/expert; scope_file=root/'scope.json'; require(sha(scope_file)==SCOPE_SHA[expert],expert+' scope SHA mismatch')
    scope=read(scope_file); require(scope['phase']=='S4_CHECKPOINT_CONFIRMATION' and scope['status']=='FROZEN_REVIEWED',expert+' scope phase/status')
    identities=dict(scope['code_sha256']); identities.update(scope['frozen_inputs_sha256']); identities[scope['config_file']]=scope['config_sha256']; identities[scope['input_manifest_file']]=scope['manifest_sha256']
    for name,want in identities.items():
        path=(root/name).resolve(); require(path.is_relative_to(root.resolve()) and sha(path)==want,expert+' frozen file '+name)
    require(scope['code_sha256'].get('statistics_v7.py')==STAT_SHA,expert+' statistics SHA')
    config=read(root/scope['config_file']); plan=read(root/config['plan_file']); manifest=read(root/scope['input_manifest_file']); hashes=read(root/config['expected_tensor_hashes_file']); assets=read(root/config['assets_file']); means=read(root/config['mean_assets_file'])
    require(config['expert']==expert and config['layers']==list(range(40)) and config['expected_tensor_hashes_file']==scope['expected_tensor_hashes_file'],expert+' config')
    for key in ('plan_file','assets_file','mean_assets_file','expected_tensor_hashes_file'): require(config[key] in scope['frozen_inputs_sha256'],expert+' unbound '+key)
    require(plan['expert']==expert and plan['family']=='CHECKPOINT_80' and plan['alpha']==.025 and plan['K']==80 and plan['theta_equivalence']==LIMIT and set(plan['layers'])=={str(i) for i in range(40)},expert+' plan family')
    require(all(p['n']==1024 for p in plan['layers'].values()),expert+' n must be 1024')
    return scope,config,plan,manifest,hashes,assets,means


def audit(expert,scope,config,plan,manifest,hashes,assets,means,fieller_set):
    folder=RESULTS/expert; start=read(folder/'START.json'); ex=read(folder/'EXIT.json'); env=rows(folder/'environment.jsonl')
    require(start['scope']['_verified_scope_sha256']==SCOPE_SHA[expert] and start['scope']['scope_id']==scope['scope_id'],expert+' START scope')
    r=ex['result']; require(ex['status']=='SUCCESS' and ex['exception'] is None and r['status']=='CONFIRMATION_COLLECTION_COMPLETE' and r['completed_layers']==list(range(40)),expert+' incomplete EXIT')
    require(len(env)==1 and env[0]['scope_sha256']==SCOPE_SHA[expert] and env[0]['stream']=='CONFIRMATION/400' and env[0]['expert']==expert and env[0]['family']=='CHECKPOINT_80',expert+' environment')
    layer_rows=rows(folder/'layers.jsonl'); lp=rows(folder/'layer_plan.jsonl'); weights=rows(folder/'weights.jsonl'); spots=rows(folder/'fp64_spots.jsonl'); blocks=rows(folder/'blocks.jsonl')
    require(len(layer_rows)==40 and {x['layer'] for x in layer_rows}==set(range(40)) and all(x['expert']==expert and x['n']==1024 and x['status']=='COMPLETE' for x in layer_rows),expert+' layer receipt coverage')
    require(len(lp)==40 and {x['layer'] for x in lp}==set(range(40)) and all(x['expert']==expert for x in lp),expert+' plan receipt coverage')
    lmap={x['layer']:x for x in lp}
    require(len(spots)==80 and {(x['layer'],x['arm']) for x in spots}=={(i,a) for i in range(40) for a in ('Oq','Dq')} and all(x['expert']==expert and x['rows']=='independent_z_w' and x['numerical_status']=='UNASSESSED' and all(math.isfinite(v) and v>=0 for k in ('squared_error','reference_norm_sq') for v in x[k]) for x in spots),expert+' spot coverage')
    required={f'{expert}/{model}/blocks.{i}.ffn.{suffix}' for i in range(40) for model in ('original','distilled') for suffix in ('0.weight','0.bias','2.weight','2.bias')}
    seen=set(); require(len(weights)==320,expert+' tensor count')
    for x in weights:
        key=f"{x['expert']}/{x['model']}/{x['key']}"; require(key in required and key not in seen,expert+' unexpected/duplicate tensor receipt'); seen.add(key)
        require(x['key'].startswith(f"blocks.{x['layer']}.ffn.") and x['identity_status']=='PRECOMMITTED_HASH_MATCH' and x['sha256']==hashes[key],expert+' tensor SHA identity')
        spec=manifest['tensors'][key]; lo,hi=spec['spec']['data_offsets']; require(x['path']==spec['path'] and x['dtype']==spec['spec']['dtype'] and x['bytes']==hi-lo,expert+' tensor manifest identity')
    require(seen==required,expert+' tensor coverage')
    require(len(blocks)==40960,expert+' block count'); grouped={i:[] for i in range(40)}
    for b in blocks:
        require(b['expert']==expert and b['layer'] in grouped and b['stream']=='CONFIRMATION/400',expert+' block identity'); grouped[b['layer']].append(b)
    result=[]
    for i in range(40):
        p=plan['layers'][str(i)]; l=lmap[i]; lam=p['lambda']; c=p['c']
        require(l['n']==1024 and l['lambda']==lam and near(l['c_plan'],c) and near(l['c_recomputed'],c),expert+f' layer {i} c/plan mismatch')
        expect_mode='SKIPPED_ZERO_LAMBDA' if lam==0 else 'AFFINE'
        require(l['control_mode']==expect_mode and l['assets']=={'Oq':assets[f'{expert}/{i}/Oq']['sha256'],'Dq':assets[f'{expert}/{i}/Dq']['sha256'],'mean_difference':means[f'{expert}/{i}']['sha256']},expert+' layer asset SHA receipt')
        br=sorted(grouped[i],key=lambda x:x['block_id']); require([x['block_id'] for x in br]==list(range(1024)),expert+f' layer {i} block ids')
        raw=[]; adjusted=[]; denom=[]; md=[]
        for x in br:
            D=x['D_Oq']; U=x['U_checkpoint']; cv=x['C_checkpoint']; observed=x['signed_adjusted_U']; mm=x['mean_diff_norm_unbiased']
            require(all(type(v) in (int,float) and math.isfinite(v) for v in (D,U,observed,mm)) and D>=0 and U>=0 and x['C_mode']==expect_mode,expert+' bad scalar')
            if lam==0:
                require(cv is None and observed==U,expert+' zero lambda/skip mismatch')
            else:
                require(type(cv) in (int,float) and math.isfinite(cv) and cv>=0,expert+' invalid control')
                expected=U-lam*(cv-c); tolerance=5e-14*max(1e-12,abs(U),abs(lam*(cv-c)))
                require(abs(observed-expected)<=tolerance,expert+' signed control mismatch')
            raw.append(U); adjusted.append(observed); denom.append(D); md.append(mm)
        raw=np.array(raw); adjusted=np.array(adjusted); denom=np.array(denom); md=np.array(md)
        fit=fieller_set(adjusted,denom,alpha=.025,K=80); raw_fit=fieller_set(raw,denom,alpha=.025,K=80)
        rec={'expert':expert,'layer':i,'n':len(br),'n_required_from_planning':p['n_required'],'planning_status':p['status'],'lambda':lam,'c':c,'raw_point':raw_fit['point'],'adjusted_point':fit['point'],'mean_D_Oq':float(denom.mean()),'mean_U_checkpoint':float(raw.mean()),'mean_adjusted_U':float(adjusted.mean()),'mean_diff_norm_unbiased':float(md.mean()),'fieller':fit,'raw_fieller':raw_fit,'decision':decision(fit),'status':'STATISTICAL_APPROX_NUMERICS_UNASSESSED','power_status':'PLANNED_SAMPLE_SIZE_NOT_PROOF_OF_POWER'}
        result.append(rec)
    source_files=('START.json','EXIT.json','environment.jsonl','layers.jsonl','layer_plan.jsonl','weights.jsonl','fp64_spots.jsonl','blocks.jsonl')
    return result,{'job_id':start['allocation']['job_id'],'scope_sha256':SCOPE_SHA[expert],'complete_layers':40,'blocks':len(blocks),'tensor_receipts':len(weights),'fp64_spot_receipts':len(spots),'elapsed_seconds':ex['elapsed_seconds'],'local_evidence_sha256':{name:sha(folder/name) for name in source_files},'raw_tensor_note':'SHA checked by runner on compute node; local audit checks receipts and frozen manifest, not raw bytes','numerical_status':'UNASSESSED_NO_CERTIFIED_BOUND'}


def main():
    checked={expert:checked_scope(expert) for expert in ('high','low')}
    spec=importlib.util.spec_from_file_location('frozen_statistics_v7',SOURCE/'high'/'statistics_v7.py'); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    all_rows=[]; evidence={}
    for expert in ('high','low'):
        records,proof=audit(expert,*checked[expert],module.fieller_set); all_rows.extend(records); evidence[expert]=proof
    require(len(all_rows)==80 and {(x['expert'],x['layer']) for x in all_rows}=={(e,i) for e in ('high','low') for i in range(40)},'family incomplete')
    counts={k:sum(x['decision']==k for x in all_rows) for k in ('STAT_EQUIVALENT','STAT_ABOVE_TOLERANCE','INCONCLUSIVE')}
    summary={'status':'STATISTICAL_APPROX_NUMERICS_UNASSESSED','family':'CHECKPOINT_80','alpha':.025,'K':80,'theta_equivalence':LIMIT,'scope_sha256':SCOPE_SHA,'statistics_sha256':STAT_SHA,'evidence':evidence,'decisions':counts,'limitations':['Fieller intervals are asymptotic approximations, not rigorous bounds.','FP64 spot checks and quadrature comparisons are diagnostics and do not bound numerical error.','Numerical reserve in the planning formula is not a demonstrated error bound.','n=1024 completion does not establish adequate power.','Equality or invalid/unbounded confidence sets are INCONCLUSIVE.'],'rows':all_rows}
    (RESULTS/'analysis.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n',encoding='utf8')
    fields=['expert','layer','n','n_required_from_planning','planning_status','lambda','c','raw_point','adjusted_point','mean_D_Oq','mean_U_checkpoint','mean_adjusted_U','mean_diff_norm_unbiased','decision','status','power_status']
    with (RESULTS/'analysis.csv').open('w',encoding='utf8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore'); writer.writeheader(); writer.writerows(all_rows)
    print(json.dumps({'status':summary['status'],'decisions':counts,'evidence':evidence}))

if __name__=='__main__': main()
