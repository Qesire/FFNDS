"""Independent scalar recomputation of all 80 frozen Fieller analyses, no model calls."""
import hashlib,json,math,re,statistics
from pathlib import Path

ROOT=Path(__file__).resolve().parent
STAGE=ROOT.parent/'g19_v7_formal_checkpoint_confirm_r1'
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def rows(p):return [json.loads(x) for x in p.read_text(encoding='utf-8-sig').splitlines() if x.strip()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def close(x,y): assert math.isclose(x,y,rel_tol=5e-12,abs_tol=1e-17),(x,y)
analysis=load(ROOT/'analysis.json'); freeze=load(ROOT/'ANALYSIS_FREEZE.json')
assert sha(ROOT/'analyze_confirmation.py')==freeze['script_sha256']=='5a37b74b5ed38b8c038d60e84e5ef942e9aaf5b46f7599550e0254609ebf9676'
assert analysis['alpha']==.025 and analysis['K']==80 and analysis['theta_equivalence']==.0004
published={(r['expert'],r['layer']):r for r in analysis['rows']}; assert len(published)==len(analysis['rows'])==80
critical=statistics.NormalDist().inv_cdf(1-.025/(2*80)); limit=.0004
out=[]; evidence={}; signed_negative=0; totalblocks=0
for expert in ('high','low'):
    stage=STAGE/expert; folder=ROOT/expert; scope=load(stage/'scope.json'); config=load(stage/'config.json'); plan=load(stage/config['plan_file'])
    assert sha(stage/'scope.json')==analysis['scope_sha256'][expert]==freeze['scope_'+expert]
    for name,h in {**scope['code_sha256'],**scope['frozen_inputs_sha256'],scope['config_file']:scope['config_sha256'],scope['input_manifest_file']:scope['manifest_sha256']}.items():assert sha(stage/name)==h
    start=load(folder/'START.json'); end=load(folder/'EXIT.json'); env=rows(folder/'environment.jsonl')
    assert start['scope']['_verified_scope_sha256']==sha(stage/'scope.json')
    assert end['status']=='SUCCESS' and end['exception'] is None and end['result']['status']=='CONFIRMATION_COLLECTION_COMPLETE' and end['result']['completed_layers']==list(range(40))
    assert len(env)==1 and env[0]['stream']=='CONFIRMATION/400' and env[0]['scope_sha256']==sha(stage/'scope.json')
    job=str(start['allocation']['job_id']); sched=[x for x in (ROOT/'scheduler_completed.txt').read_text().splitlines() if re.search(r'\bJobId='+job+r'\b',x)]
    assert len(sched)==1 and 'JobState=COMPLETED' in sched[0] and 'ExitCode=0:0' in sched[0]
    weights=rows(folder/'weights.jsonl'); hashes=load(stage/config['expected_tensor_hashes_file'])
    assert len(weights)==320 and len({(r['model'],r['key']) for r in weights})==320
    for r in weights: assert r['identity_status']=='PRECOMMITTED_HASH_MATCH' and r['sha256']==hashes[f"{expert}/{r['model']}/{r['key']}"]
    blocks=rows(folder/'blocks.jsonl'); assert len(blocks)==40960; totalblocks+=len(blocks)
    bylayer={i:[] for i in range(40)}
    for r in blocks:
        assert r['expert']==expert and r['stream']=='CONFIRMATION/400'
        bylayer[r['layer']].append(r)
    layerplans={r['layer']:r for r in rows(folder/'layer_plan.jsonl')}; assert len(layerplans)==40
    for layer in range(40):
        br=sorted(bylayer[layer],key=lambda x:x['block_id']); assert [r['block_id'] for r in br]==list(range(1024))
        p=plan['layers'][str(layer)]; lam=p['lambda']; c=p['c']; assert p['n']==1024
        assert layerplans[layer]['lambda']==lam; close(layerplans[layer]['c_recomputed'],c)
        Y=[]; D=[]; raw=[]
        for r in br:
            u=r['U_checkpoint']; d=r['D_Oq']; obs=r['signed_adjusted_U']; assert all(math.isfinite(x) for x in (u,d,obs)) and min(u,d)>=0
            if lam:
                cv=r['C_checkpoint']; assert cv>=0 and math.isfinite(cv)
                expected=u-lam*(cv-c); assert r['C_mode']=='AFFINE'
            else:
                assert r['C_checkpoint'] is None and r['C_mode']=='SKIPPED_ZERO_LAMBDA'; expected=u
            close(obs,expected); Y.append(obs); D.append(d); raw.append(u); signed_negative+=obs<0
        n=1024; ym=math.fsum(Y)/n; dm=math.fsum(D)/n
        vy=math.fsum((y-ym)**2 for y in Y)/(n-1); vd=math.fsum((d-dm)**2 for d in D)/(n-1); cov=math.fsum((y-ym)*(d-dm) for y,d in zip(Y,D))/(n-1)
        scale=critical**2/n; a=dm*dm-scale*vd; b=-2*(ym*dm-scale*cov); cc=ym*ym-scale*vy; disc=b*b-4*a*cc
        assert a>0 and disc>0 and dm-critical*math.sqrt(vd/n)>0
        q=-.5*(b+math.copysign(math.sqrt(disc),b)); bounds=sorted((q/a,cc/q))
        verdict='STAT_EQUIVALENT' if bounds[1]<limit else ('STAT_ABOVE_TOLERANCE' if bounds[0]>limit else 'INCONCLUSIVE')
        orig=published[expert,layer]; assert orig['decision']==verdict and orig['fieller']['decision_eligible'] and orig['fieller']['denominator_positive']
        assert len(orig['fieller']['intervals'])==1
        for x,y in zip(orig['fieller']['intervals'][0],bounds):close(x,y)
        close(orig['adjusted_point'],ym/dm); close(orig['raw_point'],math.fsum(raw)/n/dm)
        out.append({'expert':expert,'layer':layer,'adjusted_MSE_ratio':ym/dm,'RMS_ratio':math.sqrt(ym/dm),'fieller_interval':bounds,'decision':verdict,'threshold_distance':min(abs(t-limit) for t in bounds)})
    files=('START.json','EXIT.json','environment.jsonl','layers.jsonl','layer_plan.jsonl','weights.jsonl','fp64_spots.jsonl','blocks.jsonl')
    localsha={f:sha(folder/f) for f in files}
    assert localsha==analysis['evidence'][expert]['local_evidence_sha256']
    evidence[expert]={'job_id':job,'scope_sha256':sha(stage/'scope.json'),'elapsed_seconds':end['elapsed_seconds'],'local_evidence_sha256':localsha}
counts={k:sum(r['decision']==k for r in out) for k in ('STAT_EQUIVALENT','STAT_ABOVE_TOLERANCE','INCONCLUSIVE')}; assert counts==analysis['decisions']
report={'status':'INDEPENDENT_ALL_80_SCALAR_RECOMPUTATION_PASS','n_blocks':totalblocks,'family_alpha':.025,'K':80,'critical_normal':critical,'threshold_relative_MSE':limit,'equivalent_threshold_relative_RMS':math.sqrt(limit),'decision_counts':counts,'negative_adjusted_observations':signed_negative,'closest_to_threshold':sorted(out,key=lambda r:r['threshold_distance'])[:6],'inconclusive':[r for r in out if r['decision']=='INCONCLUSIVE'],'evidence':evidence,'limitations':['Asymptotic normal/Fieller family inference, not finite-sample coverage guarantee.','Floating point and Gaussian input rounding are not bounded; numerical status remains UNASSESSED.','Read-only local scalar receipts and hashes; no remote model rerun or local raw tensor bytes.']}
(ROOT/'INDEPENDENT_RESULT_CHECKS.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='evidence'},indent=2))
