import importlib.util,unittest
from pathlib import Path
import numpy as np
from analyze_confirmation import decision,checked_scope

class Tests(unittest.TestCase):
 def test_strict_decisions_and_unbounded(self):
  base={'decision_eligible':True,'denominator_positive':True}
  self.assertEqual(decision({**base,'intervals':[[.0001,.00039]]}),'STAT_EQUIVALENT')
  self.assertEqual(decision({**base,'intervals':[[.00041,.0005]]}),'STAT_ABOVE_TOLERANCE')
  for iv in [[[.0001,.0004]],[[.0004,.0006]],[[None,.0002]],[[.0001,.0002],[.0005,None]],[]]:
   self.assertEqual(decision({**base,'intervals':iv}),'INCONCLUSIVE')
  self.assertEqual(decision({'decision_eligible':False,'denominator_positive':True,'intervals':[[0,.0001]]}),'INCONCLUSIVE')
  self.assertEqual(decision({'decision_eligible':True,'denominator_positive':False,'intervals':[[0,.0001]]}),'INCONCLUSIVE')
 def test_current_frozen_scopes_and_signed_fieller(self):
  for expert in ('high','low'):
   scope,config,plan,manifest,hashes,assets,means=checked_scope(expert)
   self.assertEqual(len(plan['layers']),40); self.assertEqual(config['expert'],expert)
  src=Path(__file__).resolve().parent.parent/'g19_v7_formal_checkpoint_confirm_r1'/'high'/'statistics_v7.py'
  spec=importlib.util.spec_from_file_location('stats_test',src); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
  y=np.array([-.2,-.1,.0,.1]*256); d=np.full(1024,10.)
  result=m.fieller_set(y,d,alpha=.025,K=80)
  self.assertLess(result['point'],0); self.assertTrue(result['denominator_positive'])

if __name__=='__main__':unittest.main()
