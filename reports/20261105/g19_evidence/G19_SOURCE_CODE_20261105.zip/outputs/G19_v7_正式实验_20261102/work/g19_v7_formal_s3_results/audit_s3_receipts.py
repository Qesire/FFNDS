"""Independent S3 receipt identity audit; reads local downloads and S12 ledgers only."""
import hashlib,json,re
from pathlib import Path
from analyze_s3_structure import STRATA
HERE=Path(__file__).resolve().parent
STAGED=HERE.parent/'g19_v7_formal_s3_r1'
S12=HERE.parent/'g19_v7_formal_s12_results'

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for x in iter(lambda:f.read(1024*1024),b''): h.update(x)
 return h.hexdigest()
def jl(p):
 with p.open(encoding='utf-8-sig') as f:return [json.loads(x) for x in f if x.strip()]
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))

def main():
 reports=[]; counts={'unit_records':0,'A1_receipts_matched':0,'raw_tensor_receipts_matched':0,'candidate_receipts_matched':0,'scope_receipts_matched':0}; issues=[]
 for e in ('high','low'):
  srcweights={(x['model'],x['key']):x['sha256'] for x in jl(S12/e/'weights.jsonl')}
  s12A={(x['layer'],x['arm']):x['sha256'] for x in jl(S12/e/'artifacts.jsonl') if x.get('kind')=='A1'}
  for st,layers in enumerate(STRATA):
   name=f'{e}_s{st}'; result=HERE/name; stage=STAGED/name
   info={'shard':name,'issues':[]}
   if not result.is_dir():info['status']='NOT_DOWNLOADED'; reports.append(info);continue
   def check(cond,msg):
    if not cond:info['issues'].append(msg);issues.append(name+': '+msg)
   try:
    start=load(result/'START.json'); scope=load(stage/'scope.json'); scopehash=sha(stage/'scope.json'); review=load(stage/'INDEPENDENT_REVIEW.json'); env=jl(result/'environment.jsonl')[0]; config=load(stage/'config.json')
    check(start['scope'].get('_verified_scope_sha256')==scopehash==env.get('scope_sha256')==review.get('scope_sha256'),'scope hash mismatch')
    check(review.get('status')=='ACCEPTED' and review.get('reviewer') not in scope['authors'],'review missing or not independent')
    check(scope.get('phase')=='S3_STRUCTURE_DEVELOPMENT' and config.get('expert')==e and config.get('layers')==list(layers),'scope phase or shard identity mismatch')
    for fname,digest in {**scope['code_sha256'],**scope['frozen_inputs_sha256'],scope['config_file']:scope['config_sha256'],scope['input_manifest_file']:scope['manifest_sha256']}.items(): check(sha(stage/fname)==digest,'frozen identity mismatch '+fname)
    counts['scope_receipts_matched']+=not bool(info['issues'])
    assets=load(stage/scope['s12_assets_file']); expected=load(stage/scope['expected_tensor_hashes_file'])
    weightrows=jl(result/'weights.jsonl'); seen=set()
    for r in weightrows:
     key=(r['model'],r['key']); full=f"{e}/{r['model']}/{r['key']}"
     check(key not in seen,'duplicate raw tensor receipt '+full);seen.add(key)
     check(r['layer'] in layers and r['identity_status']=='PRECOMMITTED_HASH_MATCH' and r['sha256']==srcweights.get(key)==expected.get(full),'raw tensor receipt mismatch '+full)
     if r['sha256']==srcweights.get(key)==expected.get(full) and r['identity_status']=='PRECOMMITTED_HASH_MATCH':counts['raw_tensor_receipts_matched']+=1
    unitrows=jl(result/'units.jsonl'); count_units=set(); candidate_art={r['path']:r for r in jl(result/'artifacts.jsonl')}
    for u in unitrows:
     key=(u['layer'],u['arm']);counts['unit_records']+=1; check(key not in count_units and u['expert']==e and u['layer'] in layers and u['arm'] in ('Oq','Dq'),'duplicate/bad unit'); count_units.add(key)
     expectedA=assets.get(f"{e}/{u['layer']}/{u['arm']}",{}).get('sha256')
     check(u.get('A1_sha256')==expectedA==s12A.get(key),'A1 receipt mismatch '+str(key))
     if u.get('A1_sha256')==expectedA==s12A.get(key) and expectedA:counts['A1_receipts_matched']+=1
     for candidate in u.get('successful_candidates',[]):
      shared=candidate.endswith('_OQ_SHARED'); base=candidate.removesuffix('_OQ_SHARED'); filename=f"{u['layer']:02d}_{u['arm']}_{base}"+('_shared' if shared else '')+'.pt'
      rec=candidate_art.get(filename); valid=rec is not None and bool(re.fullmatch('[0-9a-f]{64}',rec.get('sha256','')))
      check(valid,'missing/malformed candidate artifact receipt '+filename)
      counts['candidate_receipts_matched']+=int(valid)
    exitfile=result/'EXIT.json'; info['exit_present']=exitfile.exists()
    if exitfile.exists():
      exit=load(exitfile); info['exit_status']=exit.get('status');info['result_status']=exit.get('result',{}).get('status')
      check(exit.get('status')=='SUCCESS' and exit.get('result',{}).get('status')=='S3_SHARD_INCOMPLETE','unexpected terminal status')
      check(len(unitrows)==6,'terminal receipt but missing unit rows')
    else: info['status']='PARTIAL_NO_EXIT'
    info['unit_count']=len(unitrows);info['raw_tensor_receipts']=len(weightrows);info['candidate_artifact_receipts']=len(candidate_art)
    if not info.get('status'): info['status']='CHECKED_WITH_INCOMPLETE_SCIENTIFIC_RESULTS' if not info['issues'] else 'IDENTITY_ERROR'
   except (OSError,KeyError,ValueError,IndexError) as exc:
    info['status']='AUDIT_ERROR';info['issues'].append(repr(exc));issues.append(name+': '+repr(exc))
   reports.append(info)
 output={'status':'RECEIPT_CHECK_PARTIAL' if any(x.get('status') in ('PARTIAL_NO_EXIT','NOT_DOWNLOADED') for x in reports) else ('RECEIPT_IDENTITY_ERROR' if issues else 'RECEIPT_IDENTITY_CHECKED'),'counts':counts,'issues':issues,'shards':reports,'limits':['Receipt comparison only: original raw tensor bytes, A1 files and candidate .pt bytes were not downloaded for local independent rehash.','SUCCESS process status does not imply complete candidate families; all oblique unresolved outcomes remain missing.','Scheduler text is a snapshot, not independently refreshed by this script.']}
 (HERE/'s3_receipt_audit.json').write_text(json.dumps(output,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
 print(json.dumps(output,indent=2))
if __name__=='__main__':main()
