"""Read-only S3 receipt analysis. Writes only derived S3 summary/CSV in --root.
Eight planned shards, 48 Oq/Dq units; missing candidates remain explicit rows.
No GPU, weights or server operations. Descriptive independent development only.
"""
import argparse, csv, json, math, re, statistics
from pathlib import Path

STRATA=((0,1,7),(12,13,19),(23,24,28),(33,37,38))
CANDIDATES=('ORTH_FULL_RJD','EDGE_FULL_RJD','ORTH_SUBSPACE_512','EDGE_SUBSPACE_384_E256','OBLIQUE_SUBSPACE_512')
D=5120; M=13824; N=D-1


def cost(name):
    linear=D*D; baseline=2*D*M
    if name=='FULL_Q2': return {'candidate_main_macs':baseline,'baseline_main_macs':baseline,'accounting':'best fused h0+h1+h2 in one W2; detector actually used separate A bypass'}
    name=name.removesuffix('_OQ_SHARED')
    k,e={'ORTH_FULL_RJD':(N,0),'EDGE_FULL_RJD':(N,N//2),'ORTH_SUBSPACE_512':(512,0),'EDGE_SUBSPACE_384_E256':(384,256),'OBLIQUE_SUBSPACE_512':(512,0)}[name]
    return {'candidate_main_macs':linear+2*D*k+D*e,'baseline_main_macs':baseline,'directions':k,'edges':e,'accounting':'dense main MAC only, includes A bypass; excludes build, feature ops, memory and timing'}


def rows(path):
    if not path.is_file(): return []
    with path.open(encoding='utf-8-sig') as f: return [json.loads(line) for line in f if line.strip()]


def mean(values,n):
    if not isinstance(values,list) or len(values)!=n or any(not isinstance(x,(float,int)) or not math.isfinite(x) or x<0 for x in values): raise ValueError('invalid raw squared values')
    return statistics.fmean(values)


def dist(values):
    vals=[x for x in values if x is not None]
    return {'count':len(vals),'min':min(vals),'median':statistics.median(vals),'max':max(vals)} if vals else {'count':0,'min':None,'median':None,'max':None}


def compare(a,b): return None if b is None or b<=0 else a/b


def read_shard(root,expert,stratum):
    path=root/f'{expert}_s{stratum}'
    if not path.is_dir(): return {'status':'NOT_DOWNLOADED','name':path.name}, {}, {}, {}, {}
    end=path/'EXIT.json'; start=path/'START.json'
    ending=json.loads(end.read_text(encoding='utf-8-sig')) if end.is_file() else None
    beginning=json.loads(start.read_text(encoding='utf-8-sig')) if start.is_file() else None
    info={'status':'PARTIAL_RECEIPTS' if ending is None else ending.get('result',{}).get('status','UNKNOWN'),'process_exit':None if ending is None else ending.get('status'), 'name':path.name}
    if beginning:
        info['job_id']=str(beginning['allocation']['job_id']); info['scope_sha256']=beginning['scope'].get('_verified_scope_sha256'); info['phase']=beginning['scope'].get('phase')
        scheduler_lines=[line for f in root.glob('scheduler*.txt') for line in f.read_text(encoding='utf-8-sig').splitlines() if re.search(r'\bJobId='+re.escape(info['job_id'])+r'(?:\s|$)',line)]
        info['scheduler_state']='NOT_DOWNLOADED' if not scheduler_lines else ('COMPLETED_0_0' if any('JobState=COMPLETED' in line and 'ExitCode=0:0' in line for line in scheduler_lines) else 'OTHER_OR_UNCONFIRMED')
        if info['phase']!='S3_STRUCTURE_DEVELOPMENT': raise ValueError(path.name+' incorrect phase')
    env=rows(path/'environment.jsonl')
    if env and beginning and env[0].get('scope_sha256')!=info['scope_sha256']: raise ValueError(path.name+' environment scope mismatch')
    info['environment']=env[0] if env else None
    if ending: info['inconclusive_units']=ending.get('result',{}).get('inconclusive_units',[])
    unit={}; refs={}; blocks={}; statuses={}
    for x in rows(path/'units.jsonl'):
        key=(x['layer'],x['arm'])
        if x.get('expert')!=expert or key[0] not in STRATA[stratum] or key[1] not in ('Oq','Dq') or key in unit: raise ValueError(path.name+' invalid unit identity')
        unit[key]=x
    for x in rows(path/'reference_blocks.jsonl'):
        key=(x['layer'],x['arm'])
        if key in refs or key[0] not in STRATA[stratum] or key[1] not in ('Oq','Dq') or x.get('block_ids')!=list(range(64)) or x.get('stream')!='DEVELOPMENT_72': raise ValueError(path.name+' invalid reference blocks')
        for field in ('D_F','D_residual','D_Q2','U_Q2'): mean(x[field],64)
        refs[key]=x
    for x in rows(path/'blocks.jsonl'):
        key=(x['layer'],x['arm'],x['candidate'])
        if key in blocks or key[0] not in STRATA[stratum] or key[1] not in ('Oq','Dq') or x.get('block_ids')!=list(range(64)) or x.get('stream')!='DEVELOPMENT_72': raise ValueError(path.name+' invalid candidate blocks')
        mean(x['squared_error'],64)
        if 'operator_frob_probe' in x:
            if x.get('operator_probe_ids')!=list(range(16)) or x.get('operator_probe_streams')!=[73,75]: raise ValueError(path.name+' invalid operator probes')
            mean(x['operator_frob_probe'],16)
        blocks[key]=x
    for x in rows(path/'candidate_status.jsonl'):
        k=(x['layer'],x['arm'],x['candidate'],x.get('comparison'))
        if k in statuses: raise ValueError(path.name+' duplicate status')
        statuses[k]=x
    return info,unit,refs,blocks,statuses


def make_record(expert,layer,arm,name,unit,refs,blocks,statuses,shard_status):
    k=(layer,arm); available=blocks.get((layer,arm,name)); ref=refs.get(k); base=name.removesuffix('_OQ_SHARED'); shared=name.endswith('_OQ_SHARED')
    statusrow=statuses.get((layer,arm,base,'OQ_SHARED_BASIS' if shared else None))
    if available and (not ref or not unit): raise ValueError('candidate blocks without complete reference/unit')
    if available and base!='FULL_Q2' and (not statusrow or statusrow.get('status')!='OK'): raise ValueError('candidate blocks conflict with status')
    if available: status='OK'
    elif statusrow: status=statusrow['status']
    elif shard_status=='NOT_DOWNLOADED': status='NOT_DOWNLOADED'
    elif shared and statuses.get((layer,'Oq',base,None),{}).get('status') not in (None,'OK'): status='UPSTREAM_OQ_CANDIDATE_UNRESOLVED'
    elif k not in unit: status='UNIT_NOT_RECORDED'
    else: status='CANDIDATE_NOT_RECORDED'
    c=cost(name); row={'expert':expert,'layer':layer,'arm':arm,'candidate':name,'candidate_status':status,'unit_status':unit.get(k,{}).get('status','NOT_RECORDED'), 'available':available is not None,'ratio_mse_over_V':None,'ratio_rms_over_sqrt_V':None,'ratio_mse_over_Q2_energy':None,'operator_frob_probe_mean':None,'operator_over_Q2_energy':None,'ref_variance_mean':None,'q2_energy_mean':None,'n_blocks':None,'n_operator_probes':None,'shared_delta_F_mse_over_checkpoint_energy':None,'shared_delta_Q2_mse_over_delta_Q2_energy':None,**c}
    row['candidate_macs_over_original']=c['candidate_main_macs']/c['baseline_main_macs']
    if not available: return row
    if name!='FULL_Q2' and name not in unit[k].get('successful_candidates',[]): raise ValueError('available candidate missing from successful list')
    E=mean(available['squared_error'],64); V=mean(ref['D_F'],64); Q=mean(ref['U_Q2'],64)
    if V<=0: raise ValueError('nonpositive denominator')
    row.update(error_mean=E,ref_variance_mean=V,q2_energy_mean=Q,ratio_mse_over_V=E/V,ratio_rms_over_sqrt_V=math.sqrt(E/V),ratio_mse_over_Q2_energy=compare(E,Q),n_blocks=64)
    if 'operator_frob_probe' in available:
        op=mean(available['operator_frob_probe'],16); row.update(operator_frob_probe_mean=op,operator_over_Q2_energy=compare(op,Q),n_operator_probes=16)
    if arm=='Dq' and name!='FULL_Q2':
        suffix='SHARED' if shared else 'OWN'
        for field,ref_field,out_field,estimand in [('DELTA_'+suffix,'U_checkpoint_difference','shared_delta_F_mse_over_checkpoint_energy','DELTA_FULL_FFN_AFTER_FIXED_AFFINE_AND_Q2_APPROX'),('DELTA_Q2_'+suffix,'U_delta_Q2','shared_delta_Q2_mse_over_delta_Q2_energy','DELTA_Q2_ONLY')]:
            x=blocks.get((layer,arm,base+'_'+field))
            if x:
                if x.get('estimand')!=estimand or ref_field not in ref: raise ValueError('delta estimand/denominator mismatch')
                row[out_field]=compare(mean(x['squared_error'],64),mean(ref[ref_field],64))
    return row


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parent); args=ap.parse_args(); root=args.root
    shard_info=[]; allrows=[]; missing_units=[]; available_units=[]
    for e in ('high','low'):
        for s,layers in enumerate(STRATA):
            info,units,refs,blocks,statuses=read_shard(root,e,s); shard_info.append(info)
            for layer in layers:
                for arm in ('Oq','Dq'):
                    key=(layer,arm)
                    (available_units if key in units else missing_units).append({'expert':e,'layer':layer,'arm':arm,'status':units.get(key,{}).get('status','NOT_RECORDED')})
                    names=['FULL_Q2',*CANDIDATES]+([x+'_OQ_SHARED' for x in CANDIDATES] if arm=='Dq' else [])
                    for name in names: allrows.append(make_record(e,layer,arm,name,units,refs,blocks,statuses,info['status']))
    assert len(available_units)+len(missing_units)==48 and len(allrows)==408
    metrics={}
    for name in ['FULL_Q2',*CANDIDATES]+[n+'_OQ_SHARED' for n in CANDIDATES]:
        subset=[r for r in allrows if r['candidate']==name and r['available']]
        metrics[name]={'n':len(subset),'MSE_over_V':dist([r['ratio_mse_over_V'] for r in subset]),'RMS_over_sqrt_V':dist([r['ratio_rms_over_sqrt_V'] for r in subset]),'full_F_error_over_Q2_energy':dist([r['ratio_mse_over_Q2_energy'] for r in subset]),'operator_residual_over_Q2_energy':dist([r['operator_over_Q2_energy'] for r in subset]),'delta_F_error_over_checkpoint_energy':dist([r['shared_delta_F_mse_over_checkpoint_energy'] for r in subset]),'delta_Q2_error_over_delta_Q2_energy':dist([r['shared_delta_Q2_mse_over_delta_Q2_energy'] for r in subset]),'macs':cost(name)}
    status_counts={}
    for r in allrows: status_counts[r['candidate_status']]=status_counts.get(r['candidate_status'],0)+1
    comparisons=[]
    for e in ('high','low'):
      for layer in sum((list(x) for x in STRATA),[]):
       for arm in ('Oq','Dq'):
        idx={r['candidate']:r for r in allrows if r['expert']==e and r['layer']==layer and r['arm']==arm}
        a=idx['ORTH_SUBSPACE_512']; b=idx['EDGE_SUBSPACE_384_E256']
        if a['available'] and b['available']:
            assert a['candidate_main_macs']==b['candidate_main_macs']
            comparisons.append({'expert':e,'layer':layer,'arm':arm,'edge_minus_orth_MSE_over_V':b['ratio_mse_over_V']-a['ratio_mse_over_V'],'same_main_MAC':a['candidate_main_macs']})
    shared_comparisons=[]
    for own in (r for r in allrows if r['arm']=='Dq' and r['candidate'] in CANDIDATES and r['available']):
        matches=[r for r in allrows if r['expert']==own['expert'] and r['layer']==own['layer'] and r['arm']=='Dq' and r['candidate']==own['candidate']+'_OQ_SHARED' and r['available']]
        if matches:
            shared=matches[0]
            shared_comparisons.append({'expert':own['expert'],'layer':own['layer'],'candidate':own['candidate'],'shared_minus_own_MSE_over_V':shared['ratio_mse_over_V']-own['ratio_mse_over_V'],'shared_minus_own_operator_over_Q2':shared['operator_over_Q2_energy']-own['operator_over_Q2_energy']})
    summary={'status':'DESCRIPTIVE_DEVELOPMENT_NOT_CONFIRMATION','planned_units':48,'downloaded_unit_records':len(available_units),'unrecorded_units':missing_units,'unit_records':available_units,'shards':shard_info,'candidate_status_counts':status_counts,'metrics':metrics,'shared_vs_own':{'count':len(shared_comparisons),'shared_minus_own_MSE_over_V':dist([r['shared_minus_own_MSE_over_V'] for r in shared_comparisons]),'per_unit':shared_comparisons},'equal_MAC_edge384_vs_orth512':{'count':len(comparisons),'edge_minus_orth_MSE_over_V':dist([r['edge_minus_orth_MSE_over_V'] for r in comparisons]),'per_unit':comparisons},'limitations':['Development selection/evaluation only; 64 blocks and 16 operator probes are not a confirmation or confidence bound.','Candidate full-FFN error divided by Q2 energy is not itself Q2 approximation error; use operator residual diagnostic for Q2 tensor.','Operator residual/Q2 energy uses independent 16-probe numerator and 64-block Q2 denominator; diagnostic, not a strict bound.','Main MAC proxy omits basis construction, data movement, memory and runtime; no native speed or quality claim.','Oblique unresolved is numerical proposal failure, not proof against nonorthogonal structure or all low-compute representations.','Process EXIT SUCCESS may coexist with S3_SHARD_INCOMPLETE; candidate and unit statuses must be retained separately.']}
    (root/'s3_structure_summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
    with (root/'s3_structure_units.csv').open('w',encoding='utf-8',newline='') as f:
        fields=list(dict.fromkeys(k for r in allrows for k in r)); writer=csv.DictWriter(f,fieldnames=fields); writer.writeheader(); writer.writerows(allrows)
    print(json.dumps({'downloaded_units':len(available_units),'status_counts':status_counts,'metrics':metrics,'equal_MAC':summary['equal_MAC_edge384_vs_orth512']['edge_minus_orth_MSE_over_V']},indent=2))
if __name__=='__main__': main()
