import json,tempfile,unittest
from pathlib import Path
import analyze_s3_structure as a

class Tests(unittest.TestCase):
 def test_matched_main_cost_and_fused_reference(self):
  self.assertEqual(a.cost('ORTH_SUBSPACE_512')['candidate_main_macs'],a.cost('EDGE_SUBSPACE_384_E256')['candidate_main_macs'])
  self.assertEqual(a.cost('FULL_Q2')['candidate_main_macs'],2*5120*13824)
  self.assertGreater(a.cost('EDGE_FULL_RJD')['candidate_main_macs'],a.cost('ORTH_FULL_RJD')['candidate_main_macs'])
 def test_missing_candidate_does_not_hide_valid(self):
  units={(0,'Oq'):{'status':'UNIT_INCONCLUSIVE','successful_candidates':['ORTH_FULL_RJD']}}
  refs={(0,'Oq'):{'D_F':[4.]*64,'U_Q2':[2.]*64}}
  blocks={(0,'Oq','ORTH_FULL_RJD'):{'squared_error':[1.]*64,'operator_frob_probe':[3.]*16}}
  statuses={(0,'Oq','ORTH_FULL_RJD',None):{'status':'OK'},(0,'Oq','OBLIQUE_SUBSPACE_512',None):{'status':'UNRESOLVED_ALL_PENCILS'}}
  valid=a.make_record('high',0,'Oq','ORTH_FULL_RJD',units,refs,blocks,statuses,'S3_SHARD_INCOMPLETE')
  missing=a.make_record('high',0,'Oq','OBLIQUE_SUBSPACE_512',units,refs,blocks,statuses,'S3_SHARD_INCOMPLETE')
  self.assertEqual(valid['ratio_mse_over_V'],.25); self.assertEqual(valid['operator_over_Q2_energy'],1.5)
  self.assertEqual(missing['candidate_status'],'UNRESOLVED_ALL_PENCILS'); self.assertIsNone(missing['ratio_mse_over_V'])
 def test_wrong_block_identity_rejected(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'high_s0'; p.mkdir(); row={'layer':0,'arm':'Oq','block_ids':list(range(63))+[62],'stream':'DEVELOPMENT_72','D_F':[1]*64,'D_residual':[1]*64,'D_Q2':[1]*64,'U_Q2':[1]*64}
   (p/'reference_blocks.jsonl').write_text(json.dumps(row)+'\n')
   with self.assertRaisesRegex(ValueError,'reference blocks'): a.read_shard(Path(tmp),'high',0)
if __name__=='__main__': unittest.main(verbosity=2)
