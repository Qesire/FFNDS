"""Independent read-only reaggregation of downloaded S3 receipts; no model calls."""
import csv, hashlib, json, math, statistics
from pathlib import Path

ROOT=Path(__file__).resolve().parent
STAGE=ROOT.parent/'g19_v7_formal_s3_r1'
S12=ROOT.parent/'g19_v7_formal_s12_results'
LAYERS=((0,1,7),(12,13,19),(23,24,28),(33,37,38))
OWN=('ORTH_FULL_RJD','EDGE_FULL_RJD','ORTH_SUBSPACE_512','EDGE_SUBSPACE_384_E256')
SAMPLE={('high',0,'Oq'),('high',38,'Dq'),('low',12,'Oq'),('low',28,'Dq')}
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def lines(p): return [json.loads(x) for x in p.read_text(encoding='utf-8-sig').splitlines() if x.strip()]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def avg(a,n):
    assert len(a)==n and all(math.isfinite(x) and x>=0 for x in a)
    return math.fsum(a)/n
def close(a,b): assert math.isclose(a,b,rel_tol=3e-14,abs_tol=1e-15),(a,b)
def triangle(a,b,c):
    for x,y,z in zip(a,b,c):
        lo=(math.sqrt(x)-math.sqrt(y))**2; hi=(math.sqrt(x)+math.sqrt(y))**2
        assert lo-1e-10*max(1,hi)<=z<=hi+1e-10*max(1,hi),(x,y,z)

csvrows=list(csv.DictReader((ROOT/'s3_structure_units.csv').open(encoding='utf-8-sig',newline='')))
assert len(csvrows)==408
table={(r['expert'],int(r['layer']),r['arm'],r['candidate']):r for r in csvrows}
assert len(table)==408
summary=load(ROOT/'s3_structure_summary.json')
counts=dict(scopes=0,units=0,references=0,raw_weights=0,A1=0,candidate_artifact_receipts=0,successful_candidate_rows=0,own_oblique_unresolved=0,complex_pencils=0)
samples=[]; ratios={k:[] for k in ('FULL_Q2',*OWN)}; equal=[]; shared=[]; paths={}
for expert in ('high','low'):
    sw={(x['model'],x['key']):x['sha256'] for x in lines(S12/expert/'weights.jsonl')}
    sa={(x['layer'],x['arm']):x['sha256'] for x in lines(S12/expert/'artifacts.jsonl') if x['kind']=='A1'}
    for s,layerset in enumerate(LAYERS):
        root=ROOT/f'{expert}_s{s}'; stage=STAGE/root.name
        scope=load(stage/'scope.json'); start=load(root/'START.json'); end=load(root/'EXIT.json')
        assert start['scope']['_verified_scope_sha256']==sha(stage/'scope.json')==load(stage/'INDEPENDENT_REVIEW.json')['scope_sha256']
        assert end['status']=='SUCCESS' and end['result']['status']=='S3_SHARD_INCOMPLETE'
        for p,h in {**scope['code_sha256'],**scope['frozen_inputs_sha256'],scope['config_file']:scope['config_sha256'],scope['input_manifest_file']:scope['manifest_sha256']}.items(): assert sha(stage/p)==h
        counts['scopes']+=1
        units={(x['layer'],x['arm']):x for x in lines(root/'units.jsonl')}; assert len(units)==6
        refs={(x['layer'],x['arm']):x for x in lines(root/'reference_blocks.jsonl')}; assert len(refs)==6
        rawblocks=lines(root/'blocks.jsonl'); blocks={(x['layer'],x['arm'],x['candidate']):x for x in rawblocks}; assert len(blocks)==len(rawblocks)==90
        statuses={(x['layer'],x['arm'],x['candidate'],x.get('comparison')):x for x in lines(root/'candidate_status.jsonl')}
        weights=lines(root/'weights.jsonl'); assert len(weights)==24 and len({(x['model'],x['key']) for x in weights})==24
        expected=load(stage/scope['expected_tensor_hashes_file']); assets=load(stage/scope['s12_assets_file'])
        for x in weights:
            assert x['identity_status']=='PRECOMMITTED_HASH_MATCH' and x['sha256']==sw[x['model'],x['key']]==expected[f"{expert}/{x['model']}/{x['key']}"]
            counts['raw_weights']+=1
        arts=lines(root/'artifacts.jsonl'); assert len(arts)==36 and len({x['path'] for x in arts})==36
        amap={x['path']:x for x in arts}
        for x in arts: assert len(x['sha256'])==64 and all(c in '0123456789abcdef' for c in x['sha256'])
        counts['candidate_artifact_receipts']+=36
        for b in rawblocks:
            assert b['block_ids']==list(range(64)) and b['stream']=='DEVELOPMENT_72'
            avg(b['squared_error'],64)
            if 'operator_frob_probe' in b:
                assert b['operator_probe_ids']==list(range(16)) and b['operator_probe_streams']==[73,75]
                avg(b['operator_frob_probe'],16)
        for layer in layerset:
            for arm in ('Oq','Dq'):
                u=units[layer,arm]; ref=refs[layer,arm]; counts['units']+=1; counts['references']+=1
                assert u['expert']==expert and u['status']=='UNIT_INCONCLUSIVE'
                assert u['A1_sha256']==sa[layer,arm]==assets[f'{expert}/{layer}/{arm}']['sha256']; counts['A1']+=1
                assert ref['block_ids']==list(range(64)) and ref['stream']=='DEVELOPMENT_72'
                for field in ('D_F','D_residual','D_Q2','U_Q2'): avg(ref[field],64)
                V=avg(ref['D_F'],64); Q=avg(ref['U_Q2'],64); assert V>0 and Q>0
                names=list(OWN)+([n+'_OQ_SHARED' for n in OWN] if arm=='Dq' else [])
                assert set(u['successful_candidates'])==set(names)
                rejected=statuses[layer,arm,'OBLIQUE_SUBSPACE_512',None]
                assert rejected['status']=='UNRESOLVED_ALL_PENCILS' and len(rejected['attempts'])==4
                assert all(x['status']=='REJECTED_COMPLEX_PENCIL' for x in rejected['attempts'])
                counts['own_oblique_unresolved']+=1; counts['complex_pencils']+=4
                ob=table[expert,layer,arm,'OBLIQUE_SUBSPACE_512']; assert ob['available']=='False' and ob['ratio_mse_over_V']==''
                if arm=='Dq':
                    ob=table[expert,layer,arm,'OBLIQUE_SUBSPACE_512_OQ_SHARED']; assert ob['available']=='False' and ob['candidate_status']=='UPSTREAM_OQ_CANDIDATE_UNRESOLVED'
                local={}
                for name in ['FULL_Q2',*names]:
                    b=blocks[layer,arm,name]; E=avg(b['squared_error'],64); ratio=E/V
                    row=table[expert,layer,arm,name]
                    assert row['available']=='True'; close(float(row['ratio_mse_over_V']),ratio)
                    close(float(row['ratio_rms_over_sqrt_V']),math.sqrt(ratio)); close(float(row['ratio_mse_over_Q2_energy']),E/Q)
                    if name!='FULL_Q2':
                        sharedflag=name.endswith('_OQ_SHARED'); base=name.removesuffix('_OQ_SHARED')
                        assert statuses[layer,arm,base,'OQ_SHARED_BASIS' if sharedflag else None]['status']=='OK'
                        filename=f'{layer:02d}_{arm}_{base}'+('_shared' if sharedflag else '')+'.pt'; assert filename in amap
                        op=avg(b['operator_frob_probe'],16); close(float(row['operator_over_Q2_energy']),op/Q)
                        counts['successful_candidate_rows']+=1
                    if name in ratios: ratios[name].append(ratio)
                    local[name]=ratio
                equal.append(local['EDGE_SUBSPACE_384_E256']-local['ORTH_SUBSPACE_512'])
                if (expert,layer,arm) in SAMPLE:
                    samples.append({'expert':expert,'layer':layer,'arm':arm,'D_F_mean':V,'U_Q2_mean':Q,'ratios_MSE_over_V':local})
                if arm=='Dq':
                    oq=refs[layer,'Oq']; triangle(ref['U_Q2'],oq['U_Q2'],ref['U_delta_Q2'])
                    for name in OWN:
                        for suffix,predname in [('OWN',name),('SHARED',name+'_OQ_SHARED')]:
                            delta=blocks[layer,arm,name+'_DELTA_'+suffix]
                            assert delta['estimand']=='DELTA_FULL_FFN_AFTER_FIXED_AFFINE_AND_Q2_APPROX'
                            triangle(blocks[layer,arm,predname]['squared_error'],blocks[layer,'Oq',name]['squared_error'],delta['squared_error'])
                            row=table[expert,layer,arm,predname]
                            close(float(row['shared_delta_F_mse_over_checkpoint_energy']),avg(delta['squared_error'],64)/avg(ref['U_checkpoint_difference'],64))
                            dq2=blocks[layer,arm,name+'_DELTA_Q2_'+suffix]
                            assert dq2['estimand']=='DELTA_Q2_ONLY'
                            close(float(row['shared_delta_Q2_mse_over_delta_Q2_energy']),avg(dq2['squared_error'],64)/avg(ref['U_delta_Q2'],64))
                        shared.append(local[name+'_OQ_SHARED']-local[name])
        for file in ('START.json','EXIT.json','units.jsonl','reference_blocks.jsonl','blocks.jsonl','weights.jsonl','artifacts.jsonl','candidate_status.jsonl'): paths[f'{root.name}/{file}']=sha(root/file)
assert len(samples)==4 and counts['units']==48 and counts['successful_candidate_rows']==288 and len(shared)==96
for name,values in ratios.items():
    stat=summary['metrics'][name]['MSE_over_V']
    assert len(values)==stat['count']==48
    for k,v in [('min',min(values)),('median',statistics.median(values)),('max',max(values))]: close(stat[k],v)
for k,values in [('equal_MAC_edge384_vs_orth512',equal),('shared_vs_own',shared)]:
    field='edge_minus_orth_MSE_over_V' if k.startswith('equal') else 'shared_minus_own_MSE_over_V'
    for key,v in [('min',min(values)),('median',statistics.median(values)),('max',max(values))]: close(summary[k][field][key],v)
out={'status':'INDEPENDENT_LOCAL_REAGGREGATION_PASS','counts':counts,'sampled_units':samples,'all_48_equal_MAC_edge_favored':all(x<0 for x in equal),'equal_MAC_main_ops':5120**2+2*5120*512,'full_q2_point_below_5pct':sum(x<.05 for x in ratios['FULL_Q2']),'edge_full_point_below_5pct':sum(x<.05 for x in ratios['EDGE_FULL_RJD']),'input_receipt_sha256':paths,'limits':['Local receipt arithmetic and identity checks; no re-execution of FFN or independently downloaded binary tensor/A1/candidate verification.','64 development blocks per unit; no simultaneous confidence claims.','All oblique proposals unresolved, not a structural impossibility result.']}
(ROOT/'INDEPENDENT_RESULT_CHECKS.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k!='input_receipt_sha256'},indent=2))
