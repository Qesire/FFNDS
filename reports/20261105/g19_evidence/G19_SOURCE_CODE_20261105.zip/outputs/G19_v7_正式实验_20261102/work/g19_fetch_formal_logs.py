"""Fetch only finite-job metadata/logs; no computation on login node."""
import json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
tasks=[]
for expert,job in [('high','127908'),('low','127909')]:
    tasks.append((root/'g19_v7_formal_s12_results'/expert,'/public/home/scc/pb23061276/projects/wan-quant/work/g19_v7_formal_s12_r1/'+expert,job))
for stage,result in [('g19_v7_formal_s3_r1','g19_v7_formal_s3_results'),('g19_v7_formal_checkpoint_confirm_r1','g19_v7_formal_checkpoint_confirm_results')]:
    for s in (root/stage/'SUBMISSIONS.jsonl').read_text(encoding='utf8').splitlines():
        r=json.loads(s);tasks.append((root/result/r['folder'],r['remote'],r['job_id']))
for folder,remote,job in tasks:
    folder.mkdir(exist_ok=True,parents=True)
    for ext in ('out','err'):
        p=folder/f'slurm-{job}.{ext}'
        subprocess.run(['pscp','-q','-batch','-load','107','107.ustc.edu.cn:'+remote+f'/slurm-{job}.{ext}',str(p.relative_to(Path.cwd()))],check=True,capture_output=True,text=True)
print(json.dumps({'job_logs_fetched':len(tasks)}))
