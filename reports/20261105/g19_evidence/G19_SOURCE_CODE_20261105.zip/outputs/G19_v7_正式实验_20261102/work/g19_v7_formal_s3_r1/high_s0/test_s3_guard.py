import json, tempfile, unittest, sys, types
from pathlib import Path
from unittest.mock import patch
import runtime_guard as g
import runner_s3

class S3GuardTests(unittest.TestCase):
 def fixture(self,p,phase='S3_STRUCTURE_DEVELOPMENT',omit=None):
  names=['runner_s3.py','deep_structure_v7.py','job_s3.sh','core_math.py','runtime_guard.py','weights_v7.py','statistics_v7.py']
  for name in names+['config.json','manifest.json','tensor_hashes.json','s12_assets.json']:
   (p/name).write_text('fixture',encoding='utf8')
  code={n:g.sha256_file(p/n) for n in names if n!=omit}
  scope={'status':'FROZEN_REVIEWED','authors':['author'],'phase':phase,'scope_id':'s3_high_0','code_sha256':code,
         'config_file':'config.json','config_sha256':g.sha256_file(p/'config.json'),
         'input_manifest_file':'manifest.json','manifest_sha256':g.sha256_file(p/'manifest.json'),
         'expected_tensor_hashes_file':'tensor_hashes.json','s12_assets_file':'s12_assets.json',
         'frozen_inputs_sha256':{n:g.sha256_file(p/n) for n in ('tensor_hashes.json','s12_assets.json')},
         'active_registry_file':'ACTIVE_RESEARCH.json',
         'budget':{'gpus_per_job':1,'max_jobs':1,'wall_seconds':1800,'soft_seconds':1650,'cpus':4,'host_memory_gib':64,'min_free_disk_gib':1}}
  path=p/'scope.json'; path.write_text(json.dumps(scope),encoding='utf8'); digest=g.sha256_file(path)
  (p/'INDEPENDENT_REVIEW.json').write_text(json.dumps({'status':'ACCEPTED','reviewer':'reviewer','scope_sha256':digest}),encoding='utf8')
  active={'state':'SCOPE_FROZEN_IN_ACTIVE','session_max_gpus':2,'max_concurrent_jobs':2,'scopes':{'s3_high_0':{'scope_sha256':digest,'state':'AUTHORIZED_FOR_ONE_JOB','max_jobs':1}}}
  (p/'ACTIVE_RESEARCH.json').write_text(json.dumps(active),encoding='utf8')
  return path,digest,active
 def test_s3_phase_and_frozen_assets(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp); scope,digest,_=self.fixture(p)
   with patch.object(g.shutil,'disk_usage',return_value=type('U',(),{'free':2*1024**3})()):
    self.assertEqual(g.verify_frozen_scope(p,scope,digest)['phase'],'S3_STRUCTURE_DEVELOPMENT')
    (p/'s12_assets.json').write_text('tampered')
    with self.assertRaisesRegex(RuntimeError,'Identity mismatch'): g.verify_frozen_scope(p,scope,digest)
 def test_required_s3_module(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp); scope,digest,_=self.fixture(p,omit='runner_s3.py')
   with self.assertRaisesRegex(RuntimeError,'bind every execution module'): g.verify_frozen_scope(p,scope,digest)
 def test_other_phase_cannot_use_s3_bindings(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp); scope,digest,_=self.fixture(p,phase='S12_FORMAL_CENSUS_AND_PLANNING')
   with self.assertRaisesRegex(RuntimeError,'bind every execution module'): g.verify_frozen_scope(p,scope,digest)
 def test_active_exact_scope_and_concurrency(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp); scope,digest,active=self.fixture(p)
   for field,value in (('state','PROPOSED'),('session_max_gpus',3),('max_concurrent_jobs',3)):
    bad=dict(active); bad[field]=value; (p/'ACTIVE_RESEARCH.json').write_text(json.dumps(bad))
    with self.assertRaisesRegex(RuntimeError,'ACTIVE authorization'): g.verify_frozen_scope(p,scope,digest)
   active['scopes']['s3_high_0']['scope_sha256']='0'*64
   (p/'ACTIVE_RESEARCH.json').write_text(json.dumps(active))
   with self.assertRaisesRegex(RuntimeError,'ACTIVE authorization'): g.verify_frozen_scope(p,scope,digest)
 def test_runner_rejects_unfrozen_asset_manifest_before_torch_or_weights(self):
  fake=types.ModuleType('runtime_guard')
  fake.require_compute_allocation=lambda: {'synthetic':True}
  fake.verify_frozen_scope=lambda *args: {'phase':'S3_STRUCTURE_DEVELOPMENT','s12_assets_file':'assets.json','expected_tensor_hashes_file':'tensor.json','frozen_inputs_sha256':{'tensor.json':'0'*64}}
  fake.RunReceipt=object
  with patch.dict(sys.modules,{'runtime_guard':fake}), patch.object(sys,'argv',['runner_s3.py','--scope','fixture','--scope-sha','0'*64]):
   with self.assertRaisesRegex(ValueError,'missing frozen s12_assets_file'): runner_s3.main()
 def test_scope_sha_review_and_module_hash(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp); scope,digest,_=self.fixture(p)
   with self.assertRaisesRegex(RuntimeError,'Scope SHA256'): g.verify_frozen_scope(p,scope,'0'*64)
   review={'status':'ACCEPTED','reviewer':'author','scope_sha256':digest}
   (p/'INDEPENDENT_REVIEW.json').write_text(json.dumps(review))
   with self.assertRaisesRegex(RuntimeError,'distinct reviewer'): g.verify_frozen_scope(p,scope,digest)
   review['reviewer']='reviewer'; (p/'INDEPENDENT_REVIEW.json').write_text(json.dumps(review)); (p/'runner_s3.py').write_text('changed')
   with self.assertRaisesRegex(RuntimeError,'Identity mismatch'): g.verify_frozen_scope(p,scope,digest)
if __name__=='__main__': unittest.main(verbosity=2)
