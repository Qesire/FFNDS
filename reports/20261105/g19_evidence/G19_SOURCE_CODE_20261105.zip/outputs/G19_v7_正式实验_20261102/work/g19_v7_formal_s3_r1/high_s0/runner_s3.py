"""S3 diagnostic runner; runtime guard must be adapted/reviewed for this scope.
No import of torch or weight access occurs before scheduler and scope verification.
"""
import argparse, hashlib, json, math, time
from pathlib import Path

LAYERS=((0,1,7),(12,13,19),(23,24,28),(33,37,38))


def validate_config(c):
    if c.get('expert') not in ('high','low') or type(c.get('stratum')) is not int or not 0<=c['stratum']<4: raise ValueError('invalid shard')
    if c.get('layers')!=list(LAYERS[c['stratum']]): raise ValueError('invalid registered layers')
    for k,v in {'blocks':64,'operator_probes':16,'dev_slices':8,'mixtures':4,'gh_nodes':384,'reduced_rank':512,'edge_reduced_rank':384,'edge_reduced_count':256,'pencil_tries':4}.items():
        if c.get(k)!=v: raise ValueError('scope configuration mismatch: '+k)
    if type(c.get('seed')) is not int or c['seed']<0: raise ValueError('invalid seed')
    if not isinstance(c.get('output_dir'),str) or not c['output_dir']: raise ValueError('missing output')


def file_sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()


def checked_asset(assets,expert,layer,arm):
    key=f'{expert}/{layer}/{arm}'
    if key not in assets: raise ValueError('missing S12 A1 asset '+key)
    row=assets[key]; digest=row.get('sha256','')
    if not isinstance(digest,str) or len(digest)!=64 or file_sha(row['path'])!=digest: raise ValueError('S12 A1 SHA mismatch '+key)
    return Path(row['path'])


def validate_inputs(c,assets,hashes):
    for layer in c['layers']:
        for model in ('original','distilled'):
            for suffix in ('0.weight','0.bias','2.weight','2.bias'):
                key=f"{c['expert']}/{model}/blocks.{layer}.ffn.{suffix}"
                if not isinstance(hashes.get(key),str) or len(hashes[key])!=64: raise ValueError('missing tensor digest '+key)
        for arm in ('Oq','Dq'): checked_asset(assets,c['expert'],layer,arm)

def emit(path,row):
    row=dict(row)
    if 'squared_error' in row:
        if len(row['squared_error'])!=64: raise ValueError('incomplete heldout blocks')
        row['block_ids']=list(range(64))
    if 'operator_frob_probe' in row:
        if len(row['operator_frob_probe'])!=16: raise ValueError('incomplete operator probes')
        row['operator_probe_ids']=list(range(16))
    with path.open('a',encoding='utf-8') as f: f.write(json.dumps(row,allow_nan=False)+'\n')


def block_mean_square(diff,blocks):
    """Four signed evaluations constitute one independent block."""
    if diff.ndim!=2 or diff.shape[0]!=blocks*4: raise ValueError('invalid signed block shape')
    return diff.square().sum(-1).reshape(blocks,4).mean(-1)


def block_variance(x,blocks):
    """Unbiased paired-difference variance statistic, one per Gaussian block."""
    if x.ndim!=2 or x.shape[0]!=blocks*4: raise ValueError('invalid signed block shape')
    y=x.reshape(blocks,4,-1)
    return ((y[:,0]-y[:,2]).square().sum(-1)+(y[:,1]-y[:,3]).square().sum(-1))/4


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--scope',type=Path,required=True); ap.add_argument('--scope-sha',required=True); args=ap.parse_args()
    from runtime_guard import require_compute_allocation,verify_frozen_scope,RunReceipt
    allocation=require_compute_allocation(); root=Path(__file__).resolve().parent
    scope=verify_frozen_scope(root,args.scope,args.scope_sha)
    if scope.get('phase')!='S3_STRUCTURE_DEVELOPMENT': raise ValueError('incorrect scope phase')
    for key in ('s12_assets_file','expected_tensor_hashes_file'):
        if scope.get(key) not in scope.get('frozen_inputs_sha256',{}): raise ValueError('missing frozen '+key)
    c=json.loads((root/scope['config_file']).read_text(encoding='utf-8-sig')); validate_config(c)
    assets=json.loads((root/scope['s12_assets_file']).read_text(encoding='utf-8-sig'))
    hashes=json.loads((root/scope['expected_tensor_hashes_file']).read_text(encoding='utf-8-sig'))
    manifest=json.loads((root/scope['input_manifest_file']).read_text(encoding='utf-8-sig'))
    import numpy as np
    import torch
    import scipy
    import torch.nn.functional as TF
    from weights_v7 import load_tensor,rne_lift
    from core_math import coefficients
    from statistics_v7 import rng_for
    import deep_structure_v7 as ds
    if not torch.cuda.is_available() or torch.cuda.device_count()!=1: raise RuntimeError('one visible CUDA device required')
    total=torch.cuda.get_device_properties(0).total_memory
    if total<32*1024**3: raise RuntimeError('GPU memory below scope')
    torch.cuda.set_per_process_memory_fraction(min(.95,40*1024**3/total),0)
    torch.backends.cuda.matmul.allow_tf32=False; torch.backends.cudnn.allow_tf32=False
    torch.set_num_threads(scope['budget']['cpus']); out=Path(c['output_dir'])
    with RunReceipt(out,scope,allocation) as receipt:
      receipt.result={'status':'PARTIAL','completed_units':[],'inconclusive_units':[],'estimand':'S3_DEVELOPMENT_DIAGNOSTIC_NOT_CONFIRMATION'}
      validate_inputs(c,assets,hashes)  # fail with EXIT receipt, before any raw tensor read
      emit(out/'environment.jsonl',{'scope_sha256':args.scope_sha,'torch':torch.__version__,'numpy':np.__version__,'scipy':scipy.__version__,'gpu':torch.cuda.get_device_name(0),'gpu_total_bytes':total,'tf32':False,'dtype_geometry':'float64','dtype_forward':'float32','namespace':'DEVELOPMENT','streams':{'slices':70,'mixtures':71,'heldout':72,'output_probes':73,'pencils':74,'input_probes':75}})
      def checkpoint():
        receipt.check_deadline()
        if torch.cuda.max_memory_allocated()>40*1024**3: raise MemoryError('GPU_MEMORY_BUDGET_EXCEEDED')
      def rand(layer,stream,shape,dtype):
        return torch.as_tensor(rng_for(c['seed'],'DEVELOPMENT',c['expert'],layer,stream).standard_normal(shape),dtype=dtype,device='cuda')
      def save(name,cand):
        path=out/name
        if path.exists(): raise FileExistsError(str(path))
        with path.open('xb') as f: torch.save({k:v.detach().cpu() if torch.is_tensor(v) else v for k,v in cand.items()},f)
        emit(out/'artifacts.jsonl',{'path':name,'sha256':file_sha(path),'kind':'CANDIDATE'})
        return path
      def forward(z,w):
        z=z.float(); d=z.shape[-1]; u=(z-z.mean(-1,keepdim=True))*math.sqrt(d/(d-1))
        return TF.linear(TF.gelu(TF.linear(u,w['0.weight'],w['0.bias']),approximate='tanh'),w['2.weight'],w['2.bias'])
      def get_weights(layer,model):
        data={}
        for suffix in ('0.weight','0.bias','2.weight','2.bias'):
            checkpoint(); key=f"{c['expert']}/{model}/blocks.{layer}.ffn.{suffix}"
            arr,rec=load_tensor(manifest,c['expert'],model,layer,suffix,hashes[key]); emit(out/'weights.jsonl',{'layer':layer,'model':model,**rec})
            if model=='original': arr=rne_lift(arr)
            data[suffix]=torch.as_tensor(arr,device='cuda',dtype=torch.float32)
        w=data['0.weight']; W=data['2.weight']; b=data['0.bias']; b2=data['2.bias']
        if w.ndim!=2 or W.shape!=(w.shape[1],w.shape[0]) or b.shape!=(w.shape[0],) or b2.shape!=(w.shape[1],): raise ValueError('invalid FFN geometry')
        return data
      with torch.no_grad():
       for layer in c['layers']:
        checkpoint(); oq_paths={}; oq_target=None; oq_q2=None; oq_true=None
        for arm,model in (('Oq','original'),('Dq','distilled')):
         start=time.monotonic(); checkpoint(); torch.cuda.reset_peak_memory_stats()
         phase_begin=time.monotonic(); w=get_weights(layer,model); read_seconds=time.monotonic()-phase_begin; d=w['0.weight'].shape[1]; m=w['0.weight'].shape[0]
         if d!=5120 or m!=13824: raise ValueError('unexpected model geometry')
         Apath=checked_asset(assets,c['expert'],layer,arm); A=torch.as_tensor(np.load(Apath,allow_pickle=False),dtype=torch.float64,device='cuda')
         if A.shape!=(d,d) or not torch.isfinite(A).all().item(): raise ValueError('invalid frozen A1')
         phase_begin=time.monotonic(); W=w['0.weight'].double(); beta=(W-W.mean(1,keepdim=True))*math.sqrt(d/(d-1)); norms=beta.norm(dim=1)
         p=beta/norms.clamp_min(1e-300)[:,None]; V=w['2.weight'].double().T; aa=[]
         for i in range(0,m,512):
            checkpoint(); aa.append(coefficients(norms[i:i+512].cpu().numpy(),w['0.bias'][i:i+512].double().cpu().numpy(),2,384)[0])
         aa=np.concatenate(aa); aa[norms.cpu().numpy()==0,1:]=0
         a=torch.as_tensor(aa,device='cuda',dtype=torch.float64); mu=a[:,0]@V+w['2.bias'].double(); a2=a[:,2]
         # Same per-layer streams across arms, held-out streams independent from geometry.
         torch.cuda.synchronize(); gh_seconds=time.monotonic()-phase_begin
         T=rand(layer,70,(8,d),torch.float64); weights=rand(layer,71,(4,8),torch.float64)
         H=ds.support_coordinates(p); phase=time.monotonic(); slices=ds.slices_in_coordinates(H,a2,V,T); checkpoint()
         del H
         rjd=ds.random_combination_basis(slices,weights)
         if rjd['status']!='OK':
            for name in ('ORTH_FULL_RJD','EDGE_FULL_RJD','ORTH_SUBSPACE_512','EDGE_SUBSPACE_384_E256','OBLIQUE_SUBSPACE_512'):
                emit(out/'candidate_status.jsonl',{'layer':layer,'arm':arm,'candidate':name,'status':'UNRESOLVED_RJD_DEPENDENCY_FAILED','trials':rjd['trials']})
            unit_id=f"{c['expert']}/{layer}/{arm}"
            emit(out/'units.jsonl',{'expert':c['expert'],'layer':layer,'arm':arm,'status':'UNIT_INCONCLUSIVE_RJD_DEPENDENCY','unit_seconds':time.monotonic()-start,'peak_cuda_bytes':torch.cuda.max_memory_allocated()})
            receipt.result['inconclusive_units'].append(unit_id)
            del w,A,W,beta,norms,p,V,a,a2,mu,T,weights,slices,rjd
            torch.cuda.empty_cache(); checkpoint(); continue
         R=rjd.pop('basis'); B=ds.support_embed(R.T).T
         rot=R.T@slices@R; del R,slices
         candidate_paths={}; unit_issues=[]; successful_candidates=[]
         def build(name,fn):
            checkpoint()
            try:
                obj=fn()
                if obj.get('status')!='OK':
                    unit_issues.append(name+':'+obj['status']); emit(out/'candidate_status.jsonl',{'layer':layer,'arm':arm,'candidate':name,'status':obj['status']}); return None
                path=save(f'{layer:02d}_{arm}_{name}.pt',obj); candidate_paths[name]=path
                if arm=='Oq': oq_paths[name]=path
                return obj
            except (ValueError,RuntimeError) as exc:
                if isinstance(exc,torch.cuda.OutOfMemoryError) or any(x in str(exc).lower() for x in ('out of memory','alloc_failed','cuda error','illegal memory')) or 'INTERRUPTED_SIGNAL_' in str(exc): raise
                unit_issues.append(name+':NUMERICAL_FAILURE'); emit(out/'candidate_status.jsonl',{'layer':layer,'arm':arm,'candidate':name,'status':'NUMERICAL_FAILURE','error':repr(exc)}); return None
         full=build('ORTH_FULL_RJD',lambda:ds.fit_edges(p,a2,V,B,edge_count=0))
         # Rank from fixed development slice diagonals, independent of full-output fit success.
         energy=torch.sum(torch.diagonal(rot,dim1=-2,dim2=-1)**2,dim=0)
         idx=torch.argsort(energy,descending=True,stable=True); del full,energy
         chosen=idx[:512]; sub=B[:,chosen]; subrot=rot[:,chosen][:,:,chosen]
         edges=ds.select_edges_from_slices(rot,min((d-1)//2,(d-1)*(d-2)//2)); del rot
         temp=build('EDGE_FULL_RJD',lambda:ds.fit_edges(p,a2,V,B,edges=edges)); del temp,B,edges
         temp=build('ORTH_SUBSPACE_512',lambda:ds.fit_edges(p,a2,V,sub,edge_count=0)); del temp
         Bedge=sub[:,:384]; edge_ids=ds.select_edges_from_slices(subrot[:,:384,:384],256)
         temp=build('EDGE_SUBSPACE_384_E256',lambda:ds.fit_edges(p,a2,V,Bedge,edges=edge_ids)); del temp,Bedge,edge_ids
         pencil=rand(layer,74,(4,2,8),torch.float64); rejected=[]; oblique=None
         for attempt in range(4):
            checkpoint(); P1=torch.sum(pencil[attempt,0,:,None,None]*subrot,dim=0); P2=torch.sum(pencil[attempt,1,:,None,None]*subrot,dim=0)
            prop=ds.oblique_common_basis(sub,P1,P2)
            if prop['status']!='OK': rejected.append({'try':attempt,'status':prop['status']}); continue
            oblique=ds.fit_atoms(p,a2,V,prop['B']); rejected.append({'try':attempt,'status':oblique['status']})
            if oblique['status']=='OK': break
         if oblique is None or oblique['status']!='OK':
            unit_issues.append('OBLIQUE_SUBSPACE_512:UNRESOLVED_ALL_PENCILS')
            emit(out/'candidate_status.jsonl',{'layer':layer,'arm':arm,'candidate':'OBLIQUE_SUBSPACE_512','status':'UNRESOLVED_ALL_PENCILS','attempts':rejected})
         else:
            temp=build('OBLIQUE_SUBSPACE_512',lambda:oblique); del temp
         del subrot,sub,oblique,pencil,P1,P2,prop
         torch.cuda.synchronize()
         phase_seconds={'read_weights':read_seconds,'GH_and_preprocess':gh_seconds,'geometry_and_fit':time.monotonic()-phase}
         zw=rand(layer,72,(64,2,d),torch.float32); z=torch.stack((zw[:,0],-zw[:,0],zw[:,1],-zw[:,1]),dim=1).reshape(-1,d)
         true=forward(z,w).double(); zd=z.double(); target=true-mu-zd@A
         if arm=='Oq': oq_target=target.cpu(); oq_true=true.cpu()
         q2=ds.full_q2(zd,p,a2,V); fullerr=block_mean_square(target-q2,64)
         if arm=='Oq': oq_q2=q2.cpu()
         stats={'layer':layer,'arm':arm,'stream':'DEVELOPMENT_72','block_ids':list(range(64)),
                'D_F':block_variance(true,64).cpu().tolist(),'D_residual':block_variance(target,64).cpu().tolist(),
                'D_Q2':block_variance(q2,64).cpu().tolist(),'U_Q2':block_mean_square(q2,64).cpu().tolist()}
         if arm=='Dq' and oq_true is not None:
            stats['U_checkpoint_difference']=block_mean_square(true-oq_true.to('cuda'),64).cpu().tolist()
            stats['U_delta_residual']=block_mean_square(target-oq_target.to('cuda'),64).cpu().tolist()
            stats['U_delta_Q2']=block_mean_square(q2-oq_q2.to('cuda'),64).cpu().tolist()
         emit(out/'reference_blocks.jsonl',stats)
         Tp=rand(layer,73,(16,d),torch.float64); Up=rand(layer,75,(16,d),torch.float64)
         emit(out/'blocks.jsonl',{'layer':layer,'arm':arm,'candidate':'FULL_Q2','stream':'DEVELOPMENT_72','squared_error':fullerr.cpu().tolist()})
         for name,path in candidate_paths.items():
            checkpoint(); phase=time.monotonic(); cp=None; shared=None; shared_d=None
            try:
                cp=torch.load(path,map_location='cuda',weights_only=True)
                pred=ds.predict_q2(zd,cp); diff=target-pred; per=block_mean_square(diff,64)
                if arm=='Dq' and name in oq_paths:
                    oq_cp=torch.load(oq_paths[name],map_location='cuda',weights_only=True)
                    oq_pred=ds.predict_q2(zd,oq_cp)
                    delta_error=block_mean_square((target-oq_target.to('cuda'))-(pred-oq_pred),64)
                    emit(out/'blocks.jsonl',{'layer':layer,'arm':arm,'candidate':name+'_DELTA_OWN','estimand':'DELTA_FULL_FFN_AFTER_FIXED_AFFINE_AND_Q2_APPROX','stream':'DEVELOPMENT_72','squared_error':delta_error.cpu().tolist()})
                    delta_q2=block_mean_square((q2-oq_q2.to('cuda'))-(pred-oq_pred),64)
                    emit(out/'blocks.jsonl',{'layer':layer,'arm':arm,'candidate':name+'_DELTA_Q2_OWN','estimand':'DELTA_Q2_ONLY','stream':'DEVELOPMENT_72','squared_error':delta_q2.cpu().tolist()})
                    del oq_cp,oq_pred,delta_error,delta_q2
                pr=ds.probe_residual(p,a2,V,cp,Tp,Up)
                emit(out/'blocks.jsonl',{'layer':layer,'arm':arm,'candidate':name,'stream':'DEVELOPMENT_72','squared_error':per.cpu().tolist(),'operator_probe_streams':[73,75],'operator_frob_probe':pr.cpu().tolist()})
                successful_candidates.append(name)
                emit(out/'candidate_status.jsonl',{'layer':layer,'arm':arm,'candidate':name,'status':'OK','seconds':time.monotonic()-phase})
                del cp
            except (ValueError,RuntimeError) as exc:
                if isinstance(exc,torch.cuda.OutOfMemoryError) or any(x in str(exc).lower() for x in ('out of memory','alloc_failed','cuda error','illegal memory')) or 'INTERRUPTED_SIGNAL_' in str(exc): raise
                unit_issues.append(name+':NUMERICAL_FAILURE'); emit(out/'candidate_status.jsonl',{'layer':layer,'arm':arm,'candidate':name,'status':'NUMERICAL_FAILURE','error':repr(exc)})
            finally:
                cp=None; shared=None; shared_d=None
         if arm=='Dq':
          if len(oq_paths)<5: unit_issues.append('OQ_SHARED_GEOMETRY_INCOMPLETE')
          for name,oq_path in oq_paths.items():
           checkpoint(); shared=None; shared_d=None
           try:
                   shared=torch.load(oq_paths[name],map_location='cuda',weights_only=True)
                   if shared['kind']=='atoms': shared_d=ds.fit_atoms(p,a2,V,shared['B'])
                   else: shared_d=ds.fit_edges(p,a2,V,shared['B'],edges=shared['edges'])
                   if shared_d['status']!='OK':
                       unit_issues.append(name+':SHARED_REFIT_FAILED')
                       emit(out/'candidate_status.jsonl',{'layer':layer,'arm':arm,'candidate':name,'comparison':'OQ_SHARED_BASIS','status':shared_d['status']})
                   else:
                       path=save(f'{layer:02d}_{arm}_{name}_shared.pt',shared_d)
                       shared_pred=ds.predict_q2(zd,shared_d); per=block_mean_square(target-shared_pred,64)
                       oq_pred=ds.predict_q2(zd,shared)
                       delta_error=block_mean_square((target-oq_target.to('cuda'))-(shared_pred-oq_pred),64)
                       emit(out/'blocks.jsonl',{'layer':layer,'arm':arm,'candidate':name+'_DELTA_SHARED','estimand':'DELTA_FULL_FFN_AFTER_FIXED_AFFINE_AND_Q2_APPROX','stream':'DEVELOPMENT_72','squared_error':delta_error.cpu().tolist()})
                       delta_q2=block_mean_square((q2-oq_q2.to('cuda'))-(shared_pred-oq_pred),64)
                       emit(out/'blocks.jsonl',{'layer':layer,'arm':arm,'candidate':name+'_DELTA_Q2_SHARED','estimand':'DELTA_Q2_ONLY','stream':'DEVELOPMENT_72','squared_error':delta_q2.cpu().tolist()})
                       del oq_pred,delta_error,delta_q2,shared_pred
                       pr=ds.probe_residual(p,a2,V,shared_d,Tp,Up)
                       emit(out/'blocks.jsonl',{'layer':layer,'arm':arm,'candidate':name+'_OQ_SHARED','stream':'DEVELOPMENT_72','squared_error':per.cpu().tolist(),'operator_probe_streams':[73,75],'operator_frob_probe':pr.cpu().tolist()})
                       successful_candidates.append(name+'_OQ_SHARED')
                       emit(out/'candidate_status.jsonl',{'layer':layer,'arm':arm,'candidate':name,'comparison':'OQ_SHARED_BASIS','status':'OK'})
                   del shared,shared_d
           except (ValueError,RuntimeError) as exc:
            if isinstance(exc,torch.cuda.OutOfMemoryError) or any(x in str(exc).lower() for x in ('out of memory','alloc_failed','cuda error','illegal memory')) or 'INTERRUPTED_SIGNAL_' in str(exc): raise
            unit_issues.append(name+':SHARED_NUMERICAL_FAILURE'); emit(out/'candidate_status.jsonl',{'layer':layer,'arm':arm,'candidate':name,'comparison':'OQ_SHARED_BASIS','status':'NUMERICAL_FAILURE','error':repr(exc)})
           finally:
            shared=None; shared_d=None
         emit(out/'units.jsonl',{'expert':c['expert'],'layer':layer,'arm':arm,'A1_sha256':file_sha(Apath),'phase_seconds':phase_seconds,'unit_seconds':time.monotonic()-start,'peak_cuda_bytes':torch.cuda.max_memory_allocated(),'rjd_trials':rjd['trials'],'pencil_attempts':rejected,'status':'UNIT_INCONCLUSIVE' if unit_issues else 'UNIT_COMPLETE','issues':unit_issues,'successful_candidates':successful_candidates})
         unit_id=f"{c['expert']}/{layer}/{arm}"
         receipt.result['inconclusive_units' if unit_issues else 'completed_units'].append(unit_id)
         del w,A,W,beta,norms,p,V,a,a2,mu,T,weights,rjd,idx,chosen,candidate_paths,zw,z,true,zd,target,q2,fullerr,Tp,Up
         torch.cuda.empty_cache(); checkpoint()
       receipt.result['status']='S3_SHARD_INCOMPLETE' if receipt.result['inconclusive_units'] else 'S3_SHARD_COMPLETE_WITH_CANDIDATE_STATUSES'
if __name__=='__main__': main()
