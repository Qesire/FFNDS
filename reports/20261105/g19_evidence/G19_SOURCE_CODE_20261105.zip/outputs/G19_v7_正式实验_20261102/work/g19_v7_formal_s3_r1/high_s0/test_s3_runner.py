import hashlib, json, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
import torch
import runner_s3 as r
import deep_structure_v7 as ds

class TestRunner(unittest.TestCase):
 def cfg(self):
  return {'expert':'high','stratum':0,'layers':[0,1,7],'blocks':64,'operator_probes':16,'dev_slices':8,'mixtures':4,'gh_nodes':384,'reduced_rank':512,'edge_reduced_rank':384,'edge_reduced_count':256,'pencil_tries':4,'seed':1,'output_dir':'out'}
 def test_shard_and_sizes(self):
  c=self.cfg(); r.validate_config(c)
  for k,v in [('layers',[0,1,2]),('blocks',63),('expert','other'),('stratum',4),('mixtures',8)]:
   bad=self.cfg(); bad[k]=v
   with self.assertRaises(ValueError): r.validate_config(bad)
 def test_asset_hash_and_missing(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'A.npy'; p.write_bytes(b'one'); digest=hashlib.sha256(b'one').hexdigest(); assets={'high/0/Oq':{'path':str(p),'sha256':digest}}
   self.assertEqual(r.checked_asset(assets,'high',0,'Oq'),p)
   with self.assertRaises(ValueError): r.checked_asset(assets,'high',1,'Oq')
   p.write_bytes(b'two')
   with self.assertRaises(ValueError): r.checked_asset(assets,'high',0,'Oq')
 def test_missing_shard_input(self):
  c=self.cfg(); hashes={}
  for layer in c['layers']:
   for model in ('original','distilled'):
    for suffix in ('0.weight','0.bias','2.weight','2.bias'):
     hashes[f"high/{model}/blocks.{layer}.ffn.{suffix}"]='0'*64
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'a'; p.write_bytes(b'a'); h=hashlib.sha256(b'a').hexdigest()
   assets={f'high/{layer}/{arm}':{'path':str(p),'sha256':h} for layer in c['layers'] for arm in ('Oq','Dq')}
   r.validate_inputs(c,assets,hashes); del assets['high/1/Oq']
   with self.assertRaisesRegex(ValueError,'missing S12'): r.validate_inputs(c,assets,hashes)
 def test_signed_blocks(self):
  d=torch.tensor([[1.,0.],[2.,0.],[3.,0.],[4.,0.],[2.,0.],[2.,0.],[2.,0.],[2.,0.]])
  torch.testing.assert_close(r.block_mean_square(d,2),torch.tensor([7.5,4.]))
  with self.assertRaises(ValueError): r.block_mean_square(d,3)
  torch.testing.assert_close(r.block_variance(d,2),torch.tensor([2.,0.]))
  with self.assertRaises(ValueError): r.block_variance(d,3)
 def test_block_indices_persisted(self):
  with tempfile.TemporaryDirectory() as t:
   path=Path(t)/'blocks.jsonl'; r.emit(path,{'squared_error':[0.]*64,'operator_frob_probe':[0.]*16})
   row=json.loads(path.read_text()); self.assertEqual(row['block_ids'],list(range(64))); self.assertEqual(row['operator_probe_ids'],list(range(16)))
   with self.assertRaises(ValueError): r.emit(path,{'squared_error':[0.]*63})
 def test_small_q2_shared_and_full(self):
  dtype=torch.float64; p=torch.eye(3,dtype=dtype); a=torch.ones(3,dtype=dtype); V=torch.eye(3,dtype=dtype); z=torch.tensor([[1.,2.,3.],[-1.,-2.,-3.],[0.,1.,2.],[0.,-1.,-2.]],dtype=dtype)
  oq=ds.fit_edges(p,a,V,p,edge_count=0); dq=ds.fit_edges(p,a,2*V,oq['B'],edges=oq['edges'])
  delta=ds.full_q2(z,p,a,2*V)-ds.full_q2(z,p,a,V)-(ds.predict_q2(z,dq)-ds.predict_q2(z,oq))
  self.assertLess(r.block_mean_square(delta,1).max().item(),1e-24)
 def test_tiny_rjd_pipeline_and_shared(self):
  torch.manual_seed(17); dtype=torch.float64; d=5; m=7; out=3
  p=torch.randn(m,d,dtype=dtype); p-=p.mean(1,keepdim=True); p/=p.norm(dim=1,keepdim=True)
  a=torch.randn(m,dtype=dtype); V=torch.randn(m,out,dtype=dtype); H=ds.support_coordinates(p)
  T=torch.randn(8,out,dtype=dtype); S=ds.slices_in_coordinates(H,a,V,T)
  res=ds.random_combination_basis(S,torch.randn(4,8,dtype=dtype)); self.assertEqual(res['status'],'OK')
  R=res['basis']; B=ds.support_embed(R.T).T; rot=R.T@S@R
  own=ds.fit_edges(p,a,V,B,edges=ds.select_edges_from_slices(rot,2))
  refit=ds.fit_edges(p,a,2*V,B,edges=own['edges'])
  z=torch.randn(8,d,dtype=dtype); qo=ds.full_q2(z,p,a,V); qd=ds.full_q2(z,p,a,2*V)
  error=(qd-qo)-(ds.predict_q2(z,refit)-ds.predict_q2(z,own))
  self.assertEqual(r.block_mean_square(error,2).shape,(2,))
  probe=ds.probe_residual(p,a,V,own,torch.randn(4,out,dtype=dtype),torch.randn(4,d,dtype=dtype)); self.assertTrue(torch.isfinite(probe).all())
 def test_oom_not_swallowed(self):
  S=torch.stack([torch.eye(2,dtype=torch.float64)]*2); weights=torch.ones((4,2),dtype=torch.float64)
  with patch('torch.linalg.eigh',side_effect=torch.cuda.OutOfMemoryError('out of memory')):
   with self.assertRaises(torch.cuda.OutOfMemoryError): ds.random_combination_basis(S,weights)
if __name__=='__main__': unittest.main(verbosity=2)
