import math, unittest
import torch
import deep_structure_v7 as s
T=torch.float64
class Tests(unittest.TestCase):
 def test_slice_mv(self):
  p=torch.tensor([[1.,0.],[2**-.5,2**-.5]],dtype=T); a=torch.tensor([1.,-2.],dtype=T); V=torch.tensor([[1.,2.],[-1.,3.]],dtype=T); t=torch.tensor([.5,-.2],dtype=T); x=torch.tensor([1.,-3.],dtype=T)
  M=p.T@torch.diag(a*(V@t))@p; torch.testing.assert_close(s.slice_mv(p,a,V,t,x),M@x)
 def test_fullrank_quadratic(self):
  d=4;p=torch.eye(d,dtype=T); a=torch.ones(d,dtype=T); V=torch.eye(d,dtype=T); cand=s.fit_atoms(p,a,V,p)
  z=torch.tensor([[2.,-1.,0.,3.]],dtype=T)
  torch.testing.assert_close(s.predict_q2(z,cand),s.full_q2(z,p,a,V)); self.assertEqual(torch.linalg.matrix_rank(p).item(),d)
  self.assertLess(s.budget_macs(d,d,d,d,linear_bypass=False)['candidate'],d*d*3)
 def test_multi_slice_joint(self):
  a=.37; R=torch.tensor([[math.cos(a),-math.sin(a)],[math.sin(a),math.cos(a)]],dtype=T); diag=torch.stack((torch.diag(torch.tensor([1.,3.],dtype=T)),torch.diag(torch.tensor([2.,-4.],dtype=T))))
  S=R@diag@R.T; B=s.orthogonal_common_basis(torch.eye(2,dtype=T),S,sweeps=2); transformed=B.T@S@B
  self.assertLess(abs(transformed[:,0,1]).max().item(),1e-10)
 def test_oblique_signed_original_fit(self):
  B=torch.tensor([[1.,1/math.sqrt(2)],[0.,1/math.sqrt(2)]],dtype=T); p=B.T.contiguous(); a=torch.tensor([1.,1.],dtype=T); V=torch.tensor([[1.,2.],[-2.,-1.]],dtype=T)
  S=s.projected_slices(p,a,V,torch.eye(2,dtype=T),torch.eye(2,dtype=T)); proposed=s.oblique_common_basis(torch.eye(2,dtype=T),S[0],S[1]); self.assertEqual(proposed['status'],'OK')
  c=s.fit_atoms(p,a,V,proposed['B']); self.assertEqual(c['status'],'OK')
  z=torch.tensor([[1.,2.],[-.2,.7],[3.,-.3]],dtype=T); torch.testing.assert_close(s.predict_q2(z,c),s.full_q2(z,p,a,V),atol=1e-10,rtol=1e-10)
  bad=s.fit_atoms(p,a,V,torch.tensor([[1.,1.],[0.,0.]],dtype=T)); self.assertNotEqual(bad['status'],'OK')
  self.assertNotEqual(s.oblique_common_basis(torch.eye(2,dtype=T),torch.zeros((2,2),dtype=T),S[1])['status'],'OK')
 def test_full_support_householder_and_rjd(self):
  gen=torch.Generator().manual_seed(12); d=5; p=torch.randn((4,d),generator=gen,dtype=T); p=p-p.mean(dim=1,keepdim=True); p=p/torch.linalg.vector_norm(p,dim=1,keepdim=True); H=s.support_coordinates(p)
  torch.testing.assert_close(s.support_embed(H),p,atol=1e-12,rtol=1e-12); torch.testing.assert_close(torch.linalg.vector_norm(H,dim=1),torch.ones(4,dtype=T))
  a=torch.tensor([1.,-1.,2.,.5],dtype=T); V=torch.randn((4,3),generator=gen,dtype=T); probes=torch.randn((3,3),generator=gen,dtype=T)
  S=s.slices_in_coordinates(H,a,V,probes); r=s.random_combination_basis(S,torch.randn((4,3),generator=gen,dtype=T)); self.assertEqual(r['status'],'OK'); R=r['basis']; B=s.support_embed(R.T).T
  torch.testing.assert_close(B.T@B,torch.eye(d-1,dtype=T),atol=1e-12,rtol=1e-12); torch.testing.assert_close(B.sum(dim=0),torch.zeros(d-1,dtype=T),atol=1e-12,rtol=0)
  for j in range(3): torch.testing.assert_close(B.T@(p.T@torch.diag(a*(V@probes[j]))@p)@B,R.T@S[j]@R,atol=1e-11,rtol=1e-11)
 def test_select_edges_from_slices(self):
  S=torch.zeros((2,4,4),dtype=T); S[0,0,3]=S[0,3,0]=2; S[1,1,2]=S[1,2,1]=1
  self.assertEqual(s.select_edges_from_slices(S,2),[(0,3),(1,2)])
  p=torch.eye(4,dtype=T); a=torch.ones(4,dtype=T); V=torch.eye(4,dtype=T)
  c=s.fit_edges(p,a,V,p,edges=s.select_edges_from_slices(S,2)); z=torch.ones((1,4),dtype=T)
  self.assertEqual(s.predict_q2(z,c).shape,(1,4))
 def test_full_q2_cost_accounting(self):
  b=s.budget_macs(5120,5120,13824,128)
  self.assertEqual(b['full_q2_best_fused'],2*5120*13824)
  self.assertEqual(b['full_q2_detector_unfused'],5120**2+2*5120*13824)
 def test_degenerate_pencil_is_unresolved(self):
  M1=torch.tensor([[2.,1.],[1.,2.]],dtype=T); M2=2*M1
  result=s.oblique_common_basis(torch.eye(2,dtype=T),M1,M2)
  self.assertEqual(result['status'],'DEGENERATE_PENCIL_UNRESOLVED')
  # SPD simultaneous diagonalization exists despite this proposal failure.
  _,Q=torch.linalg.eigh(M1); self.assertLess(abs((Q.T@M2@Q)[0,1]).item(),1e-12)
 def test_signed_complex_pencil_rejected(self):
  I=torch.eye(2,dtype=T); M1=torch.diag(torch.tensor([1.,-1.],dtype=T)); M2=torch.tensor([[0.,1.],[1.,0.]],dtype=T)
  self.assertEqual(s.oblique_common_basis(I,M1,M2)['status'],'REJECTED_COMPLEX_PENCIL')
 def test_edges_sqrt2_and_full_metric(self):
  p=torch.tensor([[2**-.5,2**-.5],[2**-.5,-2**-.5]],dtype=T); a=torch.tensor([1.,1.],dtype=T); V=torch.tensor([[1.,2.],[-1.,-2.]],dtype=T)
  B=torch.eye(2,dtype=T); c=s.fit_edges(p,a,V,B,edge_count=1); torch.testing.assert_close(c['E'][0],torch.tensor([math.sqrt(2),2*math.sqrt(2)],dtype=T))
  z=torch.tensor([[1.,2.],[3.,-1.]],dtype=T); torch.testing.assert_close(s.predict_q2(z,c),s.full_q2(z,p,a,V),atol=1e-12,rtol=1e-12)
  c0=s.fit_edges(p,a,V,B,edge_count=0); self.assertGreater(torch.sum((s.full_q2(z,p,a,V)-s.predict_q2(z,c0))**2).item(),0)
 def test_probe_exact_identity(self):
  p=torch.tensor([[1.,0.],[2**-.5,2**-.5]],dtype=T); a=torch.tensor([1.,1.],dtype=T); V=torch.tensor([[1.,0.],[0.,1.]],dtype=T); cand=s.fit_atoms(p,a,V,torch.tensor([[1.],[0.]],dtype=T))
  Tprobe=torch.stack([math.sqrt(2)*torch.eye(2,dtype=T)[i] for i in range(2) for _ in range(2)]); Uprobe=torch.stack([math.sqrt(2)*torch.eye(2,dtype=T)[j] for _ in range(2) for j in range(2)])
  estimate=s.probe_residual(p,a,V,cand,Tprobe,Uprobe).mean(); full=torch.stack([p.T@torch.diag(a*V[:,i])@p for i in range(2)]); approx=torch.stack([cand['B']@torch.diag(cand['C'][:,i])@cand['B'].T for i in range(2)])
  torch.testing.assert_close(estimate,((full-approx)**2).sum())
  direct=torch.stack([torch.sum((s.slice_mv(p,a,V,t,u)-s.candidate_slice_mv(cand,t,u))**2) for t,u in zip(Tprobe,Uprobe)])
  torch.testing.assert_close(s.probe_residual(p,a,V,cand,Tprobe,Uprobe,chunk_size=2),direct)
 def test_shared_refit_and_same_input(self):
  p=torch.eye(3,dtype=T); a=torch.ones(3,dtype=T); Vo=torch.eye(3,dtype=T); Vd=2*Vo; B=torch.eye(3,dtype=T)
  co=s.fit_atoms(p,a,Vo,B); shared=s.fit_atoms(p,a,Vd,co['B']); own=s.fit_atoms(p,a,Vd,B); torch.testing.assert_close(shared['C'],own['C'])
  z=torch.tensor([[1.,2.,3.],[-1.,0.,2.]],dtype=T); mu=torch.tensor([.2,.4,.7],dtype=T); A=torch.eye(3,dtype=T); F=lambda x:mu+x@A+s.full_q2(x,p,a,Vd)
  err=s.same_input_errors(F,z,mu,A,shared,p,a,Vd); self.assertLess(err['full_q2'].max().item(),1e-24); self.assertLess(err['candidate'].max().item(),1e-24)
 def test_checkpoint_comparison(self):
  p=torch.eye(3,dtype=T); a=torch.ones(3,dtype=T); V=torch.eye(3,dtype=T); B=torch.eye(3,dtype=T); oq=s.fit_atoms(p,a,V,B); dq=s.fit_atoms(p,a,2*V,B)
  out=s.checkpoint_comparison(torch.tensor([[1.,2.,3.]],dtype=T),p,a,V,p,a,2*V,oq,dq)
  self.assertEqual(out['status'],'OK'); self.assertLess(out['delta_shared_q2_error'].max().item(),1e-24)
  smaller=s.fit_atoms(p,a,2*V,B[:,:2])
  with self.assertRaises(ValueError): s.checkpoint_comparison(torch.ones((1,3),dtype=T),p,a,V,p,a,2*V,oq,smaller)
 def test_score_slices_and_frozen_edges(self):
  p=torch.eye(3,dtype=T); a=torch.ones(3,dtype=T); V=torch.eye(3,dtype=T); B=torch.eye(3,dtype=T)
  c=s.fit_edges(p,a,V,B,edge_count=1,score_slices=torch.eye(3,dtype=T)); r=s.fit_edges(p,a,2*V,B,edges=c['edges']); self.assertEqual(c['edges'],r['edges']); torch.testing.assert_close(r['C'],2*c['C'])
 def test_full_basis_zero_edges_not_rejected(self):
  # Test >128 control path without any full-size model or GPU.
  d=129; p=torch.zeros((1,d),dtype=T); p[0,0]=1.; a=torch.ones(1,dtype=T); V=torch.ones((1,1),dtype=T); B=torch.eye(d,dtype=T)
  result=s.fit_edges(p,a,V,B,edge_count=0); self.assertEqual(result['edges'],[])
  with self.assertRaises(ValueError): s.fit_edges(p,a,V,B,edge_count=1)
 def test_invalid_p_scale(self):
  p=torch.tensor([[2.,0.]],dtype=T); a=torch.ones(1,dtype=T); V=torch.ones((1,1),dtype=T)
  with self.assertRaises(ValueError): s.full_q2(torch.ones((1,2),dtype=T),p,a,V)
  with self.assertRaises(ValueError): s.full_q2(torch.ones((1,2),dtype=T),torch.zeros_like(p),a,V)
 def test_budget(self):
  b=s.budget_macs(5120,5120,13824,1024,100); self.assertEqual(b['candidate'],5120**2+2*5120*1024+100*5120); self.assertEqual(b['rank1024_atoms_with_bypass'],5120**2+2*5120*1024)
if __name__=='__main__': unittest.main(verbosity=2)
