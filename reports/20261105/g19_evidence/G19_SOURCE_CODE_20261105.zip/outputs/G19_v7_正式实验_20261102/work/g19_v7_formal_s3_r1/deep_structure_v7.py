"""Exploratory Q2 full-vector structure; row p[m,d], V[m,out]."""
import math
import torch


def _check(p,a,V):
    if p.ndim!=2 or a.ndim!=1 or V.ndim!=2 or p.shape[0]!=a.numel() or V.shape[0]!=a.numel() or p.dtype!=a.dtype or p.dtype!=V.dtype or p.device!=a.device or p.device!=V.device or any(not torch.isfinite(x).all().item() for x in (p,a,V)): raise ValueError('bad geometry or nonfinite')
    lengths=torch.linalg.vector_norm(p,dim=1)
    if not torch.all((torch.abs(lengths-1)<=1e-6)|(lengths==0)).item() or torch.any((lengths==0)&(a!=0)).item(): raise ValueError('p rows must be unit or zero with zero a2')


def slice_mv(p,a,V,t,x):
    """M_t x = p.T @ (a * (V @ t) * (p @ x))."""
    _check(p,a,V)
    if t.shape!=(V.shape[1],) or x.ndim not in (1,2) or x.shape[0]!=p.shape[1]: raise ValueError('bad slice/probe')
    y=p@x; w=a*(V@t); return p.T@(w*y if x.ndim==1 else w[:,None]*y)


def support_coordinates(x):
    """Householder coordinates of row vectors: maps 1-perpendicular support to R^(d-1)."""
    d=x.shape[-1]
    if d<2 or not torch.isfinite(x).all().item(): raise ValueError('invalid input')
    v=torch.ones(d,dtype=x.dtype,device=x.device)/math.sqrt(d); v[-1]-=1
    v=v/torch.linalg.vector_norm(v)
    return (x-2*(x@v)[...,None]*v)[...,:-1]


def support_embed(x):
    """Inverse isometric embedding R^(d-1) -> 1-perpendicular in R^d."""
    if x.ndim<1 or x.shape[-1]<1 or not torch.isfinite(x).all().item(): raise ValueError('invalid support coordinates')
    d=x.shape[-1]+1; y=torch.cat((x,torch.zeros((*x.shape[:-1],1),dtype=x.dtype,device=x.device)),dim=-1)
    v=torch.ones(d,dtype=x.dtype,device=x.device)/math.sqrt(d); v[-1]-=1; v=v/torch.linalg.vector_norm(v)
    return y-2*(y@v)[...,None]*v


def slices_in_coordinates(H,a,V,T):
    """[m,n] FULL support coordinates -> [s,n,n] full signed slices.
    Unit row norms are required, so use projected_slices for reduced Q.
    Builds one slice at a time; caller must budget tensor, eigensolver and workspace.
    """
    _check(H,a,V)
    if T.ndim!=2 or T.shape[1]!=V.shape[1] or not torch.isfinite(T).all().item(): raise ValueError('bad slices')
    W=(V@T.T)*a[:,None]
    return torch.stack([H.T@(W[:,i,None]*H) for i in range(T.shape[0])])


def projected_slices(p,a,V,Q,T):
    _check(p,a,V)
    if Q.ndim!=2 or Q.shape[0]!=p.shape[1] or T.ndim!=2 or T.shape[1]!=V.shape[1] or not torch.isfinite(Q).all().item() or not torch.isfinite(T).all().item() or not torch.allclose(Q.T@Q,torch.eye(Q.shape[1],device=Q.device,dtype=Q.dtype),atol=1e-6,rtol=1e-6): raise ValueError('bad basis/slices')
    # Reduced row norms are generally <1; construct restricted tensor directly.
    H=p@Q; W=(V@T.T)*a[:,None]
    return torch.stack([H.T@(W[:,i,None]*H) for i in range(T.shape[0])])


def random_combination_basis(slices,weights):
    """Randomized joint diagonalization; caller supplies frozen dev weights[4..8,s].
    Returns n-by-n basis in supplied coordinates and per-trial diagnostics.
    """
    if slices.ndim!=3 or slices.shape[1]!=slices.shape[2] or weights.ndim!=2 or weights.shape[1]!=slices.shape[0] or not 4<=weights.shape[0]<=8 or not torch.isfinite(slices).all().item() or not torch.isfinite(weights).all().item(): raise ValueError('bad RJD inputs')
    if not torch.allclose(slices,slices.transpose(1,2),atol=1e-6,rtol=1e-6): raise ValueError('symmetric slices required')
    best=None; best_score=float('inf'); diagnostics=[]
    for row in weights:
        try:
            M=torch.sum(row[:,None,None]*slices,dim=0)
            _,R=torch.linalg.eigh(M)
            # Diagonal entries of R^T M_s R, without building transformed M_s.
            diag=torch.sum(R.unsqueeze(0)*(slices@R),dim=1)
            score=float((torch.sum(slices*slices)-torch.sum(diag*diag)).item())
            if not math.isfinite(score): raise ValueError('nonfinite objective')
            diagnostics.append({'status':'OK','offdiag_energy_raw':score})
            if score<best_score: best=R; best_score=score
        except (RuntimeError,ValueError) as e:
            if isinstance(e,torch.cuda.OutOfMemoryError) or any(x in str(e).lower() for x in ('out of memory','alloc_failed','cuda error','illegal memory')) or 'INTERRUPTED_SIGNAL_' in str(e): raise
            diagnostics.append({'status':'NUMERICAL_FAILURE','error':str(e)})
    if best is None: return {'status':'ALL_EIGH_FAILED','trials':diagnostics}
    return {'status':'OK','basis':best,'offdiag_energy_raw':best_score,'trials':diagnostics,'method':'RJD_DEVELOPMENT_DIAGNOSTIC'}


def orthogonal_common_basis(Q,slices,sweeps=8):
    """Multi-slice Jacobi joint-diagonalization restricted to Q."""
    if slices.ndim!=3 or slices.shape[1]!=slices.shape[2] or Q.shape[1]!=slices.shape[1] or type(sweeps)!=int or sweeps<0 or not torch.isfinite(slices).all().item() or not torch.allclose(slices,slices.transpose(1,2),atol=1e-7,rtol=1e-7): raise ValueError('bad symmetric slices')
    k=Q.shape[1]
    if k>128: raise ValueError('Jacobi reference limited to k<=128; use random_combination_basis')
    R=torch.eye(k,device=Q.device,dtype=Q.dtype); S=slices.clone()
    for _ in range(sweeps):
        for i in range(k):
            for j in range(i+1,k):
                v=torch.stack((S[:,i,i]-S[:,j,j],2*S[:,i,j]),dim=1); _,U=torch.linalg.eigh(v.T@v); v=U[:,-1]
                theta=.5*torch.atan2(v[1],v[0]); c=torch.cos(theta); sn=torch.sin(theta)
                ci=S[:,:,i].clone(); cj=S[:,:,j].clone()
                S[:,:,i]=c*ci+sn*cj; S[:,:,j]=-sn*ci+c*cj
                ri=S[:,i,:].clone(); rj=S[:,j,:].clone()
                S[:,i,:]=c*ri+sn*rj; S[:,j,:]=-sn*ri+c*rj
                ri=R[:,i].clone(); rj=R[:,j].clone()
                R[:,i]=c*ri+sn*rj; R[:,j]=-sn*ri+c*rj
    return Q@R


def oblique_common_basis(Q,M1,M2,cond_max=1e6,imag_tol=1e-8,eig_gap_tol=1e-6):
    """Signed symmetric pencil; preserve failures instead of assuming SPD."""
    k=Q.shape[1]
    if M1.shape!=(k,k) or M2.shape!=(k,k) or not math.isfinite(cond_max) or cond_max<=1 or imag_tol<0 or not math.isfinite(eig_gap_tol) or eig_gap_tol<=0 or any(not torch.isfinite(x).all().item() for x in (Q,M1,M2)) or not torch.allclose(M1,M1.T,atol=1e-7,rtol=1e-7) or not torch.allclose(M2,M2.T,atol=1e-7,rtol=1e-7): raise ValueError('bad pencil')
    try:
        c1=float(torch.linalg.cond(M1).item())
        if not math.isfinite(c1) or c1>cond_max: return {'status':'REJECTED_SINGULAR_PENCIL','cond_pencil':c1}
        eig,S=torch.linalg.eig(torch.linalg.solve(M1,M2))
        if float(torch.max(torch.abs(eig.imag)).item())>imag_tol or float(torch.max(torch.abs(S.imag)).item())>imag_tol: return {'status':'REJECTED_COMPLEX_PENCIL','cond_pencil':c1}
        values=torch.sort(eig.real).values
        if k>1 and torch.any(torch.abs(values[1:]-values[:-1]) <= eig_gap_tol*torch.maximum(torch.ones_like(values[1:]),torch.maximum(torch.abs(values[1:]),torch.abs(values[:-1])))).item():
            return {'status':'DEGENERATE_PENCIL_UNRESOLVED','cond_pencil':c1,'eigenvalues':values}
        S=S.real; cond=float(torch.linalg.cond(S).item())
        if not math.isfinite(cond) or cond>cond_max: return {'status':'REJECTED_ILL_CONDITIONED_BASIS','cond_basis':cond,'cond_pencil':c1}
        B=Q@torch.linalg.inv(S).T; norms=torch.linalg.vector_norm(B,dim=0)
        if (norms<=0).any().item(): return {'status':'REJECTED_ZERO_DIRECTION'}
        return {'status':'OK','B':B/norms,'cond_pencil':c1,'cond_basis':cond}
    except RuntimeError as e:
        if isinstance(e,torch.cuda.OutOfMemoryError) or any(x in str(e).lower() for x in ('out of memory','alloc_failed','cuda error','illegal memory')) or 'INTERRUPTED_SIGNAL_' in str(e): raise
        return {'status':'REJECTED_NUMERICAL_FAILURE','error':str(e)}


def fit_atoms(p,a,V,B,cond_max=1e8):
    """Original-Frobenius optimal coefficient per output via K=(B.T B)^2."""
    _check(p,a,V)
    if B.ndim!=2 or B.shape[0]!=p.shape[1] or B.shape[1]==0 or not torch.isfinite(B).all().item(): raise ValueError('bad B')
    norms=torch.linalg.vector_norm(B,dim=0)
    if (norms<=0).any().item(): return {'status':'REJECTED_ZERO_DIRECTION'}
    B=B/norms; H=p@B; K=(B.T@B)**2; rhs=(H*H).T@(a[:,None]*V)
    try:
        cond=float(torch.linalg.cond(K).item())
        if not math.isfinite(cond) or cond>cond_max: return {'status':'REJECTED_GRAM_CONDITION','cond_gram':cond,'B':B}
        C=torch.linalg.solve(K,rhs)
        if not torch.isfinite(C).all().item(): raise ValueError('nonfinite solve')
        return {'status':'OK','B':B,'C':C,'cond_gram':cond,'kind':'atoms','edges':[]}
    except (RuntimeError,ValueError) as e:
        if isinstance(e,torch.cuda.OutOfMemoryError) or any(x in str(e).lower() for x in ('out of memory','alloc_failed','cuda error','illegal memory')) or 'INTERRUPTED_SIGNAL_' in str(e): raise
        return {'status':'REJECTED_GRAM_SOLVE','error':str(e),'B':B}


def select_edges_from_slices(slices,edge_count):
    """Rank edge energy of frozen development slices in the candidate orthogonal basis.
    Includes sqrt(2) feature normalization; no per-edge host/GPU synchronizations.
    """
    if slices.ndim!=3 or slices.shape[1]!=slices.shape[2] or not torch.isfinite(slices).all().item(): raise ValueError('bad basis slices')
    k=slices.shape[1]
    if type(edge_count)!=int or not 0<=edge_count<=k*(k-1)//2: raise ValueError('bad edge budget')
    if edge_count==0: return []
    ij=torch.triu_indices(k,k,offset=1,device=slices.device)
    score=2*torch.sum(slices[:,ij[0],ij[1]]**2,dim=0)
    # stable ordering resolves ties in lexicographic triangular-index order.
    order=torch.argsort(score,descending=True,stable=True)[:edge_count]
    return list(zip(ij[0,order].cpu().tolist(),ij[1,order].cpu().tolist()))


def fit_edges(p,a,V,B,edge_count=None,edges=None,score_slices=None):
    """Orthogonal basis; select full-output edge energies or refit frozen edges."""
    _check(p,a,V)
    if B.ndim!=2 or B.shape[0]!=p.shape[1]: raise ValueError('bad basis')
    k=B.shape[1]
    if not torch.allclose(B.T@B,torch.eye(k,dtype=B.dtype,device=B.device),atol=1e-6,rtol=1e-6): raise ValueError('orthonormal basis required')
    H=p@B; weighted=a[:,None]*V; diag=(H*H).T@weighted
    if edges is None:
        if type(edge_count)!=int or not 0<=edge_count<=k*(k-1)//2: raise ValueError('bad edge budget')
        if k>128 and edge_count>0: raise ValueError('large basis requires edges from select_edges_from_slices')
        if score_slices is not None:
            if score_slices.ndim!=2 or score_slices.shape[1]!=V.shape[1] or not torch.isfinite(score_slices).all().item(): raise ValueError('bad development slices')
            score_weight=a[:,None]*(V@score_slices.T)
        else:
            score_weight=weighted
        scored=[]
        if edge_count:
            for i in range(k):
                for j in range(i+1,k):
                    v=math.sqrt(2)*(H[:,i]*H[:,j])@score_weight; scored.append((float(torch.sum(v*v).item()),i,j))
        edges=[(i,j) for _,i,j in sorted(scored,key=lambda x:(-x[0],x[1],x[2]))[:edge_count]]
    else:
        edges=[tuple(e) for e in edges]
        if len(set(edges))!=len(edges) or any(i<0 or j>=k or i>=j for i,j in edges): raise ValueError('invalid edges')
    chunks=[]
    for start in range(0,len(edges),64):
        part=edges[start:start+64]; ii=[x[0] for x in part]; jj=[x[1] for x in part]
        chunks.append(math.sqrt(2)*(H[:,ii]*H[:,jj]).T@weighted)
    E=torch.cat(chunks,dim=0) if chunks else torch.empty((0,V.shape[1]),dtype=V.dtype,device=V.device)
    return {'status':'OK','kind':'edges','B':B,'C':diag,'edges':edges,'E':E}


def predict_q2(z,candidate):
    if candidate.get('status')!='OK': raise ValueError('candidate is not usable')
    B,C=candidate['B'],candidate['C']; h=z@B; out=((h*h-1)/math.sqrt(2))@C
    if candidate['kind']=='edges' and candidate['edges']:
        out=out+torch.stack([h[...,i]*h[...,j] for i,j in candidate['edges']],dim=-1)@candidate['E']
    return out


def full_q2(z,p,a,V):
    _check(p,a,V); h=z@p.T; return (((h*h-1)/math.sqrt(2))*a)@V


def candidate_slice_mv(candidate,t,u):
    B,C=candidate['B'],candidate['C']; out=B@((C@t)*(B.T@u))
    if candidate['kind']=='edges':
        ii=[e[0] for e in candidate['edges']]; jj=[e[1] for e in candidate['edges']]
        v=(candidate['E']@t)/math.sqrt(2); bu=B.T@u
        out=out+B[:,ii]@(v*bu[jj])+B[:,jj]@(v*bu[ii])
    return out


def probe_residual(p,a,V,candidate,T,U,chunk_size=16):
    """Independent isotropic t,u pairs: mean targets full-output Frob².
    Evaluate probes in chunks without materializing the full vector-output tensor.
    """
    _check(p,a,V)
    if T.ndim!=2 or U.ndim!=2 or T.shape[0]!=U.shape[0] or T.shape[0]==0 or T.shape[1]!=V.shape[1] or U.shape[1]!=p.shape[1] or type(chunk_size)!=int or chunk_size<1 or not torch.isfinite(T).all().item() or not torch.isfinite(U).all().item() or candidate.get('status')!='OK': raise ValueError('bad probes or candidate')
    B,C=candidate['B'],candidate['C']; vals=[]
    for start in range(0,len(T),chunk_size):
        t=T[start:start+chunk_size].T; u=U[start:start+chunk_size].T
        actual=p.T@((a[:,None]*(V@t))*(p@u))
        bu=B.T@u; estimate=B@((C@t)*bu)
        if candidate['kind']=='edges' and candidate['edges']:
            ii=[e[0] for e in candidate['edges']]; jj=[e[1] for e in candidate['edges']]
            v=(candidate['E']@t)/math.sqrt(2)
            estimate=estimate+B[:,ii]@(v*bu[jj,:])+B[:,jj]@(v*bu[ii,:])
        vals.append(torch.sum((actual-estimate)**2,dim=0))
    result=torch.cat(vals)
    if not torch.isfinite(result).all().item(): raise ValueError('nonfinite residual')
    return result


def same_input_errors(F,z,mu,A,candidate,p,a,V):
    target=F(z); baseline=mu+z@A; full=baseline+full_q2(z,p,a,V); approx=baseline+predict_q2(z,candidate)
    return {'full_q2':torch.sum((target-full)**2,dim=-1),'candidate':torch.sum((target-approx)**2,dim=-1)}


def budget_macs(d,out,m,k,edges=0,linear_bypass=True):
    if any(type(x)!=int or x<0 for x in (d,out,m,k,edges)) or d==0 or out==0 or m==0 or k>d or edges>k*(k-1)//2: raise ValueError('bad budget')
    linear=d*out if linear_bypass else 0
    return {'candidate':linear+d*k+k*out+edges*out,'full_q2_best_fused':d*m+m*out,'full_q2_detector_unfused':linear+d*m+m*out,'original_ffn':d*m+m*out,'rank1024_atoms_with_bypass':linear+d*min(1024,d)+min(1024,d)*out,'scope':'main dense MAC only; excludes nonlinear ops, memory, build and reuse'}

def checkpoint_comparison(z,p_o,a_o,V_o,p_d,a_d,V_d,shared_o,own_d):
    """Freeze original geometry/edge set; refit Dq coefficients and compare own Dq geometry.
    Return full-vector Q2 outputs and Delta Q2; this is development, not confirmation.
    """
    if shared_o.get('status')!='OK' or own_d.get('status')!='OK': raise ValueError('usable candidates required')
    if p_o.shape[1]!=p_d.shape[1] or V_o.shape[1]!=V_d.shape[1]: raise ValueError('checkpoint dimension mismatch')
    d=p_o.shape[1]; o=V_o.shape[1]
    cost=lambda c: (d+o)*c['B'].shape[1]+o*len(c.get('edges',[]))
    if cost(shared_o)!=cost(own_d): raise ValueError('checkpoint candidates must have same MAC budget')
    if shared_o['kind']=='atoms':
        shared_d=fit_atoms(p_d,a_d,V_d,shared_o['B'])
    elif shared_o['kind']=='edges':
        shared_d=fit_edges(p_d,a_d,V_d,shared_o['B'],edges=shared_o['edges'])
    else: raise ValueError('unknown geometry')
    if shared_d['status']!='OK': return {'status':'SHARED_REFIT_FAILED','shared_d':shared_d}
    qo=full_q2(z,p_o,a_o,V_o); qd=full_q2(z,p_d,a_d,V_d)
    po=predict_q2(z,shared_o); pd_shared=predict_q2(z,shared_d); pd_own=predict_q2(z,own_d)
    return {'status':'OK','shared_d':shared_d,'oq_q2_error':torch.sum((qo-po)**2,dim=-1),
            'dq_shared_q2_error':torch.sum((qd-pd_shared)**2,dim=-1),
            'dq_own_q2_error':torch.sum((qd-pd_own)**2,dim=-1),
            'delta_shared_q2_error':torch.sum(((qd-qo)-(pd_shared-po))**2,dim=-1),
            'candidate_main_macs_excluding_bypass':cost(shared_o)}
