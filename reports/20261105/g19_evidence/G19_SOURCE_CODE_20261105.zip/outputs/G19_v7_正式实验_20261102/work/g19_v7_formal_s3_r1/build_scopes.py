"""Create finite review candidates, never ACTIVE, submit or read real weights."""
from pathlib import Path
import hashlib,json,shutil
root=Path(__file__).resolve().parent
results=root.parent/'g19_v7_formal_s12_results'
remote='/public/home/scc/pb23061276/projects/wan-quant/work'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8',newline='\n')
def rows(p): return [json.loads(s) for s in p.read_text(encoding='utf8').splitlines()]
assets={}; hashes={}; evidence={}
for expert in ('high','low'):
    r=results/expert
    receipt=json.loads((r/'EXIT.json').read_text(encoding='utf8'))
    assert receipt['status']=='SUCCESS' and receipt['result']['completed_layers']==list(range(40))
    assert len(receipt['result']['completed_units'])==120
    for rec in rows(r/'weights.jsonl'):
        key=f"{expert}/{rec['model']}/{rec['key']}"
        assert key not in hashes
        hashes[key]=rec['sha256']
    for rec in rows(r/'artifacts.jsonl'):
        if rec['kind']=='A1' and rec['arm'] in ('Oq','Dq'):
            assets[f"{expert}/{rec['layer']}/{rec['arm']}"]={'path':remote+f"/g19_v7_formal_s12_r1/{expert}/runs/s12_01/"+rec['path'],'sha256':rec['sha256']}
    evidence[expert]={f:sha(r/f) for f in ('START.json','EXIT.json','artifacts.jsonl','weights.jsonl')}
assert len(hashes)==640 and len(assets)==160
write(root/'s12_assets.json',assets); write(root/'expected_tensor_hashes.json',hashes); write(root/'s12_evidence.json',evidence)
layers=((0,1,7),(12,13,19),(23,24,28),(33,37,38))
files=['runner_s3.py','deep_structure_v7.py','runtime_guard.py','weights_v7.py','core_math.py','statistics_v7.py','job_s3.sh','test_deep_structure.py','test_s3_runner.py','test_s3_guard.py','STRUCTURE_SELF_AUDIT.txt','RUNNER_S3_SELF_AUDIT.txt']
for f in files: assert (root/f).is_file(),f
summary=[]
for expert in ('high','low'):
 for h,ls in enumerate(layers):
    name=f'{expert}_s{h}'; folder=root/name
    folder.mkdir(exist_ok=False)
    for f in files+['input_manifest.json','s12_assets.json','expected_tensor_hashes.json','s12_evidence.json']:
        shutil.copyfile(root/f,folder/f)
    config={'expert':expert,'stratum':h,'layers':list(ls),'seed':2026110207,'blocks':64,'operator_probes':16,'dev_slices':8,'mixtures':4,'gh_nodes':384,'reduced_rank':512,'edge_reduced_rank':384,'edge_reduced_count':256,'pencil_tries':4,'output_dir':remote+f'/g19_v7_formal_s3_r1/{name}/runs/s3_01'}
    write(folder/'config.json',config)
    scope={'scope_id':f'G19_V7_S3_{expert.upper()}_STRATUM{h}_R1','status':'FROZEN_REVIEWED','phase':'S3_STRUCTURE_DEVELOPMENT','authors':['/root','/root/terra_p0_implementation'],
      'active_registry_file':'ACTIVE_RESEARCH.json','activation_requires':'Independent ACCEPTED exact scope followed by finite ACTIVE registration; draft is not active',
      'config_file':'config.json','config_sha256':sha(folder/'config.json'),'input_manifest_file':'input_manifest.json','manifest_sha256':sha(folder/'input_manifest.json'),
      's12_assets_file':'s12_assets.json','expected_tensor_hashes_file':'expected_tensor_hashes.json',
      'frozen_inputs_sha256':{f:sha(folder/f) for f in ('s12_assets.json','expected_tensor_hashes.json','s12_evidence.json')},'code_sha256':{f:sha(folder/f) for f in files},
      'budget':{'max_jobs':1,'gpus_per_job':1,'session_max_gpus':2,'cpus':4,'host_memory_gib':64,'gpu_allocation_peak_gib':40,'wall_seconds':1800,'soft_seconds':1650,'min_free_disk_gib':30,'output_budget_gib':20},
      'units':[{'expert':expert,'layer':l,'arm':a} for l in ls for a in ('Oq','Dq')],'unit_count':6,
      'finite_stage_jobs':8,'max_stage_gpu_hours':4,'max_concurrent_jobs_all_stages':2,
      'reference':'Gaussian u=sqrt(d/(d-1))*Pi*z alpha=1; tanh GELU/all biases, Oq explicit original BF16 RNE versus Dq decoded stored BF16; not native BF16 inference',
      'candidates':['ORTH_FULL_RJD_5119','EDGE_FULL_RJD_5119_E2559','ORTH_SUBSPACE_512','EDGE_SUBSPACE_384_E256','OBLIQUE_SUBSPACE_512','FULL_Q2_REFERENCE'],
      'geometry':'Full support 5119; eight independent development signed output slices, four random mixtures; reduced signed pencil four attempts, repeated/complex/singular/ill-conditioned pencils unresolved; original Frobenius metric Gram fit',
      'data_contract':{'namespace':'DEVELOPMENT','geometry_streams':[70,71,74],'heldout_stream':72,'paired_blocks':64,'operator_output_stream':73,'operator_input_stream':75,'operator_probes':16,'inference':'DEVELOPMENT_DIAGNOSTIC_NOT_CONFIRMATION','same_inputs_across_checkpoints':True},
      'estimands':['Full FFN error with frozen mean and A1 bypass','Q2 full-output operator residual','Difference of checkpoint full FFNs after affine and Q2 approximation','Explicit pure Delta Q2 approximation','Oq shared basis refit on Dq versus own Dq basis'],
      'cost_policy':'Main MAC counts and measured construction cost; full-Q2 best fused comparator=2dm; no end-to-end speedup claim',
      'missingness_policy':'Keep every candidate and unit failure. Do not discard valid ORTH/EDGE because signed oblique unresolved. No population mean from successful-only subset.',
      'numeric_policy':'FP64 geometry/GH384 and FP32 TF32-off forward; numeric indicators UNASSESSED, no certified error bounds.',
      'claim_limits':['No simultaneous confidence claim from 64 blocks/16 probes','No rejection of all nonorthogonal geometries from rank512 pencil attempts','No native distribution or video quality conclusion','No whole-FFN speedup conclusion'],
      'failure_policy':'Each scope at most one job, no automatic retry/layer replacement; preserve missing/partial/failed outputs; any changed continuation separately reviewed.'}
    write(folder/'scope.json',scope)
    summary.append({'folder':name,'scope_sha256':sha(folder/'scope.json'),'scope_id':scope['scope_id']})
write(root/'SCOPE_INDEX.json',summary)
print(json.dumps(summary))
