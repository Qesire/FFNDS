from pathlib import Path
import shutil
root=Path(__file__).resolve().parent
source=root/'g19_v7_formal_s12_r1'
guard=(source/'runtime_guard.py').read_text(encoding='utf8')
old="""    required = {'runner_v7.py', 'runtime_guard.py', 'weights_v7.py',
                'core_math.py', 'statistics_v7.py', 'structure_v7.py', 'job_v7.sh'}"""
new="""    modules_by_phase = {
        'S12_FORMAL_CENSUS_AND_PLANNING': {'runner_v7.py','structure_v7.py','job_v7.sh','core_math.py'},
        'S3_STRUCTURE_DEVELOPMENT': {'runner_s3.py','deep_structure_v7.py','job_s3.sh','core_math.py'},
        'S4_CHECKPOINT_CONFIRMATION': {'runner_confirm.py','job_confirm.sh'},
    }
    if scope.get('phase') not in modules_by_phase:
        raise RuntimeError('Unknown formal experiment phase')
    required = {'runtime_guard.py','weights_v7.py','statistics_v7.py'} | modules_by_phase[scope['phase']]"""
assert old in guard
guard=guard.replace(old,new).replace("if scope.get('phase') == 'S12_FORMAL_CENSUS_AND_PLANNING':", "if scope.get('phase') in modules_by_phase:")
guard=guard.replace("Insufficient free filesystem space for full A1 artifacts", "Insufficient free filesystem space for reviewed artifacts")
guard=guard.replace("or budget['cpus'] > 4 or budget['host_memory_gib'] > 64", "or not 0 < budget['cpus'] <= 4 or not 0 < budget['host_memory_gib'] <= 64")
for name in ('g19_v7_formal_s3_r1','g19_v7_formal_checkpoint_confirm_r1'):
    dest=root/name
    (dest/'runtime_guard.py').write_text(guard,encoding='utf8',newline='\n')
    for f in ('weights_v7.py','core_math.py','statistics_v7.py'):
        shutil.copyfile(source/f,dest/f)
    shutil.copyfile(source/'high/input_manifest.json',dest/'input_manifest.json')
    phase='s3' if name.endswith('s3_r1') else 'confirm'
    job=(source/'high/job_v7.sh').read_text(encoding='utf8').replace('g19_v7_s12','g19_v7_'+phase).replace('runner_v7.py','runner_'+phase+'.py')
    (dest/('job_'+phase+'.sh')).write_text(job,encoding='utf8',newline='\n')
print('Prepared two common code copies and phase-bound guards; no scopes activated.')
