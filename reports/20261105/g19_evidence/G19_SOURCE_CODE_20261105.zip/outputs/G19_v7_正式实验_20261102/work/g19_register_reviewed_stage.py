"""Register every exact reviewed finite scope in an existing stage index."""
import argparse,datetime,hashlib,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('stage',type=Path);args=p.parse_args()
root=args.stage.resolve(); index=json.loads((root/'SCOPE_INDEX.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
scopes={}
for item in index:
    folder=root/item['folder']; scope=json.loads((folder/'scope.json').read_text(encoding='utf8'))
    digest=sha(folder/'scope.json'); review=json.loads((folder/'INDEPENDENT_REVIEW.json').read_text(encoding='utf8'))
    assert digest==item['scope_sha256'] and scope['scope_id']==item['scope_id']
    assert review['status']=='ACCEPTED' and review['scope_sha256']==digest and review['reviewer'] not in scope['authors']
    identities={**scope['code_sha256'],**scope['frozen_inputs_sha256'],scope['config_file']:scope['config_sha256'],scope['input_manifest_file']:scope['manifest_sha256']}
    for f,h in identities.items(): assert sha(folder/f)==h,f
    assert not (folder/'ACTIVE_RESEARCH.json').exists()
    scopes[scope['scope_id']]={'state':'AUTHORIZED_FOR_ONE_JOB','scope_sha256':digest,'max_jobs':1,'folder':item['folder'],'units':scope['unit_count'],'review_sha256':sha(folder/'INDEPENDENT_REVIEW.json')}
active={'schema':'G19_FINITE_ACTIVE_V1','state':'SCOPE_FROZEN_IN_ACTIVE','user_authorization':'2026-11-02 开始正式实验。','registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'session_max_gpus':2,'max_concurrent_jobs':2,'gpus_per_job':1,'stage':root.name,'scopes':scopes,'failure_policy':'No auto retries; each finite registered scope at most one job.'}
for folder in [root]+[root/i['folder'] for i in index]:
    with (folder/'ACTIVE_RESEARCH.json').open('x',encoding='utf8') as f:json.dump(active,f,ensure_ascii=False,indent=2)
    if folder!=root:
        files=sorted(p for p in folder.iterdir() if p.is_file() and p.name!='sha256sums.txt')
        (folder/'sha256sums.txt').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in files),encoding='utf8',newline='\n')
print(json.dumps({'state':active['state'],'scopes':len(scopes),'scope_ids':list(scopes)}))
