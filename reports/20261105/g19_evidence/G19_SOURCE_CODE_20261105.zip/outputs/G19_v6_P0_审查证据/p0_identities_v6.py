"""G19 v6 · P0 身份与数学准备（CPU，无 GPU，无新模型执行）。

对应《G19_v6_完整研究方案.md》§8 P0 行：读权重清单；验证反例、零能量、
实际偏置、矩阵方向；确认公式与实现一致。所有公式来自 math_core_v6（§3–§6）。
"""
import argparse, json, math, pathlib, struct, hashlib, time
import numpy as np
from math_core_v6 import (reference_scale, project_rows, tanh_gelu, tanh_gelu_prime,
                          exact_gelu, exact_gelu_prime, g_exact_closed,
                          coefficients, a1_matrix, spectral_stats, eta_quad,
                          certified_reject, sobolev_tail_bound)

R = {}


def read_tensor(manifest, key):
    rec = manifest['tensors'][key]
    p = pathlib.Path(rec['path']); info = manifest['files'][str(p)]; sp = rec['spec']
    st = p.stat()
    if st.st_size != info['size'] or st.st_mtime_ns != info['mtime_ns']:
        raise ValueError(f'weight stat mismatch {p}')
    with p.open('rb') as f:
        n = struct.unpack('<Q', f.read(8))[0]
        raw = f.read(n)
        if hashlib.sha256(raw).hexdigest() != info['header_sha256']:
            raise ValueError(f'header hash mismatch {p}')
        if json.loads(raw)[rec['key']] != sp:
            raise ValueError(f'spec mismatch {key}')
        lo, hi = sp['data_offsets']
        f.seek(8 + n + lo)
        buf = f.read(hi - lo)
    if len(buf) != hi - lo:
        raise ValueError(f'truncated {key}')
    if sp['dtype'] == 'BF16':
        x = (np.frombuffer(buf, dtype='<u2').astype(np.uint32) << 16).view(np.float32).copy()
    else:
        x = np.frombuffer(buf, dtype='<f4').copy()
    x = x.reshape(sp['shape']).astype(np.float64)
    if not np.isfinite(x).all():
        raise ValueError(f'nonfinite {key}')
    return x


def to_bf16(x):
    """§3 Oq：原始 F32 按 BF16 舍入（就近偶数）。"""
    u = np.asarray(x, dtype=np.float32).view(np.uint32).copy()
    r = (u + 0x7FFF + ((u >> 16) & 1)) & 0xFFFF0000
    return r.view(np.float32).astype(np.float64)


# ---------------- fixtures ----------------
def fixtures():
    out = {}
    b = np.array([0.3, 0.0, -0.3]); s = np.array([0.0, 1.0, 2.5])
    _, gb = coefficients(s, b, 1, 512)
    _, gmb = coefficients(s, -b, 1, 512)
    out['parity_g_plus_g_neg'] = float(np.max(np.abs(gb + gmb - 1.0)))          # §5: =1
    _, g = coefficients(s, b, 1, 512)
    kappa = (coefficients(s, b, 1, 512)[1] - 0.5) / np.where(np.abs(b) > 0, b, 1.0)
    small = np.array([1e-4, 2e-4]); s2 = np.array([0.7, 1.3])
    _, gs = coefficients(s2, small, 1, 512)
    out['linearization_residual'] = float(np.max(np.abs(gs - (0.5 + small * kappa[:2]))))
    # 精确 GELU 的闭式 vs 求积
    bb = np.array([0.0, 0.25, -0.25]); ss = np.array([0.0, 1.0, 2.0])
    _, ge_q = coefficients(ss, bb, 1, 512, activation='exact')
    out['exact_gelu_closed_vs_quad'] = float(np.max(np.abs(ge_q - g_exact_closed(bb, ss))))
    # 零尺度神经元：不得出 NaN
    a0, g0 = coefficients(np.zeros(3), np.array([0.1, 0.0, -0.2]), 2, 512)
    out['zero_scale_finite'] = bool(np.isfinite(a0).all() and np.isfinite(g0).all())
    out['zero_scale_a1_abs'] = float(np.max(np.abs(a0[:, 1])))
    # A1^T 1 = 0（各向同性商空间参考）
    rng = np.random.default_rng(7)
    m, d = 40, 12
    W1 = rng.normal(size=(m, d)); W2 = rng.normal(size=(d, m)); b1 = rng.normal(size=m) * 0.1
    wc = project_rows(W1); beta = reference_scale(d, 1.0) * wc
    s3 = np.linalg.norm(beta, axis=1)
    p3 = np.where(s3[:, None] > 0, beta / np.where(s3[:, None] > 0, s3[:, None], 1.0), 0.0)
    V = W2.T
    c512, _ = coefficients(s3, b1, 1, 512)
    A1 = a1_matrix(p3, c512[:, 1], V)
    out['a1_transpose_ones_rel'] = float(np.linalg.norm(A1.T @ np.ones(d)) / max(np.linalg.norm(A1), 1e-300))
    # 两条积分路线（512 / 768 节点）的矩阵级比较
    c768, _ = coefficients(s3, b1, 1, 768)
    A1b = a1_matrix(p3, c768[:, 1], V)
    out['AB_matrix_rel_frobenius'] = float(np.linalg.norm(A1 - A1b) / max(np.linalg.norm(A1), 1e-300))
    out['AB_trace_rel'] = float(abs(np.trace(A1 @ A1.T) - np.trace(A1b @ A1b.T)) / max(np.trace(A1 @ A1.T), 1e-300))
    # 正负神经元反例：b 与 -b 应给出 g 互补
    out['neuron_pair_g_sum'] = float(np.max(np.abs(
        coefficients(np.array([1.0, 2.0]), np.array([0.5, 0.5]), 1, 512)[1] +
        coefficients(np.array([1.0, 2.0]), np.array([-0.5, -0.5]), 1, 512)[1] - 1.0)))
    return out


# ---------------- 真实单元 ----------------
def unit(manifest, expert, model, layer, arm, nodes=512, Q=1):
    t0 = time.time()
    pref = f'{expert}/{model}/blocks.{layer}.ffn.'
    W1 = read_tensor(manifest, pref + '0.weight')
    W2 = read_tensor(manifest, pref + '2.weight')
    b1 = read_tensor(manifest, pref + '0.bias')
    b2 = read_tensor(manifest, pref + '2.bias')
    m, d = W1.shape
    if arm == 'Oq':
        W1 = to_bf16(W1); W2 = to_bf16(W2); b1 = to_bf16(b1); b2 = to_bf16(b2)
    if not np.all(b1 == 0):
        bias_nonzero = True
    else:
        bias_nonzero = False
    wc = project_rows(W1)
    beta = reference_scale(d, 1.0) * wc
    s = np.linalg.norm(beta, axis=1)
    p = np.where(s[:, None] > 0, beta / np.where(s[:, None] > 0, s[:, None], 1.0), 0.0)
    V = W2.T
    a_b, g = coefficients(s, b1, Q, nodes)
    a_0, _ = coefficients(s, np.zeros_like(b1), Q, nodes)
    A_b = a1_matrix(p, a_b[:, 1], V)
    A_0 = a1_matrix(p, a_0[:, 1], V)
    H = A_b @ A_b.T
    ev = np.linalg.eigvalsh(H)[::-1]
    st = spectral_stats(ev)
    # 两条积分路线的系数差 -> §6 eta_quad
    a_768, g768 = coefficients(s, b1, Q, 768)
    delta = np.abs(g - g768)
    vnorm = np.linalg.norm(V, axis=1)
    eta = eta_quad(beta, delta, vnorm)
    res = {
        'unit': f'{expert}/{layer}/{model}/{arm}', 'd': d, 'm': m,
        'b1_nonzero': bool(bias_nonzero),
        'b1_max_abs': float(np.abs(b1).max()),
        's_quantiles': [float(np.quantile(s, q)) for q in (0.0, 0.5, 0.9, 1.0)],
        'g_range': [float(g.min()), float(g.max())],
        'g_minus_half_max_abs': float(np.max(np.abs(g - 0.5))),
        'A1_fro': float(np.linalg.norm(A_b)),
        'A1_bias_effect_rel': float(np.linalg.norm(A_b - A_0) / max(np.linalg.norm(A_0), 1e-300)),
        'A1_transpose_ones_rel': float(np.linalg.norm(A_b.T @ np.ones(d)) / max(np.linalg.norm(A_b), 1e-300)),
        'E1_trace_rel': float(abs(st['trace'] - np.linalg.norm(A_b) ** 2) / max(st['trace'], 1e-300)),
        'spectrum': st,
        'eta_quad': eta,
        'certified_reject_5pct': {str(r): certified_reject(
            float(np.sum(np.sort(ev)[::-1][r:] ** 2)), eta, float(np.linalg.norm(A_b)), 0.05)
            for r in (128, 256, 512, 1024, 2048)},
        'seconds': round(time.time() - t0, 2),
    }
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--manifest', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--units', default='high:0:original:O32,high:0:original:Oq,low:15:original:O32')
    ap.add_argument('--skip-fixtures', action='store_true')
    a = ap.parse_args()
    man = json.loads(pathlib.Path(a.manifest).read_text())
    if man.get('schema') != 'G19_MANIFEST_V6':
        raise ValueError('manifest schema mismatch')
    out = {'stage': 'P0', 'manifest_schema': man['schema'], 'started_unix': time.time()}
    if not a.skip_fixtures:
        out['fixtures'] = fixtures()
    out['units'] = []
    for spec in a.units.split(','):
        expert, layer, model, arm = spec.split(':')
        out['units'].append(unit(man, expert, model, int(layer), arm))
        print('UNIT_DONE', spec, flush=True)
    out['finished_unix'] = time.time()
    pathlib.Path(a.out).write_text(json.dumps(out, indent=2))
    print('P0_WRITTEN', a.out)


if __name__ == '__main__':
    main()
