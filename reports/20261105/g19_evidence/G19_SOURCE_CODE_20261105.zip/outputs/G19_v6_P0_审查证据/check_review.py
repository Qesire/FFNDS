"""Review-only small algebraic counterexamples and arithmetic on existing receipts.
No model execution, no remote writes, no modification of reviewed implementation.
"""
import pathlib,json,sys,math,hashlib
import numpy as np
root=pathlib.Path(__file__).resolve().parent
src=root/'ffn_property_discovery_20261102_v6_p0'
if not src.exists():
 src=root
sys.path.insert(0,str(src))
from math_core_v6 import certified_reject,sobolev_tail_bound
r=json.loads((src/'p0_identities.json').read_text())
old=json.loads((src/'p0_identities_run1_127741.json').read_text())
summary={'review_kind':'existing receipts plus small function-level algebraic checks, not a model experiment','source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in src.iterdir() if p.is_file()},'run1_exact_gelu_control_error':old['fixtures']['exact_gelu_closed_vs_quad'],'unit_checks':[]}
for u in r['units']:
 st=u['spectrum']; e=u['A1_bias_effect_rel']
 rr=st['tail_share']['1024']; sr=math.sqrt(rr)
 entry={'unit':u['unit'],'trace':st['trace'],'bias_effect_denominator':'A1(b=0)','bias_relative_effect':e,'tail_checks':{},'zero_bias_R1024_possible_interval_from_bias_norm_only':[max(sr*(1-e)-e,0)**2,(sr*(1+e)+e)**2], 'max_relative_A_error_allowing_rank1024_rejection_at_5pct':max((sr-math.sqrt(.05))/(1+math.sqrt(.05)),0)}
 for rank,saved in u['certified_reject_5pct'].items():
  share=st['tail_share'][rank]; L=share*st['trace']
  # Show only the correct algebra at eta=0. The saved eta is not an error certificate.
  correct=certified_reject(L,0,u['A1_fro'],.05)
  entry['tail_checks'][rank]={'saved_incorrect_lower':saved['lower'],'correct_point_ratio':correct['lower'],'saved_reject':saved['reject_at_budget'],'correct_point_reject':correct['reject_at_budget'],'formal_certificate':'NOT_ESTABLISHED'}
 summary['unit_checks'].append(entry)
ev=np.array([9.,2.]); base=sum(ev[1:])/sum(ev)
summary['scale_invariance_counterexample']={'eigenvalues':[9,2],'correct_tail_ratio':base,'bad_ratio_original':sum(ev[1:]**2)/sum(ev),'bad_ratio_after_A_times10':sum((100*ev[1:])**2)/sum(100*ev),'correct_ratio_after_A_times10':sum(100*ev[1:])/sum(100*ev)}
v=sobolev_tail_bound(6,{2:0},2,2)
assert v['R_Q_upper']==.5
v2=sobolev_tail_bound(2.6,{2:1},2,2)
assert v2['R_Q_upper']==0
summary['sobolev_counterexamples']=[{'F':'h3=(z^3-3z)/sqrt(6)','Q':2,'k':2,'D2':6,'true_R2':1,'implementation':v},{'F':'h2+sqrt(0.1)*h3','Q':2,'k':2,'D2':2.6,'true_R2':.1,'implementation':v2}]
(root/'review_checks.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
for e in summary['unit_checks']:
 print(e['unit'],e['tail_checks'],e['zero_bias_R1024_possible_interval_from_bias_norm_only'],e['max_relative_A_error_allowing_rank1024_rejection_at_5pct'])
print('SOB0LEV_COUNTEREXAMPLES',summary['sobolev_counterexamples'])
print('RUN1_GELU_ERROR',summary['run1_exact_gelu_control_error'])
