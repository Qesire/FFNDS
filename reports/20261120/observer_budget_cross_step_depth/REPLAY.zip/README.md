# FFNDS 观测预算与跨站点实验

REPORT.md 为主报告。无需权重即可查看 work 下的逐源 JSON 与子实验说明。

复算使用 PyTorch 2.8.0+cu126、NumPy、SciPy。图表另需 Matplotlib。三份 CAL 与 11 份 DEV 仅使用 seed 42。第 19 层原生权重和输入根据 work/native-inputs/BINDINGS.json 取回，将面板放在 work/native-inputs/、两组权重放在其 high19/ 和 low19/ 子目录。第 4 层的 24 份捕获放在 work/depth1120/bank/。下载器需要对原归档的访问权。本包不含原生模型或视频。

从包根目录执行以下命令。对接受 high 参数的命令，再以 low 重做，之后运行对应汇总脚本。

~~~text
python work/budget1120/run_budget.py high
python work/budget1120/complement.py high
python work/budget1120/complement.py high --confirm
python work/kernel1120/kernel_study.py high
python work/kernel1120/extra_sources.py high
python work/depth1120/run.py high
python work/depth1120/orthogonal.py high
python work/depth1120/orthogonal_budget.py high
python work/steps1120/replay.py
python work/steps1120/full_output.py
python work/steps1120/history_conditional.py
python work/budget1120/summarize.py
python work/budget1120/summarize_complement.py
python work/depth1120/summarize.py
python work/depth1120/summarize_budget.py
python work/kernel1120/summary.py
python work/kernel1120/coverage.py
python work/kernel1120/figure.py
~~~

SHA256SUMS 给出本包内容哈希。报告中的观测数按每次命中、每个站点统计。归档光栅位置、教师强制端点误差和自由生成视频是不同的观测对象。
