"""Read-only diagnostic on archived Wan FFN operands. No video inference."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_weights(root, expert, binding):
    shapes = [(13824, 5120), (13824,), (5120, 13824), (5120,)]
    weights = []
    for suffix, shape in zip(("0.weight", "0.bias", "2.weight", "2.bias"), shapes):
        name = "blocks.19.ffn." + suffix
        path = root / (expert + "19") / (name + ".bf16")
        assert digest(path) == binding["ffn_tensor_sha256"][name]
        t = torch.from_numpy(np.fromfile(path, dtype="<u2")).view(torch.bfloat16)
        weights.append(t.reshape(shape).cuda().float())
    return weights


def panel(root, ref):
    path = root / Path(ref["path"]).name
    assert digest(path) == ref["sha256"]
    return torch.load(path, weights_only=True, map_location="cpu")


def make_queries(token_ids, coords):
    group = (coords[:, 1] >= 14).astype(int) * 2 + (coords[:, 2] >= 26)
    probes = []
    for g in range(4):
        pool = sorted(np.flatnonzero(group == g), key=lambda i: hashlib.sha256(
            f"regional-secants-v1|{token_ids[i]}".encode()).digest())
        assert len(pool) > 16
        probes.extend(pool[:16])
    query = np.setdiff1d(np.arange(len(group)), probes)
    edges = []
    for i in query:
        other = query[(coords[query, 0] == coords[i, 0]) & (query != i)]
        if len(other):
            dist = ((coords[other, 1:] - coords[i, 1:]) ** 2).sum(axis=1)
            edges.append((i, other[np.lexsort((token_ids[other], dist))[0]]))
    return group, np.array(probes), query, np.array(edges)


def choose(scores, local, k, mode, group):
    if mode == "global":
        return scores.topk(k).indices
    half = k // 2
    core = scores.topk(half).indices
    owner = group if mode == "regional" else (group + 1) % 4
    mixed = (local[owner] + scores) * 0.5
    mixed[core] = -torch.inf
    return torch.cat((core, mixed.topk(k - half).indices))


def score(pred, truth, gate, query, edges, groups):
    err = (pred - truth) * gate
    ref = truth * gate
    def relative(a, b):
        return (a.norm() / b.norm().clamp_min(1e-15)).item()
    left, right = edges.T
    metrics = {"gated": relative(err[query], ref[query]),
               "p90_row_relative": torch.quantile(err[query].norm(dim=1) /
                       ref[query].norm(dim=1).clamp_min(1e-15), 0.9).item()}
    for name, use in (("edge", np.ones(len(left), dtype=bool)),
                      ("edge_inside", groups[left] == groups[right]),
                      ("edge_cross", groups[left] != groups[right])):
        if use.any():
            i, j = left[use], right[use]
            metrics[name] = relative(err[i] - err[j], ref[i] - ref[j])
            metrics[name + "_count"] = len(i)
    return metrics


def run_case(root, row, weights):
    a, h = panel(root, row["anchor"]), panel(root, row["hit"])
    assert torch.equal(a["token_indices"], h["token_indices"])
    ids = a["token_indices"].numpy()
    coords = a["token_thw"].numpy()
    assert np.array_equal((coords[:, 0]*29+coords[:, 1])*52+coords[:, 2],ids)
    grp, probes, query, edges = make_queries(ids, coords)
    w1, bias1, w2, bias2 = weights
    u0, u1 = (x["U"].cuda().float() for x in (a, h))
    z0, z1 = (F.linear(u, w1, bias1) for u in (u0,u1))
    h0, h1 = (F.gelu(z, approximate="tanh") for z in (z0,z1))
    dh = h1 - h0
    dz = z1 - z0
    de = dh - 0.5*dz
    gate = h["gate"].cuda().float().reshape(-1)
    truth = F.linear(dh, w2)
    direct_native = h["Y_pre_gate"].cuda().float() - a["Y_pre_gate"].cuda().float()
    odd = F.linear(0.5*dz, w2)
    algebra_rel = ((odd + F.linear(de, w2) - truth).norm() / truth.norm()).item()
    assert algebra_rel < 2e-5
    result = {"expert":row["expert"],"source":row["source"],"layer":19,
              "probe_ids":ids[probes].tolist(), "query_count":len(query),
              "reference_gated_gap":score(direct_native, truth, gate,query,edges,grp)["gated"],
              "all_channels_closure":algebra_rel, "arms":{}}
    for family, features, k in (("P", dh, 5120), ("odd", de, 2560)):
        score_global = features[probes].square().mean(0)
        score_group = [features[probes[grp[probes] == g]].square().mean(0) for g in range(4)]
        for mode in ("global","regional","permuted"):
            predicted = torch.zeros_like(truth) if family == "P" else odd.clone()
            for g in range(4):
                rows = np.flatnonzero(grp == g)
                index = choose(score_global, score_group, k, mode, g)
                predicted[rows] += F.linear(features[rows][:,index], w2[:,index])
            result["arms"][family+"_"+mode] = score(predicted, truth, gate,query,edges,grp)
    for key, mask_feat in (("native",dh),("even",de)):
        idx=mask_feat[probes].square().mean(0).topk(2560).indices
        for name, out in (("ordinary",F.linear(dh[:,idx],w2[:,idx])),
                          ("half",odd+F.linear(de[:,idx],w2[:,idx]))):
            result["arms"][name+"_mask_"+key]=score(out,truth,gate,query,edges,grp)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("expert", choices=["high","low"])
    parser.add_argument("--root",type=Path,default=Path("work/native-inputs"))
    parser.add_argument("--out",type=Path,default=Path("work"))
    args=parser.parse_args()
    torch.backends.cuda.matmul.allow_tf32=False
    bindings_path=args.root/"BINDINGS.json"
    assert digest(bindings_path)=="8f7320c61dbafd44df0b1662235405de8961dd5c5d52d846c979fdb4179b1ab6"
    bindings=json.loads(bindings_path.read_text(encoding="utf8"))
    with torch.inference_mode():
        weights=load_weights(args.root,args.expert,bindings["sites"][args.expert+"19"])
        rows=[]
        for row in bindings["pairs"]:
            if (row["source"] in {"vbi_0392","vbi_1013","vbi_0800"} and
                   row["expert"]==args.expert and row["layer"]==19):
                result=run_case(args.root,row,weights)
                rows.append(result)
                print(row["source"],{k:round(v["gated"],5) for k,v in result["arms"].items()},flush=True)
        assert len(rows)==3
        (args.out/("replay_"+args.expert+".json")).write_text(json.dumps(
            {"torch":str(torch.__version__),"device":torch.cuda.get_device_name(),"cases":rows},indent=2))
