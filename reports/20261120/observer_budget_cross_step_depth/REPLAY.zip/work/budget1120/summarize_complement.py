"""Summarize source-level changes in the frozen orthogonal-output direction study."""
import json
from itertools import product
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
ARMS=("diagonal","least_squares","exact_probe_gate")
METRICS=("J","point","edge","gated_angle","gated_signed_scale","gated_amplitude",
         "gated_relative","orthogonal_difference","common_gain","difference_gain","angle")


def summarize(rows,arm):
    out={}
    for metric in METRICS:
        data=[[r[ref][metric] for ref in ("prior","diagonal",arm)] for r in rows]
        base,diag,new=np.array(data).T
        out[metric]=dict(absolute=float(new.mean()),static=float(base.mean()),
                         delta_static=float((new-base).mean()),delta_diagonal=float((new-diag).mean()))
        if metric in ("J","point","edge"):
            out[metric].update(relative_static=float((100*(new/base-1)).mean()),
                               relative_diagonal=float((100*(new/diag-1)).mean()))
    return out


def main():
    output={}
    for dataset in ("complement","confirm"):
        rows=[]
        for e in ("high","low"):
            raw=json.loads((HERE/(dataset+"_"+e+".json")).read_bytes())
            rows.extend(dict(r,expert=e) for r in raw)
        sources=sorted({r["source"] for r in rows})
        budgets=sorted({r["p"] for r in rows})
        assert len(sources)==(3 if dataset=="complement" else 8)
        overall=[]
        sites=[]
        source_stats=[]
        for p,a in product(budgets,ARMS):
            rr=[r for r in rows if r["p"]==p]
            overall.append(dict(p=p,arm=a,**summarize(rr,a)))
            for s in sources:
                subset=[r for r in rr if r["source"]==s]
                source_stats.append(dict(p=p,arm=a,source=s,**summarize(subset,a)))
                for e in ("high","low"):
                    sub=[r for r in subset if r["expert"]==e]
                    assert len(sub)==16
                    sites.append(dict(p=p,arm=a,expert=e,source=s,**summarize(sub,a)))
        output[dataset]=dict(sources=sources,overall=overall,by_source=source_stats,by_expert_source=sites)
    (HERE/"complement_summary.json").write_text(json.dumps(output,separators=(",",":"),allow_nan=False))
    for dataset,out in output.items():
        print(dataset)
        for r in out["overall"]:
            print(r["p"],r["arm"],*[round(r[m][k],5) for m,k in
                  (("J","relative_static"),("J","relative_diagonal"),("gated_angle","absolute"),
                   ("gated_signed_scale","absolute"),("orthogonal_difference","absolute"))])


if __name__=="__main__":
    main()
