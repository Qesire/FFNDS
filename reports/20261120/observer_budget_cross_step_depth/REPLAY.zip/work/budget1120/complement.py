"""One additional direction in the complement of the frozen sixteen output modes."""
import argparse
import json
import numpy as np
import torch
import run_budget as b


def joint_dot(x,y,ed):
    value=(x*y).sum(1).mean()
    if len(ed):
        i,j=ed.T
        value+=((x[j]-x[i])*(y[j]-y[i])).sum(1).mean()
    return value


def run(expert,confirm=False):
    root=b.WORK/"native-inputs"
    rows,m,_=b.setup(root,expert)
    v=m["v"]
    out=[]
    manifest=json.loads((root/"BINDINGS.json").read_bytes())
    sources=[n for n in manifest["dev_sources"] if n not in b.fixed.DEV] if confirm else b.fixed.DEV
    assert len(sources)==(8 if confirm else 3)
    budgets=(32,64) if confirm else (32,64,128)
    for source in sources:
        row=rows[source]
        ids,coords,base,q,y0,truth,observe=b.panel(root,row,m)
        gate=b.fixed.panel(root,row["hit"])["gate"].flatten().float().cuda()
        base_delta=base-y0
        direction=base_delta-(base_delta@v.T)@v
        for fold,(pool,test) in enumerate(b.split_panel(ids)):
            et=b.edge_indices(test,coords,ids)
            c=b.eval_cache(truth[test],et,gate)
            def score(hit):
                return b.metrics(hit.bfloat16().float()-y0[test],c)
            prior=score(base[test]+q[test]@v)
            for kind in b.LAYOUTS:
                for seed in b.SEEDS:
                    order=b.layout(pool,ids,coords,seed,kind)
                    for n in budgets:
                        p=order[:n]
                        ed=b.edge_indices(p,coords,ids)
                        observed=observe(p)
                        half,_=b.online.coefficients(q[p].double(),(observed-base[p]).double()@v.double().T,ed,True)
                        g=(2*half-1).float()
                        pred=base+(q*g)@v
                        u=direction[p].double()
                        res=(observed-pred[p]).double()
                        h=joint_dot(u,res,ed)/joint_dot(u,u,ed)
                        yp=observed-y0[p]
                        dx,dy=((v0[ed[:,1]]-v0[ed[:,0]])*gate for v0 in (yp,pred[p]-y0[p]))
                        du=(u[ed[:,1]]-u[ed[:,0]])*gate
                        # Moment-preserving scale on gated probe edges. Contrast arm only.
                        exact=((dx-dy)*dx).sum()/(du*dx).sum()
                        rec=dict(source=source,fold=fold,layout=kind,seed=seed,p=n,prior=prior,
                                 h=float(h),exact_gated=float(exact),diagonal=score(pred[test]),
                                 least_squares=score(pred[test]+h.float()*direction[test]),
                                 exact_probe_gate=score(pred[test]+exact.float()*direction[test]))
                        assert np.isfinite(rec["h"]) and np.isfinite(rec["exact_gated"])
                        out.append(rec)
        print(expert,source,len(out),flush=True)
    return out


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("expert",choices=("high","low"))
    p.add_argument("--confirm",action="store_true")
    args=p.parse_args()
    torch.backends.cuda.matmul.allow_tf32=False
    torch.set_num_threads(4)
    with torch.inference_mode():
        out=run(args.expert,args.confirm)
    prefix="confirm_" if args.confirm else "complement_"
    (b.HERE/(prefix+args.expert+".json")).write_text(json.dumps(out,separators=(",",":"),allow_nan=False))
