"""Equal-weight held-out source comparisons for the observer-budget experiment."""
import json
from itertools import product
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
ARMS = ("half", "support_scaled", "full_trust")
METRICS = ("J", "point", "edge", "angle", "signed_edge_scale", "common_gain",
           "difference_gain", "common_difference_error", "orthogonal_difference",
           "gated_angle", "gated_signed_scale", "gated_relative", "gated_amplitude")
RELATIVE = ("J", "point", "edge")


def change(after, before, name):
    return 100 * (after[name] / before[name] - 1) if name in RELATIVE else after[name] - before[name]


def average(rows, keys):
    return {k: float(np.mean([r[k] for r in rows])) for k in keys}


def main():
    records=[]
    ceilings=[]
    draws=[]
    for expert in ("high","low"):
        x=json.loads((HERE/(expert+".json")).read_bytes())
        folds={(f["source"],f["fold"]):f for f in x["folds"]}
        assert len(x["results"])==3*2*4*2*7
        pools={(r["source"],r["fold"]):np.array(r["half_gain"]) for r in x["results"] if r["p"]==256}
        for s,f in sorted(folds):
            baseline=folds[s,f]["prior"]
            oracle=folds[s,f]["query_fitted"]
            ceilings.append(dict(expert=expert,source=s,fold=f,
                                 **{m:change(oracle,baseline,m) for m in METRICS}))
        for r in x["results"]:
            s,f=r["source"],r["fold"]
            prior=folds[s,f]["prior"]
            meta={k:r[k] for k in ("layout","seed","p","source","fold")}
            reference=pools[s,f]-1
            direction=np.array(r["half_gain"])-1
            draws.append(dict(**meta,expert=expert,exposure_min=r["support_min"],
                              min_ess=r["support_ess_min"],median_ess=r["support_ess_median"],
                              gain_rmse=r["half_gain_rms_to_pool256"],edges=r["edges"],frames=r["frames"],
                              wrong_update_fraction=float((reference*direction<0).mean())))
            for a in ARMS:
                after=r[a]
                records.append(dict(**meta,expert=expert,arm=a,delta_raw=after["J"]-prior["J"],
                                    prior_J=prior["J"],**{m:change(after,prior,m) for m in METRICS}))
    budgets=x["budgets"][1:]
    overall=[]
    by_layout=[]
    by_site=[]
    for a,p in product(ARMS,budgets):
        rows=[r for r in records if r["arm"]==a and r["p"]==p]
        sources=[]
        for s,e in product(x["dev"],("high","low")):
            group=[r for r in rows if r["source"]==s and r["expert"]==e]
            site=dict(arm=a,p=p,expert=e,source=s,**average(group,METRICS))
            by_site.append(site)
            sources.append(site)
        overall.append(dict(arm=a,p=p,**average(rows,METRICS),
                            site_min_J=min(r["J"] for r in sources),site_max_J=max(r["J"] for r in sources),
                            site_J_improved=sum(r["J"]<0 for r in sources),
                            draws_J_worse=sum(r["J"]>0 for r in rows),nominal_draws=len(rows)))
        for g in x["layouts"]:
            group=[r for r in rows if r["layout"]==g]
            by_layout.append(dict(arm=a,p=p,layout=g,**average(group,METRICS)))
    design=[]
    for g,p in product(x["layouts"],budgets):
        group=[r for r in draws if r["layout"]==g and r["p"]==p]
        design.append(dict(p=p,layout=g,**average(group,("edges","frames","min_ess","median_ess",
                                                       "gain_rmse","wrong_update_fraction")),
                           minimum_observed_exposure=min(r["exposure_min"] for r in group)))
    allocations=[]
    for a in ARMS:
        for ph,pl in ((32,96),(64,64),(96,32)):
            pair=[r for r in records if r["arm"]==a and r["p"]==(ph if r["expert"]=="high" else pl)]
            # Equal unit weight for percentage change. Also show pooled scale-sensitive raw energies.
            allocations.append(dict(arm=a,p_high=ph,p_low=pl,**average(pair,METRICS),
                                    pooled_delta_J_percent=100*sum(r["delta_raw"] for r in pair)/
                                                              sum(r["prior_J"] for r in pair),
                                    by_source={s:average([r for r in pair if r["source"]==s],METRICS)
                                               for s in x["dev"]}))
    out=dict(metric_units="Relative percentage for J, point, edge. Absolute changes in all other metrics.",
             weights="Uniform across sources, sites, crossed folds, layouts and seeds. No nominal sample count inferred.",
             overall=overall,by_layout=by_layout,by_site=by_site,design=design,
             query_label_fit=ceilings,equal_budget_allocation=allocations)
    (HERE/"summary.json").write_text(json.dumps(out,indent=1,allow_nan=False), encoding="utf8")
    for row in overall:
        print(row["arm"],row["p"],*[round(row[k],5) for k in ("J","angle","gated_angle","gated_signed_scale","orthogonal_difference")])


if __name__=="__main__":
    main()
