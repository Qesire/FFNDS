"""Observe 64 complete native FFN rows; adjust 16 orthogonal output-mode amplitudes."""
import argparse
import json
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
import run as fixed


def probe_edges(p, coords, ids):
    result = []
    for i in p:
        candidates = p[(p != i) & (coords[p,0] == coords[i,0])]
        if len(candidates):
            distance = ((coords[candidates,1:] - coords[i,1:])**2).sum(1)
            j = candidates[np.lexsort((ids[candidates],distance))[0]]
            result.append((min(i,j),max(i,j)))
    if not result:
        return np.empty((0,2),dtype=np.int64)
    return np.unique(np.asarray(result),axis=0)


def coefficients(q, target_proj, edges, use_edges):
    den = q.square().mean(0)
    num = (q*target_proj).mean(0)
    if use_edges and len(edges):
        i,j=edges.T
        d=q[j]-q[i]
        den += d.square().mean(0)
        num += (d*(target_proj[j]-target_proj[i])).mean(0)
    # Explicit prior 1 and prior precision equal to observed support per direction.
    return torch.where(den>0,(num+den)/(2*den).clamp_min(1e-30),torch.ones_like(den)),den


def run(root,expert):
    path=root/"BINDINGS.json"
    assert fixed.digest(path)=="8f7320c61dbafd44df0b1662235405de8961dd5c5d52d846c979fdb4179b1ab6"
    manifest=json.loads(path.read_text())
    rows={r["source"]:r for r in manifest["pairs"] if r["expert"]==expert and r["layer"]==19}
    ws=fixed.load_weights(root,expert,manifest["sites"][expert+"19"])
    w1,b1,w2,b2=ws
    num=torch.zeros(len(w1),device="cuda",dtype=torch.float64);den=torch.zeros_like(num)
    for name in fixed.CAL:
        dz,dh,_,_=fixed.operands(root,rows[name],ws)
        num+=(dh.double()*dz).mean(0);den+=dz.double().square().mean(0)
    beta=(num/den.clamp_min(1e-30)).float()
    receipt=json.loads((fixed.WORK/"compiled"/(expert+".json")).read_text())
    sel=torch.tensor(receipt["selected_ids"],device="cuda")
    assert fixed.thash(sel)==receipt["selected_sha256"] and fixed.thash(beta)==receipt["beta_sha256"]
    cal=[fixed.data(root,rows[name],ws,beta,sel) for name in fixed.CAL]
    scale=torch.stack([p["z"][p["q"]].square().mean(0) for p in cal]).mean(0).sqrt().clamp_min(1e-8)
    left,right,stats=fixed.fit(cal,scale,gamma=1)
    del cal
    sigma=right.norm(dim=1)
    v=right/sigma[:,None]
    eye=torch.eye(fixed.RANK,device="cuda")
    defect=(v@v.T-eye).abs().max().item()
    assert defect<5e-5,defect
    # Q=(dH_K L-dU J); right singular vectors have unit norm.
    zmap=left*sigma
    jmap=(w1[sel].T*beta[sel])@zmap
    omitted=beta.clone();omitted[sel]=0
    A0=((w1.T*omitted)@w2.T).bfloat16()
    b=w2[:,sel].T.contiguous()
    W1,B1,W2,B2=[p.bfloat16() for p in ws]
    hfun=lambda u,w,bias:F.gelu(F.linear(u,w,bias),approximate="tanh")
    report=dict(expert=expert,cal=list(fixed.CAL),dev=list(fixed.DEV),rank=fixed.RANK,ridge_scale_vs_support=1,
                fit=stats,right_orthogonality_max_abs=defect,selection_sha256=receipt["selected_sha256"],
                mixed_policy="Archived BF16 Y0; BF16 dense anchor H0_K; BF16 narrow hit H1_K; rounded BF16 delta_H, BF16 dU@A0; FP32 selected-output GEMM and Q projections; final BF16 add. Probe-only full BF16 W1/GELU/W2; DEV teacher full-M BF16 only used for held-out metrics.",
                cases={})
    for name in fixed.DEV:
        a,h=[fixed.panel(root,rows[name][k]) for k in ("anchor","hit")]
        assert all(torch.equal(a[k],h[k]) for k in ("token_indices","token_thw"))
        coords=h["token_thw"].numpy();ids=h["token_indices"].numpy()
        _,p,qq,edge0=fixed.make_queries(ids,coords)
        pe=probe_edges(p,coords,ids)
        order={row:k for k,row in enumerate(p)}
        ed=np.asarray([[order[i],order[j]] for i,j in pe],dtype=np.int64).reshape(-1,2)
        assert len(p)==64 and len(qq)==448 and not (set(p)&set(qq)) and set(pe.ravel())<=set(p)
        unique=np.unique(np.sort(edge0,axis=1),axis=0)
        i,j=unique.T.copy()
        dy,dx=(coords[j,1:]-coords[i,1:]).T
        flip=np.where(abs(dx)>=abs(dy),dx,dy)<0
        i[flip],j[flip]=j[flip],i[flip].copy()
        u0,u1=[p0["U"].cuda() for p0 in (a,h)]
        y0=a["Y_pre_gate"].cuda()
        h0=hfun(u0,W1,B1)[:,sel]
        hk=hfun(u1,W1[sel],B1[sel])
        dh=(hk.float()-h0.float()).bfloat16().float()
        du=u1.float()-u0.float()
        base=y0.float()+(du.bfloat16()@A0).float()+dh@b
        Q=dh@zmap-du@jmap
        split=base+Q@v
        obs=F.linear(hfun(u1[p],W1,B1),W2,B2).float()
        P=Q[p].double()
        projected=(obs-base[p]).double()@v.double().T
        gains={"prior":torch.ones(fixed.RANK,device="cuda",dtype=torch.float64)}
        flags={}
        for arm,use_edges in (("online_point",False),("online_joint",True)):
            g,support=coefficients(P,projected,ed,use_edges)
            gains[arm]=g
            flags[arm]={"g":g.tolist(),"support":support.tolist(),
                        "positive_count":(g>0).sum().item(),"max_gain_shift":(g-1).abs().max().item()}
            # Explicit Kronecker dictionary normal equations (16x16) agree with componentwise update.
            ps=P.T@P/len(p)
            if use_edges and len(ed):
                dp=P[ed[:,1]]-P[ed[:,0]]
                ps+=dp.T@dp/len(ed)
            gram=ps*(v.double()@v.double().T)
            rhs=(projected*P).mean(0)
            if use_edges and len(ed):
                rhs+=(dp*(projected[ed[:,1]]-projected[ed[:,0]])).mean(0)
            direct=torch.linalg.solve(gram+torch.diag(support),rhs+support)
            flags[arm]["gram_gain_defect"]=(g-direct).abs().max().item()
            assert flags[arm]["gram_gain_defect"]<5e-5
            if use_edges:
                # Modes lacking probe support retain their prior rows exactly.
                active=support>1e-18
                T=torch.eye(fixed.RANK,device="cuda",dtype=torch.float64)
                QTY=P.T@projected/len(p)
                if len(ed):
                    QTY+=dp.T@(projected[ed[:,1]]-projected[ed[:,0]])/len(ed)
                J=torch.diag(support)
                T[active]=torch.linalg.solve((ps+J)[active][:,active],
                                             (QTY+J)[active]-ps[active][:,~active]@T[~active])
                gains["online_joint_full16"]=T
                flags["online_joint_full16"]={"T":T.tolist(),
                    "off_diagonal_frobenius":float((T-torch.diag(T.diagonal())).norm())}
        truth=h["Y_pre_gate"].cuda().float()-y0.float()
        out={}
        for arm,g in gains.items():
            modal=Q*g.float() if g.ndim==1 else Q@g.float()
            pred=(base+modal@v).bfloat16().float()-y0.float()
            out[arm]=fixed.metrics(pred,truth,qq,i,j)
        assert torch.equal(split.bfloat16().float()-y0.float(),(base+(Q*gains["prior"].float())@v).bfloat16().float()-y0.float())
        report["cases"][name]=dict(probes=ids[p].tolist(),query_count=len(qq),query_edges=len(i),
                probe_edges=len(ed),probe_frames=np.unique(coords[p,0]).tolist(),gains=flags,metrics=out)
        print(expert,name,len(pe),[round(val["objective"],4) for val in out.values()], flush=True)
    return report


if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("expert",choices=("high","low")); args=parser.parse_args()
    torch.backends.cuda.matmul.allow_tf32=False
    torch.set_num_threads(4)
    with torch.inference_mode():
        result=run(fixed.WORK/"native-inputs",args.expert)
    (Path(__file__).parent/("online_"+args.expert+".json")).write_text(json.dumps(result,indent=2,allow_nan=False))
