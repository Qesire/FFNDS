"""Exploratory frozen calibration and output-weighted routing on three real input pairs."""
import argparse
import json
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from native_replay import digest, load_weights, make_queries, panel, score


def operands(root,row,weights):
    a,h=(panel(root,row[key]) for key in ("anchor","hit"))
    assert torch.equal(a["token_indices"],h["token_indices"])
    w1,b1,_,_=weights
    z0,z1=(F.linear(x["U"].cuda().float(),w1,b1) for x in (a,h))
    dh=F.gelu(z1,approximate="tanh")-F.gelu(z0,approximate="tanh")
    return z1-z0,dh,h["gate"].reshape(-1).cuda().float(),h


def output_energy(w2,gate):
    return (w2.square().T @ gate.square()).clamp_min(0)


def masked(e,w2,scores,local,groups,kind):
    n=2560
    if kind in ("fixed","global"):
        idx=scores.topk(n).indices
        return F.linear(e[:,idx],w2[:,idx])
    out=e.new_empty((len(e),w2.shape[0]))
    core=scores.topk(n//2).indices
    for g in range(4):
        local_group=g if kind=="regional" else (g+1)%4
        mix=0.5*(local[local_group]+scores)
        mix[core]=-torch.inf
        index=torch.cat((core,mix.topk(n//2).indices))
        i=np.flatnonzero(groups==g)
        out[i]=F.linear(e[i][:,index],w2[:,index])
    return out


def run(root,expert):
    path=root/"BINDINGS.json"
    assert digest(path)=="8f7320c61dbafd44df0b1662235405de8961dd5c5d52d846c979fdb4179b1ab6"
    bind=json.loads(path.read_text())
    weights=load_weights(root,expert,bind["sites"][expert+"19"])
    w1,_,w2,_=weights
    cases=[r for r in bind["pairs"] if r["expert"]==expert and r["layer"]==19]
    cal=[r for r in cases if r["source"] in ("vbi_0032","vbi_0304","vbi_0456")]
    dev=[r for r in cases if r["source"] in ("vbi_0392","vbi_1013","vbi_0800")]
    assert len(cal)==len(dev)==3
    numerator=torch.zeros(w1.shape[0],device="cuda",dtype=torch.float64)
    energy=torch.zeros_like(numerator)
    for row in cal:
        dz,dh,_,_=operands(root,row,weights)
        numerator+=(dh.double()*dz).mean(0)
        energy+=dz.double().square().mean(0)
    beta=torch.where(energy>0,numerator/energy.clamp_min(1e-30),0).float()
    static=torch.zeros_like(beta)
    for row in cal:
        dz,dh,gate,_=operands(root,row,weights)
        static+=(dh-dz*beta).square().mean(0)*output_energy(w2,gate)
    results=[]
    for row in dev:
        dz,dh,gate,h=operands(root,row,weights)
        c,p,q,edges=make_queries(h["token_indices"].numpy(),h["token_thw"].numpy())
        e=dh-dz*beta
        base=F.linear(dz*beta,w2)
        target=F.linear(dh,w2)
        out_norm=output_energy(w2,gate)
        scores=e[p].square().mean(0)*out_norm
        local=[e[p[c[p]==g]].square().mean(0)*out_norm for g in range(4)]
        assert ((base+F.linear(e,w2)-target).norm()/target.norm()).item()<2e-5
        arms={"slope_only":score(base,target,gate,q,edges,c)}
        for mode in ("fixed","global","regional","permuted"):
            out=base+masked(e,w2,static if mode=="fixed" else scores,local,c,mode)
            arms[mode]=score(out,target,gate,q,edges,c)
        for s in (0.,0.5):
            fixed=F.linear(dz*s,w2)+masked(dh-dz*s,w2,scores,local,c,"global")
            arms["same_mask_slope_"+str(s)]=score(fixed,target,gate,q,edges,c)
        # Match the hidden-unit scoring metric on P64, controlling the output-axis weighting.
        pscore=dh[p].square().mean(0)*out_norm
        ix=pscore.topk(5120).indices
        arms["P_global_gate_weighted"]=score(F.linear(dh[:,ix],w2[:,ix]),target,gate,q,edges,c)
        results.append({"expert":expert,"source":row["source"],"arms":arms})
        print(row["source"],{k:round(v["gated"],5) for k,v in arms.items()},flush=True)
    return {"cal":[r["source"] for r in cal],"beta_quantiles":torch.quantile(
        beta,torch.tensor([0.,.1,.5,.9,1.],device="cuda")).tolist(),"cases":results}


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("expert",choices=["high","low"])
    parser.add_argument("--root",type=Path,default=Path("work/native-inputs"))
    parser.add_argument("--out",type=Path,default=Path("work"))
    args=parser.parse_args()
    torch.backends.cuda.matmul.allow_tf32=False
    with torch.inference_mode():
        data=run(args.root,args.expert)
    (args.out/("slopes_"+args.expert+".json")).write_text(json.dumps(data,indent=2))
