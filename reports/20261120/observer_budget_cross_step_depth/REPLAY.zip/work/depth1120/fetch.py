"""Fetch the 24 pinned layer-04 bank endpoints using an existing PuTTY session."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
CAL_DEV = ("vbi_0032", "vbi_0304", "vbi_0456", "vbi_0392", "vbi_0800", "vbi_1013")
BINDINGS_SHA = "8f7320c61dbafd44df0b1662235405de8961dd5c5d52d846c979fdb4179b1ab6"


def fetch(session, executable):
    manifest = HERE.parent / "native-inputs" / "BINDINGS.json"
    assert hashlib.sha256(manifest.read_bytes()).hexdigest() == BINDINGS_SHA
    data = json.loads(manifest.read_text())
    bank = PurePosixPath(data["bank_root"])
    out = HERE / "bank"
    out.mkdir(exist_ok=True)
    missing = {}
    for pair in data["pairs"]:
        if pair["layer"] != 4 or pair["source"] not in CAL_DEV:
            continue
        for ref in (pair["anchor"], pair["hit"]):
            remote = PurePosixPath(ref["path"])
            local = out / remote.name
            if not (local.exists() and hashlib.sha256(local.read_bytes()).hexdigest() == ref["sha256"]):
                missing[str(remote.relative_to(bank))] = ref
    if not missing:
        return
    import shlex
    cmd = shlex.join(["tar", "-C", str(bank), "-cf", "-", *missing])
    proc = subprocess.Popen([executable, "-batch", "-T", "-load", session, cmd], stdout=subprocess.PIPE)
    with proc.stdout, tarfile.open(fileobj=proc.stdout, mode="r|") as stream:
        for member in stream:
            ref = missing.pop(member.name)
            assert member.isfile() and member.size == ref["bytes"]
            payload = stream.extractfile(member).read()
            assert hashlib.sha256(payload).hexdigest() == ref["sha256"]
            (out / Path(member.name).name).write_bytes(payload)
            print(member.name, flush=True)
    assert proc.wait() == 0 and not missing


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--session", required=True)
    parser.add_argument("--plink", default=r"C:\Program Files\PuTTY\plink.exe")
    args = parser.parse_args()
    fetch(args.session, args.plink)
