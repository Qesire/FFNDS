"""Cross-fit the proposed decoder over budget, graph, seed and layout."""
import argparse
import json
from pathlib import Path

import numpy as np
import torch

from orthogonal import depth, fixed, rb

HERE = Path(__file__).resolve().parent


def run(expert):
    root=depth.WORK/"native-inputs"
    rows,mats,cfg=rb.setup(root,expert)
    v=mats["v"]
    out=dict(expert=expert,base=cfg,cal=fixed.CAL,dev=fixed.DEV,seeds=[1120,3041],
             layouts=["uniform","near_pair"],budgets=[16,32,64,128,256],cases={})
    for src in fixed.DEV:
        ids,coords,base,qfeat,y0,truth,observe=rb.panel(root,rows[src],mats)
        up=[fixed.panel(root,rows[src][k])["U"].float() for k in ("anchor","hit")]
        du=up[1]-up[0]
        prior=base+qfeat@v
        records=[]
        for fold,(pool,test) in enumerate(rb.split_panel(ids)):
            ed=rb.edge_indices(test,coords,ids)
            state=rb.eval_cache(truth[test],ed)
            def score(x):
                met=rb.metrics(x[test].bfloat16().float()-y0[test],state)
                return {k:met[k] for k in ("J","point","edge","angle","signed_edge_scale","orthogonal_difference",
                                             "common_gain","difference_gain","common_difference_error")}
            for seed in out["seeds"]:
                for layout in out["layouts"]:
                    order=rb.layout(pool,ids,coords,seed,layout)
                    for n in out["budgets"]:
                        if n==256 and (seed!=1120 or layout!="uniform"):
                            continue
                        p=order[:n]
                        obs=observe(p)
                        rp=obs-prior[p]
                        projected=(obs-base[p]).double()@v.double().T
                        g,_=rb.online.coefficients(qfeat[p].double(),projected,rb.edge_indices(p,coords,ids),True)
                        modal=base+(qfeat*g.float())@v
                        corr,a=depth.calibrated(du,p,rp.cpu(),coords,ids)
                        records.append(dict(fold=fold,seed=seed,layout=layout,n=n,alpha=a[0],
                                modal=score(modal),overlap=score(modal+corr.cuda())))
        out["cases"][src]=records
        print(expert,src,len(records),flush=True)
    return out


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("expert",choices=("high","low"))
    args=parser.parse_args()
    torch.backends.cuda.matmul.allow_tf32=False
    torch.set_num_threads(4)
    with torch.inference_mode():
        out=run(args.expert)
    (HERE/("orthogonal_budget_"+args.expert+".json")).write_text(json.dumps(out,indent=1,allow_nan=False))
