"""Equal-weight source comparisons of two decoders given identical native rows."""
import json
from pathlib import Path
from statistics import mean

HERE=Path(__file__).resolve().parent
out={"groups":[],"overall":[]}
for expert in ("high","low"):
    data=json.loads((HERE/("orthogonal_budget_"+expert+".json")).read_bytes())
    for source,records in data["cases"].items():
        for n in data["budgets"]:
            cells=[r for r in records if r["n"]==n]
            # Within-fold, same ordered probe sequence. The full pool is fixed once per fold.
            if n==256:
                vs64=[(a,b) for a in cells for b in records if b["n"]==64 and a["fold"]==b["fold"]]
            else:
                vs64=[(a,b) for a in cells for b in records if b["n"]==64 and
                      (a["fold"],a["seed"],a["layout"])==(b["fold"],b["seed"],b["layout"])]
            out["groups"].append(dict(expert=expert,source=source,n=n,cells=len(cells),
                paired_new64_J=mean(100*(a["overlap"]["J"]/b["overlap"]["J"]-1) for a,b in vs64),
                worse=sum(r["overlap"]["J"]>r["modal"]["J"] for r in cells),
                **{k:mean(100*(r["overlap"][k]/r["modal"][k]-1) for r in cells)
                   for k in ("J","point","edge")},
                **{k:mean(r["overlap"][k]-r["modal"][k] for r in cells)
                   for k in ("angle","signed_edge_scale","orthogonal_difference","common_gain","difference_gain")}))
for n in (16,32,64,128,256):
    groups=[r for r in out["groups"] if r["n"]==n]
    out["overall"].append(dict(n=n,worse_groups=sum(r["J"]>0 for r in groups),
        worse_cells=sum(r["worse"] for r in groups),cells=sum(r["cells"] for r in groups),
        **{k:mean(r[k] for r in groups) for k in ("J","paired_new64_J","point","edge","angle","signed_edge_scale",
                                                    "orthogonal_difference","common_gain","difference_gain")}))
    print(n,[(r["source"],r["expert"],round(r["J"],3)) for r in groups],out["overall"][-1])
(HERE/"orthogonal_budget_summary.json").write_text(json.dumps(out,indent=1,allow_nan=False))
