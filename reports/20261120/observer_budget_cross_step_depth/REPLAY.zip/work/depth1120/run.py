"""Teacher-forced cross-depth residual transport, 04 -> 19, within a Wan expert."""
import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
sys.path.insert(0, str(WORK / "budget1120"))
import run_budget as rb

fixed = rb.fixed
RIDGE = 0.25


def graph(indices, coords, ids):
    # Orient each same-frame undirected nearest edge by its dominant spatial axis.
    edges = rb.edge_indices(indices, coords, ids)
    return indices[edges[:, 0]], indices[edges[:, 1]]


def read_pair(manifest, root, rows, mats, expert, source):
    ids, coords, base, qfeat, y0, truth, _ = rb.panel(root, rows[source], mats)
    yhat = (base + qfeat @ mats["v"]).bfloat16().float()
    p19 = [fixed.panel(root, rows[source][key]) for key in ("anchor", "hit")]
    r04, = [r for r in manifest["pairs"] if r["layer"] == 4 and r["expert"] == expert and r["source"] == source]
    p04 = [fixed.panel(HERE / "bank", r04[key]) for key in ("anchor", "hit")]
    for ix, key in enumerate(("anchor", "hit")):
        tag = rows[source][key]
        assert r04[key]["timestep"] == tag["timestep"] and r04[key]["step"] == tag["step"]
        assert r04[key]["token_sha256"] == tag["token_sha256"]
        for k in ("token_indices", "token_thw"):
            assert torch.equal(p19[ix][k], p04[ix][k]) and torch.equal(p04[ix][k], p04[0][k])
    assert np.array_equal(ids, (coords[:, 0]*29+coords[:, 1])*52+coords[:, 2])
    def delta(panels, key):
        return panels[1][key].float()-panels[0][key].float()
    _, p, test, _ = fixed.make_queries(ids, coords)
    i, j = graph(test, coords, ids)
    return dict(ids=ids, coords=coords, p=p, test=test, i=i, j=j, yhat=yhat.cpu(), y0=y0.cpu(),
                truth=truth.cpu(), residual=(truth+y0-yhat).cpu(), early_y=delta(p04, "Y_pre_gate"),
                early_u=delta(p04, "U"), current_u=delta(p19, "U"),
                hashes={f"b{layer}_{key}": r[key]["sha256"] for layer,r in [(4,r04),(19,rows[source])]
                        for key in ("anchor","hit")}, token_sha256=r04["hit"]["token_sha256"])


def augment(z, item):
    test, i, j = (item[k] for k in ("test", "i", "j"))
    return torch.cat([z[test], (z[j]-z[i])*(len(test)/len(i))**0.5])


def transfer(cal, name):
    # min_W sum ||X W-R||^2_point + ||D(X W-R)||^2_edge + lambda ||W||^2.
    # Scale CAL features so a typical point has unit diagonal in the dual Gram.
    norm2 = torch.stack([item[name][item["test"]].square().sum(1).mean() for item in cal]).mean()
    x = torch.cat([augment(item[name], item) for item in cal]).cuda() / norm2.sqrt()
    y = torch.cat([augment(item["residual"], item) for item in cal]).cuda()
    gram = x @ x.T
    gram.diagonal().add_(RIDGE)
    chol = torch.linalg.cholesky(gram)
    dual = torch.cholesky_solve(y, chol)
    rel = float((gram @ dual-y).norm()/y.norm())
    assert rel < 1e-3
    def predict(z):
        return ((z.cuda()/norm2.sqrt() @ x.T) @ dual).cpu()
    return predict, dict(ridge=RIDGE, cal_feature_norm2=float(norm2), normal_eq_relative=rel,
                         augmented_rows=len(x))


def spread(u, p, obs):
    # Current-layer input-delta linear kernel, normalized on available input rows.
    # The same current-layer kernel and ridge are used by every arm.
    x = u.cuda() / u.square().sum(1).mean().sqrt()
    pp = x[p]
    gram = pp @ pp.T
    gram.diagonal().add_(RIDGE)
    return (((x @ pp.T) @ torch.cholesky_solve(obs.cuda(), torch.linalg.cholesky(gram)))).cpu()


def calibrated(u, p, labels, coords, ids, early=None):
    """Fit correction amplitudes from actual current probes with analytic leave-one-out."""
    x = u.cuda()/u.square().sum(1).mean().sqrt()
    xp = x[p]
    gram = xp@xp.T
    gram.diagonal().add_(RIDGE)
    inv = torch.cholesky_inverse(torch.linalg.cholesky(gram))
    k = (x@xp.T) @ inv
    def loo(v):
        return v-(inv@v)/inv.diagonal()[:,None]
    labels=labels.cuda()
    observed=[loo(labels)]
    candidates=[k@labels]
    if early is not None:
        f = early.cuda()
        observed.append(f[p]-loo(f[p]))
        candidates.append(f-k@f[p])
    edges = rb.edge_indices(p, coords, ids)
    def aug(v):
        if not len(edges):
            return v.reshape(-1).double()
        i,j=edges.T
        return torch.cat((v, (v[j]-v[i])*(len(p)/len(i))**0.5)).flatten().double()
    basis=torch.stack([aug(v) for v in observed])
    gram=basis@basis.T
    rhs=basis@aug(labels)
    gram.diagonal().mul_(1+RIDGE)
    weights=torch.linalg.solve(gram,rhs)
    return sum(w.float()*b for w,b in zip(weights,candidates)).cpu(), weights.tolist()


def run(expert):
    root = WORK / "native-inputs"
    manifest = json.loads((root/"BINDINGS.json").read_bytes())
    rows, mats, cfg = rb.setup(root, expert)
    packs = {src: read_pair(manifest, root, rows, mats, expert, src) for src in (*fixed.CAL,*fixed.DEV)}
    del mats
    assert set(fixed.CAL).isdisjoint(fixed.DEV)
    tr, checks = {}, {}
    for name in ("early_y", "early_u", "current_u"):
        tr[name], checks[name] = transfer([packs[s] for s in fixed.CAL], name)
    out = dict(expert=expert, cal=fixed.CAL, dev=fixed.DEV, step_pair=[0,1] if expert=="high" else [2,3],
               transfer_layer=[4,19], base=cfg, transfer_checks=checks, kernel_ridge=RIDGE, cases={},
               provenance={s:dict(token_sha256=z["token_sha256"],**z["hashes"]) for s,z in packs.items()})
    for src in fixed.DEV:
        z = packs[src]
        p, test, i, j = (z[k] for k in ("p","test","i","j"))
        assert not set(p).intersection(test) and set(i).union(j) <= set(test)
        u, true = z["current_u"], z["residual"]
        static = torch.zeros_like(true)
        corrections = dict(prior=static, current64=spread(u,p,true[p]))
        weights = {}
        corrections["current64_cal"],weights["current64_cal"] = calibrated(u,p,true[p],z["coords"],z["ids"])
        pseudo = {k: model(z[k][p]) for k,model in tr.items()}
        for name,labels in pseudo.items():
            corrections[name+"64"] = spread(u,p,labels)
        # Null control: cyclically misassign measured values within each spatial quadrant.
        perm = np.roll(np.arange(64).reshape(4,16), 8, axis=1).ravel()
        corrections["early_y64_shuffle"] = spread(u,p,pseudo["early_y"][perm])
        for fold in range(2):
            ix = np.arange(64).reshape(4,16)[:,fold*8:(fold+1)*8].ravel()
            complement = np.setdiff1d(np.arange(64),ix)
            corrections[f"current32_f{fold}"] = spread(u,p[ix],true[p[ix]])
            pc, pe = p[ix], p[complement]
            key = f"current32_cal_f{fold}"
            corrections[key],weights[key] = calibrated(u,pc,true[pc],z["coords"],z["ids"])
            for variant in ("early_y","early_u","early_y_shuffle"):
                labels = torch.empty_like(true[p])
                labels[ix] = true[p[ix]]
                if variant.endswith("_shuffle"):
                    shuff = np.roll(complement.reshape(4,8),4,axis=1).ravel()
                    labels[complement] = pseudo["early_y"][shuff]
                else:
                    labels[complement] = pseudo[variant][complement]
                corrections[f"mixed_{variant}_f{fold}"] = spread(u,p,labels)
                early = spread(u,pe,labels[complement])
                key = f"mixed_{variant}_cal_f{fold}"
                corrections[key],weights[key] = calibrated(u,pc,true[pc],z["coords"],z["ids"],early)
        # Full early input/output is an information-ceiling comparison (512 rows).
        corrections["all512_early_y_direct"] = tr["early_y"](z["early_y"])
        corrections["all512_early_u_direct"] = tr["early_u"](z["early_u"])
        corrections["all512_current_u_direct"] = tr["current_u"](z["current_u"])
        def score(correction):
            pred = (z["yhat"]+correction).bfloat16().float()-z["y0"]
            return fixed.metrics(pred.cuda(),z["truth"].cuda(),test,i,j)
        metrics = {name: score(c) for name,c in corrections.items()}
        def projected_alignment(labels):
            r=true[p].double()
            y=labels.double()
            return dict(cos=float((r*y).sum()/(r.norm()*y.norm())),
                        signed_gain=float((r*y).sum()/r.square().sum()),
                        relative=float((r-y).norm()/r.norm()))
        out["cases"][src]=dict(query=len(test),edges=len(i),probe_ids=z["ids"][p].tolist(),
            metrics=metrics,probe_only_loo_gains=weights,
            pseudo_label_check={k:projected_alignment(v) for k,v in pseudo.items()})
        print(expert,src,{k:round(v["objective"],6) for k,v in metrics.items()},flush=True)
    return out


if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("expert",choices=("high","low"))
    args=parser.parse_args()
    torch.backends.cuda.matmul.allow_tf32=False
    torch.set_num_threads(4)
    with torch.inference_mode():
        result=run(args.expert)
    (HERE/(args.expert+".json")).write_text(json.dumps(result,ensure_ascii=False,indent=1,allow_nan=False))
