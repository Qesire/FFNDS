"""Combine online modal gains with kernel reconstruction in the orthogonal complement."""
import argparse
import json
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
spec=spec_from_file_location("depth_experiment",HERE/"run.py")
depth=module_from_spec(spec)
spec.loader.exec_module(depth)
rb, fixed = depth.rb, depth.fixed


def run(expert):
    root=depth.WORK/"native-inputs"
    rows,mats,cfg = rb.setup(root,expert)
    v=mats["v"]
    out=dict(expert=expert,cal=fixed.CAL,dev=fixed.DEV,base=cfg,cases={})
    def perp(x):
        return x-(x@v.T)@v
    for src in fixed.DEV:
        ids,coords,base,qfeat,y0,truth,observe=rb.panel(root,rows[src],mats)
        _,p,test,_=fixed.make_queries(ids,coords)
        i,j=depth.graph(test,coords,ids)
        ed=rb.edge_indices(p,coords,ids)
        up=[fixed.panel(root,rows[src][key])["U"].float() for key in ("anchor","hit")]
        du=up[1]-up[0]
        # Both decoders consume exactly the same freshly computed 64 full-FFN outputs.
        obs=observe(p)
        projected=(obs-base[p]).double()@v.double().T
        g,_=rb.online.coefficients(qfeat[p].double(),projected,ed,True)
        prior=base+qfeat@v
        modal=base+(qfeat*g.float())@v
        rp=obs-prior[p]
        cp,alpha=depth.calibrated(du,p,perp(rp).cpu(),coords,ids)
        cp=cp.cuda()
        full,af=depth.calibrated(du,p,rp.cpu(),coords,ids)
        full=full.cuda()
        leak=float((cp@v.T).norm()/cp.norm())
        md=modal-prior
        def jointdot(a,b):
            return (a[test]*b[test]).sum()/len(test)+((a[j]-a[i])*(b[j]-b[i])).sum()/len(i)
        dot=jointdot(md.double(),cp.double())
        cos=float(dot/(jointdot(md.double(),md.double())*jointdot(cp.double(),cp.double())).sqrt())
        assert leak<1e-4 and abs(cos)<1e-4
        def score(x):
            return fixed.metrics(x.bfloat16().float()-y0,truth,test,i,j)
        metrics={arm:score(pred) for arm,pred in (
            ("prior",prior),("online_joint16",modal),("perp_only",prior+cp),
            ("online_joint16_perp",modal+cp),("current_kernel",prior+full),("overlap_sum",modal+full))}
        # Numeric check of additivity before final BF16 rounding.
        actual=y0+truth
        err=(prior-actual).double()
        def change(d):
            return 2*jointdot(err,d)+jointdot(d,d)
        additivity=float(abs(change((md+cp).double())-change(md.double())-change(cp.double()))/
                         jointdot(err,err))
        assert additivity<1e-5
        out["cases"][src]=dict(metrics=metrics,probe_ids=ids[p].tolist(),query=len(test),edges=len(i),
            probe_edges=len(ed),perp_amplitude=alpha[0],full_amplitude=af[0],subspace_leak=leak,
            corrections_joint_cos=cos,additive_loss_defect_relative=additivity,
            probe_dense_vs_archived_rel=float((obs-y0[p]-truth[p]).norm()/truth[p].norm()))
        print(expert,src, {k:round(vv["objective"],5) for k,vv in metrics.items()},flush=True)
    return out


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("expert",choices=("high","low"))
    args=parser.parse_args()
    torch.backends.cuda.matmul.allow_tf32=False
    torch.set_num_threads(4)
    with torch.inference_mode():
        result=run(args.expert)
    (HERE/("orthogonal_"+args.expert+".json")).write_text(json.dumps(result,indent=1,allow_nan=False))
