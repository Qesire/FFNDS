"""Summarize paired source results; all relative changes use the same static prior."""
import json
from pathlib import Path
from statistics import mean

HERE=Path(__file__).resolve().parent
rows=[]
for expert in ("high","low"):
    data=json.loads((HERE/(expert+".json")).read_bytes())
    for source,z in data["cases"].items():
        m=z["metrics"]
        base=m["prior"]["objective"]
        def pct(*arms):
            return (mean(m[k]["objective"] for k in arms)/base-1)*100
        def avg(arm):
            return pct(arm+"_f0",arm+"_f1")
        row=dict(expert=expert,source=source,prior=base,query=z["query"],edges=z["edges"],
                 teacher64_pct=pct("current64"),teacher64_loo_pct=pct("current64_cal"),
                 early64_pct=pct("early_y64"),shuffle64_pct=pct("early_y64_shuffle"),
                 mixed32_32_pct=avg("mixed_early_y"),current32_pct=avg("current32"),
                 mixed_loo_pct=avg("mixed_early_y_cal"),current32_loo_pct=avg("current32_cal"),
                 early_alignment_cos=z["pseudo_label_check"]["early_y"]["cos"],
                 early_input_cos=z["pseudo_label_check"]["early_u"]["cos"],
                 signed_gain_on_target=z["pseudo_label_check"]["early_y"]["signed_gain"],
                 early_full512_direct_pct=pct("all512_early_y_direct"),
                 mixed_loo_increment_pct_prior=avg("mixed_early_y_cal")-avg("current32_cal"))
        for metric in ("common_relative","edge_relative","median_signed_edge_scale","directional_angle_median_deg"):
            row[metric]={arm:m[arm][metric] for arm in ("prior","current64","current64_cal","early_y64","early_y64_shuffle")}
        rows.append(row)
        print(expert,source,*(f"{row[x]:.4f}" for x in ("teacher64_pct","teacher64_loo_pct","early64_pct",
                   "shuffle64_pct","mixed32_32_pct","mixed_loo_pct","mixed_loo_increment_pct_prior","early_alignment_cos")))
(HERE/"summary.json").write_text(json.dumps(rows,indent=1,allow_nan=False))
