"""Apply frozen CAL shrinkage without the deteriorating full current map (exploratory follow-up)."""
import json
import numpy as np
import torch

import full_output as broad


def run():
    prior = broad.prior
    path = prior.ROOT / "BINDINGS.json"
    assert prior.fixed.digest(path) == "8f7320c61dbafd44df0b1662235405de8961dd5c5d52d846c979fdb4179b1ab6"
    binding = json.loads(path.read_text())
    full = json.loads((broad.HERE/"full_output.json").read_text())
    alpha = full["alpha_selection"]["alpha"]
    cal,dev = broad.CAL, tuple(binding["dev_sources"])
    high,_ = prior.snapshot("high",binding,cal+dev)
    torch.cuda.empty_cache()
    low,v = prior.snapshot("low",binding,cal+dev)
    for s in cal+dev:
        assert all(np.array_equal(high[s][k],low[s][k]) for k in ("q","i","j","ids","coords"))
    rows = broad.calibration_rows(low,high,v)
    model = broad.learn(rows,cal)["early_g"]
    del rows
    mean = torch.stack([low[s]["gain"][64] for s in cal]).mean(0)
    report=dict(cal=list(cal),dev=list(dev),alpha=alpha,parent_sha=prior.fixed.digest(broad.HERE/"full_output.json"),
                frozen_before_followup="CAL direction, CAL scaling and CAL mean-gain prior. Baselines chosen after examining primary DEV.",
                cases={})
    for s in dev:
        h,d = high[s],low[s]
        early = h["Q"].double()*h["gain"][64]
        subtraction = d["Q"].double()@model["partialize"]
        extend = model["conditional"]
        fields = dict(none=torch.zeros_like(d["base"]),matched=alpha*((early-subtraction)@extend),
                      shuffled=alpha*((early[prior.permute_in_frame(h)]-subtraction)@extend))
        arms = {}
        for key,gain in (("unit",torch.ones_like(mean)),("calmean",mean)):
            for name,f in fields.items():
                arms[key+"_"+name]={n:broad.evaluate(d,v,f,n,gain) for n in (0,16,64)}
        for n in (0,16,64):
            old=full["cases"][s]["arms"]["base"][str(n)]["objective"]
            assert abs(arms["unit_none"][n]["objective"]-old)<1e-6
        report["cases"][s] = arms
    return report


if __name__=="__main__":
    torch.set_num_threads(4)
    torch.backends.cuda.matmul.allow_tf32=False
    with torch.inference_mode():
        report = run()
    (broad.HERE/"history_conditional.json").write_text(json.dumps(report,indent=2,allow_nan=False),encoding="utf8")
