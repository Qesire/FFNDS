"""Causal high step-1 observations for layer-19 low step-3 recovery on native HHLL panels."""
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
sys.path.insert(0, str(WORK / "joint-readout-1120"))
import online

fixed = online.fixed
ROOT = WORK / "native-inputs"
SOURCES = fixed.CAL + fixed.DEV


def coordinates(ids, coords):
    _, p, q, edges = fixed.make_queries(ids, coords)
    i, j = np.unique(np.sort(edges, axis=1), axis=0).T.copy()
    dy, dx = (coords[j, 1:] - coords[i, 1:]).T
    flip = np.where(abs(dx) >= abs(dy), dx, dy) < 0
    i[flip], j[flip] = j[flip], i[flip].copy()
    probes, probe_edges = {}, {}
    for count in (16, 64):
        rows = p.reshape(4, 16)[:, :count // 4].flatten()
        row_index = {row: z for z, row in enumerate(rows)}
        pe = online.probe_edges(rows, coords, ids)
        probes[count] = rows
        probe_edges[count] = np.asarray([(row_index[a], row_index[b]) for a, b in pe],
                                        dtype=np.int64).reshape(-1, 2)
    return q, i, j, probes, probe_edges


def snapshot(expert, bindings, sources=SOURCES):
    rows = {r["source"]: r for r in bindings["pairs"] if r["expert"] == expert and r["layer"] == 19}
    ws = fixed.load_weights(ROOT, expert, bindings["sites"][expert + "19"])
    w1, b1, w2, b2 = ws
    num = torch.zeros(len(w1), device="cuda", dtype=torch.float64)
    den = torch.zeros_like(num)
    for name in fixed.CAL:
        dz, dh, _, _ = fixed.operands(ROOT, rows[name], ws)
        num += (dh.double() * dz).mean(0)
        den += dz.double().square().mean(0)
    beta = (num / den.clamp_min(1e-30)).float()
    receipt = json.loads((WORK / "compiled" / (expert + ".json")).read_text())
    sel = torch.tensor(receipt["selected_ids"], device="cuda")
    assert fixed.thash(sel) == receipt["selected_sha256"] and fixed.thash(beta) == receipt["beta_sha256"]
    cal = [fixed.data(ROOT, rows[name], ws, beta, sel) for name in fixed.CAL]
    scale = torch.stack([x["z"][x["q"]].square().mean(0) for x in cal]).mean(0).sqrt().clamp_min(1e-8)
    left, right, _ = fixed.fit(cal, scale, gamma=1)
    del cal
    sigma = right.norm(dim=1)
    v = right / sigma[:, None]
    assert (v @ v.T - torch.eye(fixed.RANK, device="cuda")).abs().max() < 5e-5
    zmap = left * sigma
    jmap = (w1[sel].T * beta[sel]) @ zmap
    omitted = beta.clone()
    omitted[sel] = 0
    A0 = ((w1.T * omitted) @ w2.T).bfloat16()
    b = w2[:, sel].T.contiguous()
    W1, B1, W2, B2 = [p.bfloat16() for p in ws]

    def hidden(u, weight, bias):
        return F.gelu(F.linear(u, weight, bias), approximate="tanh")

    cache = {}
    expected = (0, 1) if expert == "high" else (2, 3)
    for name in sources:
        a, h = [fixed.panel(ROOT, rows[name][k]) for k in ("anchor", "hit")]
        for pair, step in zip((a, h), expected):
            m = pair["metadata"]
            assert (m["source"], m["seed"], m["layer"], m["expert"], m["step"], m["timestep"]) == (
                name, 42, 19, expert, step, bindings["schedule"][step]["timestep"])
        assert all(torch.equal(a[k], h[k]) for k in ("token_indices", "token_thw"))
        ids, coords = h["token_indices"].numpy(), h["token_thw"].numpy()
        q, i, j, p, ed = coordinates(ids, coords)
        u0, u1 = a["U"].cuda(), h["U"].cuda()
        y0 = a["Y_pre_gate"].cuda().float()
        h0 = hidden(u0, W1, B1)[:, sel]
        hk = hidden(u1, W1[sel], B1[sel])
        dh = (hk.float() - h0.float()).bfloat16().float()
        du = u1.float() - u0.float()
        base = y0 + (du.bfloat16() @ A0).float() + dh @ b
        Q = dh @ zmap - du @ jmap
        obs, gain = {}, {}
        for n in (16, 64):
            obs_y = F.linear(hidden(u1[p[n]], W1, B1), W2, B2).float()
            obs[n] = (obs_y - base[p[n]]).double() @ v.double().T
            gain[n], _ = online.coefficients(Q[p[n]].double(), obs[n], ed[n], True)
        d = dict(ids=ids, coords=coords, q=q, i=i, j=j, p=p, ed=ed, Q=Q, obs=obs, gain=gain,
                 token_sha=h["metadata"]["token_id_sha256_le_int64"])
        if expert == "low":
            native = h["Y_pre_gate"].cuda().float()
            d.update(base=base, y0=y0, truth=native-y0)
            if name in fixed.CAL:
                d["Y"] = (native - base).double() @ v.double().T - Q.double()
        cache[name] = d
    return cache, v


def joint_stack(mats, low):
    rows = []
    for name in fixed.CAL:
        m, d = mats[name].double(), low[name]
        q, i, j = d["q"], d["i"], d["j"]
        rows.extend((m[q] / np.sqrt(len(q)*len(fixed.CAL)),
                     (m[j]-m[i]) / np.sqrt(len(i)*len(fixed.CAL))))
    return torch.cat(rows)


def regressor(features, low):
    X = joint_stack(features, low)
    Y = joint_stack({s: low[s]["Y"] for s in fixed.CAL}, low)
    scale = X.square().sum(0).sqrt().clamp_min(1e-12)
    A = X / scale
    gram, rhs = A.T @ A, A.T @ Y
    lam = .1 * gram.diagonal().mean()
    system = gram + lam * torch.eye(gram.shape[0], device="cuda", dtype=gram.dtype)
    coef = torch.linalg.solve(system, rhs)
    defect = (system @ coef - rhs).norm() / rhs.norm()
    assert defect < 1e-12
    return coef / scale[:, None], dict(ridge=float(lam), dim=len(coef), relative_normal_residual=float(defect))


def gain_transfer(high, low):
    a, b = [torch.stack([d[s]["gain"][64] for s in fixed.CAL]) for d in (high, low)]
    x, y = a - a.mean(0), b - b.mean(0)
    gram = x @ x.T
    lam = .1 * gram.diagonal().mean()
    t = x.T @ torch.linalg.solve(gram + lam * torch.eye(len(a), device="cuda", dtype=a.dtype), y)
    return a.mean(0), b.mean(0), t, dict(rank=int(torch.linalg.matrix_rank(x)), ridge=float(lam))


def permute_in_frame(d):
    perm = np.arange(len(d["ids"]))
    for frame in np.unique(d["coords"][:, 0]):
        ix = np.flatnonzero(d["coords"][:, 0] == frame)
        ix = ix[np.argsort(d["ids"][ix])]
        perm[ix] = np.roll(ix, max(1, len(ix)//2))
    return perm


def sparse_innovation(d, shuffled=False):
    # Non-tuned four-nearest IDW in fractional grid coordinates, exact at measured rows.
    p = d["p"][64]
    coords = d["coords"].astype(np.float64) / np.array([20, 28, 51])
    sq = np.square(coords[:, None, :] - coords[p][None, :, :]).sum(2)
    idx = np.argsort(sq, axis=1, kind="stable")[:, :4]
    weights = 1 / np.maximum(np.take_along_axis(sq, idx, axis=1), 1e-30)
    weights /= weights.sum(1, keepdims=True)
    excess = d["obs"][64] - d["Q"][p].double()
    if shuffled:
        excess = excess.roll(17, dims=0)
    return (torch.from_numpy(weights).cuda()[:, :, None] * excess[idx]).sum(1)


def ceiling(d, v, hist, sparse):
    # A panel-specific oracle. Both the target and projectors are pre-final-rounding.
    # Each stack has Frobenius loss equal to mean point error plus mean edge error.
    q, i, j = d["q"], d["i"], d["j"]

    def stack(x):
        return torch.cat((x[q] / np.sqrt(len(q)), (x[j]-x[i]) / np.sqrt(len(i))))

    V = torch.linalg.qr(v.double().T, mode="reduced").Q
    R = stack(d["truth"].double() - (d["base"].double()-d["y0"].double()) - d["Q"].double() @ v.double())
    total = R.square().sum()
    current = torch.linalg.qr(stack(d["Q"].double()), mode="reduced").Q
    upper = {"structural_J":float(total), "only_low_output16":float((R @ V).square().sum()/total)}
    for name, x in (("high_Q", hist), ("high_sparse_innovation", sparse)):
        X = stack(x)
        for residualize in (False, True):
            Z = X - current @ (current.T @ X) if residualize else X
            u, sigma, _ = torch.linalg.svd(Z, full_matrices=False)
            rank = int((sigma > max(Z.shape)*torch.finfo(Z.dtype).eps*sigma.max()).sum())
            corr = u[:, :rank].T @ R
            upper[name + ("_given_current" if residualize else "")] = dict(
                rank=rank, free_output=float(corr.square().sum()/total),
                low_output16=float((corr@V).square().sum()/total))
    return upper


def evaluate(d, v, correction, prior, count):
    Q = d["Q"]
    if count:
        p = d["p"][count]
        coef, support = online.coefficients(Q[p].double(), d["obs"][count]-correction[p],
                                            d["ed"][count], True)
        gain = torch.where(support > 0, coef + (prior-1)/2, prior)
    else:
        gain = prior
    observed = (d["base"] + (Q*gain.float() + correction.float()) @ v).bfloat16().float() - d["y0"]
    return fixed.metrics(observed, d["truth"], d["q"], d["i"], d["j"])


def run():
    path = ROOT / "BINDINGS.json"
    assert fixed.digest(path) == "8f7320c61dbafd44df0b1662235405de8961dd5c5d52d846c979fdb4179b1ab6"
    bindings = json.loads(path.read_text())
    high, _ = snapshot("high", bindings)
    torch.cuda.empty_cache()
    low, v = snapshot("low", bindings)
    for s in SOURCES:
        for k in ("coords", "ids", "q", "i", "j"):
            assert np.array_equal(high[s][k], low[s][k])
        assert all(np.array_equal(high[s]["p"][n], low[s]["p"][n]) for n in (16, 64))
    obs = {s: high[s]["Q"].double()*high[s]["gain"][64] for s in SOURCES}
    sparse = {s:sparse_innovation(high[s]) for s in SOURCES}
    features = {
        "current_matrix": {s: low[s]["Q"].double() for s in SOURCES},
        "history_static": {s: high[s]["Q"].double() for s in SOURCES},
        "history_obs64": obs,
        "current_and_history_static": {s: torch.cat((low[s]["Q"].double(),high[s]["Q"].double()),1) for s in SOURCES},
        "current_and_history_obs64": {s: torch.cat((low[s]["Q"].double(),obs[s]),1) for s in SOURCES},
        "sparse_early_innovation": sparse,
    }
    maps, stats = {}, {}
    for method, f in features.items():
        maps[method], stats[method] = regressor(f, low)
    mean_early, mean_late, gain_map, gain_stats = gain_transfer(high, low)
    report = dict(binding_sha256=fixed.digest(path), cal=list(fixed.CAL), dev=list(fixed.DEV), seed=42,
                  schedule=bindings["schedule"], site="layer19; high 0->1; dense reset low 2->3",
                  pytorch=str(torch.__version__), ridge_stats=stats, gain_map=gain_stats, cases={})
    ref = json.loads((WORK / "joint-readout-1120" / "online_low.json").read_text())["cases"]
    for name in fixed.DEV:
        d = low[name]
        zero = torch.zeros_like(obs[name])
        one = torch.ones_like(mean_late)
        probeid = {n:d["ids"][p].tolist() for n,p in d["p"].items()}
        out = dict(probes=probeid, query=len(d["q"]), edges=len(d["i"]), token_ids_sha=d["token_sha"], arms={})
        cases = {"current": (zero,one), "cal_mean_gain": (zero,mean_late)}
        for k in features:
            cases[k] = (features[k][name] @ maps[k],one)
        hist = high[name]
        out["descriptive_query_oracle"] = ceiling(d, v, obs[name], sparse[name])
        cases["sparse_early_innovation_shuffled"] = (
            sparse_innovation(hist,shuffled=True) @ maps["sparse_early_innovation"],one)
        perm = permute_in_frame(hist)
        cases["history_obs64_within_frame_permuted"] = (obs[name][perm] @ maps["history_obs64"],one)
        cases["mean_early_gain_current_rows"] = ((hist["Q"].double()*mean_early) @ maps["history_obs64"],one)
        cases["early16_with_map_fit_at64"] = ((hist["Q"].double()*hist["gain"][16]) @ maps["history_obs64"],one)
        cases["gain_prior_from_early64"] = (zero, mean_late+(hist["gain"][64]-mean_early)@gain_map)
        others = [s for s in fixed.DEV if s != name]
        out["wrong_gain_sources"] = others
        for z, other in enumerate(others):
            wrong = high[other]["gain"][64]
            cases["wrong_early_gain_"+str(z)] = ((hist["Q"].double()*wrong) @ maps["history_obs64"],one)
            cases["wrong_gain_prior_"+str(z)] = (zero,mean_late+(wrong-mean_early)@gain_map)
        for method, (correction, prior) in cases.items():
            out["arms"][method] = {n:evaluate(d, v, correction, prior, n) for n in (0,16,64)}
        for count, baseline in ((0, "prior"), (64, "online_joint")):
            old, new = ref[name]["metrics"][baseline], out["arms"]["current"][count]
            assert abs(old["objective"]-new["objective"])/old["objective"] < 2e-5, (name,count,old,new)
        print(name, {k:round(a[64]["objective"],3) for k,a in out["arms"].items()},flush=True)
        report["cases"][name] = out
    return report


if __name__ == "__main__":
    torch.set_num_threads(4)
    torch.backends.cuda.matmul.allow_tf32 = False
    with torch.inference_mode():
        report = run()
    (HERE / "results.json").write_text(json.dumps(report, indent=2, allow_nan=False),encoding="utf8")
