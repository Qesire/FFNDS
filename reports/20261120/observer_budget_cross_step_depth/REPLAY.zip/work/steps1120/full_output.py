"""Test whether a CAL-only history map can generalize outside the low expert's 16 directions."""
import json
from pathlib import Path

import numpy as np
import torch

import replay as prior

HERE = Path(__file__).resolve().parent
CAL = prior.fixed.CAL


def stack(rows, data):
    q, i, j = data["q"], data["i"], data["j"]
    return torch.cat((rows[q] / np.sqrt(len(q)), (rows[j]-rows[i]) / np.sqrt(len(i))))


def ridge(x, y):
    scale = x.square().sum(0).sqrt().clamp_min(1e-15)
    z = x / scale
    gram = z.T @ z
    system = gram + .1 * gram.diagonal().mean() * torch.eye(len(scale), dtype=x.dtype, device=x.device)
    rhs = z.T @ y
    t = torch.linalg.solve(system, rhs)
    assert (system @ t-rhs).norm() < 1e-10 * rhs.norm()
    return t / scale[:,None]


def calibration_rows(d, high, v):
    rows = {}
    for s in CAL:
        x = d[s]["Q"].double()
        h = high[s]["Q"].double()
        native_residual = d[s]["truth"].double() - (d[s]["base"].double()-d[s]["y0"].double()) - x @ v.double()
        rows[s] = {key:stack(val, d[s]) for key,val in (
            ("y",native_residual), ("low", x), ("early_g", h*high[s]["gain"][64]),
            ("early_q", h), ("current_nonlinear",x*x.abs()))}
    return rows


def learn(rows, names):
    y, x = [torch.cat([rows[s][k] for s in names]) for k in ("y","low")]
    current = ridge(x, y)
    residual = y-x@current
    xtx = x.T@x
    maps = {"current":current}
    for key in ("early_g","early_q","current_nonlinear"):
        f = torch.cat([rows[s][key] for s in names])
        # Exact partial regression in the CAL point-plus-edge inner product.
        align = torch.linalg.solve(xtx, x.T@f)
        z = f-x@align
        assert (x.T@z).norm()/(x.norm()*z.norm()) < 1e-11
        maps[key] = dict(partialize=align, conditional=ridge(z,residual), standalone=ridge(f,y))
    return maps


def shrinkage(rows):
    folds = {}
    num = den = 0.0
    for held in CAL:
        model = learn(rows,[s for s in CAL if s != held])
        x, f, y = [rows[held][k] for k in ("low","early_g","y")]
        target = y - x@model["current"]
        shift = (f-x@model["early_g"]["partialize"])@model["early_g"]["conditional"]
        dot = float((shift*target).sum())
        energy = float(shift.square().sum())
        num += dot
        den += energy
        folds[held] = dict(cross=dot, energy=energy, unrestricted_alpha=dot/energy)
    return dict(folds=folds, unrestricted_alpha=num/den, alpha=float(np.clip(num/den,0,1)))


def evaluate(d, v, correction, count, prior_gain=None):
    if prior_gain is None:
        prior_gain = torch.ones(v.shape[0],dtype=torch.float64,device=v.device)
    gain = prior_gain
    if count:
        p = d["p"][count]
        observed = d["obs"][count]-correction[p].double()@v.double().T
        fitted, support = prior.online.coefficients(d["Q"][p].double(),observed,d["ed"][count],True)
        gain = torch.where(support>0,fitted+(prior_gain-1)/2,prior_gain)
    absolute = d["base"]+(d["Q"]*gain.float())@v+correction.float()
    return prior.fixed.metrics(absolute.bfloat16().float()-d["y0"],d["truth"],d["q"],d["i"],d["j"])


def run():
    bindings_path = prior.ROOT/"BINDINGS.json"
    assert prior.fixed.digest(bindings_path)=="8f7320c61dbafd44df0b1662235405de8961dd5c5d52d846c979fdb4179b1ab6"
    binding = json.loads(bindings_path.read_text())
    dev = tuple(binding["dev_sources"])
    assert len(dev)==11 and not (set(dev)&set(CAL))
    high,_ = prior.snapshot("high",binding,CAL+dev)
    torch.cuda.empty_cache()
    low,v = prior.snapshot("low",binding,CAL+dev)
    for s in CAL+dev:
        assert all(np.array_equal(high[s][k],low[s][k]) for k in ("q","i","j","ids","coords"))
    train = calibration_rows(low,high,v)
    calibration = shrinkage(train)
    model = learn(train,CAL)
    del train
    ref = json.loads((HERE/"results.json").read_text())["cases"]
    report = dict(binding_sha=prior.fixed.digest(bindings_path),cal=list(CAL),dev=list(dev),
                  original_dev=list(prior.fixed.DEV),new_dev=[s for s in dev if s not in prior.fixed.DEV],
                  site="Seed42, layer 19. High 0->1 to low 2->3, dense teacher endpoints.",ridge=.1,
                  alpha_selection=calibration,torch=str(torch.__version__),cases={})
    for s in dev:
        d,h = low[s],high[s]
        hq,lq = h["Q"].double(),d["Q"].double()
        hg = hq*h["gain"][64]
        perm = prior.permute_in_frame(h)
        current = lq@model["current"]
        early = model["early_g"]
        partial,readout = early["partialize"],early["conditional"]
        add = (hg-lq@partial)@readout
        other = next(other for other in dev if other != s)
        alt = hg[perm]
        control = model["current_nonlinear"]
        corr = {
            "base":torch.zeros_like(current),"current16":current,
            "early_static16":hq@model["early_q"]["standalone"],"early_obs16":hg@early["standalone"],
            "early_obs16_shuffle":alt@early["standalone"],
            "current_plus_early":current+add,
            "current_plus_early_shrunk":current+calibration["alpha"]*add,
            "current_plus_early_shuffle":current+(alt-lq@partial)@readout,
            "current_plus_early_wronggain":current+(hq*high[other]["gain"][64]-lq@partial)@readout,
            "current_plus_current_nonlinear":current+(lq*lq.abs()-lq@control["partialize"])@control["conditional"],
        }
        out=dict(query=len(d["q"]),edges=len(d["i"]),token_sha256=d["token_sha"],wrong_gain_source=other,
                 actual_probe_rowids={str(n):d["ids"][d["p"][n]].tolist() for n in (16,64)},arms={})
        for key,val in corr.items():
            out["arms"][key]={n:evaluate(d,v,val,n) for n in (0,16,64)}
        if s in ref:
            for n in (0,16,64):
                old=ref[s]["arms"]["current"][str(n)]["objective"]
                assert abs(out["arms"]["base"][n]["objective"]-old)/old<2e-5
        report["cases"][s]=out
        print(s,{k:round(val[64]["objective"],4) for k,val in out["arms"].items()},flush=True)
    return report


if __name__=="__main__":
    torch.set_num_threads(4)
    torch.backends.cuda.matmul.allow_tf32=False
    with torch.inference_mode():
        report=run()
    (HERE/"full_output.json").write_text(json.dumps(report,indent=2,allow_nan=False),encoding="utf8")
