"""Frozen follow-up on the other eight DEV sources, with original three reported separately."""
import json
import sys
import numpy as np
import torch
import torch.nn.functional as F
from kernel_study import HERE, WORK, fixed, online, budget, features, joint_weights
from roi import region_masks


def integrated_order(k, pool, edges):
    # Point + same-frame difference evaluation on the unlabeled candidate pool.
    cov=k[pool][:,pool].double().cpu().numpy()
    chosen=np.zeros(len(pool),dtype=bool)
    order=[]
    for _ in range(128):
        en=(cov*cov).mean(0)+((cov[edges[:,1]]-cov[edges[:,0]])**2).mean(0)
        score=en/(1+cov.diagonal())
        score[chosen]=-np.inf
        j=int(np.argmax(score))
        chosen[j]=True
        order.append(j)
        c=cov[:,j]/np.sqrt(1+cov[j,j])
        cov=cov-np.outer(c,c)
    return pool[order]


def main(expert):
    root=WORK/"native-inputs"
    rows,m,meta=budget.setup(root,expert)
    pairs=[features(root,rows[s],m) for s in fixed.CAL]
    num=sum((dz.double()*dh).mean(0) for dz,dh in pairs)
    den=sum(dz.double().square().mean(0) for dz,_ in pairs)
    beta=(num/den.clamp_min(1e-30)).float()
    scale=torch.stack([(dh-dz*beta).square().mean(0) for dz,dh in pairs]).mean(0).sqrt().clamp_min(1e-8)
    del pairs
    manifest=json.loads((root/"BINDINGS.json").read_bytes())
    out=dict(expert=expert,cal=fixed.CAL,dev=manifest["dev_sources"],original_dev=fixed.DEV,
             seed=1120,probe_budgets=[32,64,128],fractions=[.5],results=[])
    for name in manifest["dev_sources"]:
        ids,coords,base,q,y0,truth,observe=budget.panel(root,rows[name],m)
        a,h=[fixed.panel(root,rows[name][key]) for key in ("anchor","hit")]
        gate=h["gate"].reshape(-1).cuda().float()
        u0,u1=a["U"].cuda(),h["U"].cuda()
        hidden=lambda x,w,b:F.gelu(F.linear(x,w,b),approximate="tanh")
        h0=hidden(u0,m["w1"],m["b1"])
        x=features(root,rows[name],m,beta,scale)
        kernel=x@x.T/x.shape[1]
        v=m["v"]
        prior=base+q@v
        regions=region_masks(name,coords)
        for fold,(pool,test) in enumerate(budget.split_panel(ids)):
            graph=budget.edge_indices(test,coords,ids)
            state=budget.eval_cache(truth[test],graph,gate)
            def score(y):
                return budget.metrics(y.bfloat16().float()-y0[test],state)
            designs={"uniform":budget.layout(pool,ids,coords,1120,"uniform"),
                     "integrated":integrated_order(kernel,pool,budget.edge_indices(pool,coords,ids))}
            for design,order in designs.items():
                for n in (32,64,128):
                    p=order[:n]
                    edges=budget.edge_indices(p,coords,ids)
                    hp=hidden(u1[p],m["w1"],m["b1"])
                    observed=F.linear(hp,m["w2"],m["b2"]).float()
                    gp,_=online.coefficients(q[p].double(),(observed-base[p]).double()@v.double().T,edges,True)
                    gain=(2*gp-1).float()
                    def diag(index):
                        return base[index]+(q[index]*gain)@v
                    weights=joint_weights(kernel,p,test,[])
                    innovation=observed-diag(p)
                    delta=weights@innovation
                    scores=dict(static=score(prior[test]),diag_full=score(diag(test)),
                                point_kernel=score(prior[test]+weights@(observed-prior[p])),
                                mix=score(diag(test)+.5*delta))
                    if n==64:
                        idx=(hp.float()-h0[p].float()).square().mean(0).topk(5120).indices
                        act=(hidden(u1[test],m["w1"][idx],m["b1"][idx]).float()-h0[test][:,idx].float()).bfloat16()
                        p64=y0[test]+F.linear(act.float(),m["w2"][:,idx].float())
                        scores["P64_5120"]=score(p64)
                        shuffle=np.random.default_rng(7783).permutation(n)
                        scores["mix_shuffled"]=score(diag(test)+.5*(weights@innovation[shuffle]))
                    roi={}
                    for label,mask in regions.items():
                        members=mask[test][graph]
                        incident=members.any(1)
                        rec=dict(probed=int(mask[p].sum()),pool=int(mask[pool].sum()),held=int(mask[test].sum()),
                                 held_internal_edges=int(members.all(1).sum()),held_incident_edges=int(incident.sum()))
                        if incident.any() and n==64:
                            u,w=graph[incident].T
                            target=(truth[test][w]-truth[test][u])*gate
                            for arm,hit in (("diag_full",diag(test)),("mix",diag(test)+.5*delta)):
                                y=hit.bfloat16().float()-y0[test]
                                delta_y=(y[w]-y[u])*gate
                                rec[arm]=dict(signed_scale=float(torch.median((target*delta_y).sum(1)/target.square().sum(1))),
                                              angle_deg=float(torch.median(F.cosine_similarity(target,delta_y).clamp(-1,1).acos().rad2deg())))
                        roi[label]=rec
                    out["results"].append(dict(source=name,fold=fold,p=n,design=design,ids=ids[p].tolist(),metrics=scores,regions=roi))
        print(expert,name,flush=True)
    (HERE/(expert+"_extra.json")).write_text(json.dumps(out,indent=1,allow_nan=False))


if __name__=="__main__":
    torch.backends.cuda.matmul.allow_tf32=False
    torch.set_num_threads(3)
    with torch.inference_mode():
        main(sys.argv[1])
