import json
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
raw={e:json.loads((HERE/(e+"_extra.json")).read_bytes()) for e in ("high","low")}


def compare(p, group, method, base, design="uniform", base_design=None):
    rows=[]
    for expert,d in raw.items():
        for source in d["dev"]:
            if (source in d["original_dev"]) != (group=="first3"):
                continue
            matched=[]
            for fold in range(2):
                def entry(arm,layout):
                    return next(z["metrics"][arm] for z in d["results"] if (z["source"],z["fold"],z["p"],z["design"])==(source,fold,p,layout))
                a,b=entry(method,design),entry(base,base_design or design)
                keys=("J","point","edge","gated_angle","gated_signed_scale","orthogonal_difference","common_gain","difference_gain")
                matched.append({k:100*(a[k]/b[k]-1) if k in ("J","point","edge") else a[k]-b[k] for k in keys})
            rows.append(dict(site=expert,source=source,**{k:float(np.mean([v[k] for v in matched])) for k in keys}))
    mean={k:float(np.mean([r[k] for r in rows])) for k in keys}
    mean["J_wins"]=sum(r["J"]<0 for r in rows)
    mean["angle_wins"]=sum(r["gated_angle"]<0 for r in rows)
    mean["scale_increases"]=sum(r["gated_signed_scale"]>0 for r in rows)
    return dict(p=p,group=group,method=method,base=base,design=design,base_design=base_design or design,mean=mean,units=rows)


if __name__=="__main__":
    summaries=[]
    for g in ("first3","other8"):
        for p in (32,64,128):
            for method,base in (("mix","diag_full"),("point_kernel","diag_full"),("diag_full","static")):
                summaries.append(compare(p,g,method,base))
            summaries.append(compare(p,g,"mix","mix","integrated","uniform"))
            if p==64:
                for method,base in (("mix","mix_shuffled"),("mix","P64_5120")):
                    summaries.append(compare(p,g,method,base))
    (HERE/"summary.json").write_text(json.dumps(summaries,indent=1))
    for row in summaries:
        if row["group"]=="other8" or row["p"]==64:
            m=row["mean"]
            print(row["group"],row["p"],row["design"],row["method"],row["base"],round(m["J"],3),m["J_wins"],round(m["gated_angle"],3),round(m["gated_signed_scale"],4),round(m["orthogonal_difference"],5))
