"""Current-panel joint residual regression tested on disjoint native token rows."""
import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
sys.path.insert(0, str(WORK / "budget1120"))
import run_budget as budget

fixed = budget.fixed
online = budget.online
BUDGETS = (16, 32, 64, 96, 128, 256)


def features(root, row, m, beta=None, scale=None):
    a,h = [fixed.panel(root, row[k]) for k in ("anchor","hit")]
    s = m["sel"]
    w,b = m["w1"][s],m["b1"][s]
    # Preserve anchor native projection / GELU row, and use the narrow hit projection.
    z0 = F.linear(a["U"].cuda(),m["w1"],m["b1"])[:,s]
    z1 = F.linear(h["U"].cuda(),w,b)
    dz = z1.float()-z0.float()
    da = (F.gelu(z1,approximate="tanh").float()-F.gelu(z0,approximate="tanh").float()).bfloat16().float()
    if beta is None:
        return dz, da
    return (da-dz*beta)/scale


def max_variance_order(k, pool):
    # Greedy conditional variance under scalar noise variance one.
    gram=k[pool][:,pool].double().cpu().numpy()
    residual=np.diag(gram).copy()
    factor=np.zeros_like(gram)
    indices=[]
    for t in range(len(pool)):
        j=int(residual.argmax())
        indices.append(j)
        col=(gram[:,j]-factor[:,:t]@factor[j,:t])/np.sqrt(1+residual[j])
        factor[:,t]=col
        residual-=col**2
        residual[j]=-np.inf
    return pool[indices]


def joint_weights(k, p, test, edges, lam=1):
    dtype=torch.float64
    eye=torch.eye(len(p),device=k.device,dtype=dtype)
    metric=eye.clone()
    if len(edges):
        incidence=eye[edges[:,1]]-eye[edges[:,0]]
        metric += len(p)/len(edges)*(incidence.T@incidence)
    system=k[p][:,p].double()+lam*torch.cholesky_inverse(torch.linalg.cholesky(metric))
    weights=torch.cholesky_solve(k[test][:,p].T.double().contiguous(),torch.linalg.cholesky(system)).T
    assert torch.isfinite(weights).all()
    return weights.float()


def run(expert):
    root=WORK/"native-inputs"
    rows,m,meta=budget.setup(root,expert)
    # Calibrate the new kernel features in native precision, independently of the static rank-16 fit.
    pairs=[features(root,rows[s],m) for s in fixed.CAL]
    numerator=sum((dz.double()*dh).mean(0) for dz,dh in pairs)
    denominator=sum(dz.double().square().mean(0) for dz,_ in pairs)
    beta=(numerator/denominator.clamp_min(1e-30)).float()
    scale=torch.stack([(dh-dz*beta).square().mean(0) for dz,dh in pairs]).mean(0).sqrt().clamp_min(1e-8)
    del pairs
    output=dict(site=expert+"19",method="joint linear kernel, lambda=1, no offset",cal=fixed.CAL,dev=fixed.DEV,
                seeds=[1120,3041],budgets=BUDGETS,meta=meta,results=[],controls=[])
    for name in fixed.DEV:
        ids,coords,base,q,y0,truth,observe=budget.panel(root,rows[name],m)
        v=m["v"]
        prior=base+q@v
        x=features(root,rows[name],m,beta,scale)
        kernel=x@x.T/x.shape[1]
        for fold,(pool,test) in enumerate(budget.split_panel(ids)):
            state=budget.eval_cache(truth[test],budget.edge_indices(test,coords,ids))
            def score(hit):
                return budget.metrics(hit.bfloat16().float()-y0[test],state)
            output["controls"].append(dict(source=name,fold=fold,prior=score(prior[test])))
            designs=[("uniform",seed,budget.layout(pool,ids,coords,seed,"uniform")) for seed in (1120,3041)]
            designs.append(("max_variance",0,max_variance_order(kernel,pool)))
            for design,seed,order in designs:
                for n in BUDGETS:
                    p=order[:n] if n<256 else pool
                    edges=budget.edge_indices(p,coords,ids)
                    observed=observe(p)
                    gains,_=online.coefficients(q[p].double(),(observed-base[p]).double()@v.double().T,edges,True)
                    diag=base[test]+(q[test]*gains.float())@v
                    residual=observed-prior[p]
                    weights=joint_weights(kernel,p,test,edges)
                    correction=weights@residual
                    outside=float((correction-(correction@v.T)@v).square().sum()/correction.square().sum())
                    record=dict(source=name,fold=fold,design=design,seed=seed,p=n,edges=len(edges),
                                diag=score(diag),joint_kernel=score(prior[test]+correction),
                                orthogonal_to_v_fraction=outside)
                    if n==64:
                        shift=np.random.default_rng(7783).permutation(n)
                        assert np.sum(shift==np.arange(n))<=4
                        record["permuted_labels"]=score(prior[test]+weights@residual[shift])
                        record["point_kernel"]=score(prior[test]+joint_weights(kernel,p,test,[])@residual)
                        record["ridge4_kernel"]=score(prior[test]+joint_weights(kernel,p,test,edges,lam=4)@residual)
                    output["results"].append(record)
        print(expert,name,"completed",flush=True)
    return output


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("expert",choices=("high","low"))
    args=p.parse_args()
    torch.set_num_threads(3)
    torch.backends.cuda.matmul.allow_tf32=False
    with torch.inference_mode():
        result=run(args.expert)
    (HERE/(args.expert+".json")).write_text(json.dumps(result,indent=1,allow_nan=False))
