import hashlib
import json
from pathlib import Path
import shutil
import zipfile

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
OUT=WORK.parent/"outputs"
report=OUT/"FFNDS_观测预算与跨步跨层还原.md"
files={}
for pattern in ("budget1120/*","kernel1120/*","depth1120/*","steps1120/*","joint-readout-1120/run.py",
                "joint-readout-1120/online.py","joint-readout-1120/online_low.json",
                "compiled/high.json","compiled/low.json","native_replay.py","native_slopes.py",
                "native-inputs/BINDINGS.json","native-inputs/*19/tensor_manifest.json",
                "track1013/results.npz","track0392/per_frame.csv"):
    for f in WORK.glob(pattern):
        if f.is_file() and f.suffix in {".json",".py",".md",".npz",".csv",".png"}:
            files["work/"+f.relative_to(WORK).as_posix()]=f.read_bytes()
shutil.copyfile(HERE/"observer_budget.png",OUT/"observer_budget.png")
files["observer_budget.png"]=(OUT/"observer_budget.png").read_bytes()
files["REPORT.md"]=report.read_bytes()
files["README.md"]="""# FFNDS 观测预算与跨站点实验

REPORT.md 为主报告。无需权重即可查看 work 下的逐源 JSON 与子实验说明。

复算使用 PyTorch 2.8.0+cu126、NumPy、SciPy。图表另需 Matplotlib。三份 CAL 与 11 份 DEV 仅使用 seed 42。第 19 层原生权重和输入根据 work/native-inputs/BINDINGS.json 取回，将面板放在 work/native-inputs/、两组权重放在其 high19/ 和 low19/ 子目录。第 4 层的 24 份捕获放在 work/depth1120/bank/。下载器需要对原归档的访问权。本包不含原生模型或视频。

从包根目录执行以下命令。对接受 high 参数的命令，再以 low 重做，之后运行对应汇总脚本。

~~~text
python work/budget1120/run_budget.py high
python work/budget1120/complement.py high
python work/budget1120/complement.py high --confirm
python work/kernel1120/kernel_study.py high
python work/kernel1120/extra_sources.py high
python work/depth1120/run.py high
python work/depth1120/orthogonal.py high
python work/depth1120/orthogonal_budget.py high
python work/steps1120/replay.py
python work/steps1120/full_output.py
python work/steps1120/history_conditional.py
python work/budget1120/summarize.py
python work/budget1120/summarize_complement.py
python work/depth1120/summarize.py
python work/depth1120/summarize_budget.py
python work/kernel1120/summary.py
python work/kernel1120/coverage.py
python work/kernel1120/figure.py
~~~

SHA256SUMS 给出本包内容哈希。报告中的观测数按每次命中、每个站点统计。归档光栅位置、教师强制端点误差和自由生成视频是不同的观测对象。
""".encode()
files["SHA256SUMS"]="".join(f"{hashlib.sha256(v).hexdigest()}  {k}\n" for k,v in sorted(files.items())).encode()
target=OUT/"REPLAY.zip"
with zipfile.ZipFile(target,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for name,content in sorted(files.items()):
        z.writestr(name,content)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for f in z.namelist():
        if f.endswith(".py"):
            compile(z.read(f),f,"exec")
        if f.endswith(".json"):
            json.loads(z.read(f))
    for line in z.read("SHA256SUMS").decode().splitlines():
        h,name=line.split("  ",1)
        assert hashlib.sha256(z.read(name)).hexdigest()==h
print(len(files),target.stat().st_size,hashlib.sha256(target.read_bytes()).hexdigest())
