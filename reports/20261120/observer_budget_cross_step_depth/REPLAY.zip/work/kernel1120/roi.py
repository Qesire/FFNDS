"""Map Dense-tracked image boxes to approximate token centers for held-out coverage."""
import csv
from pathlib import Path
import numpy as np

WORK=Path(__file__).resolve().parents[1]


def region_masks(source,coords):
    # Nominal centers on the 832 x 464 grid. Frame 4t is a temporal reference, not a VAE inverse.
    t=4*coords[:,0]
    xy=np.stack((16*coords[:,2]+8,16*coords[:,1]+8),axis=1)
    regions={}
    if source=="vbi_1013":
        z=np.load(WORK/"track1013/results.npz")
        boxes={"image_left_fingers":(426,168,482,213),"image_right_fingers":(488,179,532,220),
               "mouth_and_pipe":(412,110,463,155)}
        for name, box in boxes.items():
            shift=np.full((81,2),np.nan)
            for f in np.unique(t):
                keep=z["Dense_valid"][f] & (z["region"]==name)
                if keep.sum()>=3:
                    shift[f]=np.median(z["Dense_xy"][f,keep]-z["Dense_xy"][0,keep],axis=0)
            regions[name]=(box,shift)
    elif source=="vbi_0392":
        with (WORK/"track0392/per_frame.csv").open() as f:
            dense=[r for r in csv.DictReader(f) if r["support"]=="arm_dense" and r["arm"]=="Dense"]
        for name,box in {"cushion":(645,250,721,300),"shelf":(533,112,624,164)}.items():
            shift=np.full((81,2),np.nan)
            for r in dense:
                if int(r[name+"_count"])>=3:
                    shift[int(r["frame"])]=[float(r[name+"_dense_x"]),float(r[name+"_dense_y"])]
            regions[name]=(box,shift)
    masks={}
    for name,(box,shift) in regions.items():
        centered=xy-shift[t]
        mask=((centered>=np.array(box[:2])) & (centered<np.array(box[2:]))).all(1)
        masks[name]=mask
    if source=="vbi_1013":
        masks["either_hand"]=masks["image_left_fingers"]|masks["image_right_fingers"]
    return masks
