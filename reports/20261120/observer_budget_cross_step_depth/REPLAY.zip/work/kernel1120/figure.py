from pathlib import Path
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from summary import compare

HERE=Path(__file__).resolve().parent
plt.rcParams.update({"font.family":"Microsoft YaHei","axes.spines.top":False,"axes.spines.right":False,
                     "axes.unicode_minus":False,"font.size":10})
fig,axes=plt.subplots(1,2,figsize=(10,3.9),layout="constrained")
p=(32,64,128)
for method,design,label,color in (("diag_full","uniform","16 模态，均匀选点","#6b7280"),
                                  ("mix","uniform","全输出残差，均匀选点","#19647e"),
                                  ("mix","integrated","全输出残差，点与边联合选点","#bc5a26")):
    vals=[]
    for n in p:
        z=compare(n,"other8",method,"static",design)
        vals.append(-z["mean"]["J"])
    axes[0].plot(p,vals,"o-",label=label,color=color,lw=2)
axes[0].set(title="另外八个来源的第 19 层",xlabel="完整 FFN 观测行数",ylabel="相对静态先验的联合误差降幅（%）",xticks=p)
axes[0].legend(frameon=False,fontsize=9)
coverage=json.loads((HERE/"coverage.json").read_bytes())["vbi_1013"]
for key,label,color in (("either_hand","任一手指区","#19647e"),("image_right_fingers","右侧手指区","#bc5a26")):
    r=coverage[key]["no_hit_uniform"]
    axes[1].plot([int(x) for x in r],[100*y for y in r.values()],"o-",lw=2,label=label,color=color)
axes[1].set(title="1013 全视频栅格的均匀抽样",xlabel="均匀、不放回观测行数",ylabel="一次也没采到该区域的概率（%）",ylim=(0,100),xticks=[32,64,128,256])
axes[1].legend(frameon=False,fontsize=9)
for ax in axes:
    ax.grid(axis="y",color="#dddddd",lw=.7)
fig.savefig(HERE/"observer_budget.png",dpi=180,bbox_inches="tight")
