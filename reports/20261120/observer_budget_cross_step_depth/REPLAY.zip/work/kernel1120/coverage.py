import json
import math
import numpy as np
from roi import WORK, region_masks


if __name__=="__main__":
    root=WORK/"kernel1120"
    geo=json.loads((root/"fixed_geometry.json").read_bytes())
    rows=np.arange(geo["N"])
    coords=np.stack(np.unravel_index(rows,(21,29,52)),axis=1)
    p=np.array(geo["probe_ids"])
    out={}
    first_boxes={"vbi_0392":[(645,250,721,300),(533,112,624,164)],
                 "vbi_1013":[(426,168,482,213),(488,179,532,220)]}
    for src in ("vbi_0392","vbi_1013"):
        out[src]={}
        pairs=[]
        for frame in (2,7,12,17):
            for left,top,right,bottom in first_boxes[src]:
                # Two horizontal neighboring centers nearest the initial box midpoint.
                inside=rows[(coords[:,0]==frame)&(coords[:,2]*16+8>=left)&(coords[:,2]*16+24<right)&
                            (coords[:,1]*16+8>=top)&(coords[:,1]*16+8<bottom)]
                distance=((coords[inside,2]*16+16-(left+right)/2)**2+
                          (coords[inside,1]*16+8-(top+bottom)/2)**2)
                idx=inside[distance.argmin()]
                pairs.append([idx,idx+1])
        pair_ids=np.asarray(pairs)
        retained=[int(i) for i in p if i not in set(pair_ids.ravel())][:48]
        alternative=np.asarray(retained+pair_ids.ravel().tolist())
        assert len(set(alternative))==64
        for label,mask in region_masks(src,coords).items():
            size=int(mask.sum())
            out[src][label]=dict(total=len(mask),in_region=size,historical_positions=int(mask[p].sum()),
                                 latent_slices_with_center=int(len(set(coords[mask,0]))),
                                 reserved16_hits=int(mask[alternative].sum()),
                                 reserved16_complete_region_pairs=int(mask[pair_ids].all(1).sum()),
                                 no_hit_uniform={n:math.prod(1-size/(len(mask)-i) for i in range(n)) for n in (32,64,128,256)})
    (root/"coverage.json").write_text(json.dumps(out,indent=1))
    for source,items in out.items():
        print(source,[(k,v["in_region"],v["historical_positions"],round(v["no_hit_uniform"][64],3)) for k,v in items.items()])
