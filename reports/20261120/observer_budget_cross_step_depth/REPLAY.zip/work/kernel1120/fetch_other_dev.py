"""Retrieve the other eight manifest-designated DEV sources for a frozen panel check."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import shlex
import subprocess
import tarfile
import sys

ROOT=Path(__file__).resolve().parents[1]/"native-inputs"
def fetch(session):
    raw=(ROOT/"BINDINGS.json").read_bytes()
    assert hashlib.sha256(raw).hexdigest()=="8f7320c61dbafd44df0b1662235405de8961dd5c5d52d846c979fdb4179b1ab6"
    bindings=json.loads(raw)
    bank=PurePosixPath(bindings["bank_root"])
    missing={}
    for pair in bindings["pairs"]:
        if pair["layer"]!=19 or pair["source"] not in bindings["dev_sources"]:
            continue
        for ref in (pair["hit"],pair["anchor"]):
            remote=PurePosixPath(ref["path"])
            local=ROOT/remote.name
            if not local.is_file() or hashlib.sha256(local.read_bytes()).hexdigest()!=ref["sha256"]:
                missing[str(remote.relative_to(bank))]=ref
    if not missing:
        return
    cmd=shlex.join(["tar","-C",str(bank),"-cf","-",*missing])
    proc=subprocess.Popen([r"C:\Program Files\PuTTY\plink.exe","-batch","-T","-load",session,cmd],stdout=subprocess.PIPE)
    with proc.stdout,tarfile.open(fileobj=proc.stdout,mode="r|") as stream:
        for member in stream:
            ref=missing.pop(member.name)
            data=stream.extractfile(member).read()
            assert member.isfile() and len(data)==ref["bytes"] and hashlib.sha256(data).hexdigest()==ref["sha256"]
            (ROOT/Path(member.name).name).write_bytes(data)
    assert proc.wait()==0 and not missing

if __name__=="__main__":
    fetch(sys.argv[1])
